#pragma once
#include "json.hpp"
#include <algorithm>
#include <cctype>
#include <map>
#include <regex>
#include <set>
#include <string>
#include <vector>

namespace AdminSolver {
using json=nlohmann::json;
inline std::string Trim(std::string s){auto white=[](unsigned char c){return std::isspace(c);};while(!s.empty()&&white(s.front()))s.erase(s.begin());while(!s.empty()&&white(s.back()))s.pop_back();return s;}
inline std::string Lower(std::string s){std::transform(s.begin(),s.end(),s.begin(),[](unsigned char c){return char(std::tolower(c));});return s;}
inline std::string Normal(std::string s){s=Lower(s);for(auto& c:s)if(std::isspace(static_cast<unsigned char>(c)))c=' ';return Trim(std::regex_replace(s,std::regex(" +")," "));}
inline bool Match(const std::string& s,const char* pattern){return std::regex_search(s,std::regex(pattern,std::regex::icase));}
inline bool Code(const std::string& s){return std::regex_match(s,std::regex("[A-Za-z0-9][A-Za-z0-9_-]{0,63}"));}
inline std::string Clean(std::string s){s=Trim(s);while(!s.empty()&&(s.front()=='\"'||s.front()=='\''||s.front()=='`'||s.front()==':'))s.erase(s.begin());while(!s.empty()&&(s.back()=='\"'||s.back()=='\''||s.back()=='`'||s.back()=='.'||s.back()=='!'))s.pop_back();return Trim(s);}
inline int Number(const std::string& value){auto s=Lower(value);const std::vector<std::string> words={"zero","one","two","three","four","five","six","seven","eight"};for(size_t i=1;i<words.size();++i)if(s==words[i])return int(i);if(std::regex_match(s,std::regex("[1-8]")))return s[0]-'0';return 0;}
inline int Part(const std::string& text){std::smatch m;auto s=Lower(text);if(std::regex_search(s,m,std::regex(R"(\b(?:part|word|hint|clue)\s*#?\s*([1-8])\b)")))return Number(m[1]);const std::vector<std::string> names={"first","second","third","fourth","fifth","sixth","seventh","eighth"};for(size_t i=0;i<names.size();++i)if(Match(s,("\\b"+names[i]+" (?:part|word|hint|clue)\\b").c_str()))return int(i+1);if(Match(s,R"(\blast (?:part|word|hint|clue)\b)"))return -1;return 0;}
inline bool Poll(const std::string& s){return Match(s,R"(\b(poll|polls|vote|voting|votes|choose between|would you rather)\b)");}
struct Candidate {std::string code,kind,reason;bool complete=false;int round=0;json Public()const{return {{"code",code},{"kind",kind},{"reason",reason},{"complete",complete},{"round",round}};}};
struct Engine {
 bool armed=false,manual=false,autoArm=true,polling=false;int round=0,expected=0,next=1;std::string state="Waiting for a code announcement";
 std::map<int,std::string> parts;std::map<std::string,std::string> facts;json history=json::array(),rules=json::array();std::set<std::string> emitted,messages;std::string lastCode;
 void Arm(bool value,bool byHand=false){armed=value;manual=value&&byHand;polling=false;if(value){++round;parts.clear();expected=0;next=1;emitted.clear();messages.clear();lastCode.clear();state=byHand?"Manually armed · waiting for a code or clue":"Listening for code parts";}else state="Inputting stopped";}
 void Learn(const std::string& text){std::smatch m;if(std::regex_search(text,m,std::regex(R"(\bmy (age|name|favorite color|favourite color|favorite number|favourite number)\s*(?:is|:|=)\s*([A-Za-z0-9_-]{1,40})\b)",std::regex::icase)))facts[Lower(m[1])]=m[2];}
 std::pair<std::string,std::string> Solve(std::string clue,bool explicitLiteral=false){
  auto s=Normal(clue);std::smatch m;
  for(auto& f:facts)if(s=="my "+f.first||s=="his "+f.first||s=="sammy's "+f.first||s=="sammy "+f.first)return {f.second,"From an earlier announcement in this window"};
  if(std::regex_match(s,m,std::regex(R"((?:(?:what is|what's|calculate)\s+)?([0-9]{1,6})\s*([+*x-])\s*([0-9]{1,6})\s*[?=]?)"))){long long a=std::stoll(m[1]),b=std::stoll(m[3]);auto op=m[2].str();auto answer=op=="+"?a+b:op=="-"?a-b:a*b;if(answer>=0&&answer<=999999999)return {std::to_string(answer),"Simple arithmetic"};}
  for(const auto& r:rules){if(!r.is_object()||!r.contains("phrases")||!r.contains("answer")||!r["answer"].is_string())continue;auto answer=r["answer"].get<std::string>();if(!Code(answer))continue;for(const auto& phrase:r["phrases"]){if(!phrase.is_string())continue;auto p=Normal(phrase.get<std::string>());if(!p.empty()&&(s==p||s==p+"?"))return {answer,r.value("reason",std::string("Saved riddle rule"))};}}
  clue=Clean(clue);if(Code(clue)&&(explicitLiteral||!Match(clue,R"(^(the|a|my|his|your|code|codes|part|hint|clue|is|yes|no|ok|okay|wait|ready|guys|lol|hello|hi|sammy|new|next|first|second|third|vote|poll)$)")))return {clue,"Literal code text"};
  return {};
 }
 std::vector<Candidate> Feed(const std::string& raw,long long at){
  std::vector<Candidate> out;auto text=Trim(raw);if(text.empty()||text.size()>3000)return out;
  if(history.size()>=200)history.erase(history.begin());history.push_back({{"at",at},{"text",text}});Learn(text);auto low=Normal(text);
  if(Poll(text)){polling=true;state="Poll detected · logged without typing";return out;}
  const bool mentionsCode=Match(text,R"(\bcodes?\b)");
  if(Match(text,R"(\b(sold out|code expired|code ended|no more codes|no codes|code is fake|cancel the code|cancelled|canceled)\b)")){armed=false;polling=false;state="Code round ended";return out;}
  const bool announcement=mentionsCode&&!Match(text,R"(\b(no|not|later|after|soon|coming|tomorrow|maybe|asking|begging|stop asking)\b)")&&Match(text,R"(\b(code\s*(?:is|:|=|has|contains)|new code|next code|another code|code riddle|riddle.*code|redeem.*code|code.*parts|code.*words)\b|code\s*[:=])");
  const bool reset=announcement&&(!armed||Match(text,R"(\b(new|next|another) code\b)"));
  if(armed&&messages.count(low))return out;
  if(reset&&autoArm)Arm(true);if(!armed){state="Logged · waiting for a code announcement";return out;}
  const bool resume=Match(text,R"(\b(?:back to|continue|resume) (?:the )?code\b)");
  if(polling&&!announcement&&!resume){state="Poll context · waiting for code confirmation";return out;}if(announcement||resume)polling=false;
  messages.insert(low);
  std::smatch count;if(std::regex_search(low,count,std::regex(R"(\b([1-8]|one|two|three|four|five|six|seven|eight)\s+(?:parts|words)\b)")))expected=Number(count[1]);
  if(Match(text,R"(\b(reward|stock|redeems|redemptions|people|players)\b)")&&!Match(text,R"(\b(part|word|hint|clue)\b|code\s*(?:is|:|=))"))return out;
  // Multiple explicitly numbered parts in one banner are processed in order.
  const std::regex segment(R"((?:(?:part|word|hint|clue)\s*#?\s*[1-8]|(?:first|second|third|fourth|fifth|sixth|seventh|eighth|last)\s+(?:part|word|hint|clue))\b)",std::regex::icase);
  std::vector<size_t> starts;for(std::sregex_iterator it(text.begin(),text.end(),segment),end;it!=end;++it)starts.push_back(size_t(it->position()));
  if(starts.empty())starts.push_back(0);
  for(size_t n=0;n<starts.size();++n){auto chunk=Trim(text.substr(starts[n],(n+1<starts.size()?starts[n+1]:text.size())-starts[n]));while(!chunk.empty()&&(chunk.back()==';'||chunk.back()==','))chunk.pop_back();int part=Part(chunk);if(part==-1)part=expected?expected:next;
   bool correction=Match(chunk,R"(\b(actually|correction|instead|replace|not.*but)\b)");std::string clue=chunk;std::smatch m;
   if(part){clue=std::regex_replace(clue,segment,"");clue=std::regex_replace(clue,std::regex(R"(^\s*(?:is|:|=|would be)\s*)",std::regex::icase),"");}
   else if(std::regex_search(chunk,m,std::regex(R"(\b(?:code|answer)\s*(?:is\s+|[:=]\s*)(.+)$)",std::regex::icase))){clue=m[1];if(Match(chunk,R"(\bcode\s*(?:is|:|=))")&&Code(Clean(clue))){parts.clear();next=1;expected=1;}}
   else if(std::regex_search(chunk,m,std::regex(R"(\b(?:append|add|then|next|followed by)\s+["'`]?([A-Za-z0-9_-]{1,40})["'`]?\s*(?:to (?:the )?code|at the end)?[.!]?$)",std::regex::icase))){clue=m[1];part=next;}
   else if(correction){clue=std::regex_replace(clue,std::regex(R"(^\s*(?:actually|correction|instead)\s*[:,]?\s*)",std::regex::icase),"");part=std::max(1,next-1);}
   else if(mentionsCode||Match(chunk,R"(\b(parts|words|riddle|hint|clue|reward|stock)\b)")){state="Waiting for the next clue";continue;}
   auto answer=Solve(clue,part!=0||(mentionsCode&&clue!=chunk)||manual);if(!manual&&!part&&!mentionsCode&&clue==chunk&&answer.second=="Literal code text"&&!Match(clue,R"([0-9])")&&!std::regex_match(clue,std::regex("[A-Z][A-Z0-9_-]+"))){state="Ambiguous text · logged without typing";continue;}if(answer.first.empty()){if(part||Match(clue,R"(\b(what|who|riddle|clue|hint)\b|\?)")){state="Unsolved clue · add a manual answer or a rule";if(!part)part=next;parts[part]="";next=std::max(next,part+1);}continue;}
   bool standalone=part==0&&expected==0&&mentionsCode;if(!part)part=correction?std::max(1,next-1):next;
   parts[part]=answer.first;next=std::max(next,part+1);std::string code;for(int p=1;p<=int(parts.size())+1;++p){auto it=parts.find(p);if(it==parts.end()||it->second.empty())break;code+=it->second;}
   if(!Code(code)){state="Waiting for earlier parts";continue;}bool complete=standalone||(expected>0&&int(parts.size())>=expected&&next>expected&&std::all_of(parts.begin(),parts.end(),[](const auto& p){return !p.second.empty();}));
   auto kind=answer.second=="Literal code text"?(parts.size()>1?"assembled":"literal"):"rule";
   if(emitted.insert(code).second){lastCode=code;out.push_back({code,kind,answer.second,complete,round});}state=complete?"Candidate complete · redemption unverified":"Partial candidate · waiting for more parts";
  }return out;
 }
 json Public()const{json p=json::array();for(const auto& part:parts)p.push_back({{"number",part.first},{"text",part.second}});return {{"armed",armed},{"polling",polling},{"manual",manual},{"round",round},{"expected",expected},{"parts",p},{"candidate",lastCode},{"status",state},{"context",history}};}
};
}
