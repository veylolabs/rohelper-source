#define NOMINMAX
#include "Store.h"
#include "AdminWatch.h"
#include "AdminCapture.h"
#include "AdminSolver.h"
#include "AutomationPlatform.h"
#include <winrt/Windows.Foundation.h>
#include <condition_variable>
#include <deque>
#include <chrono>
#include <iomanip>

namespace AdminWatch {
inline long long Wall(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();}
inline std::string Key(const RosterClients::Client& c){return std::to_string(c.pid)+"|"+c.token;}
inline json Defaults(){return {{"roi",json::array({.06,.105,.94,.19})},{"minimumHeight",0.0},{"intervalMs",500},{"autoArm",true},{"autoSubmit",false},{"calibrated",false},{"openPoint",json::array({.104,.612})},{"fieldPoint",json::array({.5,.48})},{"submitPoint",json::array({.5,.59})}};}
inline json ValidateConfig(const json& patch){auto value=Defaults();if(!patch.is_object())throw std::runtime_error("Invalid watcher settings.");for(const auto& entry:patch.items()){if(!value.contains(entry.key()))throw std::runtime_error("Unknown watcher setting.");value[entry.key()]=entry.value();}
 for(const auto* name:{"autoArm","autoSubmit","calibrated"})if(!value[name].is_boolean())throw std::runtime_error("Invalid watcher switch.");
 for(const auto* name:{"openPoint","fieldPoint","submitPoint","roi"}){auto& a=value[name];if(!a.is_array()||a.size()!=(std::string(name)=="roi"?4:2))throw std::runtime_error("Invalid capture coordinates.");for(const auto& n:a)if(!n.is_number()||!std::isfinite(n.get<double>())||n<0||n>1)throw std::runtime_error("Coordinates must stay within the selected window.");}
 const auto& r=value["roi"];if(r[0]>=r[2]||r[1]>=r[3]||r[2].get<double>()-r[0].get<double>()<.02||r[3].get<double>()-r[1].get<double>()<.015)throw std::runtime_error("The announcement region is too small.");
 if(!value["minimumHeight"].is_number()||value["minimumHeight"]<0||value["minimumHeight"]>.1||!value["intervalMs"].is_number_integer()||value["intervalMs"]<250||value["intervalMs"]>5000)throw std::runtime_error("Invalid scan interval or text height.");return value;
}
struct Manager::Impl {
 struct Command{json value;std::promise<json> result;};
 struct Target {RosterClients::Client client;json config=Defaults();bool enabled=false;std::unique_ptr<AdminCapture::Window> capture;AdminSolver::Engine engine;std::string status="Stopped",lastRead,pendingText,lastLogged,preview;ULONGLONG due=0,pendingAt=0,lastSeen=0,blankAt=0;unsigned samples=0;long long messages=0;};
 std::filesystem::path directory,configFile;bool testMode;std::thread worker;std::mutex mutex;std::condition_variable wake;bool stop=false;std::deque<std::unique_ptr<Command>> commands;std::vector<RosterClients::Client> clients;json summary={{"targets",json::array()}};
 std::map<std::string,Target> targets;json profiles=json::object(),baseRules=json::array(),userRules=json::array(),recent=json::array();std::string storageError;unsigned long long sequence=0;
 Impl(const fs::path& data,const fs::path& rules,bool test):directory(data/L"admin-watch"),configFile(directory/L"settings.json"),testMode(test){
  try{fs::create_directories(directory);if(fs::exists(configFile)){auto saved=json::parse(SafeStorage::Read(configFile));if(saved.value("schema",0)!=1||!saved.at("profiles").is_object()||!saved.at("rules").is_array())throw std::runtime_error("Watcher settings are invalid; original file retained.");profiles=saved["profiles"];userRules=saved["rules"];for(const auto& p:profiles.items())ValidateConfig(p.value());}
   if(fs::exists(rules))baseRules=json::parse(SafeStorage::Read(rules)).at("rules");
   std::vector<fs::path> logs;for(const auto& f:fs::directory_iterator(directory))if(f.path().extension()==L".jsonl")logs.push_back(f.path());std::sort(logs.begin(),logs.end());if(logs.size()>3)logs.erase(logs.begin(),logs.end()-3);
   for(const auto& f:logs){std::ifstream in(f);std::string line;while(std::getline(in,line)){if(line.size()>20000)continue;try{auto row=json::parse(line);if(!row.is_object())continue;recent.push_back(row);if(recent.size()>1000)recent.erase(recent.begin());}catch(...){}}}
  }catch(const std::exception& e){storageError=e.what();}
  worker=std::thread([this]{Run();});
 }
 ~Impl(){{std::lock_guard<std::mutex> lock(mutex);stop=true;}wake.notify_one();if(worker.joinable())worker.join();}
 std::string Profile(const RosterClients::Client& c){return c.userId>0?"account-"+std::to_string(c.userId):"process-"+Key(c);}
 void Save(){if(!storageError.empty())throw std::runtime_error(storageError);SafeStorage::Write(configFile,json{{"schema",1},{"profiles",profiles},{"rules",userRules}}.dump());}
 void Log(const std::string& kind,Target& t,json data){
  if(!storageError.empty())throw std::runtime_error(storageError);
  const auto now=Wall();data.update({{"id",std::to_string(now)+"-"+std::to_string(1000000000ULL+(++sequence))},{"at",now},{"kind",kind},{"stream",Key(t.client)},{"pid",t.client.pid},{"userId",t.client.userId}});
  SYSTEMTIME clock{};GetLocalTime(&clock);char name[32];sprintf_s(name,"%04u-%02u-%02u.jsonl",clock.wYear,clock.wMonth,clock.wDay);auto bytes=data.dump()+"\n";
  RosterClients::Handle file(CreateFileW((directory/name).c_str(),FILE_APPEND_DATA,FILE_SHARE_READ,nullptr,OPEN_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr));DWORD written=0;
  if(file.value==INVALID_HANDLE_VALUE||!WriteFile(file.value,bytes.data(),DWORD(bytes.size()),&written,nullptr)||written!=bytes.size()||!FlushFileBuffers(file.value)){storageError="The announcement log could not be saved. Capture and automatic input are paused.";throw std::runtime_error(storageError);}
  recent.push_back(std::move(data));if(recent.size()>1000)recent.erase(recent.begin());
 }
 Target& Find(const json& request){auto key=std::to_string(request.at("pid").get<DWORD>())+"|"+request.at("token").get<std::string>();auto it=targets.find(key);if(it==targets.end())throw std::runtime_error("This client has closed. Refresh running clients.");return it->second;}
 json TargetState(Target& t){auto engine=t.engine.Public();engine.erase("context");return {{"pid",t.client.pid},{"token",t.client.token},{"userId",t.client.userId},{"enabled",t.enabled},{"config",t.config},{"status",t.status},{"lastRead",t.lastRead},{"lastSeenAt",t.lastSeen},{"messages",t.messages},{"solver",engine}};}
 json State(){json rows=json::array();for(auto& e:targets)rows.push_back(TargetState(e.second));return {{"targets",rows},{"error",storageError},{"rules",userRules},{"ruleCount",baseRules.size()+userRules.size()},{"solver","rules"}};}
 void Sync(){std::vector<RosterClients::Client> list;{std::lock_guard<std::mutex> lock(mutex);list=clients;}std::set<std::string> alive;
  for(const auto& c:list){auto key=Key(c);alive.insert(key);auto found=targets.find(key);if(found==targets.end()){Target t;t.client=c;if(profiles.contains(Profile(c)))t.config=ValidateConfig(profiles[Profile(c)]);t.engine.autoArm=t.config["autoArm"];t.engine.rules=userRules;for(const auto& r:baseRules)t.engine.rules.push_back(r);
    for(const auto& row:recent)if(row.value("kind",std::string())=="message"&&row.value("stream",std::string())==key){t.engine.history.push_back({{"at",row["at"]},{"text",row.value("text",std::string())}});t.engine.Learn(row.value("text",std::string()));++t.messages;}while(t.engine.history.size()>200)t.engine.history.erase(t.engine.history.begin());targets.emplace(key,std::move(t));
   }else found->second.client=c;
  }for(auto it=targets.begin();it!=targets.end();)if(!alive.count(it->first))it=targets.erase(it);else ++it;
 }
 void Accept(Target& t,const std::string& text,const std::string& origin="ocr"){
  Log("message",t,{{"text",text},{"origin",origin}});++t.messages;t.lastLogged=text;auto candidates=t.engine.Feed(text,Wall());
  for(const auto& c:candidates) {auto row=c.Public();row["eligible"]=t.enabled&&t.config["autoSubmit"].get<bool>()&&t.config["calibrated"].get<bool>();Log("candidate",t,row);}
  // UI-thread input broker takes these from the persisted log, serializes all
  // windows, and records the result. OCR itself never presses a key.
 }
 json Handle(const json& request){auto action=request.at("action").get<std::string>();
  if(action=="state")return State();
  if(action=="log"){auto stream=request.value("stream",std::string()),filter=request.value("kind",std::string());auto before=request.value("before",std::string());int limit=std::clamp(request.value("limit",150),1,1000);json rows=json::array();std::vector<fs::path> logs;for(const auto& e:fs::directory_iterator(directory))if(e.path().extension()==L".jsonl")logs.push_back(e.path());std::sort(logs.rbegin(),logs.rend());
   for(const auto& file:logs){std::ifstream in(file);std::string line;std::deque<json> selected;while(std::getline(in,line)){if(line.size()>20000)continue;try{auto r=json::parse(line);auto id=r.value("id",std::string());if((stream.empty()||r.value("stream",std::string())==stream)&&(filter.empty()||r.value("kind",std::string())==filter)&&(before.empty()||id<before)){selected.push_back(std::move(r));if(int(selected.size())>limit)selected.pop_front();}}catch(...){}}
    while(!selected.empty()&&int(rows.size())<limit){rows.push_back(selected.back());selected.pop_back();}if(int(rows.size())>=limit)break;
   }return {{"entries",rows},{"next",rows.empty()?std::string():rows.back().value("id",std::string())}};
  }
  if(action=="rules"||action=="catalog_rules"){auto rules=request.at("rules");if(!rules.is_array()||rules.size()>200)throw std::runtime_error("Use at most 200 local rules.");for(const auto& r:rules){if(!r.is_object()||!r.at("phrases").is_array()||r["phrases"].empty()||r["phrases"].size()>20||!r.at("answer").is_string()||!AdminSolver::Code(r["answer"]))throw std::runtime_error("A rule needs a clue and a code-compatible answer.");for(const auto& p:r["phrases"])if(!p.is_string()||p.get<std::string>().empty()||p.get<std::string>().size()>1000)throw std::runtime_error("Invalid rule clue.");}if(action=="catalog_rules")baseRules=rules;else {auto old=userRules;userRules=rules;try{Save();}catch(...){userRules=old;throw;}}for(auto& e:targets){e.second.engine.rules=userRules;for(const auto& r:baseRules)e.second.engine.rules.push_back(r);}return State();}
  if(action=="stop_inputs"){for(auto& e:targets){e.second.engine.Arm(false);e.second.engine.autoArm=false;e.second.config["autoSubmit"]=false;}return State();}
  auto& t=Find(request);
  if(action=="configure"){auto config=ValidateConfig(request.at("config"));auto old=profiles;profiles[Profile(t.client)]=config;try{Save();}catch(...){profiles=old;throw;}t.config=config;t.engine.autoArm=config["autoArm"];if(!config["autoSubmit"].get<bool>())t.engine.Arm(false);return State();}
  if(action=="enable"){if(!storageError.empty())throw std::runtime_error(storageError);t.enabled=request.at("enabled").get<bool>();t.status=t.enabled?"Starting capture…":"Stopped";if(!t.enabled){t.capture.reset();t.engine.Arm(false);}return State();}
  if(action=="arm"){auto armed=request.at("armed").get<bool>();t.engine.Arm(armed,true);t.engine.autoArm=armed?bool(t.config["autoArm"]):false;Log("control",t,{{"text",armed?"Code round manually started":"Inputting stopped"}});return State();}
  if(action=="manual"){auto text=request.at("text").get<std::string>();if(text.empty()||text.size()>3000)throw std::runtime_error("Enter a message or clue (up to 3,000 characters).");Accept(t,text,"manual");return State();}
  if(action=="input_result"){Log("input",t,{{"code",request.value("code",std::string())},{"text",request.at("text")},{"success",request.value("success",false)}});return State();}
  if(action=="preview"||action=="menu"){if(testMode)throw std::runtime_error("Live capture is disabled in test hosts.");if(!WindowsAutomationPlatform::Valid(t.client))throw std::runtime_error("This client has closed.");if(!t.capture)t.capture=std::make_unique<AdminCapture::Window>(t.client.window);AdminCapture::Image image;for(int i=0;i<10&&image.width==0;++i){image=t.capture->Frame();if(!image.width)Sleep(70);}if(!image.width)throw std::runtime_error("No frame yet. Restore the window and retry.");if(action=="menu"){AdminCapture::Reader reader;auto crop=AdminCapture::Crop(image,.15,.18,.85,.85);auto text=reader.Read(crop,false).text;auto plain=AdminSolver::Lower(text);bool menu=AdminSolver::Match(plain,R"(\bcodes?\b)")&&AdminSolver::Match(plain,R"(\b(redeem|submit|enter)\b)");auto point=t.config["fieldPoint"];auto field=AdminCapture::Crop(image,point[0].get<double>()-.3,point[1].get<double>()-.05,point[0].get<double>()+.3,point[1].get<double>()+.05);auto fieldText=reader.Read(field,false).text;if(!t.enabled)t.capture.reset();return {{"open",menu},{"text",text},{"fieldText",fieldText}};}if(!t.enabled)t.capture.reset();return {{"image",AdminCapture::DataUrl(image)},{"width",image.width},{"height",image.height},{"config",t.config},{"context",t.engine.history}};}
  if(action=="pending"){json result=json::array();for(auto it=recent.rbegin();it!=recent.rend();++it){if(it->value("kind",std::string())=="candidate"&&it->value("stream",std::string())==Key(t.client)&&it->value("at",0LL)>=request.value("since",0LL))result.push_back(*it);if(result.size()>=20)break;}return {{"candidates",result},{"state",TargetState(t)}};}
  throw std::runtime_error("Unknown announcement action.");
 }
 void Run(){try{winrt::init_apartment(winrt::apartment_type::multi_threaded);std::unique_ptr<AdminCapture::Reader> reader;
  for(;;){std::deque<std::unique_ptr<Command>> queue;{std::unique_lock<std::mutex> lock(mutex);wake.wait_for(lock,std::chrono::milliseconds(40),[&]{return stop||!commands.empty();});if(stop)break;queue.swap(commands);}Sync();
   for(auto& c:queue)try{c->result.set_value(Handle(c->value));}catch(const winrt::hresult_error& e){c->result.set_exception(std::make_exception_ptr(std::runtime_error(winrt::to_string(e.message()))));}catch(...){c->result.set_exception(std::current_exception());}
   for(auto& e:targets){auto& t=e.second;auto now=GetTickCount64();if(!t.enabled||now<t.due||!storageError.empty())continue;t.due=now+t.config["intervalMs"].get<unsigned>();
    try{if(testMode)throw std::runtime_error("Live capture is disabled in test hosts.");if(!WindowsAutomationPlatform::Valid(t.client))throw std::runtime_error("This client has closed.");if(!reader)reader=std::make_unique<AdminCapture::Reader>();if(!t.capture)t.capture=std::make_unique<AdminCapture::Window>(t.client.window);auto image=t.capture->Frame();if(!image.width){t.status="Waiting for a fresh window frame";continue;}auto r=t.config["roi"];auto crop=AdminCapture::Crop(image,r[0],r[1],r[2],r[3]);auto text=AdminSolver::Trim(reader->Read(crop,true,image.height*t.config["minimumHeight"].get<double>()).text);t.lastRead=text;t.lastSeen=Wall();t.status="Watching";
     if(text.empty()){if(!t.blankAt)t.blankAt=now;if(now-t.blankAt>=800){t.lastLogged.clear();t.pendingText.clear();t.samples=0;}continue;}t.blankAt=0;
     if(AdminSolver::Normal(text)!=AdminSolver::Normal(t.pendingText)){t.pendingText=text;t.pendingAt=now;t.samples=1;}else ++t.samples;
     if(t.samples>=2&&AdminSolver::Normal(text)!=AdminSolver::Normal(t.lastLogged)){Accept(t,text);}
    }catch(const winrt::hresult_error& error){t.status="Capture unavailable: "+winrt::to_string(error.message());t.due=now+3000;t.capture.reset();}catch(const std::exception& error){t.status=error.what();t.due=now+2000;}
   }
   auto state=State();state["recent"]=recent.size()>100?json(recent.end()-100,recent.end()):recent;{std::lock_guard<std::mutex> lock(mutex);summary=std::move(state);}
  }
  targets.clear();reader.reset();winrt::uninit_apartment();
 }catch(...){std::lock_guard<std::mutex> lock(mutex);summary["error"]="The announcement worker could not start.";for(auto& c:commands)c->result.set_exception(std::current_exception());commands.clear();stop=true;}}
};
Manager::Manager(const fs::path& data,const fs::path& rules,bool testMode):impl(std::make_unique<Impl>(data,rules,testMode)){}Manager::~Manager()=default;
void Manager::Watch(const std::vector<RosterClients::Client>& clients){{std::lock_guard<std::mutex> lock(impl->mutex);impl->clients=clients;}impl->wake.notify_one();}
std::future<json> Manager::Request(json request){auto command=std::make_unique<Impl::Command>();command->value=std::move(request);auto result=command->result.get_future();{std::lock_guard<std::mutex> lock(impl->mutex);if(impl->stop)throw std::runtime_error("The announcement worker is stopped.");impl->commands.push_back(std::move(command));}impl->wake.notify_one();return result;}
json Manager::Summary(){std::lock_guard<std::mutex> lock(impl->mutex);return impl->summary;}
}
