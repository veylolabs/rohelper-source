#pragma once
#include "Clients.h"
#include <future>
#include <memory>
namespace AdminWatch {
class Manager {
 struct Impl;std::unique_ptr<Impl> impl;
public:
 Manager(const std::filesystem::path& data,const std::filesystem::path& rules,bool testMode=false);
 ~Manager();
 void Watch(const std::vector<RosterClients::Client>& clients);
 std::future<json> Request(json request);
 json Summary();
};
}
