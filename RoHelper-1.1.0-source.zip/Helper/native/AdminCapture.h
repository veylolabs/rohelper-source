#pragma once
#include <windows.h>
#include <memory>
#include <string>
#include <vector>

namespace AdminCapture {
struct Image { int width=0,height=0; std::vector<unsigned char> pixels; };
struct Word { std::string text; double x=0,y=0,width=0,height=0; };
struct Reading { std::string text; std::vector<std::vector<Word>> lines; };
// All capture/OCR methods live on the caller's MTA worker, never the UI thread.
class Reader {
 struct Impl; std::unique_ptr<Impl> impl;
public:
 Reader(); ~Reader();
 Reading Read(const Image& image,bool whiteText=false,double minimumHeight=0);
};
class Window {
 struct Impl; std::unique_ptr<Impl> impl;
public:
 explicit Window(HWND window); ~Window();
 Image Frame();
};
Image Crop(const Image& source,double left,double top,double right,double bottom);
std::string DataUrl(const Image& image);
}
