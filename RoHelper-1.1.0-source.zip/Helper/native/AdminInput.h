#pragma once
#include "AdminWatch.h"
#include "AdminSolver.h"
#include "Automation.h"
#include "MacroRecorder.h"
#include <deque>
namespace AdminInput {
// UI-thread-only broker. Automatic input and existing macros never own focus
// simultaneously; each operation revalidates the process, window and geometry.
struct WindowsInput {
 static ULONGLONG Now(){return GetTickCount64();}
 static bool Recording(){return MacroRecorder::Running();}
 static bool Valid(const RosterClients::Client& c){return WindowsAutomationPlatform::Valid(c)&&!IsIconic(c.window);}
 static HWND Foreground(){return GetForegroundWindow();}
 static void Focus(HWND h){WindowsAutomationPlatform::Focus(h);}
 static bool Window(HWND h){return IsWindow(h);}
 static POINT Cursor(){POINT p{};GetCursorPos(&p);return p;}
 static void RestoreCursor(POINT p){SetCursorPos(p.x,p.y);}
 static UINT Send(UINT count,INPUT* inputs){return WindowsAutomationPlatform::Send(count,inputs);}
 static bool Modifiers(){for(int key:{VK_CONTROL,VK_MENU,VK_SHIFT,VK_LWIN,VK_RWIN})if(GetAsyncKeyState(key)&0x8000)return true;return false;}
 static POINT Point(HWND window,const json& coord){WindowLayout::DpiScope dpi;RECT area{};if(!GetClientRect(window,&area)||area.right<2||area.bottom<2)throw std::runtime_error("Cannot measure the code window.");POINT p{LONG(std::lround(coord[0].get<double>()*(area.right-1))),LONG(std::lround(coord[1].get<double>()*(area.bottom-1)))};if(!ClientToScreen(window,&p))throw std::runtime_error("Cannot locate the code window.");if(GetAncestor(WindowFromPoint(p),GA_ROOT)!=window)throw std::runtime_error("Code input stopped: another window covers the click point.");return p;}
 static RECT Desktop(){RECT r{GetSystemMetrics(SM_XVIRTUALSCREEN),GetSystemMetrics(SM_YVIRTUALSCREEN),0,0};r.right=r.left+GetSystemMetrics(SM_CXVIRTUALSCREEN);r.bottom=r.top+GetSystemMetrics(SM_CYVIRTUALSCREEN);return r;}
};
template<class Watcher,class Platform=WindowsInput> class BasicBroker {

 struct Job{RosterClients::Client client;json config;std::string code;bool test=false;int round=0;ULONGLONG queued=0;};
 Watcher& manager;std::deque<Job> queue;std::unique_ptr<Job> active;std::future<json> reading;std::set<std::string> seen;std::string error;ULONGLONG due=0,deadline=0,pollAt=0;int stage=0;bool opened=false;HWND previous=nullptr;POINT cursor{};
 static bool Modifiers(){return Platform::Modifiers();}
 void Send(std::vector<INPUT> inputs){if(Platform::Send(UINT(inputs.size()),inputs.data())!=inputs.size())throw std::runtime_error("Windows blocked code input.");}
 void Validate(){auto& c=active->client;if(!Platform::Valid(c)||Platform::Foreground()!=c.window)throw std::runtime_error("Code input stopped: target window lost focus or closed.");if(Modifiers())throw std::runtime_error("Code input stopped: a modifier key is held.");}
 void Click(const char* point){Validate();auto p=Platform::Point(active->client.window,active->config.at(point));Send(MouseMacro::Inputs(p,Platform::Desktop(),"left",false));}
 void Type(){Click("fieldPoint");std::vector<INPUT> keys={Automation::Key(VK_CONTROL,false),Automation::Key('A',false),Automation::Key('A',true),Automation::Key(VK_CONTROL,true)};for(unsigned char c:active->code){INPUT in{};in.type=INPUT_KEYBOARD;in.ki.wScan=c;in.ki.dwFlags=KEYEVENTF_UNICODE;keys.push_back(in);in.ki.dwFlags|=KEYEVENTF_KEYUP;keys.push_back(in);}try{Send(keys);}catch(...){auto up=Automation::Key(VK_CONTROL,true);Platform::Send(1,&up);throw;}}
 json Request(const char* action){return {{"action",action},{"pid",active->client.pid},{"token",active->client.token}};}
 void ReadMenu(){reading=manager.Request(Request("menu"));deadline=Platform::Now()+6000;}
 void Finish(bool success,const std::string& text){error=success?"":text;if(active){auto request=Request("input_result");request.update({{"code",active->code},{"success",success},{"text",text}});try{manager.Request(request);}catch(...){}if(Platform::Foreground()==active->client.window&&previous&&Platform::Window(previous)){Platform::Focus(previous);Platform::RestoreCursor(cursor);}}active.reset();stage=0;previous=nullptr;}
 static std::string Compact(std::string value){std::string result;for(unsigned char c:value)if(std::isalnum(c)||c=='_'||c=='-')result+=char(std::toupper(c));return result;}
public:
 explicit BasicBroker(Watcher& value):manager(value){}
 bool Busy()const{return bool(active);}
 json Public()const{return {{"busy",bool(active)},{"queued",queue.size()},{"code",active?active->code:""},{"pid",active?active->client.pid:0},{"error",error}};}
 void Cancel(){queue.clear();if(active)Finish(false,"Code input cancelled.");}
 void Cancel(DWORD pid){queue.erase(std::remove_if(queue.begin(),queue.end(),[&](const Job& j){return j.client.pid==pid;}),queue.end());if(active&&active->client.pid==pid)Finish(false,"Code input cancelled for this window.");}
 void Test(const RosterClients::Client& c,const json& config){if(!config.value("calibrated",false))throw std::runtime_error("Calibrate the three code buttons first.");queue.push_back({c,config,"GAARAAMAA504",true,0,Platform::Now()});}
 void Tick(const std::vector<RosterClients::Client>& clients){auto now=Platform::Now();
  try{
   if(now>=pollAt){pollAt=now+200;json state=manager.Summary();if(!state.value("error",std::string()).empty()){Cancel();error=state["error"];return;}
    for(const auto& row:state.value("recent",json::array())){auto id=row.value("id",std::string());if(row.value("kind",std::string())!="candidate"||!seen.insert(id).second||!row.value("eligible",false))continue;if(ActivityStats::Wall()-row.value("at",0LL)>15000)continue;
     for(const auto& c:clients)if(row.value("stream",std::string())==std::to_string(c.pid)+"|"+c.token)for(const auto& t:state["targets"])if(t["pid"]==c.pid&&t["token"]==c.token&&t["enabled"]==true&&t["config"]["autoSubmit"]==true&&t["solver"]["armed"]==true&&!t["solver"].value("polling",false)&&t["solver"]["round"]==row["round"]){auto code=row.value("code",std::string());if(AdminSolver::Code(code)&&queue.size()<128)queue.push_back({c,t["config"],code,false,row["round"].get<int>(),now});}
    }
    if(seen.size()>20000){std::set<std::string> fresh;for(const auto& r:state.value("recent",json::array()))fresh.insert(r.value("id",std::string()));seen.swap(fresh);}
    auto allowed=[&](const Job& j){if(j.test)return true;for(const auto& t:state["targets"])if(t["pid"]==j.client.pid&&t["token"]==j.client.token)return t["enabled"]==true&&t["config"]["autoSubmit"]==true&&t["solver"]["armed"]==true&&!t["solver"].value("polling",false)&&t["solver"]["round"]==j.round;return false;};
    queue.erase(std::remove_if(queue.begin(),queue.end(),[&](const Job& j){return !allowed(j);}),queue.end());if(active&&!allowed(*active)){Finish(false,"Code round ended or input was disabled.");return;}
   }
   if(!active){if(queue.empty())return;if(now-queue.front().queued>20000){queue.pop_front();error="A code attempt expired while waiting for other input. Stop long macros to give codes priority.";return;}if(Automation::owner||Platform::Recording()||Modifiers())return;active=std::make_unique<Job>(queue.front());queue.pop_front();previous=Platform::Foreground();cursor=Platform::Cursor();Platform::Focus(active->client.window);stage=1;due=now+150;opened=false;return;}
   if(now<due)return;Validate();
   if(stage==1){ReadMenu();stage=2;return;}
   if(stage==2||stage==4||stage==7){if(reading.wait_for(std::chrono::milliseconds(0))!=std::future_status::ready){if(now>deadline)throw std::runtime_error("Code menu verification timed out.");return;}auto result=reading.get();if(!result.value("open",false)){if(stage==2&&!opened){Click("openPoint");opened=true;stage=1;due=now+400;return;}throw std::runtime_error("Codes menu was not detected. Check calibration and restore the window.");}
    if(stage==2){Type();stage=3;due=now+250;return;}
    if(stage==4){auto text=Compact(result.value("fieldText",std::string()));if(text.find(Compact(active->code))==std::string::npos)throw std::runtime_error("Typed code could not be verified on screen; nothing was submitted. Check the text-field point.");Click("submitPoint");stage=5;due=now+500;return;}
    Type();Finish(true,"Submitted once and refilled the code field. In-game redemption is unverified.");return;
   }
   if(stage==3){ReadMenu();stage=4;return;}if(stage==5){ReadMenu();stage=7;return;}
  }catch(const std::exception& e){Finish(false,e.what());}
 }
};
using Broker=BasicBroker<AdminWatch::Manager>;
}
