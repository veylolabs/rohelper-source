#pragma once
#include "Store.h"
#include <set>
namespace GlobalHotkeys {
inline const std::set<std::string> actions={"watch_toggle","watch_arm","watch_stop","watch_test","launch_account","focus_account","automation_toggle","automation_stop_all","app_show"};
struct Chord {UINT modifiers=0,key=0;};
inline Chord Parse(const std::string& value){
 Chord result;size_t start=0;std::set<std::string> seen;
 while(start<value.size()){auto end=value.find('+',start);auto word=value.substr(start,end==std::string::npos?end:end-start);if(!seen.insert(word).second)throw std::runtime_error("Duplicate shortcut key.");
  UINT modifier=word=="Ctrl"?MOD_CONTROL:word=="Alt"?MOD_ALT:word=="Shift"?MOD_SHIFT:word=="Win"?MOD_WIN:0;
  if(modifier)result.modifiers|=modifier;
  else {if(result.key)throw std::runtime_error("Use one key and optional modifiers.");if(word.size()==1&&((word[0]>='A'&&word[0]<='Z')||(word[0]>='0'&&word[0]<='9')))result.key=word[0];
   else if(std::regex_match(word,std::regex("F([1-9]|1[0-9]|2[0-4])")))result.key=VK_F1+std::stoi(word.substr(1))-1;
   else if(word=="Pause")result.key=VK_PAUSE;else throw std::runtime_error("Choose A–Z, 0–9, F1–F24 or Pause.");}
  if(end==std::string::npos)break;start=end+1;
 }
 if(!result.key)throw std::runtime_error("Choose a shortcut key.");if(result.key==VK_F12)throw std::runtime_error("Windows reserves F12 for debugging. Choose another key.");
 if(!(result.modifiers&(MOD_CONTROL|MOD_ALT|MOD_WIN))&&result.key>=0x30&&result.key<=0x5A)throw std::runtime_error("Letter and number shortcuts need Ctrl, Alt or Win.");
 return result;
}
inline void Validate(const json& rows){if(!rows.is_array()||rows.size()>64)throw std::runtime_error("Use up to 64 shortcuts.");std::set<std::pair<UINT,UINT>> used;for(const auto& r:rows){if(!r.is_object()||!r.at("action").is_string()||!actions.count(r["action"].get<std::string>())||!r.at("chord").is_string()||!r.at("enabled").is_boolean())throw std::runtime_error("Invalid shortcut.");auto c=Parse(r["chord"]);if(r["enabled"].get<bool>()&&!used.insert({c.modifiers,c.key}).second)throw std::runtime_error("Two actions use the same shortcut.");auto account=r.value("accountId",std::string());if(account.size()>128)throw std::runtime_error("Invalid account shortcut.");if((r["action"]=="launch_account"||r["action"]=="focus_account")&&account.empty())throw std::runtime_error("Choose an account for this shortcut.");}}
class Registry {
 HWND window;fs::path path;bool test;std::map<int,json> registered;json rows=json::array();std::string error;
 void Clear(){for(const auto& r:registered)UnregisterHotKey(window,r.first);registered.clear();}
 void Register(const json& values,bool strict){Clear();int id=0x5200;for(const auto& r:values){++id;if(!r["enabled"].get<bool>())continue;auto c=Parse(r["chord"]);if(!test&&!RegisterHotKey(window,id,c.modifiers|MOD_NOREPEAT,c.key)){auto message=std::string("Shortcut ")+r["chord"].get<std::string>()+" is unavailable or already used by another application.";if(strict)throw std::runtime_error(message);error+=message+" ";continue;}registered[id]=r;}}
public:
 Registry(HWND h,const fs::path& data,bool testing):window(h),path(data/L"hotkeys.json"),test(testing){try{if(fs::exists(path)){auto loaded=json::parse(SafeStorage::Read(path));Validate(loaded);rows=std::move(loaded);}Register(rows,false);}catch(const std::exception& e){error=e.what();}}
 ~Registry(){Clear();}
 json Public(){return {{"bindings",rows},{"error",error}};}
 void Save(const json& next){Validate(next);try{Register(next,true);SafeStorage::Write(path,next.dump(2));}catch(...){Register(rows,false);throw;}rows=next;error.clear();}
 json Find(int id){auto i=registered.find(id);return i==registered.end()?json():i->second;}
};
}
