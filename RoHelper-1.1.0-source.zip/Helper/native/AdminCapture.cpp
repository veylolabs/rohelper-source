#define NOMINMAX
#include "AdminCapture.h"
#include "WindowLayout.h"
#include <algorithm>
#include <stdexcept>
#include <d3d11.h>
#include <dwmapi.h>
#include <wincrypt.h>
#include <windows.graphics.capture.interop.h>
#include <windows.graphics.directx.direct3d11.interop.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Globalization.h>
#include <winrt/Windows.Graphics.Capture.h>
#include <winrt/Windows.Graphics.DirectX.Direct3D11.h>
#include <winrt/Windows.Graphics.Imaging.h>
#include <winrt/Windows.Media.Ocr.h>
#include <winrt/Windows.Storage.Streams.h>
#pragma comment(lib,"windowsapp.lib")
#pragma comment(lib,"d3d11.lib")
#pragma comment(lib,"dwmapi.lib")
#pragma comment(lib,"crypt32.lib")

namespace AdminCapture {
using namespace winrt::Windows;
struct Reader::Impl {
 Media::Ocr::OcrEngine engine{nullptr};
 Impl(){
  engine=Media::Ocr::OcrEngine::TryCreateFromLanguage(Globalization::Language(L"en-US"));
  if(!engine)engine=Media::Ocr::OcrEngine::TryCreateFromUserProfileLanguages();
  if(!engine)throw std::runtime_error("Install an OCR language in Windows Settings > Time & language before starting the watcher.");
 }
};
Reader::Reader():impl(std::make_unique<Impl>()){} Reader::~Reader()=default;
Reading Reader::Read(const Image& image,bool whiteText,double minimumHeight){
 Reading result;if(image.width<1||image.height<1)return result;
 // Upscale narrow/tiled windows while keeping large announcement lettering at
 // native resolution. Windows OCR handles mixed word heights within a line.
 const double scale=std::min(3.0,std::min(2600.0/image.width,2000.0/image.height));
 const int width=std::max(1,int(image.width*scale)),height=std::max(1,int(image.height*scale));
 std::vector<unsigned char> pixels(size_t(width)*height*4,255);
 for(int y=0;y<height;++y)for(int x=0;x<width;++x){const auto* p=&image.pixels[(size_t(std::min(image.height-1,int(y/scale)))*image.width+std::min(image.width-1,int(x/scale)))*4];auto* q=&pixels[(size_t(y)*width+x)*4];
  if(whiteText){int low=std::min({p[0],p[1],p[2]}),high=std::max({p[0],p[1],p[2]});q[0]=q[1]=q[2]=(low>=165&&high-low<55)?0:255;}
  else{q[0]=p[0];q[1]=p[1];q[2]=p[2];}q[3]=255;
 }
 auto writer=Storage::Streams::DataWriter();writer.WriteBytes(pixels);
 auto bitmap=Graphics::Imaging::SoftwareBitmap::CreateCopyFromBuffer(writer.DetachBuffer(),Graphics::Imaging::BitmapPixelFormat::Bgra8,width,height,Graphics::Imaging::BitmapAlphaMode::Ignore);
 auto reading=impl->engine.RecognizeAsync(bitmap).get();
 for(const auto& line:reading.Lines()){std::vector<Word> words;double tallest=0;for(const auto& word:line.Words()){auto r=word.BoundingRect();words.push_back({winrt::to_string(word.Text()),r.X/scale,r.Y/scale,r.Width/scale,r.Height/scale});tallest=std::max(tallest,r.Height/scale);}
  if(words.empty()||tallest<minimumHeight)continue;
  if(!result.text.empty())result.text+='\n';for(size_t i=0;i<words.size();++i){if(i)result.text+=' ';result.text+=words[i].text;}result.lines.push_back(std::move(words));
 }return result;
}
struct Window::Impl {
 HWND hwnd;winrt::com_ptr<ID3D11Device> device;winrt::com_ptr<ID3D11DeviceContext> context;
 Graphics::DirectX::Direct3D11::IDirect3DDevice direct{nullptr};
 Graphics::Capture::GraphicsCaptureItem item{nullptr};Graphics::Capture::Direct3D11CaptureFramePool pool{nullptr};Graphics::Capture::GraphicsCaptureSession session{nullptr};
 Graphics::SizeInt32 size{};
 explicit Impl(HWND h):hwnd(h){
  if(!Graphics::Capture::GraphicsCaptureSession::IsSupported())throw std::runtime_error("Window capture needs Windows 10 version 1903 or newer and supported graphics drivers.");
  winrt::check_hresult(D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,D3D11_CREATE_DEVICE_BGRA_SUPPORT,nullptr,0,D3D11_SDK_VERSION,device.put(),nullptr,context.put()));
  auto dxgi=device.as<IDXGIDevice>();winrt::com_ptr<IInspectable> interop;winrt::check_hresult(CreateDirect3D11DeviceFromDXGIDevice(dxgi.get(),interop.put()));direct=interop.as<Graphics::DirectX::Direct3D11::IDirect3DDevice>();
  auto factory=winrt::get_activation_factory<Graphics::Capture::GraphicsCaptureItem,IGraphicsCaptureItemInterop>();
  winrt::check_hresult(factory->CreateForWindow(hwnd,winrt::guid_of<Graphics::Capture::GraphicsCaptureItem>(),winrt::put_abi(item)));
  size=item.Size();pool=Graphics::Capture::Direct3D11CaptureFramePool::CreateFreeThreaded(direct,Graphics::DirectX::DirectXPixelFormat::B8G8R8A8UIntNormalized,2,size);
  session=pool.CreateCaptureSession(item);try{session.IsCursorCaptureEnabled(false);}catch(...){}session.StartCapture();
 }
 ~Impl(){try{if(session)session.Close();if(pool)pool.Close();}catch(...) {}}
};
Window::Window(HWND window):impl(std::make_unique<Impl>(window)){} Window::~Window()=default;
Image Window::Frame(){
 WindowLayout::DpiScope dpi;
 if(!IsWindow(impl->hwnd))throw std::runtime_error("This Roblox window has closed.");
 if(IsIconic(impl->hwnd)||!IsWindowVisible(impl->hwnd))throw std::runtime_error("Paused: restore this Roblox window to capture announcements.");
 auto frame=impl->pool.TryGetNextFrame();if(!frame)return {};
 auto size=frame.ContentSize();if(size.Width!=impl->size.Width||size.Height!=impl->size.Height){frame.Close();impl->size=size;impl->pool.Recreate(impl->direct,Graphics::DirectX::DirectXPixelFormat::B8G8R8A8UIntNormalized,2,size);return {};}
 if(size.Width<=0||size.Height<=0||size.Width>10000||size.Height>10000||1LL*size.Width*size.Height>32000000)return {};
 auto access=frame.Surface().as<::Windows::Graphics::DirectX::Direct3D11::IDirect3DDxgiInterfaceAccess>();winrt::com_ptr<ID3D11Texture2D> texture;winrt::check_hresult(access->GetInterface(__uuidof(ID3D11Texture2D),texture.put_void()));
 // WGC captures the outer window; convert its client rectangle at every frame.
 RECT outer{},client{};POINT origin{};if(FAILED(DwmGetWindowAttribute(impl->hwnd,DWMWA_EXTENDED_FRAME_BOUNDS,&outer,sizeof(outer)))||!GetClientRect(impl->hwnd,&client)||!ClientToScreen(impl->hwnd,&origin))throw std::runtime_error("Cannot measure capture window.");
 int left=std::clamp(int(origin.x-outer.left),0,size.Width-1),top=std::clamp(int(origin.y-outer.top),0,size.Height-1);
 int width=std::min(int(client.right),size.Width-left),height=std::min(int(client.bottom),size.Height-top);if(width<1||height<1)return {};
 D3D11_TEXTURE2D_DESC desc{};texture->GetDesc(&desc);desc.Width=width;desc.Height=height;desc.MipLevels=1;desc.ArraySize=1;desc.BindFlags=0;desc.MiscFlags=0;desc.Usage=D3D11_USAGE_STAGING;desc.CPUAccessFlags=D3D11_CPU_ACCESS_READ;desc.SampleDesc={1,0};
 winrt::com_ptr<ID3D11Texture2D> staging;winrt::check_hresult(impl->device->CreateTexture2D(&desc,nullptr,staging.put()));
 D3D11_BOX box{UINT(left),UINT(top),0,UINT(left+width),UINT(top+height),1};impl->context->CopySubresourceRegion(staging.get(),0,0,0,0,texture.get(),0,&box);
 D3D11_MAPPED_SUBRESOURCE map{};winrt::check_hresult(impl->context->Map(staging.get(),0,D3D11_MAP_READ,0,&map));
 Image result{width,height,std::vector<unsigned char>(size_t(width)*height*4)};for(int y=0;y<height;++y)memcpy(result.pixels.data()+size_t(y)*width*4,static_cast<unsigned char*>(map.pData)+size_t(y)*map.RowPitch,size_t(width)*4);
 impl->context->Unmap(staging.get(),0);frame.Close();return result;
}
Image Crop(const Image& source,double l,double t,double r,double b){
 int left=std::clamp(int(l*source.width),0,source.width),top=std::clamp(int(t*source.height),0,source.height),right=std::clamp(int(r*source.width),left,source.width),bottom=std::clamp(int(b*source.height),top,source.height);
 Image out{right-left,bottom-top,{}};out.pixels.resize(size_t(out.width)*out.height*4);for(int y=0;y<out.height;++y)memcpy(out.pixels.data()+size_t(y)*out.width*4,source.pixels.data()+(size_t(y+top)*source.width+left)*4,size_t(out.width)*4);return out;
}
std::string DataUrl(const Image& image){
 if(image.width<1||image.height<1)return {};
 BITMAPFILEHEADER file{};BITMAPINFOHEADER header{};file.bfType=0x4d42;file.bfOffBits=sizeof(file)+sizeof(header);file.bfSize=DWORD(file.bfOffBits+image.pixels.size());header.biSize=sizeof(header);header.biWidth=image.width;header.biHeight=-image.height;header.biPlanes=1;header.biBitCount=32;header.biCompression=BI_RGB;
 std::vector<unsigned char> bytes(file.bfSize);memcpy(bytes.data(),&file,sizeof(file));memcpy(bytes.data()+sizeof(file),&header,sizeof(header));memcpy(bytes.data()+file.bfOffBits,image.pixels.data(),image.pixels.size());
 DWORD count=0;CryptBinaryToStringA(bytes.data(),DWORD(bytes.size()),CRYPT_STRING_BASE64|CRYPT_STRING_NOCRLF,nullptr,&count);std::string base64(count,'\0');if(!CryptBinaryToStringA(bytes.data(),DWORD(bytes.size()),CRYPT_STRING_BASE64|CRYPT_STRING_NOCRLF,base64.data(),&count))throw std::runtime_error("Preview encoding failed.");base64.resize(count);while(!base64.empty()&&base64.back()=='\0')base64.pop_back();return "data:image/bmp;base64,"+base64;
}
}
