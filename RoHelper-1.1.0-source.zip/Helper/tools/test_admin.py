"""Isolated watcher checks: fabricated messages, in-memory OCR and fake inputs."""
import json
from pathlib import Path
import subprocess
from toolchain import vcvars32

root = Path(__file__).resolve().parents[1]
out = root.parent / 'Output/RoHelper-tests'
out.mkdir(parents=True, exist_ok=True)
version = json.loads((root / 'version.json').read_text())['version']
q = lambda p: '"' + str(p) + '"'
for name, extra in [
    ('admin-solver', []), ('hotkeys', []), ('admin-input', []),
    ('admin-capture', ['AdminCapture.cpp']),
    ('admin-watch', ['AdminCapture.cpp', 'AdminWatch.cpp']),
]:
    command = ('cl /nologo /EHsc /MD /utf-8 /std:c++17 /DUNICODE /D_UNICODE /I' + q(root / 'vendor') +
               ' /I' + q(root / 'vendor/lua') + ' /Fo' + q(str(out) + '/') + ' ' +
               q(root / 'tests' / (name + '.cpp')) + ' ' + ' '.join(q(root / 'native' / f) for f in extra) +
               ' ' + q(root.parent / ('Output/RoHelper-' + version) / 'lua.lib') +
               ' /link user32.lib gdi32.lib shell32.lib ole32.lib advapi32.lib crypt32.lib bcrypt.lib /OUT:' + q(out / (name + '.exe')))
    batch = out / (name + '.cmd')
    batch.write_text('@echo off\ncall ' + q(vcvars32()) + ' >nul\n' + command + '\nexit /b %errorlevel%\n')
    subprocess.run(['cmd', '/c', str(batch)], cwd=root, check=True)
    subprocess.run([str(out / (name + '.exe'))], cwd=root, check=True)
