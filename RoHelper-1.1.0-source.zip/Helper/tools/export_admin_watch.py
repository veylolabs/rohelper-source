"""Update the public watcher navigation/rules without refreshing unrelated facts."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
target = root.parent / 'GameCatalog'
bundle = json.loads((root / 'web/game-content.json').read_text(encoding='utf-8'))
manifest = json.loads((target / 'manifest.json').read_text(encoding='utf-8'))
entry = next(g for g in manifest['games'] if g['id'] == 'sab')
pack = json.loads((target / entry['file']).read_text(encoding='utf-8'))
pack['navigation'] = [t for t in pack['navigation'] if t['id'] != 'admin-watch']
pack['navigation'].append(dict(id='admin-watch', name='Admin Abuse', icon='code', view='sab-admin-watch'))
pack['catalogs']['adminWatchRules'] = json.loads((root / 'web/admin-watch-rules.json').read_text(encoding='utf-8'))
raw = (json.dumps(pack, ensure_ascii=False, separators=(',', ':')) + '\n').encode()
digest = hashlib.sha256(raw).hexdigest()
entry.update(file='game-sab-' + digest[:16] + '.json', sha256=digest)
(target / entry['file']).write_bytes(raw)
manifest['revision'] = 'content-' + hashlib.sha256(json.dumps(manifest['games'], sort_keys=True).encode()).hexdigest()[:12]
(target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
bundle['manifest'] = manifest
bundle['packs']['sab'] = pack
(root / 'web/game-content.json').write_text(json.dumps(bundle, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')
print('Updated public SAB navigation/rules:', entry['file'])
