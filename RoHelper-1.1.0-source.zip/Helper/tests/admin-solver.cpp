#include "../native/AdminSolver.h"
#include <cassert>
#include <iostream>
using namespace AdminSolver;
int main(){
 Engine e;
 assert(e.Feed("W spider",1).empty()&&!e.armed);
 assert(e.Feed("vote for the next code reward",2).empty()&&!e.armed);
 assert(e.Feed("code later",3).empty()&&!e.armed);
 assert(e.Feed("The code has 3 parts",4).empty()&&e.armed);
 e.Feed("my age is 24",5);
 assert(e.parts.empty());assert(e.Feed("nice",5).empty());
 auto r=e.Feed("First part is CANDY",6);assert(r.size()==1&&r[0].code=="CANDY"&&!r[0].complete);
 assert(e.Feed("First part is CANDY",7).empty());
 e.Feed("I love this event",8);assert(e.parts.size()==1);
 r=e.Feed("Second part is my age",9);assert(r.size()==1&&r[0].code=="CANDY24");
 r=e.Feed("Third part is 6 * 7",10);assert(r.size()==1&&r[0].code=="CANDY2442"&&r[0].complete);
 e.Feed("Vote: FIRE or WATER",11);assert(e.Feed("FIRE",12).empty());
 r=e.Feed("New code: MEOW67",13);assert(r.size()==1&&r[0].code=="MEOW67");
 assert(e.Feed("New code: MEOW67",13).empty());
 e.Feed("sold out",14);assert(!e.armed&&e.Feed("MEOW76",15).empty());
 Engine other;assert(!other.armed&&other.history.empty());other.Arm(true,true);
 other.Feed("Part 2 is B",1);assert(other.lastCode.empty());r=other.Feed("Part 1 is A1",2);assert(r.size()==1&&r[0].code=="A1B");
 Engine rules;rules.rules=json::array({{{"phrases",json::array({"what has hands but cannot clap"})},{"answer","CLOCK"}}});rules.Arm(true,true);
 r=rules.Feed("what has hands but cannot clap?",1);assert(r.size()==1&&r[0].code=="CLOCK");
 rules.Feed("Part 2 is what was the second mutation",2);assert(rules.parts[2].empty());
 assert(!Code("bad code")&&!Code("<script>")&&Code("GAARAAMAA504"));
 Engine repeated;repeated.Arm(true,true);assert(repeated.Feed("FIRE",1).size()==1);assert(repeated.Feed("FIRE",2).empty());
 r=repeated.Feed("The code is FIRE24",3);assert(r.size()==1&&r[0].code=="FIRE24");
 Engine literal;literal.Feed("The code has 3 parts",1);literal.Feed("Part 1 is CANDY",2);literal.Feed("Part 2 is 24",3);r=literal.Feed("Part 3 is SAMMY",4);assert(r.size()==1&&r[0].code=="CANDY24SAMMY");
 std::cout<<"Admin solver checks passed\n";
}
