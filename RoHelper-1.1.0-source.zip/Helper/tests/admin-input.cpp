#define NOMINMAX
#include "../native/Store.h"
#include "../native/AdminInput.h"
#include <cassert>
#include <iostream>
struct FakeInput {
 inline static ULONGLONG now=100;inline static HWND foreground=(HWND)9;inline static bool valid=true,modifiers=false,menu=false;inline static int width=1000;inline static std::string typed;inline static std::vector<std::pair<HWND,POINT>> points;inline static unsigned sent=0;
 static ULONGLONG Now(){return now;}static bool Recording(){return false;}static bool Valid(const RosterClients::Client&){return valid;}static HWND Foreground(){return foreground;}static void Focus(HWND h){foreground=h;}static bool Window(HWND){return true;}static POINT Cursor(){return {};}static void RestoreCursor(POINT){}static bool Modifiers(){return modifiers;}
 static UINT Send(UINT n,INPUT* inputs){sent+=n;if(n>3)typed.clear();for(UINT i=0;i<n;++i)if(inputs[i].type==INPUT_KEYBOARD&&(inputs[i].ki.dwFlags&KEYEVENTF_UNICODE)&&!(inputs[i].ki.dwFlags&KEYEVENTF_KEYUP))typed+=char(inputs[i].ki.wScan);return n;}
 static POINT Point(HWND h,const json& c){POINT p{LONG(c[0].get<double>()*width),LONG(c[1].get<double>()*1000)};points.push_back({h,p});if(c[0]==.1)menu=true;return p;}static RECT Desktop(){return {0,0,4000,4000};}
};
struct FakeWatch {
 json state={{"targets",json::array()},{"recent",json::array()},{"error",""}},results=json::array();bool recognize=true;
 json Summary(){return state;}
 std::future<json> Request(json r){std::promise<json> promise;auto result=promise.get_future();if(r["action"]=="menu")promise.set_value({{"open",FakeInput::menu},{"fieldText",recognize?"Enter code Redeem "+FakeInput::typed:"Enter code Redeem unreadable"}});else{results.push_back(r);promise.set_value(json::object());}return result;}
};
int main(){RosterClients::Client c{},d{};c.pid=1;c.token="one";c.window=(HWND)1;d.pid=2;d.token="two";d.window=(HWND)2;std::vector<RosterClients::Client> clients{c,d};json config={{"calibrated",true},{"autoSubmit",true},{"openPoint",json::array({.1,.6})},{"fieldPoint",json::array({.5,.48})},{"submitPoint",json::array({.5,.59})}};
 FakeWatch watch;AdminInput::BasicBroker<FakeWatch,FakeInput> broker(watch);auto tick=[&]{FakeInput::now+=100;broker.Tick(clients);};
 broker.Test(c,config);broker.Test(d,config);Automation::owner=99;tick();assert(!broker.Busy()&&FakeInput::sent==0);Automation::owner=0;
 for(int i=0;i<80;++i){tick();if(FakeInput::typed=="GAARAAMAA504")FakeInput::width=2000;}
 assert(watch.results.size()==2&&watch.results[0]["success"]==true&&watch.results[1]["success"]==true);assert(FakeInput::foreground==(HWND)9);bool resized=false,second=false;for(auto& p:FakeInput::points){if(p.first==(HWND)2)second=true;else assert(!second);if(p.second.y==590&&p.second.x==1000)resized=true;}assert(resized);
 broker.Test(c,config);tick();auto before=FakeInput::sent;FakeInput::foreground=(HWND)8;tick();tick();assert(!broker.Busy()&&FakeInput::sent==before&&watch.results.back()["success"]==false);
 broker.Test(c,config);tick();broker.Cancel();before=FakeInput::sent;for(int i=0;i<10;++i)tick();assert(FakeInput::sent==before);
 watch.recognize=false;broker.Test(c,config);for(int i=0;i<40;++i)tick();assert(watch.results.back()["success"]==false);watch.recognize=true;
 watch.state["targets"]=json::array({{{"pid",1},{"token","one"},{"enabled",true},{"config",config},{"solver",{{"armed",true},{"polling",false},{"round",1}}}}});
 watch.state["recent"]=json::array({{{"id","candidate-1"},{"kind","candidate"},{"eligible",true},{"at",ActivityStats::Wall()},{"stream","1|one"},{"round",1},{"code","FIRE"}}});auto count=watch.results.size();for(int i=0;i<80;++i)tick();assert(watch.results.size()==count+1); // same persisted candidate cannot repeat
 watch.state["recent"][0]["id"]="candidate-2";watch.state["targets"][0]["solver"]["polling"]=true;count=watch.results.size();for(int i=0;i<20;++i)tick();assert(watch.results.size()==count);
 std::cout<<"PASS serialized windows, macro ownership, resized coordinates, exact test code, refill, focus-loss cancellation, emergency stop, OCR verification failure, duplicate and poll suppression. No real inputs.\n";
}
