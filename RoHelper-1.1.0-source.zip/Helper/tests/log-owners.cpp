#define NOMINMAX
#include <windows.h>
#include <cassert>
#include "../native/Store.h"
#include "../native/Clients.h"
#include <iostream>
int main(){
 auto file=std::filesystem::temp_directory_path()/(L"RoHelper-owner-test-"+std::to_wstring(GetCurrentProcessId())+L".log");
 auto handle=CreateFileW(file.c_str(),GENERIC_READ|GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,nullptr,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,nullptr);assert(handle!=INVALID_HANDLE_VALUE);
 auto owners=RosterClients::LogOwners(file.wstring());bool found=false;auto token=RosterClients::Token(GetCurrentProcess());
 for(auto& p:owners)if(p.dwProcessId==GetCurrentProcessId()&&std::to_string(RosterClients::Stamp(p.ProcessStartTime))==token)found=true;
 CloseHandle(handle);DeleteFileW(file.c_str());assert(found);
 assert(RosterClients::LogIdentity("[FLog::GameJoinLoadTime] userid: 1234")==1234);
 assert(RosterClients::LogIdentity("[FLog::GameJoinLoadTime] userid: 1234\n[FLog::GameJoinLoadTime] userid: 5678")==0);
 std::cout<<"PASS exact file owner PID and creation time, conflicting identities rejected; no Roblox process access."<<std::endl;
}
