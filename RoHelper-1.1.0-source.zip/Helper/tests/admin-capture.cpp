#define NOMINMAX
#include <windows.h>
#include <iostream>
#include <cassert>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Storage.h>
#include <winrt/Windows.Storage.Streams.h>
#include <winrt/Windows.Graphics.Imaging.h>
#include "../native/AdminCapture.h"
AdminCapture::Image Fixture(int fontSize){int width=std::max(600,fontSize*18),height=fontSize*4;BITMAPINFO info{};info.bmiHeader.biSize=sizeof(BITMAPINFOHEADER);info.bmiHeader.biWidth=width;info.bmiHeader.biHeight=-height;info.bmiHeader.biPlanes=1;info.bmiHeader.biBitCount=32;void* pixels=nullptr;HDC dc=CreateCompatibleDC(nullptr);auto bitmap=CreateDIBSection(dc,&info,DIB_RGB_COLORS,&pixels,nullptr,0);auto old=SelectObject(dc,bitmap);PatBlt(dc,0,0,width,height,BLACKNESS);auto font=CreateFontW(-fontSize,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,DEFAULT_CHARSET,OUT_DEFAULT_PRECIS,CLIP_DEFAULT_PRECIS,ANTIALIASED_QUALITY,DEFAULT_PITCH,L"Arial"),oldFont=(HFONT)SelectObject(dc,font);SetTextColor(dc,RGB(255,255,255));SetBkMode(dc,TRANSPARENT);RECT r{10,10,width-10,height-10};DrawTextW(dc,L"The code is FIRE24\nPart 2 is CANDY",-1,&r,DT_LEFT|DT_TOP);GdiFlush();AdminCapture::Image image{width,height,std::vector<unsigned char>(static_cast<unsigned char*>(pixels),static_cast<unsigned char*>(pixels)+size_t(width)*height*4)};SelectObject(dc,oldFont);SelectObject(dc,old);DeleteObject(font);DeleteObject(bitmap);DeleteDC(dc);return image;}
int wmain(int argc,wchar_t** argv){try{
 winrt::init_apartment(winrt::apartment_type::multi_threaded);AdminCapture::Reader ocr;
 if(argc>1){using namespace winrt::Windows;auto file=Storage::StorageFile::GetFileFromPathAsync(argv[1]).get();auto stream=file.OpenAsync(Storage::FileAccessMode::Read).get();auto decoder=Graphics::Imaging::BitmapDecoder::CreateAsync(stream).get();auto bits=decoder.GetPixelDataAsync(Graphics::Imaging::BitmapPixelFormat::Bgra8,Graphics::Imaging::BitmapAlphaMode::Ignore,Graphics::Imaging::BitmapTransform(),Graphics::Imaging::ExifOrientationMode::IgnoreExifOrientation,Graphics::Imaging::ColorManagementMode::DoNotColorManage).get().DetachPixelData();AdminCapture::Image image{int(decoder.PixelWidth()),int(decoder.PixelHeight()),{bits.begin(),bits.end()}};auto crop=AdminCapture::Crop(image,.06,.105,.94,.19);std::cout<<ocr.Read(crop,true,image.height*.018).text<<std::endl;return 0;}
 for(int size:{16,24,48,96}){auto text=ocr.Read(Fixture(size),true).text;assert(text.find("FIRE24")!=std::string::npos&&text.find("CANDY")!=std::string::npos);}
 std::cout<<"PASS mixed announcement font sizes (16–96px), multiline codes, local Windows OCR."<<std::endl;
}catch(const winrt::hresult_error& e){std::cerr<<"Windows OCR error "<<std::hex<<unsigned(e.code().value)<<" "<<winrt::to_string(e.message())<<std::endl;return 1;}catch(const std::exception& e){std::cerr<<e.what()<<std::endl;return 1;}}
