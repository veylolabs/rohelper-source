#define NOMINMAX
#include "../native/Store.h"
#include "../native/AdminWatch.h"
#include <cassert>
#include <iostream>
int main(){auto dir=fs::temp_directory_path()/("rohelper-watch-test-"+std::to_string(GetCurrentProcessId()));fs::create_directories(dir);RosterClients::Client a{},b{};a.pid=101;a.token="synthetic-a";a.userId=1;b.pid=202;b.token="synthetic-b";b.userId=2;
 auto cmd=[](const char* action){return json{{"action",action},{"pid",101},{"token","synthetic-a"}};};
 {
 AdminWatch::Manager m(dir,dir/L"no-rules.json",true);m.Watch({a,b});auto state=m.Request({{"action","state"}}).get();assert(state["targets"].size()==2);
 auto send=[&](std::string text){auto r=cmd("manual");r["text"]=text;return m.Request(r).get();};send("Welcome everyone");send("my age is 24");send("The code has 2 parts");send("Part 1 is FIRE");state=send("Part 2 is my age");assert(state["targets"][0]["solver"]["candidate"]=="FIRE24");assert(state["targets"][1]["solver"]["candidate"]=="");
 auto logs=m.Request({{"action","log"},{"limit",100}}).get()["entries"];assert(logs.size()==7);for(const auto& r:logs)if(r["kind"]=="candidate")assert(r["eligible"]==false);
 auto first=m.Request({{"action","log"},{"limit",3}}).get();auto next=m.Request({{"action","log"},{"limit",100},{"before",first["next"]}}).get();assert(first["entries"].size()+next["entries"].size()==7);
 auto filtered=m.Request({{"action","log"},{"stream","202|synthetic-b"}}).get();assert(filtered["entries"].empty());
 auto rule=json{{"phrases",json::array({"test clue"})},{"answer","TEST24"}};m.Request({{"action","rules"},{"rules",json::array({rule})}}).get();
 }
 {
 AdminWatch::Manager m(dir,dir/L"no-rules.json",true);m.Watch({a,b});auto state=m.Request({{"action","state"}}).get();assert(state["rules"].size()==1&&state["targets"][0]["solver"]["armed"]==false);assert(m.Request({{"action","log"}}).get()["entries"].size()==7);auto arm=cmd("arm");arm["armed"]=true;m.Request(arm).get();auto manual=cmd("manual");manual["text"]="Part 1 is my age";assert(m.Request(manual).get()["targets"][0]["solver"]["candidate"]=="24");m.Request({{"action","stop_inputs"}}).get();assert(m.Request({{"action","state"}}).get()["targets"][0]["solver"]["armed"]==false);
 }
 for(const auto& f:fs::directory_iterator(dir/L"admin-watch"))fs::remove(f.path());fs::remove(dir/L"admin-watch");fs::remove(dir);
 std::cout<<"PASS per-window context, complete message log, pagination, rule persistence, restart without replay and stop-all. No capture or real input.\n";
}
