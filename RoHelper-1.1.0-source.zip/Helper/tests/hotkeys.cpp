#define NOMINMAX
#include "../native/GlobalHotkeys.h"
#include <cassert>
#include <iostream>
int main(){using namespace GlobalHotkeys;auto chord=Parse("Ctrl+Alt+F24");assert(chord.key==VK_F24&&chord.modifiers==(MOD_CONTROL|MOD_ALT));for(auto bad:{"Ctrl","F25","F12","A","Ctrl+Ctrl+F24","Ctrl+F1+F2"}){bool rejected=false;try{Parse(bad);}catch(...){rejected=true;}assert(rejected);}
 auto row=json{{"action","watch_stop"},{"chord","Ctrl+Alt+F24"},{"enabled",true},{"accountId",""}};Validate(json::array({row}));bool duplicate=false;try{Validate(json::array({row,row}));}catch(...){duplicate=true;}assert(duplicate);
 auto dir=fs::temp_directory_path()/("rohelper-hotkey-test-"+std::to_string(GetCurrentProcessId()));fs::create_directories(dir);
 {Registry registry(nullptr,dir,true);registry.Save(json::array({row}));assert(registry.Find(0x5201)["action"]=="watch_stop");}
 {Registry registry(nullptr,dir,true);assert(registry.Public()["bindings"].size()==1);auto before=SafeStorage::Read(dir/L"hotkeys.json");try{registry.Save(json::array({row,row}));}catch(...){}assert(SafeStorage::Read(dir/L"hotkeys.json")==before);}
 fs::remove(dir/L"hotkeys.json");fs::remove(dir);
 std::cout<<"PASS F24 chords, validation, duplicates, settings persistence and failed-save preservation. No system shortcuts registered.\n";
}
