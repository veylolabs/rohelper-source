#pragma once
#define ROHELPER_VERSION "1.1.0"
