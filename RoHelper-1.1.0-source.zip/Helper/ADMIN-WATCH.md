# Admin Abuse watcher

Open **Steal a Brainrot → Admin Abuse**. Each running Roblox window has its own watcher, code round and calibration. Watching starts only when enabled; it never starts automatically after an app restart.

## First setup

1. Restore the Roblox window. Choose **Calibrate** in RoHelper.
2. Drag the announcement rectangle around the entire message area, leaving space for different font sizes and multiple lines. The OCR scales small captures and accepts mixed text sizes.
3. Select **Codes button** and click that button in the preview.
4. Open Codes in Roblox. Refresh the preview, then mark the **text field** and **Submit / Redeem button**. Save calibration.
5. Choose **Test code**. It enters `GAARAAMAA504`, verifies that the text is visible, submits once, and refills the field. An input result records what Windows accepted; it does not claim a successful in-game redemption.

Coordinates are relative to the client area and recalculated before each click. Recalibrate if Roblox changes the layout. A minimized window cannot provide reliable capture. Windows may show a capture border. Capture requires Windows 10 version 1903 or newer, supported graphics and an installed Windows OCR language.

## Watching and code rounds

Watching saves every captured announcement, including unrelated messages, to a daily log in `%LOCALAPPDATA%\RoHelper\admin-watch`. Logs, window preferences and local rules are private and excluded from distribution packages. Preview images stay in memory.

Automatic rounds require a clear code announcement. Polls and votes pause code interpretation. **Start code round** enables manual interpretation for that window; **Stop inputting** stops its code attempts. **Stop all code input** cancels queued input across windows while leaving message capture available.

Each new contiguous multipart candidate is tried once, then left in the field for the next addition. Repeated OCR reads do not repeat an attempt. The rule-based solver handles explicit parts, simple arithmetic, exact saved riddles and facts explicitly stated in earlier messages. Unknown clues remain unsolved. Use **Add clue / answer**, for example `Part 2 is CANDY`, or add an exact local riddle rule. Shared default rules arrive through the public game catalog; local overrides remain on this PC. No AI model or external AI service is used.

Input is serialized across windows and shares access with macros. A held macro can delay an attempt; queued attempts expire after 20 seconds rather than typing stale codes. Focus loss, a covered click point, a held modifier, failed OCR verification or unavailable logging stops that attempt. OCR can miss short-lived announcements or misread letters: the live read and saved log make this visible. Keep a separate log for each watched window when several show the same announcement.

## Global keybinds

Open **Settings → Global keybinds**. Choose an action, modifiers and a key. Supported keys include F13–F24; F12 is reserved by Windows. `Ctrl+Alt+F24` is supported. Conflicting bindings are rejected without replacing the saved list.

Actions cover watching, starting code rounds, test input, stopping all code input, launching or focusing a selected account, automation Start / Stop, stopping all automation and showing RoHelper. Focused-window actions use the foreground Roblox window. Launch uses the destination selected in Accounts. Shortcuts work while RoHelper is running in the tray. Stream Deck can invoke them with its System → Hotkey action; no separate plugin is needed.

## Verification

The automated checks use synthetic accounts and fake input. They cover per-window context, complete captured-message logs, pagination, persistence, no replay on restart, multipart updates, poll suppression, duplicate candidates, F24 bindings, focus cancellation, resizing, serialized input, code verification and desktop/narrow layouts. OCR fixtures cover 16–96 px lettering and multiline messages. Live in-game redemption still needs verification with the Test code button and an actual event.
