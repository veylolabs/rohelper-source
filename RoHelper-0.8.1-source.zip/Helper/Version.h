#pragma once
#define ROHELPER_VERSION "0.8.1"
