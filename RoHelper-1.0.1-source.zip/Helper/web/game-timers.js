// Shared presets are reference data. Started timers belong only to this workspace.
window.HelperGameTimers=(()=>{
 const MAX=366*86400000;
 let lastTick=Date.now(),lastSave=0;
 const sent=new Set();
 const rows=()=>db.eventTracker?.timers||[];
 const presets=()=>HelperGames.packs().flatMap(p=>(p.timerPresets||[]).map(t=>({...t,packId:p.id,game:p.name})));
 const remaining=(t,now=Date.now())=>Math.max(0,t.paused||t.clock==='online'?t.remainingMs:t.endAt-now);
 function active(t){return snapshot.clients?.some(c=>c.accountId===t.accountId);}
 function globalRemaining(t,now=Date.now()){const period=t.seconds*1000,offset=(t.offsetSeconds||0)*1000;return period-((now-offset)%period+period)%period;}
 function commit(){mark();drawCurrent();}
 function timerCard(t){
  const c=node('article',undefined,'event-card game-timer');c.dataset.timer=t.id;
  const owner=db.accounts.find(a=>a.id===t.accountId),server=db.servers.find(s=>s.id===t.serverId);
  c.append(node('h3',t.title),node('small',[HelperGames.pack(t.packId)?.name||t.packId,owner?'@'+owner.username:t.accountId?'Removed account':server?.name||'Server timer'].filter(Boolean).join(' · ')));
  const countdown=node('div','','event-countdown');countdown.dataset.gameTimer=t.id;c.append(countdown);
  const status=node('p','','muted');status.dataset.timerState=t.id;c.append(status);
  const actions=node('div',undefined,'row wrap');
  actions.append(button(t.paused?'Resume':'Pause',()=>{const value=remaining(t);if(!value)return;t.remainingMs=value;t.paused=!t.paused;t.endAt=Date.now()+value;commit();},'ghost'),button('Restart',()=>{t.remainingMs=t.seconds*1000;t.endAt=Date.now()+t.remainingMs;t.paused=false;t.startedAt=Date.now();commit();},'ghost','refresh'),button('Remove',()=>{db.eventTracker.timers=rows().filter(x=>x.id!==t.id);commit();},'ghost danger','trash'));
  c.append(actions,check('Notify when ready',!!t.notify,v=>{t.notify=v;mark();}));return c;
 }
 function start(p){
  const m=HelperSab.dialog('Start '+p.title,p.notes||'Start after the matching in-game action.','Start timer',async({close})=>{
   const seconds=Number(duration.value)*60;if(!Number.isInteger(seconds)||seconds<1||seconds*1000>MAX)throw Error('Choose a duration between 1 second and 366 days.');
   if(p.scope==='account'&&!owner.value)throw Error('Choose the account this timer belongs to.');
   const now=Date.now(),t={id:crypto.randomUUID(),presetId:p.id,packId:p.packId,title:p.title,seconds,remainingMs:seconds*1000,endAt:now+seconds*1000,startedAt:now,paused:false,notify:false,clock:p.clock||'wall',accountId:owner.value,serverId:server.value};
   db.eventTracker??={custom:[],overrides:{},hidden:[]};db.eventTracker.timers??=[];db.eventTracker.timers.push(t);mark();await flush();close();drawCurrent();
  });
  const owner=select('Timer account',[['','Choose an account'],...db.accounts.map(a=>[a.id,'@'+a.username])],'');
  const server=select('Timer server',[['','Unspecified server'],...db.servers.filter(s=>HelperGames.forPlace(s.placeId)?.id===p.packId||HelperGames.pack(p.packId)?.placeIds.includes(s.placeId)).map(s=>[s.id,s.name])],'');
  const duration=input('Timer duration (minutes)',p.seconds/60,'number');duration.min=1/60;duration.max=MAX/60000;duration.step='any';
  const fields=node('div',undefined,'form-grid');if(p.scope==='account')fields.append(label('Account',owner));else fields.append(label('Server (optional)',server));fields.append(label('Duration (minutes)',duration));m.body.append(fields);
  if(p.clock==='online')m.body.append(node('p','Counts only while RoHelper is open and the selected Roblox account is detected. Pause when leaving this game or activity.','help-text'));
  if(p.variants?.length){const v=select('Timer variant',[['base','Standard'],...p.variants.map((x,i)=>[String(i),x.title])],'base');v.onchange=()=>duration.value=(v.value==='base'?p.seconds:p.variants[Number(v.value)].seconds)/60;m.body.append(label('Cooldown variant',v));}
  if(p.source){const link=node('a','Timing source');link.href=p.source;link.target='_blank';link.rel='noopener noreferrer';m.body.append(link);}enhance(m.body);
 }
 function render(host,scope='',query='',group=''){
  host.dataset.timerScope=scope;host.dataset.timerQuery=query;host.dataset.timerGroup=group;host.id='game-timers';host.replaceChildren();
  const matches=p=>(!scope||p.packId===scope)&&(!group||(p.game||HelperGames.pack(p.packId)?.name)===group)&&[p.title,p.game,p.notes].join(' ').toLowerCase().includes(query.toLowerCase());
  const current=rows().filter(matches);host.append(node('h2','Your timers','event-section-title'));const running=node('div',undefined,'events-grid');for(const t of current)running.append(timerCard(t));if(!current.length)running.append(node('p','Start a preset below. Each account has its own timers.','muted'));host.append(running);
  host.append(node('h2','Shared timer presets','event-section-title'),node('p','Restock clocks show timing only, not live stock. Cooldowns start when you choose; adjust them to match the in-game countdown.','help-text'));
  const library=node('div',undefined,'events-grid');for(const p of presets().filter(matches)){
   const c=node('article',undefined,'event-card timer-preset');c.dataset.preset=p.packId+':'+p.id;c.append(node('h3',p.title),node('small',p.game+' · '+(p.scope==='global'?'Shared clock':p.scope==='account'?'Per account':'Per server')));
   const duration=node('div',p.scope==='global'?'':EventSchedule.countdown(p.seconds*1000),'event-countdown');if(p.scope==='global')duration.dataset.globalTimer=p.packId+':'+p.id;c.append(duration);
   if(p.notes)c.append(node('p',p.notes,'event-notes'));if(p.scope!=='global')c.append(button('Start timer',()=>start(p),'ghost','clock'));
   const foot=node('div',undefined,'event-source');foot.append(node('span',(p.confidence==='official'?'Official reference':'Community reference')+' · checked '+p.checkedOn));const link=node('a',' · Source');link.href=p.source;link.target='_blank';link.rel='noopener noreferrer';foot.append(link);c.append(foot);library.append(c);
  }host.append(library);paint();
 }
 function drawCurrent(){const host=document.querySelector('#game-timers');if(host)render(host,host.dataset.timerScope,host.dataset.timerQuery,host.dataset.timerGroup);}
 function paint(){const now=Date.now();for(const n of document.querySelectorAll('[data-game-timer]')){const t=rows().find(x=>x.id===n.dataset.gameTimer);if(t)n.textContent=remaining(t,now)?EventSchedule.countdown(remaining(t,now)):'Ready';}for(const n of document.querySelectorAll('[data-timer-state]')){const t=rows().find(x=>x.id===n.dataset.timerState);if(t)n.textContent=t.paused?'Paused':t.clock==='online'&&!active(t)?'Waiting for this account to run':t.clock==='online'?'Counting detected account time':'Keeps counting while RoHelper is closed';}const catalog=presets();for(const n of document.querySelectorAll('[data-global-timer]')){const p=catalog.find(x=>x.packId+':'+x.id===n.dataset.globalTimer);if(p)n.textContent='Next in '+EventSchedule.countdown(globalRemaining(p,now));}}
 function tick(){const now=Date.now(),elapsed=now-lastTick;lastTick=now;if(typeof db==='undefined'||!db)return;let changed=false;for(const t of rows()){
   if(!t.paused&&t.clock==='online'&&active(t)&&elapsed>0&&elapsed<10000&&t.remainingMs>0){t.remainingMs=Math.max(0,t.remainingMs-elapsed);changed=true;}
   const key='timer:'+t.id+':'+t.startedAt;if(t.notify&&!t.paused&&!remaining(t,now)&&!sent.has(key)){sent.add(key);rpc('event_notify',{key,title:t.title,message:t.title+' is ready.'}).then(r=>{if(r.delivered)toast(t.title+' is ready.');}).catch(()=>sent.delete(key));}
  }if(changed){dirty=true;changeSerial++;status();if(now-lastSave>=10000){lastSave=now;flush().catch(()=>{});}}paint();
 }
 setInterval(tick,1000);
 return {render,start,remaining,globalRemaining,presets,tick};
})();
