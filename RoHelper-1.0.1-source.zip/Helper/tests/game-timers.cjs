// Deterministic timer clocks: no real accounts, game clients or waiting.
const assert=require('node:assert/strict'),fs=require('node:fs'),vm=require('node:vm'),path=require('node:path');
let now=1793260000000,saves=0;
const timer=(id,accountId,clock='online')=>({id,accountId,clock,seconds:60,remainingMs:60000,endAt:now+60000,paused:false,notify:false});
const context={window:{},Date:class extends Date{static now(){return now;}},setInterval(){},
 db:{eventTracker:{timers:[timer('active','101'),timer('idle','102'),timer('wall','101','wall')]}},
 snapshot:{clients:[{accountId:'101'}]},HelperGames:{packs:()=>[]},document:{querySelectorAll:()=>[]},
 dirty:false,changeSerial:0,status(){},flush(){saves++;return Promise.resolve();}};
vm.createContext(context);vm.runInContext(fs.readFileSync(path.join(__dirname,'../web/game-timers.js'),'utf8'),context);
const api=context.window.HelperGameTimers,rows=context.db.eventTracker.timers;
for(let i=0;i<11;i++){now+=1000;api.tick();}
assert.equal(rows[0].remainingMs,49000);assert.equal(rows[1].remainingMs,60000);assert.equal(rows[2].remainingMs,60000);assert.equal(api.remaining(rows[2]),49000);assert.equal(saves,2);assert(context.dirty);
rows[0].paused=true;now+=1000;api.tick();assert.equal(rows[0].remainingMs,49000);
rows[0].paused=false;now+=60000;api.tick();assert.equal(rows[0].remainingMs,49000,'sleep gaps excluded');assert.equal(api.remaining(rows[2]),0,'wall clock expires while closed');
context.snapshot.clients=[];now+=1000;api.tick();assert.equal(rows[0].remainingMs,49000);
context.snapshot.clients=[{accountId:'102'}];now+=1000;api.tick();assert.equal(rows[1].remainingMs,59000);assert.equal(rows[0].remainingMs,49000);
assert.equal(api.globalRemaining({seconds:3600,offsetSeconds:0},Date.parse('2026-10-29T12:59:00Z')),60000);
assert.equal(api.globalRemaining({seconds:1800,offsetSeconds:900},Date.parse('2026-10-29T12:44:00Z')),60000);
console.log('PASS owner-specific online time, paused/offline/sleep handling, wall-clock expiry, UTC phase and batched autosave.');
