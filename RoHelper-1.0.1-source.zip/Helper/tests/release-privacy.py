"""Regression checks use fabricated values only and never read account storage."""
import base64
import importlib.util
import json
import pathlib
import struct
import tempfile
import unittest
import zipfile
import zlib

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('release_privacy', ROOT / 'tools/release_privacy.py')
P = importlib.util.module_from_spec(spec)
spec.loader.exec_module(P)


def chunk(kind, value):
    return struct.pack('>I', len(value)) + kind + value + struct.pack('>I', zlib.crc32(kind + value))


class PrivacyGate(unittest.TestCase):
    def test_paths(self):
        path = ':'.join(['Z', '/' + 'Users/SyntheticProfile/project'])
        self.assertIn('absolute-local-path', P.inspect('test.cpp', path.encode()))
        self.assertIn('absolute-local-path', P.inspect('test.cpp', path.replace('/', '\\').encode()))
        self.assertIn('absolute-local-path', P.inspect('test.cpp', ('/' + 'home/SyntheticProfile/source/').encode()))
        self.assertIn('absolute-local-path', P.inspect('test.exe', b'MZ' + path.encode('utf-16le')))
        self.assertEqual([], P.inspect('test.cpp', b"sourceRoot / 'content' / 'public.json'"))
        self.assertEqual([], P.inspect('vendor.c', b'printf("for %p:\\n", pointer);'))

    def test_private_data(self):
        for name in ['Helper/helper-data/workspace.json', 'RoHelper/accounts.json', 'Helper/.env', 'Helper/cache/Cookies', 'Helper/debug.log', 'Helper/activity.json', 'Helper/activity.previous.json']:
            self.assertIn('private-data-filename', P.inspect(name, b''))
        self.assertIn('saved-activity-statistics', P.inspect('renamed.json', b'{"totals":{},"unlocks":{},"active":{}}'))
        self.assertIn('saved-accounts', P.inspect('unexpected.json', json.dumps({'accounts': [{'id': 'synthetic'}]}).encode()))
        self.assertIn('saved-username', P.inspect('unexpected.json', b'{"username":"SyntheticUser"}'))
        self.assertEqual([], P.inspect('reference.json', b'{"accounts":[],"name":"Public reference"}'))

    def test_recovery_contacts(self):
        payload = {'recovery': {'email': 'recovery@example.invalid', 'phone': '+1 555 0100'}}
        self.assertIn('saved-recovery-contact', P.inspect('unexpected.json', json.dumps(payload).encode()))
        self.assertEqual([], P.inspect('defaults.json', b'{"recovery":{"email":"","phone":""}}'))

    def test_credentials(self):
        examples = {
            'github-token': 'gh' + 'p_' + 'X' * 36,
            'private-key': '-----BEGIN ' + 'PRIVATE KEY-----',
            'aws-key': 'AK' + 'IA' + 'X' * 16,
            'roblox-session': '_|WARNING:' + '-DO-NOT-SHARE-THIS' + 'X' * 40,
            'discord-webhook': 'https://discord.com/api/' + 'webhooks/123456/' + 'x' * 40,
            'jwt': '.'.join(['eyJ' + 'x' * 18] * 3),
        }
        for rule, example in examples.items():
            self.assertIn(rule, P.inspect('unexpected.txt', example.encode()))

    def test_image_metadata(self):
        copyright_chunk = chunk(b'tEXt', b'Copyright\0Upstream artist notice')
        timestamp = chunk(b'tEXt', b'date:create\0synthetic-date')
        image = P.PNG + copyright_chunk + timestamp + chunk(b'IEND', b'')
        self.assertIn('image-timestamp-metadata', P.inspect('asset.png', image))
        cleaned = P.strip_png_timestamps(image)
        self.assertIn(copyright_chunk, cleaned)
        self.assertNotIn(timestamp, cleaned)
        self.assertEqual([], P.inspect('asset.png', cleaned))
        self.assertIn('image-timestamp-metadata', P.inspect('pack.json', json.dumps({'image': 'data:image/png;base64,' + base64.b64encode(image).decode()}).encode()))

    def test_archives_fail_closed(self):
        with tempfile.TemporaryDirectory(dir=ROOT.parent / 'Output') as temp:
            archive = pathlib.Path(temp) / 'bad-source.zip'
            with zipfile.ZipFile(archive, 'w') as z:
                z.writestr('Helper/innocent.json', '{"username":"SyntheticUser"}')
            with self.assertRaisesRegex(RuntimeError, 'saved-username'):
                P.audit_archive(archive, ROOT)
            with zipfile.ZipFile(archive, 'w') as z:
                z.writestr('Helper/../escape', 'test')
            with self.assertRaisesRegex(RuntimeError, 'Unsafe release'):
                P.audit_archive(archive, ROOT)
            with zipfile.ZipFile(archive, 'w') as z:
                z.writestr('Helper/WebView2Loader.dll', b'MZRSDS')
            with self.assertRaisesRegex(RuntimeError, 'app-debug-record'):
                P.audit_archive(archive, ROOT)


if __name__ == '__main__':
    unittest.main()
