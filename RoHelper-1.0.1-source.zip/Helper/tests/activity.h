#pragma once
#include "../native/ActivityStats.h"
#include "../native/ClientResources.h"
inline void TestActivity(const fs::path& directory,const fs::path& sourceRoot){
 using namespace ActivityStats;auto dir=directory/"activity-synthetic";fs::create_directories(dir);Book book(dir);
 constexpr long long start=1793232000000LL;ULONGLONG awake=10000;std::vector<Observation> rows;
 for(int i=1;i<=8;++i)rows.push_back({std::to_string(i)+"|token",std::to_string(i),{{"antiAfkInputs",0}},{{"cpu",1.0},{"ram",100000000.0},{"gpu",nullptr}},"healthy",0});
 book.Observe(awake,start,rows);
 for(int n=1;n<=1200;++n)book.Observe(awake+n*3000,start+n*3000,rows);
 assert(N(book.data["totals"],"combinedMs")==8*hour);assert(N(book.data["totals"],"wallActiveMs")==hour);assert(N(book.data["totals"],"sessions")==8);assert(N(book.data["totals"],"peakAccounts")==8);
 assert(N(book.data["accounts"]["1"],"combinedMs")==hour);assert(!book.data["active"]["1|token"]["metrics"].contains("gpuMs"));
 assert(book.data["hours"][std::to_string(start)]["peakAccounts"]==8);
 auto before=N(book.data["totals"],"combinedMs");
 // A second process for the same account never doubles credited account time.
 rows.push_back({"duplicate|token","1"});book.Observe(awake+hour+3000,start+hour+3000,rows);assert(N(book.data["totals"],"combinedMs")==before+8*3000);rows.pop_back();
 before=N(book.data["totals"],"combinedMs");
 // Sleep and large timer stalls produce graph gaps, never invented playtime.
 book.Observe(awake+hour+4000,start+2*hour,rows);assert(N(book.data["totals"],"combinedMs")==before);
 book.Observe(awake+3*hour,start+4*hour,rows);assert(N(book.data["totals"],"combinedMs")==before);
 // Clock rollback does not earn negative or extra runtime.
 book.Observe(awake+3*hour+3000,start+3*hour,rows);assert(N(book.data["totals"],"combinedMs")==before);
 rows[0].counters={{"antiAfkInputs",10},{"macroCycles",2},{"focusFailures",3}};rows[0].health="paused";rows[0].lastAntiAfkAt=start;
 book.Observe(awake+3*hour+6000,start+3*hour+3000,rows);book.Observe(awake+3*hour+9000,start+3*hour+6000,rows);
 assert(N(book.data["totals"],"antiAfkInputs")==10);assert(N(book.data["totals"],"macroCycles")==2);assert(N(book.data["totals"],"focusFailures")==3);assert(N(book.data["totals"],"pausedMs")==6000);
 book.Save(true);assert(book.error.empty()&&fs::exists(dir/"activity.json"));before=N(book.data["totals"],"combinedMs");
 Book resumed(dir);rows[0].counters=json::object();resumed.Observe(20,start+10*day,rows);assert(N(resumed.data["totals"],"combinedMs")==before);assert(N(resumed.data["totals"],"sessions")==8);assert(N(resumed.data["totals"],"antiAfkInputs")==10);
 rows[0].counters={{"antiAfkInputs",1}};resumed.Observe(3020,start+10*day+3000,rows);assert(N(resumed.data["totals"],"antiAfkInputs")==11);
 resumed.Observe(6020,start+10*day+6000,{});assert(resumed.data["history"].size()==8);assert(resumed.data["active"].empty());assert(resumed.Public(2)["history"].size()==2);
 auto definitions=json::parse(SafeStorage::Read(sourceRoot/"content/achievements.json"));AchievementContent::Validate(definitions);auto workspace=DefaultWorkspace();resumed.Evaluate(definitions,workspace);assert(resumed.data["unlocks"].contains("runtime-1"));assert(!resumed.data["unlocks"].contains("runtime-87600"));assert(resumed.data["unlocks"].contains("presence-hours-1"));assert(resumed.data["unlocks"].contains("roster-8"));assert(!resumed.data["unlocks"].contains("roster-10"));
 for(auto& a:definitions["entries"])if(a["id"]=="runtime-1")a["target"]=1e14;resumed.Evaluate(definitions,workspace);assert(resumed.data["unlocks"].contains("runtime-1"));auto added=definitions["entries"][0];added["id"]="new-retroactive-milestone";added["target"]=1;definitions["entries"].push_back(added);resumed.Evaluate(definitions,workspace);assert(resumed.data["unlocks"].contains("new-retroactive-milestone"));
 resumed.Save(true);Book afterRestart(dir);assert(afterRestart.data["unlocks"]==resumed.data["unlocks"]);
 auto bad=definitions;bad["entries"][0]["metric"]="execute";assert(Fails([&]{AchievementContent::Validate(bad);}));bad=definitions;bad["entries"][0]["icon"]["paths"][0]="<script>";assert(Fails([&]{AchievementContent::Validate(bad);}));
 auto other=directory/"midnight-synthetic";fs::create_directories(other);Book midnight(other);midnight.Observe(1000,start+day-1500,{rows[0]});midnight.Observe(4000,start+day+1500,{rows[0]});assert(midnight.data["days"][std::to_string(start)]["combinedMs"]==1500);assert(midnight.data["days"][std::to_string(start+day)]["combinedMs"]==1500);assert(N(midnight.data["totals"],"bestStreak")==2);
 SafeStorage::Write(other/"activity.json","invalid synthetic stats");Book corrupt(other);assert(corrupt.blocked);corrupt.Observe(5000,start,rows);corrupt.Save(true);assert(SafeStorage::Read(other/"activity.json")=="invalid synthetic stats");
 assert(ClientResources::CpuPercent(0,2000000,1000,4)==5);assert(ClientResources::CpuPercent(10,0,1000,4)<0);assert(ClientResources::InstancePid(L"pid_321_luid_0x0000_eng_0_engtype_3D")==321);assert(!ClientResources::InstancePid(L"pid_bad_luid_0"));
 // Online definitions are optional for older feeds, cached and checksum-verified.
 auto bundle=json::parse(SafeStorage::Read(sourceRoot/"web/game-content.json"));const auto achievementBytes=bundle["achievements"].dump();const auto achievementHash=GameContent::Digest(achievementBytes);bundle["manifest"]["achievements"]={{"file","achievements-"+achievementHash.substr(0,16)+".json"},{"sha256",achievementHash}};auto old=bundle;old.erase("achievements");old["manifest"].erase("achievements");int fetched=0;
 auto updated=GameContent::Refresh(old,[&](const std::string& file){if(file=="manifest.json")return bundle["manifest"].dump();++fetched;return achievementBytes;});
 assert(fetched==1&&updated["achievements"]["entries"].size()==bundle["achievements"]["entries"].size());fetched=0;
 GameContent::Refresh(updated,[&](const std::string& file){assert(file=="manifest.json");++fetched;return bundle["manifest"].dump();});assert(fetched==1);
 assert(Fails([&]{GameContent::Refresh(old,[&](const std::string& file){return file=="manifest.json"?bundle["manifest"].dump():std::string("{}");});}));
 auto badManifest=bundle["manifest"];badManifest["achievements"]["file"]="../private.json";assert(Fails([&]{GameContent::ValidateManifest(badManifest);}));
 auto cacheDir=directory/"activity-content-cache";fs::create_directories(cacheDir);GameContent::Cache cache(cacheDir,sourceRoot/"web/game-content.json");cache.Install(updated);GameContent::Cache offline(cacheDir,sourceRoot/"web/game-content.json");assert(offline.bundle["achievements"]==updated["achievements"]);
 std::cout<<"PASS eight-account combined runtime, duplicate suppression, sleep/stall/clock gaps, persistent sessions and counters, UTC bucket splits, achievements across updates, corrupt-file preservation and resource calculations. Synthetic data only.\n";
}
