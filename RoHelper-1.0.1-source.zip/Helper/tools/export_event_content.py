"""Update public event data without rebuilding unrelated game catalogs."""
import hashlib
import json
from pathlib import Path


def overlay(pack, definitions):
    data = definitions['games'].get(pack['id'])
    if data is not None:
        pack['events'] = data['events']
        pack['timerPresets'] = data['timerPresets']
    return pack


def export():
    root = Path(__file__).resolve().parents[1]
    target = root.parent / 'GameCatalog'
    read = lambda p: json.loads(p.read_text(encoding='utf-8'))
    definitions = read(root / 'content/event-schedules.json')
    manifest = read(target / 'manifest.json')
    bundle_path = root / 'web/game-content.json'
    bundle = read(bundle_path)
    assert set(definitions['games']) == {g['id'] for g in manifest['games']}
    for entry in manifest['games']:
        previous = read(target / entry['file'])
        pack = overlay(json.loads(json.dumps(previous)), definitions)
        assert {k: v for k, v in previous.items() if k not in ('events', 'timerPresets')} == {
            k: v for k, v in pack.items() if k not in ('events', 'timerPresets')}
        raw = (json.dumps(pack, ensure_ascii=False, separators=(',', ':')) + '\n').encode()
        digest = hashlib.sha256(raw).hexdigest()
        name = 'game-' + pack['id'] + '-' + digest[:16] + '.json'
        (target / name).write_bytes(raw)
        entry.update(file=name, sha256=digest)
        bundle['packs'][pack['id']] = pack
    manifest['revision'] = 'content-' + hashlib.sha256(json.dumps({
        'games': manifest['games'], 'achievements': manifest['achievements']
    }, sort_keys=True).encode()).hexdigest()[:12]
    (target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    bundle['manifest'] = manifest
    bundle_path.write_text(json.dumps(bundle, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')
    print('Updated', len(manifest['games']), 'game schedules;',
          sum(len(v['timerPresets']) for v in definitions['games'].values()), 'timer presets.')


if __name__ == '__main__':
    export()
