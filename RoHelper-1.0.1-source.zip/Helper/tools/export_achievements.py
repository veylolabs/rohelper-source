"""Publishable, data-only achievement definitions; never opens account storage."""
import hashlib
import json
from pathlib import Path

def export():
    root = Path(__file__).resolve().parents[1]
    target = root.parent / 'GameCatalog'
    definitions = json.loads((root / 'content/achievements.json').read_text(encoding='utf-8'))
    raw = (json.dumps(definitions, ensure_ascii=False, separators=(',', ':')) + '\n').encode('utf-8')
    digest = hashlib.sha256(raw).hexdigest()
    name = 'achievements-' + digest[:16] + '.json'
    (target / name).write_bytes(raw)
    manifest = json.loads((target / 'manifest.json').read_text(encoding='utf-8'))
    manifest['achievements'] = {'file': name, 'sha256': digest}
    manifest['revision'] = 'content-' + hashlib.sha256(json.dumps({'games':manifest['games'],'achievements':manifest['achievements']},sort_keys=True).encode()).hexdigest()[:12]
    (target / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
    bundle_path = root / 'web/game-content.json'
    bundle = json.loads(bundle_path.read_text(encoding='utf-8'))
    bundle['manifest'] = manifest
    bundle['achievements'] = definitions
    bundle_path.write_text(json.dumps(bundle, ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')
    print('Exported', len(definitions['entries']), 'public achievements:', name)

if __name__ == '__main__':
    export()
