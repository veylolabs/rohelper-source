"""Build and validate distributable archives before updating release metadata."""
import hashlib
import json
import pathlib
import tempfile
import zipfile
from release_privacy import audit_archive

root = pathlib.Path(__file__).resolve().parents[1]
version = json.loads((root / 'version.json').read_text(encoding='utf-8'))['version']
out = root.parent / 'Output'
build = out / ('RoHelper-' + version)
names = ['RoHelper.exe', 'WebView2Loader.dll', 'README.md', 'LICENSE', 'LICENSES', 'web', 'update', 'update-files.json']
excluded = {'__pycache__', 'node_modules', 'helper-data', 'dev-data', 'roster-data', '.git',
            'webview', 'login-webview', 'app-updates', 'sab-backups'}
excluded_files = {'workspace.json', 'workspace.previous.json', 'sessions.bin', 'sessions.previous.bin',
                  'accounts.json', 'activity.json', 'activity.previous.json', 'remembered-unlock.v1.dat'}

def append(archive, path, name):
    if path.is_symlink():
        raise RuntimeError('Release input contains a symbolic link')
    info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(info, path.read_bytes())

reports = []
with tempfile.TemporaryDirectory(prefix='rohelper-package-', dir=out) as stage:
    for kind in ('portable', 'source'):
        target = pathlib.Path(stage) / ('RoHelper-' + version + '-' + kind + '.zip')
        with zipfile.ZipFile(target, 'w', zipfile.ZIP_DEFLATED) as archive:
            if kind == 'portable':
                for name in names:
                    item = build / name
                    if not item.exists():
                        raise RuntimeError('Required application file is missing: ' + name)
                    for path in sorted([item] if item.is_file() else item.rglob('*')):
                        if path.is_file():
                            append(archive, path, (pathlib.Path('RoHelper') / path.relative_to(build)).as_posix())
            else:
                for path in sorted(root.rglob('*')):
                    relative = path.relative_to(root)
                    if path.is_file() and not any(part.lower() in excluded for part in relative.parts) and path.name.lower() not in excluded_files and path.suffix.lower() not in ('.obj', '.pdb', '.ilk'):
                        append(archive, path, (pathlib.Path('Helper') / relative).as_posix())
        reports.append(audit_archive(target, root))
    # Neither final archive is replaced until both pass.
    for report in reports:
        (pathlib.Path(stage) / report['file']).replace(out / report['file'])
        print(report['file'], report['bytes'], 'bytes; release privacy gate passed')

release = out / ('RoHelper-' + version + '-portable.zip')
target = root.parent / 'AppReleases'
target.mkdir(exist_ok=True)
notes = (root / 'RELEASE-NOTES.txt').read_text(encoding='utf-8').strip()
manifest = dict(schema=1, version=version, platform='windows-x86', url='https://github.com/veylolabs/rohelper-releases/releases/download/v' + version + '/' + release.name, sha256=hashlib.sha256(release.read_bytes()).hexdigest(), size=release.stat().st_size, notes=notes)
(target / 'latest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
(target / 'SHA256SUMS.txt').write_text(''.join(report['sha256'] + '  ' + report['file'] + '\n' for report in reports if report['file'].endswith('-portable.zip')), encoding='utf-8')
source_dir = root.parent / 'SourceReleases'
source_dir.mkdir(exist_ok=True)
source_report = next(report for report in reports if report['file'].endswith('-source.zip'))
import shutil
shutil.copyfile(out / source_report['file'], source_dir / source_report['file'])
source_url = 'https://github.com/veylolabs/rohelper-source/raw/refs/heads/main/' + source_report['file']
(target / 'SOURCE.txt').write_text('Corresponding source for RoHelper ' + version + '\nGPL-3.0; source is hosted separately from application downloads.\n' + source_url + '\nSHA-256: ' + source_report['sha256'] + '\n', encoding='utf-8')
report_dir = out / 'RoHelper-tests'
report_dir.mkdir(exist_ok=True)
(report_dir / ('release-privacy-' + version + '.json')).write_text(json.dumps({'version': version, 'archives': reports}, indent=2) + '\n', encoding='utf-8')
print('Verified app manifest and SHA256SUMS generated.')
