#pragma once
#include "Clients.h"
#include <psapi.h>
#include <pdh.h>
#include <pdhmsg.h>
#include <condition_variable>
#include <thread>
#pragma comment(lib,"pdh.lib")
#pragma comment(lib,"psapi.lib")

namespace ClientResources {
using json=nlohmann::json;
inline std::string Key(const RosterClients::Client& c){return std::to_string(c.pid)+"|"+c.token;}
inline double CpuPercent(ULONGLONG before,ULONGLONG after,ULONGLONG elapsed,unsigned processors){return elapsed&&processors&&after>=before?std::clamp(double(after-before)/double(elapsed*10000ULL)/processors*100,0.0,100.0):-1;}
inline DWORD InstancePid(const std::wstring& name){if(name.rfind(L"pid_",0)!=0)return 0;auto end=name.find(L'_',4);if(end==std::wstring::npos)return 0;auto part=name.substr(4,end-4);if(part.empty()||!std::all_of(part.begin(),part.end(),[](wchar_t c){return c>=L'0'&&c<=L'9';}))return 0;try{auto n=std::stoull(part);return n<=MAXDWORD?static_cast<DWORD>(n):0;}catch(...){return 0;}}
inline std::map<std::wstring,double> CounterArray(PDH_HCOUNTER counter){
 std::map<std::wstring,double> result;if(!counter)return result;DWORD size=0,count=0;
 if(PdhGetFormattedCounterArrayW(counter,PDH_FMT_DOUBLE,&size,&count,nullptr)!=PDH_MORE_DATA||size>16*1024*1024)return result;
 std::vector<unsigned char> buffer(size);auto rows=reinterpret_cast<PDH_FMT_COUNTERVALUE_ITEM_W*>(buffer.data());
 if(PdhGetFormattedCounterArrayW(counter,PDH_FMT_DOUBLE,&size,&count,rows)!=ERROR_SUCCESS)return result;
 for(DWORD i=0;i<count;++i){const auto& v=rows[i].FmtValue;if(rows[i].szName&&(v.CStatus==PDH_CSTATUS_VALID_DATA||v.CStatus==PDH_CSTATUS_NEW_DATA)&&std::isfinite(v.doubleValue)&&v.doubleValue>=0)result[rows[i].szName]=v.doubleValue;}
 return result;
}
class Sampler {
 struct Previous{ULONGLONG cpu=0,at=0;};
 std::mutex mutex;std::condition_variable wake;std::thread worker;bool stopping=false;std::vector<RosterClients::Client> clients;json latest=json::object();
 void Run(){
  PDH_HQUERY query=nullptr;PDH_HCOUNTER gpu=nullptr,pids=nullptr,workingSets=nullptr,privateBytes=nullptr;
  if(PdhOpenQueryW(nullptr,0,&query)==ERROR_SUCCESS){
   auto add=[&](const wchar_t* path,PDH_HCOUNTER& counter){if(PdhAddEnglishCounterW(query,path,0,&counter)!=ERROR_SUCCESS)counter=nullptr;};
   add(L"\\GPU Engine(*)\\Utilization Percentage",gpu);add(L"\\Process(*)\\ID Process",pids);add(L"\\Process(*)\\Working Set",workingSets);add(L"\\Process(*)\\Private Bytes",privateBytes);
  }
  std::map<std::string,Previous> previous;const auto processors=std::max<DWORD>(1,GetActiveProcessorCount(ALL_PROCESSOR_GROUPS));
  for(;;){std::vector<RosterClients::Client> list;{std::unique_lock<std::mutex> lock(mutex);if(wake.wait_for(lock,std::chrono::seconds(3),[&]{return stopping;}))break;list=clients;}
   try{
    std::map<DWORD,double> gpuValues,ramValues,privateValues;
    if(query&&PdhCollectQueryData(query)==ERROR_SUCCESS){
     for(auto& e:CounterArray(gpu)){auto pid=InstancePid(e.first);if(pid)gpuValues[pid]=std::max(gpuValues[pid],std::min(100.0,e.second));}
     const auto ids=CounterArray(pids),ram=CounterArray(workingSets),bytes=CounterArray(privateBytes);
     for(auto& e:ids)if(e.second>0&&e.second<=MAXDWORD){auto pid=static_cast<DWORD>(e.second);if(ram.count(e.first))ramValues[pid]=ram.at(e.first);if(bytes.count(e.first))privateValues[pid]=bytes.at(e.first);}
    }
    const auto now=GetTickCount64();json result=json::object();std::set<std::string> alive;
    for(auto& c:list){const auto key=Key(c);alive.insert(key);json sample={{"sampledAtTick",now},{"cpu",nullptr},{"ram",nullptr},{"gpu",nullptr}};
     RosterClients::Handle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,c.pid));
     if(process.value&&RosterClients::Token(process.value)==c.token&&RosterClients::IsRoblox(process.value)){
      FILETIME created{},exited{},kernel{},user{};if(GetProcessTimes(process.value,&created,&exited,&kernel,&user)){auto cpu=RosterClients::Stamp(kernel)+RosterClients::Stamp(user);auto before=previous.find(key);if(before!=previous.end()){auto value=CpuPercent(before->second.cpu,cpu,now-before->second.at,processors);if(value>=0)sample["cpu"]=value;}previous[key]={cpu,now};}
      // PDH values avoid SIZE_T truncation when this x86 app monitors a 64-bit
      // Roblox process using more than 4 GB. Missing counters remain unknown.
      if(ramValues.count(c.pid))sample["ram"]=ramValues[c.pid];if(privateValues.count(c.pid))sample["privateBytes"]=privateValues[c.pid];
      if(gpuValues.count(c.pid))sample["gpu"]=gpuValues[c.pid];
     }
     result[key]=std::move(sample);
    }
    for(auto it=previous.begin();it!=previous.end();)if(!alive.count(it->first))it=previous.erase(it);else ++it;
    {std::lock_guard<std::mutex> lock(mutex);latest=std::move(result);}
   }catch(...){std::lock_guard<std::mutex> lock(mutex);latest=json::object();}
  }
  if(query)PdhCloseQuery(query);
 }
public:
 Sampler():worker([this]{Run();}){}
 ~Sampler(){{std::lock_guard<std::mutex> lock(mutex);stopping=true;}wake.notify_one();if(worker.joinable())worker.join();}
 void Watch(const std::vector<RosterClients::Client>& value){std::lock_guard<std::mutex> lock(mutex);clients=value;}
 json Read(){std::lock_guard<std::mutex> lock(mutex);auto out=latest;auto now=GetTickCount64();for(auto& p:out.items())if(now-p.value().value("sampledAtTick",0ULL)>12000){p.value()["cpu"]=nullptr;p.value()["ram"]=nullptr;p.value()["gpu"]=nullptr;p.value().erase("privateBytes");}return out;}
};
}
