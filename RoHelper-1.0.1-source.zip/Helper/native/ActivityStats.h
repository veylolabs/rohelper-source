#pragma once
#include "SafeStorage.h"
#include "AchievementContent.h"
#include <ctime>

namespace ActivityStats {
using json=nlohmann::json;
inline constexpr long long hour=3600000,day=24*hour;
inline const std::vector<std::string> counters={"antiAfkInputs","macroCycles","inputFailures","focusFailures"};
inline long long Wall(){FILETIME ft{};GetSystemTimeAsFileTime(&ft);return (static_cast<long long>((static_cast<ULONGLONG>(ft.dwHighDateTime)<<32)|ft.dwLowDateTime)-116444736000000000LL)/10000;}
inline ULONGLONG Awake(){ULONGLONG ticks=0;return QueryUnbiasedInterruptTime(&ticks)?ticks/10000:GetTickCount64();}
inline double N(const json& d,const std::string& key){return d.value(key,0.0);}
inline void Add(json& d,const std::string& key,double value){d[key]=N(d,key)+value;}
inline void Max(json& d,const std::string& key,double value){d[key]=std::max(N(d,key),value);}
inline json Empty(){return {{"schema",1},{"startedAt",0},{"updatedAt",0},{"totals",json::object()},{"accounts",json::object()},{"active",json::object()},{"history",json::array()},{"days",json::object()},{"hours",json::object()},{"unlocks",json::object()},{"preferences",{{"dailyGoalMs",8*hour},{"pinned",json::array()}}}};}
inline void Validate(const json& d){
 if(d.at("schema")!=1||d.dump().size()>64*1024*1024)throw std::runtime_error("Invalid activity statistics.");
 for(auto key:{"totals","accounts","active","days","hours","unlocks","preferences"})if(!d.at(key).is_object())throw std::runtime_error("Invalid activity statistics.");
 if(!d.at("history").is_array()||d["active"].size()>5000||d["accounts"].size()>100000||d["unlocks"].size()>10000)throw std::runtime_error("Activity storage exceeds its supported size.");
 auto nonnegative=[](const json& values){for(auto& e:values.items())if(!e.value().is_number()||!std::isfinite(e.value().get<double>())||e.value()<0||e.value()>1e30)throw std::runtime_error("Invalid activity counter.");};
 nonnegative(d["totals"]);
 auto session=[&](const json& s){if(!s.at("userId").is_string()||!std::regex_match(s["userId"].get<std::string>(),std::regex("[1-9][0-9]{0,23}"))||!s.at("metrics").is_object()||!s.at("counters").is_object()||!s.at("baseline").is_object()||!s.at("elapsedMs").is_number()||s["elapsedMs"]<0||!s.at("startedAt").is_number_integer()||!s.at("lastSeenAt").is_number_integer())throw std::runtime_error("Invalid session summary.");nonnegative(s["counters"]);};
 for(auto& s:d["active"].items())session(s.value());for(auto& s:d["history"])session(s);
 for(auto key:{"hours","days"})for(auto& b:d[key].items()){if(!std::regex_match(b.key(),std::regex("[0-9]{1,16}"))||!b.value().is_object())throw std::runtime_error("Invalid activity timeline.");nonnegative(b.value());}
 for(auto& u:d["unlocks"].items())if(!u.value().at("at").is_number_integer()||!u.value().at("definition").is_object())throw std::runtime_error("Invalid saved achievement.");
 auto& p=d["preferences"];if(!p.at("dailyGoalMs").is_number()||p["dailyGoalMs"]<hour/4||p["dailyGoalMs"]>1000*hour||!p.at("pinned").is_array()||p["pinned"].size()>4)throw std::runtime_error("Invalid activity preferences.");for(auto& id:p["pinned"])if(!id.is_string()||id.get<std::string>().size()>80)throw std::runtime_error("Invalid pinned achievement.");
}
inline void Metric(json& into,const json& sample,double weight){
 for(auto key:{"cpu","ram","gpu"})if(sample.contains(key)&&sample[key].is_number()&&std::isfinite(sample[key].get<double>())&&sample[key]>=0){const auto v=sample[key].get<double>();Add(into,std::string(key)+"Sum",v*weight);Add(into,std::string(key)+"Ms",weight);Max(into,std::string(key)+"Peak",v);}
}
struct Observation{std::string key,userId;json counters=json::object(),resources=json::object();std::string health="stopped";long long lastAntiAfkAt=0;};
struct Book {
 json data=Empty();std::filesystem::path path;std::string error;bool blocked=false,dirty=false,primed=false;ULONGLONG lastAwake=0,lastSave=0;long long lastWall=0;
 explicit Book(const std::filesystem::path& dir):path(dir/L"activity.json"){
  if(std::filesystem::exists(path))try{data=json::parse(SafeStorage::Read(path));Validate(data);for(auto& s:data["active"].items())s.value()["baseline"]=json::object();}catch(...){blocked=true;error="Activity statistics could not be read. The original file is preserved; account data is unaffected.";}
 }
 void Save(bool force=false){if(blocked||!dirty||(!force&&lastAwake-lastSave<30000))return;try{Validate(data);if(std::filesystem::exists(path))SafeStorage::Write(path.parent_path()/L"activity.previous.json",SafeStorage::Read(path));SafeStorage::Write(path,data.dump());lastSave=lastAwake;dirty=false;error.clear();}catch(const std::exception&){error="Activity statistics could not be saved. RoHelper will retry; keep it open until this clears.";}}
 void Timeline(long long start,long long end,int count,const json& resource){
  for(auto scale:{hour,day}){auto& table=data[scale==hour?"hours":"days"];for(auto t=start;t<end;){auto bucket=t/scale*scale,until=std::min(end,bucket+scale);auto& row=table[std::to_string(bucket)];if(row.is_null())row=json::object();double duration=double(until-t);Add(row,"observedMs",duration);Add(row,"combinedMs",duration*count);if(count)Add(row,"activeMs",duration);Max(row,"peakAccounts",count);Metric(row,resource,duration);t=until;}}
  // Hourly detail stays for 90 days; daily totals and resource summaries persist.
  for(auto it=data["hours"].begin();it!=data["hours"].end();)if(std::stoll(it.key())<end-90*day)it=data["hours"].erase(it);else ++it;
 }
 void Observe(ULONGLONG awake,long long wall,const std::vector<Observation>& observations){
  if(blocked)return;double dt=primed&&awake>=lastAwake?double(awake-lastAwake):0;
  const auto wallDelta=wall-lastWall;
  // Never credit app downtime, sleep, or a long unobserved sampling gap. Wall
  // time determines graph placement, unbiased time determines earned runtime.
  if(dt>15000||wallDelta<0||std::abs(double(wallDelta)-dt)>2000)dt=0;
  std::map<std::string,const Observation*> current;std::set<std::string> users;
  for(auto& o:observations)if(!o.userId.empty()&&users.insert(o.userId).second)current[o.key]=&o;
  int continuouslyObserved=0;json fleet=json::object();int cpuCount=0,ramCount=0,gpuCount=0;double cpu=0,ram=0,gpu=0;
  for(auto it=data["active"].begin();it!=data["active"].end();){if(!current.count(it.key())||it.value()["userId"]!=current.at(it.key())->userId){auto ended=it.value();ended["endedAt"]=ended["lastSeenAt"];ended["endReason"]=primed?"Client no longer observed":"Monitoring interrupted";data["history"].push_back(ended);it=data["active"].erase(it);}else ++it;}
  for(auto& item:current){const auto& o=*item.second;bool exists=data["active"].contains(o.key);auto& s=data["active"][o.key];
   auto& account=data["accounts"][o.userId];if(account.is_null())account=json::object();
   if(!exists){s={{"userId",o.userId},{"startedAt",wall},{"lastSeenAt",wall},{"elapsedMs",0},{"metrics",json::object()},{"counters",json::object()},{"baseline",json::object()},{"lastAntiAfkAt",0},{"health","stopped"}};Add(data["totals"],"sessions",1);Add(account,"sessions",1);}
   const double credit=exists?dt:0;if(credit){++continuouslyObserved;Add(s,"elapsedMs",credit);Add(account,"combinedMs",credit);Add(data["totals"],"combinedMs",credit);Max(account,"longestSessionMs",N(s,"elapsedMs"));Max(data["totals"],"longestSessionMs",N(s,"elapsedMs"));Metric(s["metrics"],o.resources,credit);if(!account.contains("metrics"))account["metrics"]=json::object();Metric(account["metrics"],o.resources,credit);if(o.health=="paused"){Add(s["counters"],"pausedMs",credit);Add(account,"pausedMs",credit);Add(data["totals"],"pausedMs",credit);}}
   for(auto& key:counters){double next=N(o.counters,key),before=N(s["baseline"],key),delta=next>=before?next-before:next;Add(s["counters"],key,delta);Add(account,key,delta);Add(data["totals"],key,delta);s["baseline"][key]=next;}
   if(o.lastAntiAfkAt>0)s["lastAntiAfkAt"]=o.lastAntiAfkAt;
   s["lastSeenAt"]=wall;s["health"]=o.health;s["currentResources"]=o.resources;account["lastSeenAt"]=wall;
   if(credit){if(o.resources.value("cpu",json()).is_number()){cpu+=o.resources["cpu"].get<double>();++cpuCount;}if(o.resources.value("ram",json()).is_number()){ram+=o.resources["ram"].get<double>();++ramCount;}if(o.resources.value("gpu",json()).is_number()){gpu=std::max(gpu,o.resources["gpu"].get<double>());++gpuCount;}}
  }
  // Do not treat partial process coverage as full fleet resource usage.
  if(cpuCount&&cpuCount==continuouslyObserved)fleet["cpu"]=std::min(100.0,cpu);if(ramCount&&ramCount==continuouslyObserved)fleet["ram"]=ram;if(gpuCount&&gpuCount==continuouslyObserved)fleet["gpu"]=gpu;
  if(dt){Timeline(wall-static_cast<long long>(dt),wall,continuouslyObserved,fleet);if(continuouslyObserved)Add(data["totals"],"wallActiveMs",dt);}
  Max(data["totals"],"peakAccounts",current.size());data["totals"]["uniqueAccounts"]=data["accounts"].size();
  double activeDays=0,best=0,streak=0;long long previous=-1;
  for(auto& bucket:data["days"].items())if(N(bucket.value(),"combinedMs")>0){auto date=std::stoll(bucket.key());streak=previous>=0&&date==previous+day?streak+1:1;best=std::max(best,streak);previous=date;++activeDays;}
  data["totals"]["activeDays"]=activeDays;data["totals"]["bestStreak"]=best;
  if(!data["startedAt"].get<long long>())data["startedAt"]=wall;data["updatedAt"]=wall;lastAwake=awake;lastWall=wall;primed=true;dirty=true;
 }
 void Evaluate(const json& definitions,const json& workspace){
  if(blocked||definitions.is_null())return;auto metrics=data["totals"];
  metrics["savedMacros"]=workspace.value("macros",json::array()).size();std::set<std::string> games;double items=0;
  auto count=[&](const json& rows){if(rows.is_array())for(auto& i:rows)if(i.is_object())items+=i.value("quantity",1.0);};
  for(auto& a:workspace.at("accounts"))if(a.contains("gameData"))for(auto& g:a["gameData"].items()){games.insert(g.key());auto& d=g.value();if(d.contains("inventory"))count(d["inventory"]);if(d.contains("gearInventory"))count(d["gearInventory"]);if(d.contains("items"))count(d["items"]);if(d.contains("inventories")&&d["inventories"].is_object())for(auto& group:d["inventories"].items())count(group.value());}
  metrics["trackedGames"]=games.size();metrics["catalogedItems"]=items;data["milestoneMetrics"]=metrics;
  for(auto& a:definitions["entries"]){auto id=a["id"].get<std::string>();if(!data["unlocks"].contains(id)&&N(metrics,a["metric"])>=a["target"].get<double>()){data["unlocks"][id]={{"at",Wall()},{"definition",a}};dirty=true;}}
 }
 json Public(size_t historyLimit=250)const{auto result=data;const auto& all=data["history"];result["history"]=json::array();for(size_t i=all.size()>historyLimit?all.size()-historyLimit:0;i<all.size();++i)result["history"].push_back(all[i]);result["historyCount"]=all.size();result["error"]=error;result["blocked"]=blocked;result["unsaved"]=dirty;return result;}
};
}
