#pragma once
#include <set>
#include <regex>
#include <cmath>
namespace AchievementContent {
using json=nlohmann::json;
inline const std::set<std::string> metrics={"combinedMs","wallActiveMs","sessions","peakAccounts","longestSessionMs","activeDays","bestStreak","antiAfkInputs","macroCycles","uniqueAccounts","savedMacros","trackedGames","catalogedItems"};
inline void Validate(const json& d){
 if(d.at("schema")!=1||!d.at("revision").is_string()||d["revision"].get<std::string>().size()>100||!d.at("entries").is_array()||d["entries"].size()>1000||d.dump().size()>2*1024*1024)throw std::runtime_error("Invalid achievement catalog.");
 std::set<std::string> ids;
 for(auto& a:d["entries"]){
  auto text=[&](const char* k,size_t n){if(!a.contains(k)||!a[k].is_string()||a[k].get<std::string>().size()>n)throw std::runtime_error("Invalid achievement text.");};
  text("id",80);text("name",100);text("description",500);text("group",80);text("metric",60);
  if(!std::regex_match(a["id"].get<std::string>(),std::regex("[a-z0-9][a-z0-9-]{0,79}"))||!ids.insert(a["id"]).second||!metrics.count(a["metric"]))throw std::runtime_error("Invalid achievement ID or condition.");
  if(!a.at("target").is_number()||!std::isfinite(a["target"].get<double>())||a["target"]<=0||a["target"]>1e15||!a.at("points").is_number_integer()||a["points"]<0||a["points"]>10000)throw std::runtime_error("Invalid achievement target or points.");
  auto& icon=a.at("icon");if(!icon.at("color").is_string()||!std::regex_match(icon["color"].get<std::string>(),std::regex("#[a-fA-F0-9]{6}"))||!icon.at("paths").is_array()||icon["paths"].empty()||icon["paths"].size()>8)throw std::runtime_error("Invalid achievement icon.");
  for(auto& p:icon["paths"])if(!p.is_string()||p.get<std::string>().size()>3000||!std::regex_match(p.get<std::string>(),std::regex("[MmLlHhVvCcSsQqTtAaZz0-9., +eE-]+")))throw std::runtime_error("Invalid achievement drawing.");
 }
}
}
