"""Build the isolated app; version.json is the single version source."""
import json,pathlib,subprocess,shutil,sys,hashlib
from toolchain import vcvars32
root=pathlib.Path(__file__).resolve().parents[1]
version=json.loads((root/'version.json').read_text())['version']
parts=[int(x) for x in version.split('.')];assert len(parts)==3
out=root.parent/'Output'/('RoHelper-'+version);out.mkdir(parents=True,exist_ok=True)
(root/'Version.h').write_text('#pragma once\n#define ROHELPER_VERSION "'+version+'"\n')
(root/'res.rc').write_text('''#include <windows.h>
1 ICON "native/rohelper.ico"
VS_VERSION_INFO VERSIONINFO
 FILEVERSION %s
 PRODUCTVERSION %s
 FILEOS VOS_NT_WINDOWS32
 FILETYPE VFT_APP
BEGIN
 BLOCK "StringFileInfo"
 BEGIN
  BLOCK "040904b0"
  BEGIN
   VALUE "FileDescription", "RoHelper"
   VALUE "FileVersion", "%s"
   VALUE "ProductName", "RoHelper"
   VALUE "ProductVersion", "%s"
   VALUE "OriginalFilename", "RoHelper.exe"
  END
 END
 BLOCK "VarFileInfo"
 BEGIN
  VALUE "Translation", 0x409, 1200
 END
END
'''%(','.join(map(str,parts+[0])),','.join(map(str,parts+[0])),version,version))
lua=root/'vendor/lua';objects=out/'lua-objects';objects.mkdir(exist_ok=True)
cfiles=[p for p in lua.glob('*.c') if p.name not in ('lua.c','luac.c')]
def q(p):return '"'+str(p)+'"'
lua_rsp=out/'lua.rsp';lua_rsp.write_text('/nologo /O2 /MD /c /TC /Fo'+q(str(objects)+'/')+'\n'+'\n'.join(q(p) for p in cfiles))
native_sources=[root/'main.cpp',root/'legacy/RobloxAPI.cpp',root/'legacy/BrowserLogin.cpp',root/'legacy/Crypto.cpp',root/'legacy/HandleCloser.cpp']
rsp=out/'native.rsp';rsp.write_text('/nologo /EHsc /MD /O2 /utf-8 /std:c++17 /DUNICODE /D_UNICODE /I'+q(root/'vendor')+' /I'+q(lua)+' /I'+q(root/'vendor/webview2/include')+' /Fo'+q(str(out)+'/')+'\n'+'\n'.join(q(p) for p in native_sources)+'\n'+q(out/'rohelper.res')+'\n'+q(out/'lua.lib')+'\n/link winhttp.lib ole32.lib advapi32.lib shell32.lib uuid.lib user32.lib gdi32.lib crypt32.lib bcrypt.lib dwmapi.lib version.lib /SUBSYSTEM:WINDOWS /OUT:'+q(out/'RoHelper.exe'))
batch=out/'compile.cmd';batch.write_text('@echo off\ncall '+q(vcvars32())+' >nul\ncd /d '+q(root)+'\nrc /nologo /fo '+q(out/'rohelper.res')+' res.rc\nif errorlevel 1 exit /b 1\nif exist '+q(out/'lua.lib')+' goto native\ncl @'+q(lua_rsp)+'\nif errorlevel 1 exit /b 1\nlib /nologo /OUT:'+q(out/'lua.lib')+' '+q(str(objects/'*.obj'))+'\nif errorlevel 1 exit /b 1\n:native\ncl @'+q(rsp)+'\nexit /b %errorlevel%\n')
subprocess.run(['cmd','/c',str(batch)],check=True,cwd=root)
shutil.copytree(root/'web',out/'web',dirs_exist_ok=True)
shutil.copyfile(root/'vendor/WebView2Loader.dll',out/'WebView2Loader.dll')
shutil.copyfile(root/'LICENSE',out/'LICENSE')
(out/'LICENSES').mkdir(exist_ok=True)
for name in ['WebView2-SDK-LICENSE.txt','nlohmann-json-MIT.txt']:shutil.copyfile(root/'vendor/LICENSES'/name,out/'LICENSES'/name)
shutil.copyfile(lua/'README',out/'LICENSES/Lua.txt')
if (root/'README.md').exists():shutil.copyfile(root/'README.md',out/'README.md')
shutil.copytree(root/'update',out/'update',dirs_exist_ok=True)
names=['RoHelper.exe','WebView2Loader.dll','README.md','LICENSE','LICENSES','web','update']
files={}
for name in names:
 item=out/name
 for p in ([item] if item.is_file() else item.rglob('*')):
  if p.is_file():files[p.relative_to(out).as_posix()]=hashlib.sha256(p.read_bytes()).hexdigest()
(out/'update-files.json').write_text(json.dumps(dict(schema=1,version=version,files=files),indent=2)+'\n',encoding='utf-8')
print('Built',out/'RoHelper.exe')
