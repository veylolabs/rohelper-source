"""Initial, local port of the existing RoRoster SAB implementation (GPL-3.0).
The resulting files are maintained as RoHelper source, not downloaded executable code.
"""
from pathlib import Path
import shutil
root=Path(__file__).resolve().parents[1];src=root.parent/'Roster';web=root/'web'/'sab';web.mkdir(exist_ok=True)
aliases='const {db,$,node,button,iconButton,input,select,label,panel,heading,empty,icon,avatar,modal,changed,render,rpc,toast,uid,navigate,openAccount,catalog}=bridge; const fatal="";'
for name in ['inventory','index-checklist','market','workspace','planning','workflows']:
    text=(src/'web'/(name+'.js')).read_text(encoding='utf-8')
    if name=='inventory':
        text=text.replace("/^assets\\/[a-zA-Z0-9_./-]+$/.test(src)","/^https:\\/\\//.test(src)")
        start=text.index(' async function load()');end=text.index(' function view()',start)
        text=text[:start]+''' function replaceCatalog(value){data=structuredClone(value);RosterCatalogOrder.apply(data);byId.clear();for(const r of data.brainrots)byId.set(r.id,r);for(const r of data.brainrots)if(r.duplicateOf&&byId.has(r.duplicateOf))byId.set(r.id,byId.get(r.duplicateOf));}\n'''+text[end:]
        text=text.replace(' load();return {',' return {replaceCatalog,edit,duplicate,remove,move,')
        # Factory registration happens before data is available; content comes from Helper's cache.
    if name=='index-checklist':
        start=text.index(" fetch('index-catalog.json')");end=text.index(' function available',start)
        text=text[:start]+text[end:]
        text=text.replace(' return {view,',' return {replaceCatalog:value=>{data=structuredClone(value);},view,')
    if name=='workflows':
        text=text[text.index('window.RosterTools='):]
        start=text.index(' async function waitSaved()')
        text=text[:start]+''' async function waitSaved(){await bridge.waitSaved();}\n return {toolbar,checkbox,tradeSelect,badge,planner,comparison,waitSaved};\n})();\n'''
    if name=='workspace':
        text=text.replace("const pages=[['accounts','Accounts'],['sab','Steal a Brainrot'],['inventory','SAB inventories'],['checklist','Session checklist'],['events','Events & timers'],['compare','Comparison'],['clients','Running clients'],['progress','Game notebooks'],['tags','Tags'],['settings','Settings'],['backups','Backups']];","const pages=[['accounts','Accounts'],['sab','Steal a Brainrot'],['inventory','SAB inventories'],['checklist','Session checklist'],['compare','Comparison'],['clients','Running clients'],['settings','Settings'],['backups','SAB backups']];")
        text=text.replace("$('.save-wrap').prepend(launch);","bridge.actions.prepend(launch);")
    (web/(name+'.js')).write_text('// Ported from local RoRoster (GPL-3.0).\nwindow.SabPortFactories.push(bridge=>{\n'+aliases+'\n'+text+'\n});\n',encoding='utf-8')
for name in ['income.js','catalog-order.js','mutation-effects.js','mutation-effects.css','market.css','planning.css','workspace.css','v16.css']:
    shutil.copyfile(src/'web'/name,web/name)
styles=(src/'web'/'style.css').read_text(encoding='utf-8').splitlines()
(web/'inventory.css').write_text('\n'.join([styles[10],*styles[16:19]])+'\n',encoding='utf-8')
native=root/'native'/'sab';native.mkdir(exist_ok=True)
for name in ['Eldorado.h','ExistCounts.h']:
    text=(src/name).read_text(encoding='utf-8').replace('#include "SafeStorage.h"','#include "../SafeStorage.h"')
    (native/name).write_text(text,encoding='utf-8')
print('Ported inventory, bulk tools, physical base layout, index, planning, comparison, market and income components.')
