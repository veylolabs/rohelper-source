"""Build public collection packs from checked wiki tables and official PS99 data.
No player accounts are read. Unknown prices/odds are never inferred.
"""
import json,pathlib,re,sys,hashlib,urllib.parse,collections
from adopt_sources import Document,Element
ROOT=pathlib.Path(__file__).resolve().parents[1];SRC=ROOT.parent/'Output/game-expansion-060';CHECKED='2026-10-18'
def read(p):return json.loads(p.read_text(encoding='utf-8'))
def slug(s):return re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')[:65]
def clean(s):
 s=re.sub(r'<[^>]+>','',s);s=re.sub(r'\[\[([^\]|]+)(?:\|([^\]]+))?\]\]',lambda m:m[2] or m[1],s);s=re.sub(r"'''?",'',s);return re.sub(r'\s+',' ',s).strip()
def cells(row):return [c for c in row.children if isinstance(c,Element) and c.tag in ['th','td']]
def grid(table):
 carry={};result=[]
 for row in table.children:
  pass
 # Only direct table rows, excluding nested table card content.
 rows=[r for r in table.all('tr') if next((p for p in parents(r) if p.tag=='table'),None) is table]
 for row in rows:
  line={k:v[0] for k,v in carry.items()};carry={k:(v[0],v[1]-1) for k,v in carry.items() if v[1]>1};col=0
  for c in cells(row):
   while col in line:col+=1
   width=min(100,int(c.attrs.get('colspan','1') or 1));height=min(100,int(c.attrs.get('rowspan','1') or 1))
   for j in range(width):
    line[col+j]=c
    if height>1:carry[col+j]=(c,height-1)
   col+=width
  result.append([line.get(i) for i in range(max(line.keys(),default=-1)+1)])
 return result
def parents(node):
 p=node.parent
 while p:yield p;p=p.parent
def art(cell):
 if not cell:return None
 for im in cell.all('img'):
  u=im.attrs.get('data-src',im.attrs.get('src',''))
  if u.startswith('https://') and not any(x in u.lower() for x in ['robux','sheckle','currency','checkmark','crossmark']):return u
 return None
def link(cell,host):
 for a in cell.all('a'):
  href=a.attrs.get('href','');title=a.attrs.get('title','')
  if href.startswith('/wiki/') and not any(x in href for x in ['File:','Category:','Template:']) and a.text():return urllib.parse.urljoin('https://'+host,href)
 return None
RARITIES=['Common','Uncommon','Unusual','Rare','Epic','Legendary','Mythical','Mythic','Divine','Prismatic','Transcendent','Secret','Super','Exclusive','Ancient','Godly','Vintage','Unique','Event','Trash','Limited','Exotic','Special','Apex','Relic','Fragment','Gem','Seed']
def dedupe(rows):
 unique={}
 for entry in rows:
  old=unique.setdefault(entry['id'],entry)
  if old is entry:continue
  for key in ['rarity','image','seedImage']:
   if not old.get(key) and entry.get(key):old[key]=entry[key]
  for key,value in entry.get('facts',{}).items():
   if key not in old['facts']:old['facts'][key]=value
 return list(unique.values())
NAMES={'name','crop','tool','bag','hat','mask','hat/mask','guard','belt','boots','item','result','pet','pet name','gear','egg','bait name','amulet','bee','gliding tool','planter','sprinkler'}
def tables(game,host,page,category):
 p=SRC/game/(slug(page)+'.json');data=read(p).get('parse',{});source='https://'+host+'/wiki/'+data.get('title',page).replace(' ','_');doc=Document(data.get('text',{}).get('*','')).root;out=[]
 contexts={};heading=['']
 def walk(n):
  if not isinstance(n,Element):return
  if n.tag in ['h2','h3','h4']:heading[0]=n.text().replace('[edit]','').strip()
  if n.tag=='table':contexts[id(n)]=heading[0]
  for child in n.children:walk(child)
 walk(doc)
 for table in doc.all('table'):
  if 'NavTable' in table.attrs.get('class',''):continue
  rows=grid(table);header=None;nameidx=None
  for row in rows:
   texts=[c.text() if c else '' for c in row]
   if any(t.lower() in NAMES for t in texts) and any(t in ['Image','Appearance','Rarity','Tier','Source','Location','Ingredients\u200e','Ability','Price','Cost','Bait','Color','Multiplier','Effect'] for t in texts):
    if category=='mutations' and not any('Multiplier' in t for t in texts):header=None;continue
    header=texts;nameidx=next((i for i,t in enumerate(texts) if t.lower() in NAMES),None);continue
   if header is None or nameidx is None or len(row)<=nameidx or not row[nameidx]:continue
   name=texts[nameidx].strip();name=re.sub(r'\[\d+\]','',name).strip()
   if not name or len(name)>110 or name.lower() in NAMES or name in ['None','N/A','—','-'] or ' • ' in name:continue
   # Names identify one row/item. Multi-item summary tables are not catalogs.
   if len(row[nameidx].all('a'))>8:continue
   facts={};image=None;seedImage=None
   for i,h in enumerate(header):
    if i>=len(row) or not row[i] or i==nameidx or not h:continue
    if h in ['Image','Appearance','Picture','Produce','Seed']:
     if h=='Seed':seedImage=art(row[i])
     else:image=image or art(row[i])
     continue
    value=texts[i]
    if value and len(value)<350 and h not in ['In-game Description','Description','Tips','Other Stats','Obtainment & Description','Obtainment','Use','Ability','Passive Abilities','Likes','Dislikes','Tokens']:facts[h]=value
   rarity=next((facts[h] for h in ['Rarity','Tier'] if facts.get(h) in RARITIES),None)
   if not rarity:rarity=next((r for r in RARITIES if contexts.get(id(table),'').lower() in [r.lower(),r.lower()+' crops',r.lower()+' pets',r.lower()+' fish']),None)
   for parent in parents(table):
    if 'wds-tab__content' not in parent.attrs.get('class','').split():continue
    outer=parent.parent;siblings=[c for c in outer.children if isinstance(c,Element) and 'wds-tab__content' in c.attrs.get('class','').split()]
    wrapper=next((c for c in outer.children if isinstance(c,Element) and 'wds-tabs__wrapper' in c.attrs.get('class','').split()),None)
    labels=[c.attrs.get('data-hash') or c.text() for c in wrapper.all('li') if 'wds-tabs__tab' in c.attrs.get('class','').split()] if wrapper else []
    if parent in siblings and len(labels)>=len(siblings):
     label=urllib.parse.unquote(labels[siblings.index(parent)] or '').replace('_',' ')
     if label in RARITIES:rarity=rarity or label
     if label in ['Unreleased','Unknown','Removed','Unobtainable']:facts['Source section']=label
   categoryFor=category
   if category=='equipment':
    first=header[nameidx].lower();categoryFor='tools' if first=='tool' else 'materials' if first=='item' else 'equipment'
   out.append(dict(id=categoryFor+'-'+slug(name),name=name,category=categoryFor,image=image or art(row[nameidx]),seedImage=seedImage,rarity=rarity,source=link(row[nameidx],host) or source,facts=facts,checkedOn=CHECKED))
 return dedupe(out)
def cards(game,host,page,category):
 d=read(SRC/game/(slug(page)+'.json'))['parse'];doc=Document(d['text']['*']).root;out=[]
 for t in doc.all('table'):
  if 'bfw-table-tooltips' not in t.attrs.get('class','') and category!='styles':continue
  rows=grid(t)
  if not rows or len(rows[0])!=1:continue
  name=rows[0][0].text()
  if not name or len(name)>80 or name.endswith('List') or 'Source' in name:continue
  links=rows[0][0].all('a');source=link(rows[0][0],host) or 'https://'+host+'/wiki/'+name.replace(' ','_');txt=t.text();tail=txt[len(name):].lstrip();rarity=next((r for r in sorted(RARITIES,key=len,reverse=True) if tail.startswith(r)),None)
  out.append(dict(id=category+'-'+slug(name),name=name,category=category,image=art(t),rarity=rarity,source=source,facts={},checkedOn=CHECKED))
 return dedupe(out)
def rods():
 d=read(SRC/'fisch/fishing-rods.json')['parse'];out=[]
 for t in Document(d['text']['*']).root.all('table'):
  rows=grid(t)
  if not rows or len(rows[0])<2 or rows[0][0].text()!='Name':continue
  for i,cell in enumerate(rows[0][1:],1):
   if not cell:continue
   name=cell.text()
   if not name or len(name)>90:continue
   facts={};image=None
   for row in rows[1:]:
    if len(row)<=i or not row[i] or not row[0]:continue
    k=row[0].text();v=row[i].text()
    if k=='Image':image=art(row[i])
    elif k and v and len(v)<160 and k not in ['Description','Passive','Passive Ability']:facts[k]=v
   out.append(dict(id='rods-'+slug(name),name=name,category='rods',rarity=None,image=image,source=link(cell,'fisch.fandom.com') or 'https://fisch.fandom.com/wiki/Fishing_Rods',facts=facts,checkedOn=CHECKED))
 return out
def mm2():
 pages={}
 for p in sorted((SRC/'mm2').glob('*-pages-*.json')):
  for row in read(p).get('query',{}).get('pages',{}).values():
   if row.get('revisions'):pages[row['pageid']]=row
 out=[]
 for id,p in pages.items():
  w=p['revisions'][0]['slots']['main']['*'];m=re.search(r'\{\{Infobox[ _](?:Item|Pet)\b(.*?)\}\}',w,re.S|re.I)
  if not m:continue
  fields=dict((k.lower(),v.strip()) for k,v in re.findall(r'^\|\s*(\w+)\s*=\s*(.*?)(?=\n\||$)',m[1],re.M|re.S));typ=clean(fields.get('type','')).lower();cat='knives' if 'knife' in typ else 'guns' if 'gun' in typ else 'pets' if 'pet' in typ or '{{infobox pet' in m[0].lower() else None
  if not cat:continue
  rarity=clean(fields.get('rarity',''));file=fields.get('image','').split('|')[0].strip()
  if '<gallery>' in file:file=file.split('<gallery>')[1].strip().split('|')[0].split('\n')[0]
  file=file if re.fullmatch(r'[^{}<>\n]+\.(?:png|webp|jpg|jpeg|gif)',file,re.I) else None
  out.append(dict(id='mm2-'+str(id),name=p['title'],category=cat,rarity=rarity if rarity in RARITIES else None,image=None,imageFile=file,source='https://murder-mystery-2.fandom.com/wiki/'+p['title'].replace(' ','_'),facts={},checkedOn=CHECKED))
 return out
def field(id,name,type='number',**values):return dict(id=id,name=name,type=type,default=False if type=='check' else '' if type=='text' else 0,**values)
def cat(id,name,stackable=True,fields=[]):return dict(id=id,name=name,stackable=stackable,fields=fields)
def number(id,name,max=1e9):return field(id,name,min=0,max=max,step=1)
def choice(id,name,options):return dict(id=id,name=name,type='select',default=options[0][0],options=[dict(id=k,name=v) for k,v in options])
def make(id,name,place,categories,entries,currencies,fields=[],**extra):
 unique={}
 for e in entries:
  if e['id'] not in unique:unique[e['id']]=e
  else:
   old=unique[e['id']];old['image']=old.get('image') or e.get('image');old['facts'].update(e.get('facts',{}));old['rarity']=old.get('rarity') or e.get('rarity')
 allowed={c['id'] for c in categories};rows=[e for e in unique.values() if e['category'] in allowed]
 for e in rows:assert re.fullmatch('[a-z0-9][a-z0-9_-]{0,79}',e['id']),e['id']
 pack=dict(schema=1,id=id,name=name,aliases=[name.replace(' ',''),id],placeIds=[place],icon='',fields=fields,inventoryEngine='collection',currencies=[dict(id=k,name=v,default=0,max=1e30) for k,v in currencies],catalogs={'collection':dict(schema=1,checkedOn=CHECKED,categories=categories,entries=sorted(rows,key=lambda e:e['name']),sources=sorted(set(e['source'].split('/wiki/')[0]+'/wiki/' for e in rows)),**extra)},sources=sorted(set(e['source'].split('/wiki/')[0]+'/wiki/' for e in rows)),contentNote='Public reference snapshot. Account ownership, balances and progress stay local. Community values are snapshots, never guaranteed sale prices. Missing facts stay unknown.',events=[],helpers=[])
 def tab(k,label,view,**rest):return dict(id=k,name=label,icon='book' if 'catalog' in view or 'index' in view else 'box',view=view,**rest)
 pack['aliases']+=dict([('grow-a-garden',['GAG']),('grow-a-garden-2',['GAG2','GAG 2']),('fisch',[]),('bee-swarm',['BSS','Bee Swarm']),('blox-fruits',['BF']),('mm2',['MM2']),('pet-simulator-99',['PS99','Pet Sim 99'])]).get(id,[])
 metadata=SRC/('roblox-'+place+'.json')
 if metadata.exists() and (SRC/'game-icons.json').exists():
  universe=read(metadata)['data'][0]['id']
  pack['icon']=next((i['imageUrl'] for i in read(SRC/'game-icons.json')['data'] if i['targetId']==universe and i['state']=='Completed'),'')
 sources=sorted(set(e['source'].split('/wiki/')[0]+'/wiki/' if '.fandom.com/wiki/' in e['source'] else e['source'] for e in rows));pack['sources']=sources+['https://www.roblox.com/games/'+place];pack['catalogs']['collection']['sources']=sources
 pack['navigation']=[tab('overview','Accounts','collection-overview'),tab('catalog','Catalog','collection-catalog'),dict(id='inventories',name='Inventories',icon='box',children=[tab('inventory-'+c['id'],c['name'],'collection-inventory',category=c['id']) for c in categories]),tab('search','Inventory search','collection-search'),tab('index','Index','collection-index'),tab('planner','Progress & planning','collection-planner'),tab('helpers','Helpers','collection-helpers'),tab('servers','Servers','servers'),tab('events','Events & timers','events')]
 (ROOT/'content/collections').mkdir(exist_ok=True);(ROOT/'content/collections'/(id+'.json')).write_text(json.dumps(pack,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(id,len(rows),collections.Counter(e['category'] for e in rows),flush=True);return pack
if __name__=='__main__':
 sys.stdout.reconfigure(encoding='utf-8');weight=number('weight','Weight (kg)');weight['step']=.001;level=number('level','Level');gifted=field('gifted','Gifted','check')
 for game,host in [('grow-a-garden','growagarden.fandom.com'),('grow-a-garden-2','growagarden2.fandom.com')]:
  entries=[]
  for page,category in [('Crops','crops'),('Pets','pets'),('Gears','gear'),('Eggs','eggs')]:entries+=tables(game,host,page,category)
  mutations=tables(game,host,'Crop Mutations' if game=='grow-a-garden' else 'Mutations','mutations');petmut=tables(game,host,'Pet Mutations','pet-mutations') if game=='grow-a-garden' else []
  opts=[('normal','Normal')]+[(e['id'],e['name']) for e in mutations];petopts=[('normal','Normal')]+[(e['id'],e['name']) for e in petmut]
  cropFields=[weight,choice('mutation','Mutation',opts)]
  if game=='grow-a-garden':cropFields=[weight,choice('variant','Growth variant',[('normal','Normal'),('gold','Gold'),('rainbow','Rainbow')]),dict(id='mutations',name='Crop mutations',type='multi',default=[],options=[dict(id=e['id'],name=e['name']) for e in mutations if e['name'] not in ['Gold','Golden','Rainbow']])]
  categories=[cat('crops','Harvested crops',False,cropFields),cat('seeds','Seeds'),cat('pets','Pets',False,[level,weight,choice('mutation','Pet mutation',petopts)]),cat('eggs','Eggs'),cat('gear','Gear')]
  entries+=[{**e,'id':'seeds-'+e['id'][6:],'name':e['name'],'category':'seeds','image':e.get('seedImage'),'facts':{k:v for k,v in e['facts'].items() if k not in ['Base Weight','Base Price']}} for e in entries if e['category']=='crops']
  pack=make(game,'Grow a Garden'+(' 2' if game.endswith('-2') else ''),'97598239454123' if game.endswith('-2') else '126884695634066',categories,entries,[('sheckles','Sheckles')],[number('garden-level','Garden level')],modifiers=mutations,petModifiers=petmut,indexCategories=['crops','pets'])
  if game=='grow-a-garden-2':pack['catalogs']['collection']['categories'][2]['fields']+=[choice('size','Size',[('normal','Normal'),('big','Big'),('mega','Mega')]),choice('variant','Variant',[('normal','Normal'),('rainbow','Rainbow')])];(ROOT/'content/collections'/(game+'.json')).write_text(json.dumps(pack,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 entries=[]
 for page,category in [('Bestiary','fish'),('Baits','bait'),('Boats','boats')]:entries+=tables('fisch','fisch.fandom.com',page,category)
 entries+=rods();mutations=tables('fisch','fisch.fandom.com','Mutations','mutations');enchants=tables('fisch','fisch.fandom.com','Enchantments','enchants')
 make('fisch','Fisch','16732694052',[cat('fish','Fish',False,[weight,choice('mutation','Mutation',[('normal','Normal')]+[(e['id'],e['name']) for e in mutations])]),cat('rods','Rods',False,[choice('enchant','Enchantment',[('none','None')]+[(e['id'],e['name']) for e in enchants])]),cat('bait','Baits'),cat('boats','Boats',False)],entries,[('cash','C$')],[level],modifiers=mutations,enchantments=enchants)
 entries=[]
 for page,category in [('Blox Fruits','fruits'),('Swords','swords'),('Guns','guns'),('Accessories','accessories'),('Materials','materials'),('Fighting Styles','styles')]:entries+=cards('blox-fruits','blox-fruits.fandom.com',page,category)
 make('blox-fruits','Blox Fruits','2753915549',[cat('fruits','Stored fruits',True,[field('permanent','Permanent','check')]),cat('swords','Swords',False,[number('mastery','Mastery',600),field('upgraded','Upgraded','check')]),cat('guns','Guns',False,[number('mastery','Mastery',600),field('upgraded','Upgraded','check')]),cat('accessories','Accessories',False),cat('materials','Materials'),cat('styles','Fighting styles',False,[number('mastery','Mastery',600)])],entries,[('money','Money'),('fragments','Fragments')],[level,number('sea','Sea',3),number('bounty','Bounty / honor')])
 entries=tables('bee-swarm','bee-swarm-simulator.fandom.com','Bees','bees')+tables('bee-swarm','bee-swarm-simulator.fandom.com','Items','equipment')
 recipes=tables('bee-swarm','bee-swarm-simulator.fandom.com','Blender','materials')
 entries+=recipes
 make('bee-swarm','Bee Swarm Simulator','1537690962',[cat('bees','Hive bees',False,[level,gifted,number('slot','Hive slot',50)]),cat('tools','Tools',False),cat('equipment','Equipment',False),cat('materials','Materials')],entries,[('honey','Honey'),('tickets','Tickets')],[number('bee-slots','Hive capacity',50)],recipes=recipes,hive=True)
 make('mm2','Murder Mystery 2','142823291',[cat('knives','Knives'),cat('guns','Guns'),cat('pets','Pets')],mm2(),[('coins','Coins'),('gems','Gems')],[level,number('prestige','Prestige')])
