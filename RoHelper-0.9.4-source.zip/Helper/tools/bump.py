"""Explicit release bump; rebuild after calling: bump.py patch|minor|major."""
import json,pathlib,sys
p=pathlib.Path(__file__).resolve().parents[1]/'version.json'
v=list(map(int,json.loads(p.read_text())['version'].split('.')))
i={'major':0,'minor':1,'patch':2}[sys.argv[1]];v[i]+=1
for j in range(i+1,3):v[j]=0
p.write_text(json.dumps({'version':'.'.join(map(str,v))})+'\n')
print('.'.join(map(str,v)))
