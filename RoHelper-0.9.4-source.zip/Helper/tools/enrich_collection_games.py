"""Resolve exact MM2 art/value associations and official Pet Simulator 99 data."""
import json,pathlib,re,sys,urllib.parse,concurrent.futures,hashlib
from adopt_sources import Document
from build_collection_games import make,cat,number,choice,field,read,slug,clean,ROOT,SRC,CHECKED,grid,Element
from research_game_expansion import request
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def mm2_values(fetch=False):
 p=ROOT/'content/collections/mm2.json';pack=read(p);rows=pack['catalogs']['collection']['entries'];byname={re.sub(r'[^a-z0-9]','',e['name'].lower()):e for e in rows};snapshots=[]
 for path in SRC.glob('supreme-*.html'):
  doc=Document(path.read_text(encoding='utf-8')).root;source='https://supremevalues.com/mm2/'+path.stem[8:]
  for cell in [e for e in doc.all('div') if 'itemcolumn' in e.attrs.get('class','').split()]:
   head=next((e for e in cell.all('div') if e.attrs.get('class')=='itemhead'),None)
   if not head:continue
   name=head.text();v=cell.attrs.get('data-value','')
   if not re.fullmatch(r'[0-9]+(?:\.[0-9]+)?',v):continue
   im=next((i for i in cell.all('img') if i.attrs.get('alt')==name),None)
   snapshots.append(dict(name=name,value=float(v),image=urllib.parse.urljoin(source,im.attrs['src']) if im else None,source=source))
 missing=list(dict.fromkeys(s['name'] for s in snapshots if re.sub(r'[^a-z0-9]','',s['name'].lower()) not in byname));folder=SRC/'mm2-extra';folder.mkdir(exist_ok=True)
 for i in range(0,len(missing),45):
  names=missing[i:i+45];path=folder/('pages-'+str(i)+'.json')
  if not path.exists() and fetch:path.write_bytes(request('https://murder-mystery-2.fandom.com/api.php?'+urllib.parse.urlencode(dict(action='query',titles='|'.join(names),redirects=1,prop='revisions',rvprop='content',rvslots='main',format='json'))))
  if not path.exists():continue
  for page in read(path).get('query',{}).get('pages',{}).values():
   if not page.get('revisions'):continue
   w=page['revisions'][0]['slots']['main']['*'];m=re.search(r'\{\{Infobox[ _](?:Item|Pet)\b(.*?)\}\}',w,re.S|re.I)
   if not m:continue
   fs=dict((k.lower(),v.strip()) for k,v in re.findall(r'^\|\s*(\w+)\s*=\s*(.*?)(?=\n\||$)',m[1],re.M|re.S));typ=clean(fs.get('type','')).lower();catid='knives' if 'knife' in typ else 'guns' if 'gun' in typ else 'pets' if 'pet' in typ else None
   if not catid:continue
   if any(e['id']=='mm2-'+str(page['pageid']) for e in rows):continue
   name=page['title'];e=dict(id='mm2-'+str(page['pageid']),name=name,category=catid,rarity=clean(fs.get('rarity','')) or None,image=None,imageFile=fs.get('image','').split('|')[0].strip(),source='https://murder-mystery-2.fandom.com/wiki/'+name.replace(' ','_'),facts={},checkedOn=CHECKED);rows.append(e);byname[re.sub(r'[^a-z0-9]','',name.lower())]=e
 rows=list({e['id']:e for e in rows}.values());byname={re.sub(r'[^a-z0-9]','',e['name'].lower()):e for e in rows}
 for s in snapshots:
  e=byname.get(re.sub(r'[^a-z0-9]','',s['name'].lower()))
  if not e:continue
  e.update(tradeValue=s['value'],valueUnit='SV',valueSource=s['source'],valueCheckedOn=CHECKED)
  if not e.get('image') and s['image']:e.update(image=s['image'],imageSource=s['source'])
 # Resolve remaining exact infobox files through the wiki API; no filename guessing.
 files=list(dict.fromkeys(e['imageFile'].replace('_',' ') for e in rows if not e.get('image') and re.fullmatch(r'[^{}<>\n]+\.(?:png|jpg|webp|gif|jpeg)',e.get('imageFile') or '',re.I)));metadata={}
 for i in range(0,len(files),45):
  path=folder/('image-files-'+hashlib.sha256('|'.join(files[i:i+45]).encode()).hexdigest()[:12]+'.json')
  if not path.exists() and fetch:path.write_bytes(request('https://murder-mystery-2.fandom.com/api.php?'+urllib.parse.urlencode(dict(action='query',titles='|'.join('File:'+f for f in files[i:i+45]),prop='imageinfo',iiprop='url',format='json'))))
  if path.exists():
   for page in read(path).get('query',{}).get('pages',{}).values():
    if page.get('imageinfo'):metadata[page['title'][5:].replace('_',' ').lower()]=page['imageinfo'][0]['url']
 for path in folder.glob('image-files-*.json'):
  for page in read(path).get('query',{}).get('pages',{}).values():
   if page.get('imageinfo'):metadata[page['title'][5:].replace('_',' ').lower()]=page['imageinfo'][0]['url']
 for e in rows:
  if not e.get('image') and e.get('imageFile'):e['image']=metadata.get(e['imageFile'].replace('_',' ').lower())
 # Stable IDs win when a source table references an article more than once.
 pack['catalogs']['collection']['entries']=list({e['id']:e for e in rows}.values());pack['catalogs']['collection']['valueUnit']='SV';save(p,pack)
 print('MM2',len(pack['catalogs']['collection']['entries']),'entries;',sum(e.get('tradeValue') is not None for e in rows),'Supreme snapshots;',sum(bool(e.get('image')) for e in rows),'exact art links',flush=True)
def ps99():
 images=read(SRC/'ps99-image-map.json');rap=read(SRC/'ps99-rap.json')['data'];rmap={}
 for r in rap:
  c=r['configData'];v=('golden' if c.get('pt')==1 else 'rainbow' if c.get('pt')==2 else 'normal')+('-shiny' if c.get('sh') else '')+('-'+str(c['tn']) if c.get('tn') else '')
  if c.get('cv') or c.get('pt',0) not in [0,1,2]:continue
  rmap.setdefault((r['category'],c.get('id')), {})[v]=r['value']
 specs=[('Pets','pets','Pets','Pet'),('Eggs','eggs','Eggs','Egg'),('Potions','potions','Potions','Potion'),('Enchants','enchants','Enchantments','Enchant'),('Charms','charms','Charms','Charm'),('MiscItems','items','Items','Misc'),('Hoverboards','hoverboards','Hoverboards','Hoverboard'),('Fruits','fruits','Fruits','Fruit'),('Boosts','boosts','Boosts','Boost'),('Lootboxes','lootboxes','Lootboxes','Lootbox'),('Boxes','boxes','Boxes','Box')];entries=[];cats=[]
 for collection,category,title,raptype in specs:
  cats.append(cat(category,title,category!='pets',([choice('variant','Variant',[('normal','Normal'),('golden','Golden'),('rainbow','Rainbow')]),field('shiny','Shiny','check')] if category=='pets' else [])))
  for row in read(SRC/('ps99-'+collection.lower()+'.json'))['data']:
   d=row['configData'];name=d.get('name') or d.get('DisplayName') or row['configName'];id=category+'-'+slug(row['configName']);id=id[:66]+'-'+hashlib.sha256(row['configName'].encode()).hexdigest()[:8]
   asset=d.get('thumbnail') or d.get('icon') or d.get('Icon');image=images.get(str(asset).replace('rbxassetid://','')) if asset else None
   e=dict(id=id,name=name,source='https://ps99.biggamesapi.io/api/collection/'+collection,image=image,category=category,rarity=d.get('rarity',{}).get('DisplayName') if isinstance(d.get('rarity'),dict) else None,facts={'Collection':row.get('category',collection)},checkedOn=CHECKED,configName=row['configName'])
   rapid=row['configName'].split(' | ')[-1];values=rmap.get((raptype,row['configName'])) or rmap.get((raptype,rapid))
   if values:e.update(tradeValues=values,valueUnit='Diamonds (RAP)',valueSource='https://ps99.biggamesapi.io/api/rap',valueCheckedOn=CHECKED)
   if category=='pets':
    e['variantImages']={v:images.get(str(d.get(k,'')).replace('rbxassetid://','')) for v,k in [('normal','thumbnail'),('golden','goldenThumbnail')]}
    e['indexObtainable']=d.get('indexObtainable') is not False
   tiers=d.get('Tiers')
   if category in ['potions','enchants'] and isinstance(tiers,list):
    for n,tier in enumerate(tiers,1):
     if not isinstance(tier,dict):continue
     e2=dict(e);e2['id']=e['id']+'-'+str(n);e2['name']=tier.get('DisplayName') or name+' '+str(n);e2['image']=images.get(str(tier.get('Icon','')).replace('rbxassetid://',''));e2['rarity']=tier.get('Rarity',{}).get('DisplayName');e2['facts']={**e['facts'],'Tier':n}
     v=(values or {}).get('normal-'+str(n));e2.pop('tradeValues',None)
     if v is not None:e2['tradeValue']=v
     entries.append(e2)
   else:entries.append(e)
 make('pet-simulator-99','Pet Simulator 99','8737899170',cats,entries,[('diamonds','Diamonds'),('coins','Coins')],[number('rank','Rank'),number('rebirths','Rebirths'),number('zone','Highest zone')],valueUnit='Diamonds (RAP)',indexCategories=['pets'],indexVariantField='variant',indexVariants=[dict(id=v,name=n) for v,n in [('normal','Normal'),('golden','Golden'),('rainbow','Rainbow'),('normal-shiny','Shiny'),('golden-shiny','Shiny Golden'),('rainbow-shiny','Shiny Rainbow')]])
def recipes():
 p=ROOT/'content/collections/bee-swarm.json';pack=read(p);c=pack['catalogs']['collection'];w=read(SRC/'bee-swarm/blender.json')['parse']['wikitext']['*'];rows=[]
 for chunk in re.split(r'^\|-\s*$',w,flags=re.M)[1:]:
  result=re.search(r'\{\{Color\|([^}|]+)',chunk);costs=re.findall(r'\{\{Cost\|([^}|]+)\|([0-9,]+)\}\}',chunk)
  if not result or not costs:continue
  target=next((e for e in c['entries'] if e['name']==result[1]),None)
  if not target:continue
  ingredients=[]
  for name,n in costs:
   e=next((e for e in c['entries'] if e['name']==name),None)
   if e:ingredients.append(dict(itemId=e['id'],name=name,quantity=int(n.replace(',',''))))
  if len(ingredients)==len(costs):rows.append(dict(itemId=target['id'],name=target['name'],ingredients=ingredients,durationSeconds=300,source='https://bee-swarm-simulator.fandom.com/wiki/Blender'))
 c['recipes']=rows;save(p,pack);print('Verified Bee Swarm recipes:',len(rows),flush=True)

def equipment_plans():
 p=ROOT/'content/collections/bee-swarm.json';pack=read(p);c=pack['catalogs']['collection'];byname={e['name']:e for e in c['entries']}
 w=read(SRC/'bee-swarm/items.json')['parse']['wikitext']['*']
 for chunk in re.split(r'^\|-\s*$',w,flags=re.M)[1:]:
  before=chunk.split('{{Cost',1)[0];target=next((byname[n] for n in re.findall(r'\[\[([^\]|]+)(?:\|[^\]]+)?\]\]',before) if n in byname and byname[n]['category'] in ['tools','equipment']),None)
  if not target or '{{Cost' not in chunk:continue
  expanded=re.sub(r'\{\{Hover\|[^|{}]+\|([0-9,]+)\}\}',r'\1',chunk)
  costs=re.findall(r'\{\{Cost\|([^}|]+)\|([0-9,]+)\}\}',expanded)
  if len(costs)!=expanded.count('{{Cost'):continue
  ingredients=[];currencies={};valid=True
  for name,n in costs:
   n=int(n.replace(',',''))
   if name in ['Honey','Ticket']:currencies['honey' if name=='Honey' else 'tickets']=n
   elif name in byname:ingredients.append(dict(itemId=byname[name]['id'],name=name,quantity=n))
   else:valid=False
  if valid and costs:c['recipes'].append(dict(itemId=target['id'],name=target['name'],ingredients=ingredients,currencies=currencies,source='https://bee-swarm-simulator.fandom.com/wiki/Items'))
 capacity=next(f for f in pack['fields'] if f['id']=='bee-slots');capacity.update(default=25,min=25)
 save(p,pack);print('Bee Swarm crafting / equipment plans:',len(c['recipes']),flush=True)
 p=ROOT/'content/collections/blox-fruits.json';pack=read(p);c=pack['catalogs']['collection'];byname={e['name']:e for e in c['entries']};rows=[]
 doc=Document(read(SRC/'blox-fruits/upgrading.json')['parse']['text']['*']).root
 for table in doc.all('table'):
  data=grid(table)
  if not data or [cell.text() for cell in data[0]][:6]!=['Icon','Name','Rarity','Type','Recipe','Effects']:continue
  for row in data[1:]:
   if len(row)<6:continue
   target=byname.get(row[1].text());ingredients=[];valid=True
   if not target:continue
   parts=[x for x in row[4].children if isinstance(x,Element)]
   for part in parts:
    links=part.all('a');names=[a.attrs.get('title') for a in links if a.attrs.get('title') in byname];quantity=part.text().replace(',','').strip()
    if len(set(names))!=1 or not quantity.isdigit():valid=False;break
    e=byname[names[0]];ingredients.append(dict(itemId=e['id'],name=e['name'],quantity=int(quantity)))
   if valid and ingredients:rows.append(dict(itemId=target['id'],name=target['name'],ingredients=ingredients,source='https://blox-fruits.fandom.com/wiki/Upgrading',effect=row[5].text()))
 c['recipes']=rows;save(p,pack);print('Verified Blox Fruits upgrade plans:',len(rows),flush=True)
def source_evidence():
 for f in (ROOT/'content/collections').glob('*.json'):
  p=read(f);id=p['id'];evidence=[];paths=sorted((SRC/id).glob('*.json'))
  if id=='pet-simulator-99':paths=[x for x in sorted(SRC.glob('ps99-*.json')) if x.name!='ps99-image-map.json']
  for path in paths:
   data=read(path);parsed=data.get('parse',{})
   if parsed:
    host=p['catalogs']['collection']['entries'][0]['source'].split('/wiki/')[0];url=host+'/wiki/'+parsed.get('title',path.stem).replace(' ','_')
   elif id=='pet-simulator-99':
    name=path.stem[5:];url='https://ps99.biggamesapi.io/api/rap' if name=='rap' else next((e['source'] for e in p['catalogs']['collection']['entries'] if e['source'].lower().endswith('/'+name)),None)
   else:continue
   if url:evidence.append(dict(source=url,checkedOn=CHECKED,responseSha256=hashlib.sha256(path.read_bytes()).hexdigest()))
  p['catalogs']['collection']['sourceEvidence']=evidence
  p['catalogs']['collection']['attribution']='Public reference facts adapted from the linked wiki authors under CC BY-SA 4.0 where applicable; artwork remains owned by its creators. Official BIG Games data and Supreme Values snapshots remain attributed to their respective sources.'
  save(f,p)
if __name__=='__main__':sys.stdout.reconfigure(encoding='utf-8');mm2_values('--fetch' in sys.argv);ps99();recipes();equipment_plans();source_evidence()
