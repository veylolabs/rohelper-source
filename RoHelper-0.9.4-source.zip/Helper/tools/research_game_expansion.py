"""Download public catalog evidence only. Never opens account storage."""
import json,pathlib,urllib.request,urllib.parse,concurrent.futures
root=pathlib.Path(__file__).resolve().parents[2];out=root/'Output/game-expansion-060';out.mkdir(exist_ok=True)
pages={
 'grow-a-garden':('growagarden.fandom.com',['Crops','Pets','Gears','Crop Mutations','Pet Mutations','Eggs','Cosmetics']),
 'fisch':('fisch.fandom.com',['Bestiary','Fishing Rods','Baits','Mutations','Enchantments','Boats']),
 'blox-fruits':('blox-fruits.fandom.com',['Blox Fruits','Swords','Guns','Accessories','Materials','Fighting Styles','Upgrading']),
 'bee-swarm':('bee-swarm-simulator.fandom.com',['Bees','Tools','Accessories','Items','Amulet','Blender','Planter','Equipment','Treats','Monsters','Dispenser']),
 'mm2':('murder-mystery-2.fandom.com',['Weapons','Knives','Guns','Pets','Rarities'])}
def request(url):
 return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 RoHelper public catalog research'}),timeout=40).read()
def fetch(job):
 game,host,page=job;folder=out/game;folder.mkdir(exist_ok=True);path=folder/(page.lower().replace(' ','-')+'.json')
 try:
  if not path.exists():path.write_bytes(request('https://'+host+'/api.php?'+urllib.parse.urlencode(dict(action='parse',page=page,prop='text|wikitext',format='json',redirects=1))))
  d=json.loads(path.read_bytes());p=d.get('parse',{});return game,page,len(p.get('text',{}).get('*','')),d.get('error',{}).get('code','ok')
 except Exception as e:return game,page,str(e)
if __name__=='__main__':
 jobs=[(game,host,page) for game,(host,ls) in pages.items() for page in ls]
 with concurrent.futures.ThreadPoolExecutor(max_workers=7) as pool:
  for row in pool.map(fetch,jobs):print(row)
 for name,url in [('ps99-pets','https://ps99.biggamesapi.io/api/collection/Pets'),('ps99-rap','https://ps99.biggamesapi.io/api/rap'),('ps99-eggs','https://ps99.biggamesapi.io/api/collection/Eggs')]:
  try:
   p=out/(name+'.json')
   if not p.exists():p.write_bytes(request(url))
   d=json.loads(p.read_bytes());print(name,'keys',list(d)[:6], 'size',p.stat().st_size)
  except Exception as e:print(name,str(e))
