"""Compile and run the isolated native checks with the discovered C++ toolchain."""
import json
import pathlib
import subprocess
import sys
from toolchain import vcvars32

root = pathlib.Path(__file__).resolve().parents[1]
out = root.parent / 'Output/RoHelper-tests'
out.mkdir(parents=True, exist_ok=True)
version = json.loads((root / 'version.json').read_text(encoding='utf-8'))['version']
q = lambda value: '"' + str(value) + '"'
batch = out / 'compile-tests.cmd'
batch.write_text(
    '@echo off\ncall ' + q(vcvars32()) + ' >nul\n'
    'cl /nologo /EHsc /MD /utf-8 /std:c++17 /DUNICODE /D_UNICODE '
    '/I ' + q(root / 'vendor') + ' /I ' + q(root / 'vendor/lua') +
    ' /Fo' + q(str(out) + '/') + ' ' + q(root / 'tests/native.cpp') + ' ' +
    q(root / 'legacy/Crypto.cpp') + ' ' + q(root / 'legacy/HandleCloser.cpp') + ' ' +
    q(root.parent / ('Output/RoHelper-' + version) / 'lua.lib') +
    ' /link shell32.lib uuid.lib ole32.lib winhttp.lib crypt32.lib bcrypt.lib '
    'advapi32.lib user32.lib gdi32.lib dwmapi.lib /OUT:' + q(out / 'native.exe') +
    '\nexit /b %errorlevel%\n', encoding='utf-8')
subprocess.run(['cmd', '/c', str(batch)], check=True, cwd=root)
subprocess.run([str(out / 'native.exe'), *sys.argv[1:]], check=True, cwd=root)
if not sys.argv[1:]:
    automation_batch = out / 'compile-automation-tests.cmd'
    automation_batch.write_text(
        '@echo off\ncall ' + q(vcvars32()) + ' >nul\n'
        'cl /nologo /O2 /EHsc /MD /utf-8 /std:c++17 /DUNICODE /D_UNICODE '
        '/I ' + q(root / 'vendor') + ' /I ' + q(root / 'vendor/lua') +
        ' /Fo' + q(str(out) + '/') + ' ' + q(root / 'tests/automation.cpp') + ' ' +
        q(root.parent / ('Output/RoHelper-' + version) / 'lua.lib') +
        ' /link user32.lib ole32.lib shell32.lib advapi32.lib crypt32.lib bcrypt.lib '
        '/OUT:' + q(out / 'automation.exe') + '\nexit /b %errorlevel%\n', encoding='utf-8')
    subprocess.run(['cmd', '/c', str(automation_batch)], check=True, cwd=root)
    subprocess.run([str(out / 'automation.exe')], check=True, cwd=root)
