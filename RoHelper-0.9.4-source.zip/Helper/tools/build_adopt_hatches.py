"""Build exact egg hatch pools from saved Fandom API articles, never from origins.

Usage: python tools/build_adopt_hatches.py snapshot-directory
Only current Obtainable Pets tables are used; former pools are excluded.
"""
import json,pathlib,re,sys,hashlib
from adopt_sources import Document
root=pathlib.Path(__file__).resolve().parents[1]
catalog=json.loads((root/'content/adopt-me.json').read_text(encoding='utf-8'))
snapshots=pathlib.Path(sys.argv[1]);entries=catalog['entries']
norm=lambda s:re.sub(r'[^a-z0-9]','',s.lower())
pets={norm(e['name']):e for e in entries if e['category']=='pets'}
out={'schema':1,'checkedOn':'2026-10-17','pools':{},'sources':[]}
for egg in [e for e in entries if e['category']=='eggs']:
 path=snapshots/('egg-'+egg['id']+'.json');d=json.loads(path.read_text(encoding='utf-8'))['parse'];w=d['wikitext']['*']
 sections=re.split(r'^==\s*(.*?)\s*==\s*$',w,flags=re.M);names=[];conditions={}
 for i in range(1,len(sections),2):
  if not re.fullmatch(r'(?:Current )?Obtainable Pets?|Christmas Egg Pets',sections[i]):continue
  # First linked cell of each wikitext table row is the pet, never a prose link.
  for row in re.split(r'^\|-.*$',sections[i+1],flags=re.M)[1:]:
   m=re.search(r'^\|\s*\[\[([^\]|]+)(?:\|([^\]]+))?\]\](.*)',row,re.M)
   if not m:continue
   name=m[2] or re.sub(r' \(Pet\)$','',m[1]);names.append(name)
   condition=re.search(r'<sub>\((.*?)\)</sub>',m[3])
   if condition:conditions[name]=re.sub(r'\[\[([^\]|]+)(?:\|([^\]]+))?\]\]',lambda x:x[2] or x[1],condition[1])
 if egg['name']=='Christmas Future Egg':
  assert '100% chance of hatching an [[Eggnog Dog]]' in w
  names=['Eggnog Dog']
 ids=[];missing=[];notes={}
 for name in names:
  ref=pets.get(norm(name))
  if not ref:missing.append(name);continue
  if ref['id'] not in ids:ids.append(ref['id'])
  if name in conditions:notes[ref['id']]=conditions[name]
 source='https://adoptme.fandom.com/wiki/'+d['title'].replace(' ','_')
 pool={'petIds':ids,'source':source,'checkedOn':out['checkedOn'],'snapshotSha256':hashlib.sha256(path.read_bytes()).hexdigest(),'section':'Current obtainable pets','complete':bool(ids) and not missing}
 if notes:pool['conditions']=notes
 if missing:pool['unmappedPets']=missing
 out['pools'][egg['id']]=pool;out['sources'].append(source)
 print(egg['name'],len(ids),'unmapped:',missing)
assert len(out['pools'])==41
cracked=next(e for e in entries if e['name']=='Cracked Egg')
assert len(out['pools'][cracked['id']]['petIds'])==14
assert pets['dog']['id'] not in out['pools'][cracked['id']]['petIds']
(root/'content/adopt-hatch-pools.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
