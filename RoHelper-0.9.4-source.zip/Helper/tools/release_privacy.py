"""Fail-closed release checks. Diagnostics identify locations/rules, never matched values.

This is a release hygiene gate, not a proof that arbitrary secrets cannot be encoded.
Third-party license/author notices are deliberately retained.
"""
import base64
import hashlib
import json
import os
import pathlib
import re
import struct
import zipfile

PRIVATE_PARTS = {
    'helper-data', 'dev-data', 'roster-data', 'webview', 'login-webview',
    'app-updates', 'sab-backups', '.git', '.aws', '.codex', '.ssh',
}
PRIVATE_FILES = {
    'workspace.json', 'workspace.previous.json', 'sessions.bin', 'sessions.previous.bin',
    'accounts.json', 'remembered-unlock.v1.dat', 'cookies', 'login data', 'local state',
    'history', 'web data', 'session-import.pending.bin',
}
RULES = {
    'absolute-local-path': re.compile(r'(?i)(?<![a-z0-9%])(?:[a-z]:[\\/]+(?=[a-z0-9_. -])|/(?:home|Users)/[\w.-]+/|\\\\[a-z0-9_.-]+\\(?:Users|home)\\)'),
    'roblox-session': re.compile(r'_\|WARNING:-DO-NOT-SHARE-THIS[^\s\x22\x27]{30,}'),
    'private-key': re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
    'github-token': re.compile(r'\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})'),
    'aws-key': re.compile(r'\b(?:AKIA|ASIA)[A-Z0-9]{16}\b'),
    'jwt': re.compile(r'\beyJ[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}\.[A-Za-z0-9_-]{15,}'),
    'discord-webhook': re.compile(r'https://(?:\w+\.)?discord(?:app)?\.com/api/webhooks/\d+/[\w-]{30,}'),
}
PNG = b'\x89PNG\r\n\x1a\n'
IMAGE = re.compile(r'data:image/(?:png|webp|jpeg);base64,([A-Za-z0-9+/=]+)')


def private_name(name):
    parts = pathlib.PurePosixPath(name.replace('\\', '/')).parts
    return any(p.lower() in PRIVATE_PARTS for p in parts) or any(
        p.lower() in PRIVATE_FILES or p.lower().endswith('.rhsessions.json') or p.lower() == '.env' or p.lower().startswith('.env.')
        or pathlib.PurePosixPath(p).suffix.lower() in ('.db', '.sqlite', '.sqlite3', '.dmp', '.log')
        for p in parts)


def png_chunks(data):
    if not data.startswith(PNG):
        return
    pos = len(PNG)
    while pos < len(data):
        if pos + 12 > len(data):
            raise ValueError('Truncated PNG chunk')
        size = struct.unpack('>I', data[pos:pos + 4])[0]
        end = pos + 12 + size
        if end > len(data):
            raise ValueError('Truncated PNG payload')
        kind = data[pos + 4:pos + 8]
        yield kind, data[pos + 8:pos + 8 + size], data[pos:end]
        pos = end


def timestamp_chunk(kind, payload):
    if kind == b'tIME':
        return True
    return kind in (b'tEXt', b'iTXt', b'zTXt') and payload.split(b'\0', 1)[0].lower() in (
        b'date:create', b'date:modify', b'date:timestamp', b'creation time', b'modification time')


def strip_png_timestamps(data):
    if not data.startswith(PNG):
        return data
    return PNG + b''.join(raw for kind, payload, raw in png_chunks(data)
                          if not timestamp_chunk(kind, payload))


def clean_public_images(value):
    if isinstance(value, dict):
        result = {key: clean_public_images(child) for key, child in value.items()}
        image, artwork = result.get('image'), result.get('artwork')
        if isinstance(image, str) and image.startswith('data:image/png;base64,') and isinstance(artwork, dict) and 'sha256' in artwork:
            digest = hashlib.sha256(base64.b64decode(image.split(',', 1)[1], validate=True)).hexdigest()
            if artwork['sha256'] != digest:
                artwork.setdefault('sourceSha256', artwork['sha256'])
                artwork['sha256'] = digest
        return result
    if isinstance(value, list):
        return [clean_public_images(child) for child in value]
    if isinstance(value, str) and value.startswith('data:image/png;base64,'):
        prefix, encoded = value.split(',', 1)
        return prefix + ',' + base64.b64encode(strip_png_timestamps(
            base64.b64decode(encoded, validate=True))).decode('ascii')
    return value


def inspect(name, data, dependency=False):
    findings = []
    if private_name(name):
        findings.append('private-data-filename')
    texts = [data.decode('utf-8', errors='replace')]
    if data.startswith(b'MZ'):
        for offset in (0, 1):
            texts.append(data[offset:].decode('utf-16le', errors='replace'))
        if b'RSDS' in data and not dependency:
            findings.append('app-debug-record')
    for rule, pattern in RULES.items():
        if dependency and rule == 'absolute-local-path':
            continue  # Only byte-identical vendored dependencies qualify.
        if any(pattern.search(text) for text in texts):
            findings.append(rule)
    for term in filter(None, os.environ.get('ROHELPER_PRIVATE_IDENTITY_TERMS', '').split(',')):
        if any(term.casefold() in text.casefold() for text in texts):
            findings.append('private-identity-term')
    if name.lower().endswith('.json'):
        try:
            obj = json.loads(data)
        except (ValueError, UnicodeError):
            findings.append('invalid-json')
        else:
            def visit(value):
                if isinstance(value, dict):
                    if value.get('format') == 'rohelper-account-sessions':
                        findings.append('session-export-document')
                    if any(isinstance(value.get(key), str) and value[key] for key in ('cookie', '.ROBLOSECURITY')):
                        findings.append('saved-session-value')
                    if isinstance(value.get('recovery'), dict) and any(value['recovery'].get(key) for key in ('email', 'phone', 'other')):
                        findings.append('saved-recovery-contact')
                    if isinstance(value.get('accounts'), list) and value['accounts']:
                        findings.append('saved-accounts')
                    if isinstance(value.get('username'), str) and value['username']:
                        findings.append('saved-username')
                    for child in value.values():
                        visit(child)
                elif isinstance(value, list):
                    for child in value:
                        visit(child)
            visit(obj)
    images = [data] if data.startswith(PNG) else []
    for match in IMAGE.finditer(texts[0]):
        try:
            images.append(base64.b64decode(match[1], validate=True))
        except ValueError:
            findings.append('invalid-embedded-image')
    for image in images:
        if image.startswith(PNG):
            try:
                if any(timestamp_chunk(kind, payload) for kind, payload, _ in png_chunks(image)):
                    findings.append('image-timestamp-metadata')
            except ValueError:
                findings.append('invalid-png')
    return sorted(set(findings))


def audit_archive(archive, source_root):
    approved = {
        ('Helper/vendor/WebView2Loader.dll' if archive.name.endswith('-source.zip')
         else 'RoHelper/WebView2Loader.dll'): (source_root / 'vendor/WebView2Loader.dll').read_bytes()
    }
    findings = []
    with zipfile.ZipFile(archive) as z:
        if z.testzip() is not None:
            raise RuntimeError('Release ZIP failed integrity verification')
        names = z.namelist()
        if len(names) != len(set(name.casefold() for name in names)):
            raise RuntimeError('Duplicate release ZIP paths')
        for entry in z.infolist():
            name = entry.filename
            if name.startswith(('/', '\\')) or '..' in pathlib.PurePosixPath(name).parts:
                raise RuntimeError('Unsafe release ZIP path')
            data = z.read(entry)
            dependency = name in approved and data == approved[name]
            for rule in inspect(name, data, dependency):
                findings.append({'file': name, 'rule': rule})
    if findings:
        raise RuntimeError('Release privacy gate rejected package:\n' + '\n'.join(
            item['file'] + ': ' + item['rule'] for item in findings))
    return {'file': archive.name, 'entries': len(names), 'bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'findings': []}
