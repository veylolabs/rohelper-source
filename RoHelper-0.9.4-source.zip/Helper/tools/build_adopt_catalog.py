"""Build public Adopt Me facts from saved, inspectable source snapshots.

AMTV records are read from its rendered item chooser, never executed. Wiki tables
supplement items absent from its tradeable-item list. No account files are read.
"""
import json,re,pathlib,hashlib,unicodedata
from adopt_sources import Document

ROOT=pathlib.Path(__file__).resolve().parents[1]
SRC=ROOT.parent/'Output/adopt-research'
OUT=ROOT/'content';OUT.mkdir(exist_ok=True)
CHECKED='2026-10-17'
norm=lambda s:re.sub('[^a-z0-9]','',unicodedata.normalize('NFKD',s).lower())
read=lambda p:json.loads(p.read_text(encoding='utf8'))
cats=[('pets','Pets'),('eggs','Eggs'),('pet-wear','Pet wear'),('strollers','Strollers'),('food','Food & potions'),('vehicles','Vehicles'),('toys','Toys'),('gifts','Gifts'),('stickers','Stickers'),('houses','Houses'),('dolls','Dolls')]
groups=dict(animalgrid='pets',foodgrid='food',vehiclegrid='vehicles',petweargrid='pet-wear',toygrid='toys',stickergrid='stickers',housegrid='houses',strollergrid='strollers',giftgrid='gifts')
rows={};byname={}
for raw in read(SRC/'amtv-records.json'):
    args=raw['choices'].removeprefix('getNeonChoices(').removesuffix(')').split(', ')
    assert len(args)==27 and all(re.fullmatch(r'\d+(?:\.\d+)?',a) for a in args[:25])
    sourceid=args[0];id='amtv-'+sourceid
    if id in rows:continue
    category=groups[raw['group']];pet=args[25]=='true'
    if category=='pets' and not pet:category='eggs' if re.search(r'\bEgg$',raw['name']) else 'dolls'
    parts=re.fullmatch(re.escape(raw['name'])+r' - (Common|Uncommon|Rare|Ultra-Rare|Legendary|Event) from (.+)',raw['description'])
    assert parts,raw['name']
    values=[float(v)/250 for v in args[1:13]]
    row=dict(id=id,name=raw['name'],category=category,rarity=parts[1],origin=parts[2],image='https://adoptmetradingvalues.com/'+raw['image'].replace('\\','/'),source='https://adoptmetradingvalues.com/what-is-worth.php?id='+sourceid,imageSource='https://adoptmetradingvalues.com/',checkedOn=CHECKED,valueCheckedOn=CHECKED,valueSource='https://adoptmetradingvalues.com/',valueUnit='RP',tradeValues=values if pet else values[:1],variants=pet,demand=raw['demand'],buy=None,sell=None,added=None)
    rows[id]=row;byname[(category,norm(row['name']))]=row

def wikirow(name,href,category,rarity=None,image=None):
    if category in ['pets','eggs'] and ('dolls',norm(name)) in byname:return byname[('dolls',norm(name))]
    # Exact article evidence identifies both historical spellings as one pet.
    aliases={'Malayan Tapir':'Malaysian Tapir','Woolly Rhino':'Wooly Rhino'}
    if category=='pets' and name in aliases and (category,norm(aliases[name])) in byname:
        found=byname[(category,norm(aliases[name]))];found['aliases']=[found['name']];found['name']=name;found['nameSource']='https://adoptmewiki.com'+href;byname[(category,norm(name))]=found;return found
    found=byname.get((category,norm(name)))
    if found:return found
    # A parenthesized "Pet" only disambiguates wiki articles from NPCs.
    found=byname.get((category,norm(re.sub(r' \(Pet\)$','',name))))
    if found:return found
    if not href or not href.startswith('/wiki/'):return None
    id='wiki-'+href.strip('/').split('/')[-1]
    if id in rows:return rows[id]
    row=dict(id=id,name=name,category=category,rarity=rarity,image=image,source='https://adoptmewiki.com'+href,imageSource='https://adoptmewiki.com'+href,checkedOn=CHECKED,tradeValues=[],variants=category=='pets' and name not in ['Scoob','Pet Rock','Burtaur','Pumpkin (Pet)'],buy=None,sell=None,added=None)
    rows[id]=row;byname[(category,norm(name))]=row;return row

def imagefrom(cells):
    for cell in cells:
        for im in cell.all('img'):
            src=im.attrs.get('src','');alt=im.attrs.get('alt','')
            if src.startswith('https://') and not any(w in alt.lower() for w in ['bucks','robux','candy','gingerbread','logo','currency','ticket']):return src
    return None

evidence=[]
for file,cat in [('wiki-eggs','eggs'),('wiki-vehicles','vehicles'),('wiki-strollers','strollers'),('wiki-food','food'),('wiki-toys','toys'),('wiki-gifts','gifts'),('wiki-stickers','stickers')]:
    path=SRC/(file+'.html');doc=Document(path.read_text(encoding='utf8')).root
    for table in doc.all('table'):
        trs=table.all('tr')
        if not trs:continue
        headers=[c.text() for c in trs[0].all('th')]
        ni=next((i for i,h in enumerate(headers) if h in ['Egg','Name','Stroller','Food','Drinks','Candy','Potion','Toy','Gift','Sticker']),None)
        if ni is None:continue
        ri=next((i for i,h in enumerate(headers) if h=='Rarity'),None)
        for tr in trs[1:]:
            cells=[c for c in tr.children if getattr(c,'tag',None) in ['td','th']]
            if len(cells)!=len(headers) or ni>=len(cells):continue # ambiguous rowspans are not guessed
            links=[a for a in cells[ni].all('a') if a.attrs.get('href','').startswith('/wiki/')]
            if not links:continue
            a=links[0];rarity=cells[ri].text() if ri is not None else None
            if rarity not in ['Common','Uncommon','Rare','Ultra-Rare','Legendary','Event']:rarity=None
            row=wikirow(a.text(),a.attrs['href'],cat,rarity,imagefrom([cells[i] for i,h in enumerate(headers) if h=='Image']+[cells[ni]]))
            if not row:continue
            if not row.get('rarity') and rarity:row['rarity']=rarity
            # Record the source price verbatim as a bounded reference; do not turn
            # a chest/egg purchase price into the contained pet's direct buy cost.
            pi=next((i for i,h in enumerate(headers) if h=='Price'),None)
            if pi is not None:
                price=cells[pi].text()
                currencies=[im.attrs.get('alt','') for im in cells[pi].all('img')]
                row.setdefault('purchaseReference',price[:240]);row.setdefault('purchaseCurrencies',currencies[:8])
    evidence.append(dict(source='https://adoptmewiki.com/wiki/'+file[5:]+'/',sha256=hashlib.sha256(path.read_bytes()).hexdigest()))

# The first pets table is a complete rarity list, including temporary/event pets.
doc=Document((SRC/'wiki-pets.html').read_text(encoding='utf8')).root
rarity=None
for tr in doc.all('table')[0].all('tr')[1:]:
    for cell in [c for c in tr.children if getattr(c,'tag',None)=='td']:
        if cell.text() in ['Common','Uncommon','Rare','Ultra-Rare','Legendary','Event']:rarity=cell.text();continue
        for a in cell.all('a'):
            if '\ufffd' in a.text():continue # damaged upstream title, don't create a duplicate
            wikirow(a.text(),a.attrs.get('href'), 'pets',rarity)

# Exact official 2026 event facts. End dates and minigame payouts are unknown.
pages={k:Document((SRC/(v+'.html')).read_text(encoding='utf8')).root for k,v in dict(ghost='halloween-ghost-gallery-notes',hauntlet='halloween-hauntlet-returns-notes',spotlight='halloween-stitches-spotlight-notes').items()}
eventspecs=[('ghost-gallery','Ghost Gallery & Crypt','ghost','2026-10-03',[
 ('Jumpscare','pets','Rare',40000,'Candy Corn'),('Mummy Spider','pets','Rare',None,None),('Jacobin Pigeon','pets','Common',4000,'Candy Corn'),('Jester Dragon','pets','Legendary',1000,'Robux'),('Nest Stroller','strollers','Rare',11000,'Candy Corn'),('Ghoul Mobile','vehicles','Rare',44500,'Candy Corn'),('Orbweaver Glider','vehicles','Ultra-Rare',59000,'Candy Corn'),('Ghost Blaster','toys','Ultra-Rare',7800,'Candy Corn'),('Ghost Blaster Grappling Hook','toys','Rare',5500,'Candy Corn'),('Prop Whip','toys','Uncommon',1950,'Candy Corn'),('Spirit Goggles','pet-wear','Rare',4800,'Candy Corn'),('Jumpscare Badge','pet-wear','Common',600,'Candy Corn'),('Black Water Boots','pet-wear','Uncommon',2100,'Candy Corn')],['Find ghosts hiding in furniture with your pet, then use the blaster to defeat the Ghost Gallery boss.','Crypt: daily tasks award 4 Rusty Keys; defeating the Ghost Gallery boss awards 1. Clear 4 Crypt levels for Mummy Spider.','Nest: place 8 Twigs, then Jacobin Pigeon costs 4,000 Candy Corn.']),
 ('hauntlet-2','Hauntlet 2 & Poltergeist Box','hauntlet','2026-10-09',[
 ('Bolt','pets','Uncommon',10000,'Candy Corn'),('Skelicorn','pets','Legendary',120000,'Candy Corn'),('Bubblegeist','pets','Legendary',None,None),('Bobageist','pets','Ultra-Rare',None,None),('Caramelgeist','pets','Uncommon',None,None),('Poltergeist Box','gifts','Legendary',13000,'Candy Corn'),('Bellhop Hat','pet-wear','Uncommon',2300,'Candy Corn'),('Mechanical Bolt Mask','pet-wear','Rare',5200,'Candy Corn'),('Mecha Heart Badge','pet-wear','Common',850,'Candy Corn'),('Back Luggage','pet-wear','Uncommon',2150,'Candy Corn'),('Hotel Bell Throw Toy','toys','Common',650,'Candy Corn'),('Pro Ghost Blaster','toys','Legendary',29,'Robux'),('Escaped Hauntlet, Too Sticker','stickers','Legendary',None,None)],['Stay on the same path as friends to remain together. Room items help everyone in that room.','Phone: Bolt always lies; avoid following the arrow. Rainbow Wand clears all ghosts in the room.','Keys unlock paths; Golden Keys match doors. Heart Potion heals; Golden Heart adds a heart; Ghost Potion protects for one door.','Find the Lightning Lever in the Crypt to access Skelicorn. Poltergeist Box odds: Bubblegeist 4%, Bobageist 20%, Caramelgeist 76%.']),
 ('stitches-spotlight',"Stitches’ Spotlight",'spotlight','2026-10-16',[
 ('Stitches','pets','Ultra-Rare',70000,'Candy Corn'),('Boohoo','pets','Rare',32000,'Candy Corn'),('Shoebill','pets','Uncommon',18000,'Candy Corn'),('Copycat','pets','Legendary',600,'Robux'),('Jester Dragon Mask','pet-wear','Ultra-Rare',8100,'Candy Corn'),('Stitches Neck Ruffle','pet-wear','Rare',5000,'Candy Corn'),('Creepy Clown Car','vehicles','Uncommon',23000,'Candy Corn')],['Collect Candy Corn around the tent; the spotlight removes collected Candy Corn when it catches you.','Use both platform levels and cover behind target boards. Stitches can knock the boards down.','Help the noisy hotel guests settle using items from the Crypt before taking Shoebill home.'])]
helpers=[]
for id,name,key,starts,rewards,steps in eventspecs:
    doc=pages[key];slug={'ghost':'halloween-ghost-gallery-notes','hauntlet':'halloween-hauntlet-returns-notes','spotlight':'halloween-stitches-spotlight-notes'}[key];source='https://www.playadopt.me/news/'+slug
    out=[]
    for title,cat,rarity,amount,currency in rewards:
        row=byname.get((cat,norm(title)))
        if not row:
            exact=[r for r in rows.values() if norm(r['name'])==norm(title) and r.get('origin')=='Halloween 2026']
            if len(exact)==1:row=exact[0] # retain the source's actual backpack category
        if not row:
            # Official new item not yet present in the public trading list.
            rid='official-'+re.sub('[^a-z0-9]+','-',title.lower()).strip('-')
            row=dict(id=rid,name=title,category=cat,rarity=rarity,source=source,image=None,checkedOn=CHECKED,tradeValues=[],variants=cat=='pets',sell=None);rows[rid]=row;byname[(cat,norm(title))]=row
        row['rarity']=rarity;row['added']=starts;row['addedSource']=source;row['buy']=dict(amount=amount,currency=currency,source=source) if amount is not None else None
        for im in doc.all('img'):
            if norm(im.attrs.get('alt',''))==norm(title) and im.attrs.get('src','').startswith('https://'):
                row['image']=im.attrs['src'];row['imageSource']=source;break
        reward=dict(itemId=row['id'],name=title,rarity=rarity,cost=amount,currency=currency)
        if title in ['Bubblegeist','Bobageist','Caramelgeist']:reward['reportedChance']={'Bubblegeist':4,'Bobageist':20,'Caramelgeist':76}[title]
        out.append(reward)
    helpers.append(dict(id=id,name=name,type='collection',source=source,checkedOn=CHECKED,starts=starts,ends=None,currency='Candy Corn',steps=steps,rewards=out))

for row in rows.values():
    path=SRC/('extra-'+row['id']+'.html')
    if row.get('image') or not path.exists():continue
    doc=Document(path.read_text(encoding='utf8')).root
    boxes=[e for e in doc.all() if 'portable-infobox' in e.attrs.get('class','') or e.tag=='aside' and 'info-box' in e.attrs.get('class','')]
    if boxes:
        for im in boxes[0].all('img'):
            if norm(im.attrs.get('alt','')) in [norm(row['name']),norm(row['name']+' (Pet)')] and im.attrs.get('src','').startswith('https://'):
                row['image']=im.attrs['src'];row['imageSource']=row['source'];break
table=read(SRC/'aging-tables.json')[0]
growth=dict(normal=['Newborn','Junior','Pre-Teen','Teen','Post-Teen','Full Grown'],neon=['Reborn','Twinkle','Sparkle','Flare','Sunshine','Luminous'],tasks={table[0][i]:[int(table[j][i]) for j in range(1,6)] for i in range(1,6)},source='https://adoptmetradingvalues.com/pet-aging-chart.php',sourceUpdated='2025-09-12',checkedOn=CHECKED,friendshipTasks=30,friendshipSource='https://www.playadopt.me/news/friendship-bar-and-safari',megaFullyGrown=True)
result=dict(schema=1,name='Adopt Me items',checkedOn=CHECKED,categories=[dict(id=id,name=name) for id,name in cats],entries=sorted(rows.values(),key=lambda r:(next(i for i,c in enumerate(cats) if c[0]==r['category']),r['name'].lower())),growth=growth,eventHelpers=helpers,valueNote='AMTV community snapshot in Ride Potions (RP), not euros or sale prices. Variant values use the published normal/ride/fly/fly-ride ordering; growth does not have a verified numeric adjustment.',sources=['https://adoptmetradingvalues.com/','https://adoptmewiki.com/wiki/','https://adoptme.fandom.com/wiki/','https://www.playadopt.me/news'],license='Wiki-derived reference facts attributed to Adopt Me Wiki and its original Fandom authors (CC BY-SA 4.0). Item artwork belongs to its respective owners.')
(OUT/'adopt-me.json').write_text(json.dumps(result,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
report=dict(checkedOn=CHECKED,entries=len(rows),counts={id:sum(r['category']==id for r in rows.values()) for id,_ in cats},evidence=evidence,amtvSnapshotSha256=hashlib.sha256((SRC/'amtv-records.json').read_bytes()).hexdigest(),limitations=['AMTV covers its published tradeable-item chooser; wiki tables supplement missing reference entries. Source omissions remain possible.','Unavailable or unverifiable prices, dates and artwork remain unknown.','Wings belong to Pet wear since the March 2026 backpack merge.','Pet friendship level and balances are manual notes, never read from Roblox.'])
(OUT/'adopt-me-sources.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps({'entries':len(rows),'categories':report['counts']}))
