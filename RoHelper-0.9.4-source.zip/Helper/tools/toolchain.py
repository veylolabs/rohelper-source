"""Discover an installed x86 C++ environment without a developer-specific path."""
import os
import pathlib
import subprocess


def vcvars32():
    configured = os.environ.get('ROHELPER_VCVARS32')
    if configured:
        candidate = pathlib.Path(configured)
    else:
        program_files = os.environ.get('ProgramFiles(x86)', os.environ.get('ProgramFiles', ''))
        finder = pathlib.Path(program_files) / 'Microsoft Visual Studio/Installer/vswhere.exe'
        if not finder.is_file():
            raise RuntimeError('Install Visual Studio C++ Build Tools or set ROHELPER_VCVARS32.')
        installation = subprocess.check_output([
            str(finder), '-latest', '-products', '*', '-requires',
            'Microsoft.VisualStudio.Component.VC.Tools.x86.x64', '-property', 'installationPath',
        ], text=True).strip()
        if not installation:
            raise RuntimeError('No Visual Studio installation with the x86 C++ toolchain was found.')
        candidate = pathlib.Path(installation) / 'VC/Auxiliary/Build/vcvars32.bat'
    if not candidate.is_file():
        raise RuntimeError('The configured x86 C++ environment script does not exist.')
    return candidate


if __name__ == '__main__':
    print(vcvars32())
