from release_privacy import clean_public_images
"""Audit saved Fandom API tables and package exact art. Stable IDs are retained.
Usage: python tools/refresh_sab_gear_catalog.py snapshots [--fetch-art]
"""
import base64,concurrent.futures,hashlib,io,json,pathlib,re,sys,urllib.request,urllib.parse
from adopt_sources import Document
from PIL import Image
root=pathlib.Path(__file__).resolve().parents[1];snap=pathlib.Path(sys.argv[1]);checked='2026-10-17'
dest=root/'content/sab-gear.json';old=json.loads(dest.read_text(encoding='utf-8'));entries=old['entries'];oldids={e['id'] for e in entries}
norm=lambda s:re.sub(r'[^a-z0-9]','',s.lower())
aliases={'yingyangslap':'yinyangslap','yingyanglamp':'zenlamp','radioactiveairstrikes':'radioactiveairstrike','lolipop':'lollipop','adminpanel':'adminpowers'}
key=lambda s:aliases.get(norm(s),norm(s))
def load(slug):return json.loads((snap/(slug+'-api.json')).read_text(encoding='utf-8'))['parse']
def url(page):return 'https://stealabrainrot.fandom.com/wiki/'+page.replace(' ','_')
def request(u):return urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0','Referer':'https://stealabrainrot.fandom.com/'}),timeout=45).read()
def add(name,cat,group,page,acquisition,confirmed=True):
 e=next((e for e in entries if key(e['name'])==key(name)),None)
 if not e:e={'id':'gear-'+re.sub(r'[^a-z0-9]+','-',name.lower()).strip('-'),'image':None};entries.append(e)
 e.update(name=name,category=cat,group=group,source=url(page),acquisition=acquisition,confirmed=confirmed,checkedOn=checked);return e
for e in entries:
 if e['id']=='gear-medusa-s-head':e['name']="Medusa's Head"
 e['name']={'Giant potion':'Giant Potion','Flash teleport':'Flash Teleport','Medusa�s Head':"Medusa's Head"}.get(e['name'],e['name'])
 if e['category']=='shop':e.update(group='Cash gear shop',acquisition='Cash gear shop · rebirth unlocks',confirmed=True,source=url('Gears'))
 elif e['category']=='wheel':
  rawGroup=e['group'].replace(' Wheel','')
  group={'Rainbow Event':'Rainbow','Bloodrot':'Bloodmoon','Lava':'Molten','Ying Yang':'Yin Yang','Christmas':'Christmas'}.get(rawGroup,rawGroup)
  if e['id']=='gear-cyber-slap':group='Cyber'
  e.update(group=group+' Wheel',acquisition=group+' event wheel',source=url('Slap' if e['id']=='gear-cyber-slap' else 'Gears'),confirmed=e['id']!='gear-eclipse-slap')
 elif e['category']=='default':e.update(group='Starter gear',acquisition='Given when joining the game',source=url('Gears'),confirmed=True)
 elif e['name'].endswith('Rod'):e.update(group='Fishing',acquisition='Fishing event · '+('starter rod' if e['name']=='Starter Rod' else 'Fishing Rod Shop'),source=url('Unobtainable_gears'),confirmed=True)
 else:e.update(group='Grave Digger',acquisition='Grave Digger event',source=url('Grave_Digger_Event'),confirmed=True)
for name in ['Cake Trap','Candy Bomb','Jelly Gun','Confetti Cannon','Candy Launcher','Lollipop','Sweet Scythe','Candy Coils']:add(name,'event','Candy rewards','Unobtainable gears','Piñata / Panjat Pinang rewards · formerly Candy Shop')
add('Donut Bomb','unconfirmed','Unconfirmed','Unobtainable gears','Source lists an unfinished gear · obtainment unconfirmed',False)
for name in ['Blackhole Slap','Flying Carpet','Laser Gun','Ban Hammer','Admin Powers']:add(name,'robux','Robux Shop','Shop','Robux Shop · '+('Admin Panel purchase' if name=='Admin Powers' else 'gear purchase'))
for name in ["Witch's Broom","Santa's Sleigh"]:add(name,'limited','Limited Robux Shop','Shop','Limited Robux Shop offer · current availability unknown')
add("Cupid's Wings",'limited','Cupid update','Update Log/Update 38','Limited flight gear · Cupid update')
add('Waverider','event','Code reward','Codes','WAVERIDER4FREELOL code reward · current code availability unknown')
bee=add('Flying Bee','event','Bee update shop','Queen Bee Event','Bee update shop · purchase details unconfirmed')
bee['source']='https://sabexistcount.com/news/steal-a-brainrot-august-22-bee-update-is-live-bee-lucky-block-7-new-brainrots-flying-bee-bee-emperor-base'
# Eclipse's page calls its wheel list speculative; no proposed Hammer or odds.
for e in entries:
 if e['id']=='gear-eclipse-slap':e.update(acquisition='Proposed Eclipse wheel reward · availability unconfirmed',category='unconfirmed',group='Eclipse Wheel',source=url('Eclipse_Event'),confirmed=False)
 for id,values in {'gear-admin-powers':['Admin Panel','Admin Commands'],'gear-lollipop':['Lolipop'],'gear-gummy-slap':['Gummy Bear','Gummy Stick'],'gear-grapple-gun':['Grapple Hook'],'gear-taser':['Taser Gun'],'gear-bat':['Tung Bat']}.items():
  if e['id']==id:e['aliases']=values
files={};evidence={}
for slug in ['gears','unobtainable-gears','shop','slap','gamepasses-and-dev-products_gallery']:
 d=load(slug);page=d['title'];doc=Document(d['text']['*']).root
 for table in doc.all('table'):
  rows=table.all('tr')
  if not rows:continue
  headers=[c.text().strip().replace('"','') for c in rows[0].children if getattr(c,'tag',None) in ('th','td')]
  idx=next((i for i,h in enumerate(headers) if h in ['Gear Name','Name','Item','Gear']),None)
  if idx is None:continue
  for row in rows[1:]:
   cells=[c for c in row.children if getattr(c,'tag',None) in ('th','td')]
   if len(cells)<=idx:continue
   name=cells[idx].text().strip();k=key(name);match=next((e for e in entries if key(e['name'])==k or any(key(a)==k for a in e.get('aliases',[]))),None)
   if not match or match['id'] in files:continue
   ims=[im.attrs.get('data-image-name') for cell in cells[:idx+1] for im in cell.all('img') if im.attrs.get('data-image-name') and im.attrs.get('data-image-name')!='Robux.png']
   if ims:files[match['id']]=ims[0];evidence[match['id']]={'page':url(page),'tableName':name,'file':ims[0]}
for e in entries:
 if e['id']=='gear-medusa-s-head' and e['id'] not in files:files[e['id']]="Medusa's Head.png";evidence[e['id']]={'page':url('Gears'),'file':files[e['id']]}
artdir=snap/'exact-art';artdir.mkdir(exist_ok=True);infofile=snap/'gear-imageinfo.json'
if '--fetch-art' in sys.argv:
 metadata={};names=list(dict.fromkeys(files.values()))
 for offset in range(0,len(names),40):
  query=urllib.parse.urlencode(dict(action='query',titles='|'.join('File:'+n for n in names[offset:offset+40]),prop='imageinfo',iiprop='url|size',format='json'))
  d=json.loads(request('https://stealabrainrot.fandom.com/api.php?'+query))
  for p in d['query']['pages'].values():
   if p.get('imageinfo'):metadata[norm(p['title'][5:])]=p['imageinfo'][0]
 infofile.write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
else:metadata=json.loads(infofile.read_text(encoding='utf-8')) if infofile.exists() else {}
def art(e):
 name=files.get(e['id']);info=metadata.get(norm(name or ''))
 if not info:return None
 u=info['url'].split('/revision/')[0];assert urllib.parse.urlsplit(u).hostname in ['static.wikia.nocookie.net','vignette.wikia.nocookie.net']
 p=artdir/(e['id']+'.image')
 if not p.exists():
  if '--fetch-art' not in sys.argv:return None
  try:p.write_bytes(request(u))
  except Exception as ex:
   # The official API verifies the exact file association and dimensions even
   # when the CDN refuses this build machine. Do not substitute other artwork.
   return e['id'],dict(image=info['url'],imageSource=info['url'],artwork={'provider':'Steal a Brainrot Fandom','file':name,'source':evidence[e['id']]['page'],'checkedOn':checked,'width':info['width'],'height':info['height'],'preferredSourcesChecked':['SABRValues','SABExistCount'],'downloadStatus':'CDN unavailable on build machine'})
 raw=p.read_bytes()
 try:
  im=Image.open(io.BytesIO(raw));im.verify();fmt=im.format;assert fmt in ['PNG','WEBP','JPEG'] and len(raw)<750000
 except Exception as ex:return e['id'],str(ex)
 return e['id'],dict(image='data:'+{'PNG':'image/png','WEBP':'image/webp','JPEG':'image/jpeg'}[fmt]+';base64,'+base64.b64encode(raw).decode('ascii'),imageSource=u,artwork={'provider':'Steal a Brainrot Fandom','file':name,'source':evidence[e['id']]['page'],'checkedOn':checked,'sha256':hashlib.sha256(raw).hexdigest(),'width':info['width'],'height':info['height'],'preferredSourcesChecked':['SABRValues','SABExistCount']})
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as pool:
 for r in pool.map(art,entries):
  if r and isinstance(r[1],dict):next(e for e in entries if e['id']==r[0]).update(r[1])
  elif r:print('ART UNAVAILABLE',r)
out={'schema':1,'name':'SAB gear','checkedOn':checked,'categories':[dict(id=k,name=v) for k,v in [('default','Starter gear'),('shop','Cash gear shop'),('robux','Robux Shop'),('wheel','Event wheels'),('event','Event rewards'),('limited','Limited offers'),('unconfirmed','Unconfirmed / unreleased')]],'entries':entries,'sources':sorted(set(e['source'] for e in entries)),'notes':'Community reference. Acquisition labels distinguish cash, Robux, wheels, codes and event rewards. Historical offers do not imply current availability. Speculative or unfinished items are explicitly unconfirmed. Exact approved-source artwork only.','license':'CC BY-SA 4.0','artworkPolicy':['SABRValues','SABExistCount','Steal a Brainrot Fandom (last resort)']}
assert len({e['id'] for e in entries})==len(entries) and oldids<={e['id'] for e in entries}
dest.write_text(json.dumps(clean_public_images(out),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Built',len(entries),'gears;',sum(bool(e.get('image')) for e in entries),'verified icons; missing:',[e['name'] for e in entries if not e.get('image')])
