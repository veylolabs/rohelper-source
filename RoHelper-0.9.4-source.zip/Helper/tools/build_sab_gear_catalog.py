"""Compatibility entry point for the source-audited gear catalog refresher."""
import pathlib,runpy
runpy.run_path(str(pathlib.Path(__file__).with_name('refresh_sab_gear_catalog.py')),run_name='__main__')
