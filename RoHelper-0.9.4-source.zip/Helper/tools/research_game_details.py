"""Follow exact source category lists and canonical wiki pages for catalog facts."""
import json,pathlib,urllib.parse,concurrent.futures,re,sys
from research_game_expansion import request,out,fetch
def category(cat):
 folder=out/'mm2';params=dict(action='query',generator='categorymembers',gcmtitle='Category:'+cat,gcmnamespace=0,gcmtype='page',gcmlimit=500,prop='revisions',rvprop='content',rvslots='main',format='json');batch=0
 while True:
  path=folder/(cat.lower()+'-pages-'+str(batch)+'.json')
  if not path.exists():path.write_bytes(request('https://murder-mystery-2.fandom.com/api.php?'+urllib.parse.urlencode(params)))
  d=json.loads(path.read_bytes());print(cat,batch,len(d.get('query',{}).get('pages',{})),flush=True)
  if not d.get('continue'):break
  params.update(d['continue']);batch+=1
def extra(job):return fetch(job)
if __name__=='__main__':
 sys.stdout.reconfigure(encoding='utf-8')
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
  for _ in pool.map(category,['Knives','Guns','Pets']):pass
 for job in [('bee-swarm','bee-swarm-simulator.fandom.com','Masks'),('bee-swarm','bee-swarm-simulator.fandom.com','Guards'),('bee-swarm','bee-swarm-simulator.fandom.com','Boots'),('bee-swarm','bee-swarm-simulator.fandom.com','Belts'),('bee-swarm','bee-swarm-simulator.fandom.com','Blender'),('grow-a-garden','growagarden.fandom.com','Events')]:print(extra(job),flush=True)
 for slug in ['seeds','pets','gears','mutations','weather']:
  p=out/('gag2-'+slug+'.html')
  try:
   if not p.exists():p.write_bytes(request('https://growagarden2.wiki/'+slug))
   print(p.name,p.stat().st_size,flush=True)
  except Exception as e:print(slug,str(e),flush=True)
 p=out/'ps99-collections.json'
 try:
  if not p.exists():p.write_bytes(request('https://ps99.biggamesapi.io/api/collections'))
  print('PS99 collections',json.loads(p.read_bytes())['data'],flush=True)
 except Exception as e:print('collections',str(e),flush=True)
