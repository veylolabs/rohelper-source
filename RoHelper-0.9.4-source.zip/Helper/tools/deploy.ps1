param([Parameter(Mandatory=$true)][string]$Destination,[switch]$NoStart)
$ErrorActionPreference='Stop'
$taskRoot=Split-Path $PSScriptRoot -Parent
$taskVersion=(Get-Content -LiteralPath (Join-Path $taskRoot 'version.json') -Raw|ConvertFrom-Json).version
$taskBuild=[IO.Path]::GetFullPath((Join-Path $taskRoot ("..\Output\RoHelper-"+$taskVersion)))
$taskDestination=[IO.Path]::GetFullPath($Destination)
$taskProgramFiles=@('RoHelper.exe','WebView2Loader.dll','README.md','LICENSE','LICENSES','web','update','update-files.json')
if((Get-Item -LiteralPath (Join-Path $taskBuild 'RoHelper.exe')).VersionInfo.FileVersion -ne $taskVersion){throw 'Build version does not match version.json.'}
if(Get-Process RoHelper -ErrorAction SilentlyContinue|Where-Object Path -eq (Join-Path $taskDestination 'RoHelper.exe')){throw 'Close the installed RoHelper normally before updating.'}
$taskData=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'RoHelper'
$taskHashes=@{}
if(Test-Path -LiteralPath $taskData){Get-ChildItem -LiteralPath $taskData -File|ForEach-Object {$taskHashes[$_.Name]=(Get-FileHash -LiteralPath $_.FullName).Hash}}
New-Item -ItemType Directory -Path $taskDestination -Force|Out-Null
foreach($taskName in $taskProgramFiles){Copy-Item -LiteralPath (Join-Path $taskBuild $taskName) -Destination $taskDestination -Recurse -Force}
$taskCount=0
foreach($taskName in $taskProgramFiles){$taskItem=Get-Item -LiteralPath (Join-Path $taskBuild $taskName);$taskFiles=if($taskItem.PSIsContainer){Get-ChildItem -LiteralPath $taskItem.FullName -Recurse -File}else{$taskItem};foreach($taskFile in $taskFiles){$taskRelative=$taskFile.FullName.Substring($taskBuild.Length+1);$taskInstalled=Join-Path $taskDestination $taskRelative;if((Get-FileHash -LiteralPath $taskFile.FullName).Hash -ne (Get-FileHash -LiteralPath $taskInstalled).Hash){throw "Installed mismatch: $taskRelative"};$taskCount++}}
foreach($taskName in $taskHashes.Keys){if((Get-FileHash -LiteralPath (Join-Path $taskData $taskName)).Hash -ne $taskHashes[$taskName]){throw "Existing data changed: $taskName"}}
Write-Output "RoHelper $taskVersion installed; $taskCount application files verified. Existing data preserved."
if(-not $NoStart){Start-Process -FilePath (Join-Path $taskDestination 'RoHelper.exe') -WorkingDirectory $taskDestination -WindowStyle Normal}
