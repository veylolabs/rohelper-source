import json,pathlib,sys,concurrent.futures,urllib.parse
from research_game_expansion import request,out
def ps(name):
 p=out/('ps99-'+name.lower()+'.json')
 if not p.exists():p.write_bytes(request('https://ps99.biggamesapi.io/api/collection/'+name))
 return name,len(json.loads(p.read_bytes()).get('data',[]))
def supreme(name):
 p=out/('supreme-'+name+'.html')
 try:
  if not p.exists():p.write_bytes(request('https://supremevalues.com/mm2/'+name))
  return name,p.stat().st_size
 except Exception as e:return name,str(e)
if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
  for row in pool.map(ps,['Potions','Enchants','Charms','MiscItems','Hoverboards','Fruits','Boosts','Lootboxes','Boxes']):print(row,flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
  for row in pool.map(supreme,['godlies','ancients','chromas','vintages','legendaries','rares','uncommons','commons','uniques','pets']):print('Supreme',row,flush=True)
 ids=set()
 def assets(d):
  if isinstance(d,list):
   for v in d:assets(v)
  elif isinstance(d,dict):
   for k,v in d.items():
    if isinstance(v,str) and (k.lower().endswith('thumbnail') or k.lower()=='icon') and v.startswith('rbxassetid://'):ids.add(v[13:])
    elif isinstance(v,(dict,list)):assets(v)
 for p in out.glob('ps99-*.json'):
  d=json.loads(p.read_bytes()).get('data',[])
  if not isinstance(d,list):continue
  for e in d:
   if not isinstance(e,dict):continue
   assets(e.get('configData',{}))
 mapfile=out/'ps99-image-map.json';result=json.loads(mapfile.read_bytes()) if mapfile.exists() else {};names=sorted(ids-set(result));folder=out/'roblox-thumbnails';folder.mkdir(exist_ok=True)
 def thumb(offset):
  import hashlib
  batch=names[offset:offset+80];p=folder/('assets-'+hashlib.sha256(','.join(batch).encode()).hexdigest()[:12]+'.json');query=urllib.parse.urlencode(dict(assetIds=','.join(batch),size='150x150',format='Png',isCircular='false'))
  if not p.exists():p.write_bytes(request('https://thumbnails.roblox.com/v1/assets?'+query))
  return json.loads(p.read_bytes())
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  for d in pool.map(thumb,range(0,len(names),80)):
   for e in d.get('data',[]):
    if e.get('state')=='Completed' and e.get('imageUrl','').startswith('https://'):result[str(e['targetId'])]=e['imageUrl']
 (out/'ps99-image-map.json').write_text(json.dumps(result));print('Verified',len(result),'of',len(ids),'official item thumbnails',flush=True)
