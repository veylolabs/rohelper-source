"""Small public HTML reader used by the reproducible Adopt Me catalog refresh."""
from html.parser import HTMLParser
from pathlib import Path
import urllib.request, re

class Element:
    def __init__(self,tag='',attrs=(),parent=None):
        self.tag=tag;self.attrs=dict(attrs);self.children=[];self.parent=parent
    def text(self):return re.sub(r'\s+',' ',''.join(c.text() if isinstance(c,Element) else c for c in self.children)).strip()
    def all(self,tag=None):
        out=[]
        for c in self.children:
            if isinstance(c,Element):
                if tag is None or c.tag==tag:out.append(c)
                out.extend(c.all(tag))
        return out
class Document(HTMLParser):
    def __init__(self,text):
        super().__init__(convert_charrefs=True);self.root=Element();self.current=self.root;self.feed(text)
    def handle_starttag(self,tag,attrs):
        e=Element(tag,attrs,self.current);self.current.children.append(e)
        if tag not in ('area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'):self.current=e
    def handle_startendtag(self,tag,attrs):self.current.children.append(Element(tag,attrs,self.current))
    def handle_endtag(self,tag):
        e=self.current
        while e.parent:
            if e.tag==tag:self.current=e.parent;return
            e=e.parent
    def handle_data(self,data):self.current.children.append(data)

def fetch(url,path):
    path=Path(path)
    if not path.exists():
        req=urllib.request.Request(url,headers={'User-Agent':'RoHelper public catalog research/1'})
        path.write_bytes(urllib.request.urlopen(req,timeout=30).read())
    return Document(path.read_text(encoding='utf8')).root
