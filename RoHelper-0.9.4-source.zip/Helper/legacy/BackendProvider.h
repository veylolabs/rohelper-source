#pragma once
#include "HandleCloser.h"
#include <windows.h>
#include <sddl.h>
#include <string>
#include <vector>
#include <mutex>
#include <condition_variable>
#include <thread>
#include <chrono>
#pragma comment(lib, "advapi32.lib")

// Independent implementations of the pinned mechanisms in BACKENDS.md.
// Mutex ownership, validation and release all happen on the same worker.
class BackendCoordinator {
public:
    struct Status { std::string active, error; bool ready; };
    explicit BackendCoordinator(std::wstring prefix = L"ROBLOX_") : prefix(std::move(prefix)), worker([this]{ Run(); }) {}
    ~BackendCoordinator() {
        { std::lock_guard<std::mutex> lock(mutex); quit = true; condition.notify_all(); }
        worker.join();
    }
    static bool Valid(const std::string& id) {
        return id == "ropilot-native" || id == "multiroblox" || id == "zoltak" || id == "ram-legacy";
    }
    static bool NeedsClosedClients(const std::string& message) {
        return message == "Backend change is pending. Close Roblox before starting a different multi-instance method."
            || message == "The previous native handle release could not be confirmed. Close Roblox before another launch."
            || message == "Backend saved; pending until all Roblox clients are closed."
            || message.find("Multi-instance guard could not be verified.") == 0;
    }
    Status State() { std::lock_guard<std::mutex> lock(mutex); return {active, failure, ready}; }
    std::string Active() { return State().active; }
    bool Prepare(const std::string& id, bool robloxRunning, std::string& error) {
        // A second caller must not overwrite the first caller's worker request.
        std::lock_guard<std::mutex> operation(requestMutex);
        std::unique_lock<std::mutex> lock(mutex);
        error.clear();
        if (!Valid(id)) { error = "Unknown multi-instance backend."; return false; }
        if (unconfirmed && robloxRunning) { error = "The previous native handle release could not be confirmed. Close Roblox before another launch."; return false; }
        if (!robloxRunning) { unconfirmed = false; unconfirmedPid = 0; }
        if (active != id && robloxRunning) { error = "Backend change is pending. Close Roblox before starting a different multi-instance method."; return false; }
        requested = id; clientsRunning = robloxRunning; pending = true; done = false;
        condition.notify_all();
        condition.wait(lock,[this]{return done;});
        error = failure;
        return ready && active == id;
    }
    bool AfterLaunch(DWORD pid) {
        const auto state = State();
        if (state.active == "ropilot-native") return HandleCloser::CloseProcessRobloxHandle(pid);
        std::string error;
        return !state.active.empty() && Prepare(state.active, true, error);
    }
    bool FinishLaunch(DWORD pid) {
        if (Active() != "ropilot-native") return AfterLaunch(pid);
        for (int i = 0; i < 10; ++i) {
            if (AfterLaunch(pid)) {
                std::lock_guard<std::mutex> lock(mutex);
                if (unconfirmedPid == pid) { unconfirmed = false; unconfirmedPid = 0; }
                return true;
            }
            Sleep(100);
        }
        std::lock_guard<std::mutex> lock(mutex); unconfirmed = true; unconfirmedPid = pid; return false;
    }
private:
    struct Guard { HANDLE handle; std::wstring name; bool owned; };
    static std::string GuardError(DWORD code) {
        return "Multi-instance guard could not be verified. Close Roblox and other instance managers before retrying (Windows error " + std::to_string(code) + ").";
    }
    bool Verify(const std::vector<Guard>& guards) {
        if (active == "ropilot-native") return true;
        const size_t expected = active == "multiroblox" ? 2 : 1;
        if (active.empty() || guards.size() != expected) { failure = GuardError(ERROR_INVALID_HANDLE); return false; }
        for (const auto& guard : guards) {
            DWORD flags = 0;
            if (!GetHandleInformation(guard.handle, &flags)) { failure = GuardError(GetLastError()); return false; }
            // Probe the public name with the access requested by CreateMutex.
            HANDLE named = OpenMutexW(MUTEX_ALL_ACCESS, FALSE, guard.name.c_str());
            if (!named) { failure = GuardError(GetLastError()); return false; }
            CloseHandle(named);
            if (guard.owned) {
                // Balance recursive acquisition without releasing original ownership.
                const DWORD result = WaitForSingleObject(guard.handle, 0);
                if (result != WAIT_OBJECT_0 && result != WAIT_ABANDONED) {
                    failure = GuardError(result == WAIT_FAILED ? GetLastError() : ERROR_BUSY); return false;
                }
                if (!ReleaseMutex(guard.handle)) { failure = GuardError(GetLastError()); return false; }
                if (result == WAIT_ABANDONED) { failure = GuardError(ERROR_ABANDONED_WAIT_0); return false; }
            }
        }
        return true;
    }
    void Run() {
        std::vector<Guard> guards;
        auto release = [&]{
            for (const auto& guard : guards) { if (guard.owned) ReleaseMutex(guard.handle); CloseHandle(guard.handle); }
            guards.clear();
        };
        std::unique_lock<std::mutex> lock(mutex);
        for (;;) {
            condition.wait_for(lock, std::chrono::milliseconds(1500), [this]{return pending || quit;});
            if (quit) { release(); return; }
            if (!pending) {
                if (!active.empty() && active != "ropilot-native") { ready = Verify(guards); if (ready) failure.clear(); }
                continue;
            }
            pending = false;
            if (active == requested && Verify(guards)) {
                ready = true; failure.clear(); done = true; condition.notify_all(); continue;
            }
            if (clientsRunning) {
                ready = false;
                if (failure.empty()) failure = GuardError(ERROR_INVALID_HANDLE);
                // Never drop or recreate an existing guard while clients run.
                done = true; condition.notify_all(); continue;
            }
            release(); ready = false; failure.clear(); active.clear();
            std::vector<std::wstring> names;
            if (requested == "multiroblox" || requested == "ram-legacy") names.push_back(prefix+L"singletonMutex");
            if (requested == "multiroblox" || requested == "zoltak") names.push_back(prefix+L"singletonEvent");
            if (requested == "ropilot-native") {
                for (auto suffix : {L"singletonMutex",L"singletonEvent"}) {
                    HANDLE conflict = OpenMutexW(SYNCHRONIZE, FALSE, (prefix+suffix).c_str());
                    if (conflict) { CloseHandle(conflict); failure = "Another singleton holder is active. Close that manager before choosing RoPilot native."; break; }
                    const DWORD result = GetLastError();
                    if (result != ERROR_FILE_NOT_FOUND && result != ERROR_INVALID_HANDLE) { failure = "Cannot verify singleton ownership. Close other managers before launching."; break; }
                }
            }
            PSECURITY_DESCRIPTOR descriptor = nullptr;
            SECURITY_ATTRIBUTES attributes{sizeof(SECURITY_ATTRIBUTES), nullptr, FALSE};
            // Match MultiRoblox's WorldSid / FullControl rule only on its new
            // mutexes. Never change permissions of any pre-existing object.
            if (requested == "multiroblox") {
                if (!ConvertStringSecurityDescriptorToSecurityDescriptorW(L"D:(A;;GA;;;WD)", SDDL_REVISION_1, &descriptor, nullptr))
                    failure = GuardError(GetLastError());
                attributes.lpSecurityDescriptor = descriptor;
            }
            if (failure.empty()) for (const auto& name : names) {
                SetLastError(ERROR_SUCCESS);
                HANDLE handle = CreateMutexW(requested == "multiroblox" ? &attributes : nullptr, requested != "zoltak", name.c_str());
                const DWORD result = GetLastError();
                if (!handle) {
                    failure = "Multi-instance objects are inaccessible (Windows error " + std::to_string(result) + ").";
                    break;
                }
                if (result == ERROR_ALREADY_EXISTS) {
                    // Reclaim only an unowned/abandoned guard after our own restart.
                    // A live owner is never displaced and no Roblox process is closed.
                    const auto acquired = WaitForSingleObject(handle, 0);
                    if (acquired != WAIT_OBJECT_0 && acquired != WAIT_ABANDONED) {
                        CloseHandle(handle);
                        failure = "Another MultiRoblox manager owns the instance guards. Close that manager and press Start MultiRoblox.";
                        break;
                    }
                }
                guards.push_back({handle, name, requested != "zoltak"});
            }
            if (descriptor) LocalFree(descriptor);
            if (failure.empty()) { active = requested; ready = Verify(guards); }
            if (!failure.empty()) { release(); active.clear(); ready = false; }
            done = true; condition.notify_all();
        }
    }
    std::wstring prefix;
    std::mutex mutex, requestMutex;
    std::condition_variable condition;
    std::string active, requested, failure;
    DWORD unconfirmedPid = 0;
    bool ready = false, pending = false, done = false, quit = false, unconfirmed = false, clientsRunning = false;
    std::thread worker;
};
inline BackendCoordinator& CurrentBackend() { static BackendCoordinator provider; return provider; }
