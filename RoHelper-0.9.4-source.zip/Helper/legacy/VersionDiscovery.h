#pragma once
#include <windows.h>
#include <shlobj.h>
#include <filesystem>
#include <vector>
#include <set>
#include <algorithm>
#include "json.hpp"

namespace VersionDiscovery {
struct Candidate {
    std::filesystem::path path;
    std::string source, version;
    unsigned long long rank = 0;
    bool valid = false, bootstrapper = false;
};
inline Candidate Inspect(const std::filesystem::path& path, const std::string& source) {
    Candidate item; item.path = path; item.source = source;
    item.bootstrapper = path.filename() != L"RobloxPlayerBeta.exe";
    std::error_code error;
    item.valid = !item.bootstrapper && std::filesystem::is_regular_file(path, error)
        && std::filesystem::is_regular_file(path.parent_path() / L"RobloxPlayerBeta.dll", error);
    DWORD binaryType = 0;
    item.valid = item.valid && GetBinaryTypeW(path.c_str(), &binaryType);
    DWORD ignored = 0, size = GetFileVersionInfoSizeW(path.c_str(), &ignored);
    if (size) {
        std::vector<BYTE> buffer(size);
        VS_FIXEDFILEINFO* info = nullptr; UINT length = 0;
        if (GetFileVersionInfoW(path.c_str(), 0, size, buffer.data()) && VerQueryValueW(buffer.data(), L"\\", (void**)&info, &length)
            && length >= sizeof(VS_FIXEDFILEINFO) && info->dwSignature == 0xfeef04bd) {
            item.rank = (static_cast<unsigned long long>(info->dwFileVersionMS) << 32) | info->dwFileVersionLS;
            item.version = std::to_string(HIWORD(info->dwFileVersionMS)) + "." + std::to_string(LOWORD(info->dwFileVersionMS)) + "." + std::to_string(HIWORD(info->dwFileVersionLS)) + "." + std::to_string(LOWORD(info->dwFileVersionLS));
        }
    }
    return item;
}
inline std::vector<Candidate> Enumerate(const std::vector<std::pair<std::filesystem::path, std::string>>& roots) {
    std::vector<Candidate> result; std::set<std::wstring> seen;
    for (const auto& root : roots) {
        std::error_code error;
        for (std::filesystem::directory_iterator it(root.first, std::filesystem::directory_options::skip_permission_denied, error), end; it != end; it.increment(error)) {
            if (error) break;
            if (!it->is_directory(error)) continue;
            for (const auto* name : {L"RobloxPlayerBeta.exe", L"RobloxPlayerLauncher.exe"}) {
                auto path = it->path() / name;
                if (!std::filesystem::is_regular_file(path, error)) continue;
                path = std::filesystem::weakly_canonical(path, error);
                if (error) continue;
                auto key = path.wstring(); std::transform(key.begin(), key.end(), key.begin(), towlower);
                if (seen.insert(key).second) result.push_back(Inspect(path, root.second));
            }
        }
    }
    std::sort(result.begin(), result.end(), [](const Candidate& a, const Candidate& b) {
        if (a.valid != b.valid) return a.valid > b.valid;
        if (a.rank != b.rank) return a.rank > b.rank;
        return a.path.wstring() < b.path.wstring();
    });
    return result;
}
inline std::vector<Candidate> Installed() {
    std::vector<std::pair<std::filesystem::path, std::string>> roots;
    wchar_t local[MAX_PATH], program[MAX_PATH];
    if (SUCCEEDED(SHGetFolderPathW(nullptr, CSIDL_LOCAL_APPDATA, nullptr, 0, local))) {
        for (auto name : {L"Roblox", L"Bloxstrap", L"Fishstrap"})
            roots.push_back({std::filesystem::path(local) / name / L"Versions", std::filesystem::path(name).string()});
    }
    for (int id : {CSIDL_PROGRAM_FILES, CSIDL_PROGRAM_FILESX86})
        if (SUCCEEDED(SHGetFolderPathW(nullptr, id, nullptr, 0, program))) roots.push_back({std::filesystem::path(program) / L"Roblox" / L"Versions", "Program Files"});
    return Enumerate(roots);
}
inline std::string Resolve(const std::vector<Candidate>& candidates, const std::string& selected) {
    if (!selected.empty()) {
        for (const auto& item : candidates) if (item.path.string() == selected && item.valid) return selected;
        return {}; // Explicit missing/incomplete selection never falls back.
    }
    for (const auto& item : candidates) if (item.valid) return item.path.string();
    return {};
}
// Launches must follow the currently published deployment, including rollbacks.
// A numerically newer leftover installation is not necessarily supported online.
inline std::string ResolveForLaunch(const std::vector<Candidate>& candidates, const std::string& selected, const std::string& published) {
    if(published.empty())return {};
    for(const auto& item:candidates)if(item.valid&&item.path.parent_path().filename().string()==published
        &&(selected.empty()||item.path.string()==selected))return item.path.string();
    return {};
}
inline nlohmann::json Json(const std::vector<Candidate>& candidates) {
    auto result = nlohmann::json::array();
    for (const auto& item : candidates) result.push_back({{"path", item.path.string()}, {"source", item.source}, {"version", item.version.empty() ? "unknown" : item.version}, {"valid", item.valid}, {"bootstrapper", item.bootstrapper}});
    return result;
}
}
