#pragma once
#include "json.hpp"
#include <regex>
#include <string>
#include <algorithm>
namespace ClientDeployment {
inline std::string FileVersion(const std::string& response){try{const auto j=nlohmann::json::parse(response);if(j.contains("errors"))return {};const auto value=j.at("version").get<std::string>();return std::regex_match(value,std::regex("[0-9]{1,10}(\\.[0-9]{1,10}){3}"))?value:std::string();}catch(...){return {};}}
inline bool ValidChannel(const std::string& channel){return std::regex_match(channel,std::regex("[A-Za-z0-9_-]{1,80}"));}
inline bool Production(const std::string& channel){auto lower=channel;std::transform(lower.begin(),lower.end(),lower.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});return lower=="live"||lower=="production";}
inline std::string Channel(const std::string& response){try{const auto j=nlohmann::json::parse(response);if(j.contains("errors"))return {};const auto channel=j.at("channelName").get<std::string>();return ValidChannel(channel)?channel:std::string();}catch(...){return {};}}
inline std::string Version(const std::string& response){try{const auto j=nlohmann::json::parse(response);if(j.contains("errors"))return {};const auto version=j.at("clientVersionUpload").get<std::string>();return std::regex_match(version,std::regex("version-[0-9a-fA-F]{16,64}"))?version:std::string();}catch(...){return {};}}
inline std::string VersionPath(const std::string& channel){if(!ValidChannel(channel))return {};return Production(channel)?"/v2/client-version/WindowsPlayer":"/v2/client-version/WindowsPlayer/channel/"+channel;}
// LIVE is a deployment-service alias, not a client settings bucket. Omitting
// the token lets a client inherit the last account's channel. Keep the token
// present with the protocol's empty/default value for production.
inline std::string LaunchChannel(const std::string& channel){return ValidChannel(channel)?"+channel:"+(Production(channel)?std::string():channel):std::string();}
inline std::string LaunchSuffix(const std::string& channel){const auto token=LaunchChannel(channel);return token.empty()?std::string():token+"+LaunchExp:InApp";}
}
