#pragma once
#include <string>
#include <regex>
namespace LaunchTarget {
inline std::string Url(const std::string& place, bool privateRequested, const std::string& linkCode, const std::string& accessCode, const std::string& jobId) {
    if (!std::regex_match(place,std::regex("[1-9][0-9]{0,23}"))) return {};
    const std::string base="https%3A%2F%2Fassetgame.roblox.com%2Fgame%2FPlaceLauncher.ashx%3Frequest%3D";
    if (privateRequested) {
        const std::regex code("[A-Za-z0-9_-]{1,256}");
        if (!std::regex_match(linkCode,code)||!std::regex_match(accessCode,code)) return {};
        return base+"RequestPrivateGame%26placeId%3D"+place+"%26accessCode%3D"+accessCode+"%26linkCode%3D"+linkCode;
    }
    if (!jobId.empty()) {
        if (!std::regex_match(jobId,std::regex("[a-fA-F0-9-]{1,64}"))) return {};
        return base+"RequestGameJob%26placeId%3D"+place+"%26gameJobId%3D"+jobId+"%26isPlayTogetherGame%3Dfalse";
    }
    return base+"RequestGame%26placeId%3D"+place+"%26isPlayTogetherGame%3Dfalse";
}
}
