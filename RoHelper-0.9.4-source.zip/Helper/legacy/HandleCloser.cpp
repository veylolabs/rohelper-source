#include "HandleCloser.h"
#include <vector>
#include <string>
#include <memory>
#include <cstdint>
#include <cstddef>

namespace {
using QuerySystem=LONG(NTAPI*)(ULONG,PVOID,ULONG,PULONG);
using QueryObject=LONG(NTAPI*)(HANDLE,ULONG,PVOID,ULONG,PULONG);
struct Entry { PVOID object; ULONG_PTR pid,handle; ULONG access; USHORT trace,type; ULONG attributes,reserved; };
struct Table { ULONG_PTR count,reserved; Entry entries[1]; };
struct UnicodeName { USHORT length,capacity; PWSTR buffer; };
using Handle=std::shared_ptr<void>;
Handle Owned(HANDLE value){return Handle(value,[](void* p){if(p)CloseHandle(p);});}
}

HandleCloser::Result HandleCloser::InspectNamedEvent(DWORD pid,const wchar_t* expected,bool closeSource) {
    Result result;
    auto process=Owned(OpenProcess(PROCESS_DUP_HANDLE|PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,pid));
    if(!process){result.error=GetLastError();return result;}
    if(WaitForSingleObject(process.get(),0)!=WAIT_TIMEOUT){result.error=ERROR_PROCESS_ABORTED;return result;}
    const auto library=GetModuleHandleW(L"ntdll.dll");
    const auto querySystem=reinterpret_cast<QuerySystem>(GetProcAddress(library,"NtQuerySystemInformation"));
    const auto queryObject=reinterpret_cast<QueryObject>(GetProcAddress(library,"NtQueryObject"));
    if(!querySystem||!queryObject){result.error=ERROR_PROC_NOT_FOUND;return result;}
    // Resolve Event/Mutant types from our own unnamed objects. Never query file/pipe
    // object names: those can block. Extended entries retain full-width PIDs/handles.
    auto sample=Owned(CreateEventW(nullptr,FALSE,FALSE,nullptr));
    auto sampleMutex=Owned(CreateMutexW(nullptr,FALSE,nullptr));
    if(!sample||!sampleMutex){result.error=GetLastError();return result;}
    std::vector<unsigned char> buffer(1<<20);ULONG needed=0;LONG status;
    for(;;){
        status=querySystem(64,buffer.data(),static_cast<ULONG>(buffer.size()),&needed);
        if(status>=0)break;
        if(static_cast<ULONG>(status)!=0xC0000004 || buffer.size()>=64*1024*1024){result.error=static_cast<DWORD>(status);return result;}
        size_t size=buffer.size()*2;if(needed>size)size=needed;
        if(size>64*1024*1024){result.error=ERROR_NOT_ENOUGH_MEMORY;return result;}
        buffer.resize(size);
    }
    const auto table=reinterpret_cast<const Table*>(buffer.data());
    if(table->count>(buffer.size()-offsetof(Table,entries))/sizeof(Entry)){result.error=ERROR_INVALID_DATA;return result;}
    USHORT eventType=0,mutexType=0;
    for(ULONG_PTR i=0;i<table->count;++i){const auto& item=table->entries[i];
        if(item.pid!=GetCurrentProcessId())continue;
        if(item.handle==reinterpret_cast<ULONG_PTR>(sample.get()))eventType=item.type;
        if(item.handle==reinterpret_cast<ULONG_PTR>(sampleMutex.get()))mutexType=item.type;}
    if(!eventType||!mutexType){result.error=ERROR_INVALID_DATA;return result;}
    bool sawProcess=false,complete=true,allClosed=true;
    for(ULONG_PTR i=0;i<table->count;++i){
        const auto& item=table->entries[i];if(item.pid!=pid)continue;sawProcess=true;
        if(item.type!=eventType&&item.type!=mutexType)continue;
        HANDLE copied=nullptr;
        if(!DuplicateHandle(process.get(),reinterpret_cast<HANDLE>(item.handle),GetCurrentProcess(),&copied,0,FALSE,DUPLICATE_SAME_ACCESS)){
            complete=false;result.error=GetLastError();continue;
        }
        auto duplicate=Owned(copied);
        std::vector<unsigned char> nameBuffer(4096);
        status=queryObject(copied,1,nameBuffer.data(),static_cast<ULONG>(nameBuffer.size()),&needed);
        if(status<0){complete=false;result.error=static_cast<DWORD>(status);continue;}
        const auto name=reinterpret_cast<const UnicodeName*>(nameBuffer.data());
        if(!name->buffer||!name->length)continue;
        const auto start=reinterpret_cast<uintptr_t>(name->buffer),base=reinterpret_cast<uintptr_t>(nameBuffer.data());
        if(name->length%sizeof(wchar_t)||start<base||start+name->length>base+nameBuffer.size()){complete=false;result.error=ERROR_INVALID_DATA;continue;}
        const std::wstring full(name->buffer,name->length/sizeof(wchar_t));
        const auto slash=full.find_last_of(static_cast<wchar_t>(92));
        if(full.substr(slash==std::wstring::npos?0:slash+1)!=expected)continue;
        result.found=true;
        if(closeSource){
            // Revalidate the source handle just before the close; never match by substring.
            HANDLE check=nullptr;
            if(!DuplicateHandle(process.get(),reinterpret_cast<HANDLE>(item.handle),GetCurrentProcess(),&check,0,FALSE,DUPLICATE_SAME_ACCESS)){
                complete=false;allClosed=false;result.error=GetLastError();continue;
            }
            auto recheck=Owned(check);std::vector<unsigned char> verify(4096);
            status=queryObject(check,1,verify.data(),static_cast<ULONG>(verify.size()),nullptr);
            auto verifyName=reinterpret_cast<const UnicodeName*>(verify.data());
            if(status<0||!verifyName->buffer||verifyName->length!=name->length||std::wstring(verifyName->buffer,verifyName->length/sizeof(wchar_t))!=full){complete=false;allClosed=false;result.error=ERROR_INVALID_HANDLE;continue;}
            HANDLE removed=nullptr;
            if(!DuplicateHandle(process.get(),reinterpret_cast<HANDLE>(item.handle),GetCurrentProcess(),&removed,0,FALSE,DUPLICATE_CLOSE_SOURCE|DUPLICATE_SAME_ACCESS)){
                allClosed=false;result.error=GetLastError();
            }
            if(removed)CloseHandle(removed);
        }
    }
    result.inspected=complete&&sawProcess&&WaitForSingleObject(process.get(),0)==WAIT_TIMEOUT;
    result.closed=closeSource&&result.found&&allClosed;
    return result;
}

bool HandleCloser::CloseProcessRobloxHandle(DWORD pid) {
    auto result=InspectNamedEvent(pid,L"ROBLOX_singletonEvent",true);
    // An inspected client with no singleton event is already clear. The former
    // boolean treated this normal state as failure and latched the launch block.
    return result.inspected&&(!result.found||result.closed);
}
