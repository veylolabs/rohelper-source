#pragma once
#include <windows.h>
class HandleCloser {
public:
    struct Result { bool inspected=false; bool found=false; bool closed=false; DWORD error=0; };
    static Result InspectNamedEvent(DWORD pid,const wchar_t* name,bool closeSource=false);
    static bool CloseProcessRobloxHandle(DWORD targetPid);
};
