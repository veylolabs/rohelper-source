#pragma once
#include <string>
#include <algorithm>
#include <cctype>
namespace CsrfChallenge {
struct Reply { unsigned long status = 0; std::string body, headers; };
inline std::string Header(const std::string& headers, std::string key) {
    auto lower=[](unsigned char c){return static_cast<char>(std::tolower(c));};
    std::transform(key.begin(),key.end(),key.begin(),lower);
    for(size_t start=0;start<headers.size();) {
        auto end=headers.find('\n',start);if(end==std::string::npos)end=headers.size();
        auto line=headers.substr(start,end-start);auto colon=line.find(':');
        if(colon!=std::string::npos) {
            auto name=line.substr(0,colon);std::transform(name.begin(),name.end(),name.begin(),lower);
            if(name==key) {
                auto value=line.substr(colon+1);const auto begin=value.find_first_not_of(" \t");
                if(begin==std::string::npos)return {};
                value.erase(0,begin);
                while(!value.empty()&&(value.back()=='\r'||value.back()==' '||value.back()=='\t'||value.back()=='\0'))value.pop_back();
                return value;
            }
        }
        start=end+1;
    }
    return {};
}
template<class Send> Reply Request(std::string& token, Send send) {
    auto response=send(token);
    const auto fresh=Header(response.headers,"x-csrf-token");
    const bool valid=!fresh.empty()&&fresh.size()<=4096&&std::all_of(fresh.begin(),fresh.end(),[](unsigned char c){return c>=33&&c<=126;});
    if(response.status==403&&valid&&fresh!=token) {token=fresh;response=send(token);}
    return response; // One server-directed retry only; never retry 429/5xx.
}
}
