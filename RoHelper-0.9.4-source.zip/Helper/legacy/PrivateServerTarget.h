#pragma once
#include "json.hpp"
#include <regex>
#include <set>
#include <string>
#include <functional>
#include <algorithm>
#include <cctype>

namespace PrivateServerTarget {
struct Target { std::string place, code, error; bool share = false; };
inline bool Code(const std::string& value) { return std::regex_match(value, std::regex("[A-Za-z0-9_-]{1,256}")); }
inline bool Place(const std::string& value) { return std::regex_match(value, std::regex("[1-9][0-9]{0,23}")); }
inline std::string Decode(const std::string& value) {
    std::string result;
    for (size_t i=0;i<value.size();++i) {
        if(value[i]=='%') {
            if(i+2>=value.size()) return {};
            auto hex=[](char c)->int {if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;if(c>='A'&&c<='F')return c-'A'+10;return -1;};
            int a=hex(value[i+1]),b=hex(value[i+2]);if(a<0||b<0)return {};
            result.push_back(static_cast<char>(16*a+b));i+=2;
        } else result.push_back(value[i]);
    }
    return Code(result)?result:std::string();
}
inline Target Input(const std::string& place, const std::string& link) {
    Target result{place,"",""};
    const auto invalid=[&]{result.error="Invalid VIP server link. No public server was joined.";return result;};
    if(!place.empty()&&!Place(place))return invalid();
    if(link.empty())return result;
    if(Code(link)){result.code=link;return result;}
    std::smatch match;
    if(link.size()>4096||!std::regex_match(link,match,std::regex(R"(^https://(?:www\.)?roblox\.com(/[^?#\s]*)\?([^#\s]+)(?:#[^\s]*)?$)",std::regex::icase)))return invalid();
    const auto path=match[1].str(),query=match[2].str();
    if(std::regex_match(path,std::regex("/share/?",std::regex::icase)))result.share=true;
    else {
        std::smatch game;
        if(!std::regex_match(path,game,std::regex("/games/([1-9][0-9]{0,23})(?:/.*)?",std::regex::icase)))return invalid();
        if(!place.empty()&&place!=game[1].str()){result.error="MISMATCH_PLACE_ID";return result;}
        result.place=game[1].str();
    }
    const auto key=result.share?"code":"privateServerLinkCode";
    for(size_t start=0;start<query.size();) {
        auto end=query.find('&',start);if(end==std::string::npos)end=query.size();
        const auto part=query.substr(start,end-start);const auto equal=part.find('=');
        if(equal!=std::string::npos&&part.substr(0,equal)==key) {
            const auto code=Decode(part.substr(equal+1));
            if(code.empty()||(!result.code.empty()&&result.code!=code))return invalid();
            result.code=code;
        }
        start=end+1;
    }
    if(result.code.empty())return invalid();
    return result;
}
inline Target Resolve(const std::string& response, const std::string& expectedPlace) {
    Target result{expectedPlace,"","The VIP share link could not be resolved. It may be unavailable or inaccessible to this account. No public server was joined."};
    if(response.size()>1024*1024)return result;
    try {
        const auto document=nlohmann::json::parse(response);
        if(!document.is_object()||document.contains("errors"))return result;
        std::set<std::string> codes,places;bool invalid=false,expired=false;
        std::function<void(const nlohmann::json&,int)> visit=[&](const nlohmann::json& node,int depth){
            if(depth>16){invalid=true;return;}
            if(node.is_object())for(auto it=node.begin();it!=node.end();++it) {
                if(it.key()=="linkCode") {
                    if(!it.value().is_string()||!Code(it.value().get<std::string>()))invalid=true;
                    else codes.insert(it.value().get<std::string>());
                } else if(it.key()=="placeId") {
                    std::string place;
                    if(it.value().is_string())place=it.value().get<std::string>();
                    else if(it.value().is_number_unsigned())place=std::to_string(it.value().get<unsigned long long>());
                    else if(it.value().is_number_integer())place=std::to_string(it.value().get<long long>());
                    if(place!="0") {if(!Place(place))invalid=true;else places.insert(place);}
                } else if(it.key()=="status"&&it.value().is_string()) {
                    auto status=it.value().get<std::string>();
                    std::transform(status.begin(),status.end(),status.begin(),[](unsigned char c){return static_cast<char>(std::tolower(c));});
                    if(status=="expired")expired=true;
                    if(status=="invalid"||status=="revoked"||status=="inactive"||status=="unauthorized")invalid=true;
                }
                if(it.value().is_structured())visit(it.value(),depth+1);
            } else if(node.is_array())for(const auto& item:node)visit(item,depth+1);
        };
        visit(document,0);
        if(expired){result.error="This VIP share link has expired. No public server was joined.";return result;}
        if(invalid||codes.size()!=1||places.size()>1)return result;
        if(!places.empty()) {
            if(!expectedPlace.empty()&&expectedPlace!=*places.begin()){result.error="MISMATCH_PLACE_ID";return result;}
            result.place=*places.begin();
        }
        if(!Place(result.place))return result;
        result.code=*codes.begin();result.error.clear();
    }catch(...){}
    return result;
}
}
