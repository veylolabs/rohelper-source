#pragma once
#include "json.hpp"
#include <string>

namespace GameTitles {
inline std::string Name(const nlohmann::json& item,bool sourceFirst=false) {
    for(const auto key:sourceFirst?std::initializer_list<const char*>{"sourceName","name"}:std::initializer_list<const char*>{"name"}) {
        if(item.contains(key)&&item[key].is_string()) {
            auto value=item[key].get<std::string>();
            if(!value.empty()&&value!="[TITLE UNAVAILABLE]")return value;
        }
    }
    return {};
}
// The caller sends Accept-Language: en-US. Public metadata must not inherit
// the selected account's locale; authentication is only a restricted-place fallback.
template<class Request>
std::string Lookup(const std::string& place,std::string& universe,const std::string& cookie,Request request) {
    if(universe.empty()&&!place.empty())try {
        auto result=nlohmann::json::parse(request("apis.roblox.com","/universes/v1/places/"+place+"/universe",""));
        if(result.contains("universeId")&&result["universeId"].is_number_integer())universe=std::to_string(result["universeId"].get<long long>());
    }catch(...){}
    if(!universe.empty())try {
        auto result=nlohmann::json::parse(request("games.roblox.com","/v1/games?universeIds="+universe,""));
        if(result.contains("data")&&result["data"].is_array()&&!result["data"].empty()) {
            auto name=Name(result["data"][0]);if(!name.empty())return name;
        }
    }catch(...){}
    if(!place.empty()&&!cookie.empty())try {
        auto result=nlohmann::json::parse(request("games.roblox.com","/v1/games/multiget-place-details?placeIds="+place,cookie));
        if(result.is_array()&&!result.empty())return Name(result[0],true);
    }catch(...){}
    return {};
}
}
