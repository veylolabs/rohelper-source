#pragma once
#include <string>
#include "ClientDeployment.h"
namespace ClientLaunchArguments {
// Quote one Windows argv value. Never pass these credentials through a shell.
inline std::string Quote(const std::string& value) {
    std::string out="\"";size_t slashes=0;
    for(char c:value){if(c=='\\'){++slashes;continue;}if(c=='\"')out.append(slashes*2+1,'\\');else out.append(slashes,'\\');slashes=0;out+=c;}
    out.append(slashes*2,'\\');return out+'\"';
}
inline std::string DecodeTarget(const std::string& encoded) {
    const std::string prefix="https%3A%2F%2Fassetgame.roblox.com%2Fgame%2FPlaceLauncher.ashx%3Frequest%3D";
    if(encoded.compare(0,prefix.size(),prefix)!=0)return {};
    auto hex=[](char c)->int{if(c>='0'&&c<='9')return c-'0';if(c>='A'&&c<='F')return c-'A'+10;if(c>='a'&&c<='f')return c-'a'+10;return -1;};
    std::string out;for(size_t i=0;i<encoded.size();++i){unsigned char c=encoded[i];if(c=='%'){if(i+2>=encoded.size())return {};int a=hex(encoded[i+1]),b=hex(encoded[i+2]);if(a<0||b<0)return {};c=static_cast<unsigned char>(a*16+b);i+=2;}if(c<=32||c>=127||c=='"'||c=='\\')return {};out+=static_cast<char>(c);}return out;
}
// All providers must carry an explicit channel, including empty production.
// Bare -app inherits the shared registry channel and can start an unwanted update.
inline std::string Authenticated(const std::string& ticket,const std::string& encodedTarget,const std::string& channel) {
    if(ticket.empty()||ticket.size()>32768)return {};
    for(unsigned char c:ticket)if(c<=32||c>=127||c=='+'||c=='"')return {};
    const auto suffix=ClientDeployment::LaunchSuffix(channel);if(suffix.empty())return {};
    if(!encodedTarget.empty()&&DecodeTarget(encodedTarget).empty())return {};
    return Quote("roblox-player:1+launchmode:play+gameinfo:"+ticket+(encodedTarget.empty()?"":"+placelauncherurl:"+encodedTarget)+suffix);
}
}
