#pragma once
inline void TestMouseMacros(){
    const char* origins[]={"top-left","top-center","top-right","center-left","center","center-right","bottom-left","bottom-center","bottom-right"};
    for(int i=0;i<9;i++){
        const auto p=MouseMacro::Position(origins[i],0,0,801,601);
        assert(p.x==(i%3)*400&&p.y==(i/3)*300);
        const auto x=i%3==2?-7:7,y=i/3==2?-11:11;
        const auto shifted=MouseMacro::Position(origins[i],x,y,801,601);
        assert(shifted.x==p.x+x&&shifted.y==p.y+y);
        if(i%3!=1)assert(Fails([&]{MouseMacro::Validate("left",origins[i],-x,y);}));
        if(i/3!=1)assert(Fails([&]{MouseMacro::Validate("left",origins[i],x,-y);}));
    }
    assert(Fails([]{MouseMacro::Position("center",500,0,200,100);}));
    assert(Fails([]{MouseMacro::Position("bottom-right",0,0,0,0);}));
    assert(Fails([]{MouseMacro::Validate("double","center",0,0,true);}));
    RECT desktop{-1920,-1080,3840,2160};
    const auto left=MouseMacro::Inputs({-1800,-900},desktop,"left",false);
    const auto right=MouseMacro::Inputs({100,200},desktop,"right",true);
    assert(left.size()==3&&left[0].type==INPUT_MOUSE);
    assert((left[0].mi.dwFlags&MOUSEEVENTF_VIRTUALDESK)!=0&&left[0].mi.dx>0&&left[0].mi.dy>0);
    assert(left[1].mi.dwFlags==MOUSEEVENTF_LEFTDOWN&&left[2].mi.dwFlags==MOUSEEVENTF_LEFTUP);
    assert(right.size()==2&&right[1].mi.dwFlags==MOUSEEVENTF_RIGHTDOWN);
    assert(MouseMacro::Button("right",true).mi.dwFlags==MOUSEEVENTF_RIGHTUP);
    assert(Fails([&]{MouseMacro::Move({-1921,0},desktop);}));
    // Hidden synthetic window: actual Win32 resize/coordinate conversion, no input sent.
    auto window=CreateWindowExW(0,L"STATIC",L"Synthetic mouse geometry",WS_POPUP,100,100,240,180,nullptr,nullptr,GetModuleHandleW(nullptr),nullptr);
    assert(window);auto p=MouseMacro::ScreenPosition(window,"bottom-right",-10,-20);
    assert(p.x==329&&p.y==259);
    assert(MoveWindow(window,-1200,80,480,270,FALSE));
    p=MouseMacro::ScreenPosition(window,"bottom-right",-10,-20);assert(p.x==-731&&p.y==329);
    p=MouseMacro::ScreenPosition(window,"center",0,0);assert(p.x==-960&&p.y==215);DestroyWindow(window);
    MacroVM mouse("click('left','top-left',12,34);click('right','bottom-right',-8,-9);click('double','center',-5,6);mouse_hold('right','center-left',7,-4);wait(.5);mouse_release()");
    std::vector<MacroAction> actions;while(mouse.Advance())actions.push_back(mouse.next);
    assert(actions.size()==6&&actions[0].kind=="mouse_click"&&actions[0].x==12&&actions[0].y==34);
    assert(actions[1].button=="right"&&actions[1].origin=="bottom-right"&&actions[1].x==-8);
    assert(actions[2].kind=="mouse_double"&&actions[2].button=="left");
    assert(actions[3].kind=="mouse_hold"&&actions[4].kind=="wait"&&actions[5].kind=="mouse_release");
    for(auto code:{"click('left','top-left',-1,0)","click('right','bottom-right',0,1)","click('middle','center',0,0)","mouse_hold('double','center',0,0)","mouse_release('left')","click('left','center',.5,0)"})assert(Fails([&]{MacroVM invalid(code);invalid.Advance();}));
    json block={{"id","mouse"},{"type","mouse_hold"},{"button","left"},{"origin","bottom-center"},{"x",-10},{"y",-20}};
    json macro={{"visual",json::array({block})},{"visualSource","mouse_hold('left','bottom-center',-10,-20)"}};VisualMacro::Validate(macro);
    macro["visual"][0]["y"]=20;assert(Fails([&]{VisualMacro::Validate(macro);}));
    std::cout<<"PASS nine mouse origins, signed pixel bounds, actual window resizing/negative-screen coordinates, click/hold/release inputs, Lua actions and native visual validation. No mouse input was sent.\n";
}
