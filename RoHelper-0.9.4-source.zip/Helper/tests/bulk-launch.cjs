const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'../web'),out=path.resolve(__dirname,'../../Output/RoHelper-tests');fs.mkdirSync(out,{recursive:true});
let gameContent={bundle:JSON.parse(fs.readFileSync(path.join(root,'game-content.json'),'utf8')),message:'',refreshing:false};
const defaults={volume:75,muted:false,enabled:false,mode:'simple',keys:['SPACE'],minSeconds:300,maxSeconds:480,macroId:'',repeatSeconds:30,pauseOnActivity:true};
const account=(id,name,hasSession=true)=>({id,userId:Number(id),username:name,displayName:name+' display',nickname:'',avatar:'',color:'#a78bfa',tags:[],notes:'Keep account notes',settings:{},hasSession,sessionExpired:false});
let data={schema:1,revision:0,accounts:[account('101','Main'),account('102','Storage'),account('103','Notebook',false)],servers:[{id:'vip',name:'My private server',placeId:'109983668079237',gameName:'Steal a Brainrot',gameIcon:'',type:'private',target:'https://www.roblox.com/games/109983668079237?privateServerLinkCode=example',notes:'Private notes',tags:[]}],macros:[],tags:[{id:'main',name:'Main',icon:'crown',color:'#a78bfa'},{id:'storage',name:'Storage',icon:'box',color:'#38bdf8'}],selectedServer:'vip',defaults,settings:{theme:'dark',accent:'#818cf8',minimizeToTray:true,compact:false,sidebarCollapsed:false,closedGroups:[],layout:{auto:true,mainUserId:0,mainDisplay:'display1',displays:['display1','display2','display3']}}};
data.accounts[0].tags=['main'];data.accounts[1].tags=['storage'];data.accounts[0].settings.volume=55;
let snapshot={clients:[{pid:501,token:'first',userId:101,accountId:'101',username:'Main',audio:{available:true,volume:55,muted:false},effective:{...defaults,volume:55},overrides:{},automation:{running:false,status:'Stopped'}}],monitors:[{id:'display1',label:'DISPLAY1',width:1920,height:1080},{id:'display2',label:'DISPLAY2',width:1920,height:1080},{id:'display3',label:'DISPLAY3',width:2560,height:1440}],multi:{running:true,error:''},launchBusy:false};
data.accounts.push(account('104','Other'),account('105','Expired',false),account('106','After'));
data.accounts[4].sessionExpired=true;
data.servers.push({...data.servers[0],id:'second',name:'Second destination'});
const server=http.createServer((req,res)=>{try{let name=decodeURIComponent(req.url.split('?')[0]);const file=path.join(root,name==='/'?'index.html':name);res.setHeader('Content-Type',({'.html':'text/html','.css':'text/css','.js':'text/javascript','.svg':'image/svg+xml','.png':'image/png'})[path.extname(file)]||'text/plain');res.end(fs.readFileSync(file));}catch{res.writeHead(404).end();}});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({channel:'msedge',headless:true});const launches=[],pendingLaunches=new Map(),calls=[],errors=[];
try{const p=await browser.newPage({viewport:{width:1450,height:1050}});p.on('pageerror',e=>errors.push(e.message));p.setDefaultTimeout(10000);
await p.exposeFunction('native',async m=>{calls.push(m);const r={ok:true,requestId:m.requestId};
 if(m.action==='load')Object.assign(r,{data:structuredClone(data),snapshot:structuredClone(snapshot),gameContent:structuredClone(gameContent),version:'0.9.3',dataPath:'Isolated synthetic test data'});
 if(m.action==='save'){data=structuredClone(m.data);data.revision++;r.revision=data.revision;}
 if(m.action==='scan')r.snapshot=structuredClone(snapshot);
 if(m.action==='launch'){launches.push(m);snapshot.launchBusy=true;pendingLaunches.set(m.accountId,m);return;}
 await p.evaluate(r=>window.receive(r),r);
});
await p.addInitScript(()=>{const listeners=[];window.chrome={webview:{addEventListener:(_,fn)=>listeners.push(fn),postMessage:m=>window.native(m)}};window.receive=r=>listeners.forEach(fn=>fn({data:r}));});
await p.goto('http://127.0.0.1:'+server.address().port);await p.locator('.account-card').first().waitFor();
async function finish(id,ok=true){const m=pendingLaunches.get(id);assert(m);pendingLaunches.delete(id);snapshot.launchBusy=false;if(ok){const a=data.accounts.find(a=>a.id===id);snapshot.clients.push({pid:Number(id)+1000,token:'synthetic-'+id,userId:a.userId,accountId:id,username:a.username});}await p.evaluate(r=>window.receive(r),{requestId:m.requestId,ok,message:'Roblox window opened.',launchResult:'opened',error:'Synthetic account launch failed.'});}
// Poll the observable UI action count through a test-only exposed callback, not real launches.
await p.exposeFunction('launchCount',()=>launches.length);
async function countIs(n){await p.waitForFunction(async n=>await window.launchCount()===n,n);}
await p.getByRole('button',{name:'Launch all',exact:true}).click();await countIs(1);assert.equal(launches[0].accountId,'102');assert.equal(launches[0].serverId,'vip');
assert(await p.locator('[data-play-account="104"]').isDisabled());assert(await p.getByRole('button',{name:/^Launch destination:/}).isDisabled());
await p.evaluate(()=>startBulkLaunch());assert.equal(launches.length,1);
await p.evaluate(()=>nav('settings'));await p.evaluate(()=>{db.selectedServer='second';nav('accounts');});assert(await p.getByRole('button',{name:'Stop queue',exact:true}).isVisible());
await finish('102',false);await countIs(2);assert.equal(launches[1].accountId,'104');assert.equal(launches[1].serverId,'vip');assert.match(await p.locator('[data-launch-account="102"]').innerText(),/Synthetic account launch failed/);
await p.screenshot({path:path.join(out,'bulk-launch-desktop-093.png'),fullPage:true});
await finish('104');await countIs(3);assert.equal(launches[2].accountId,'106');await finish('106');await p.waitForFunction(()=>!bulkLaunch.active);assert.equal(launches.length,3);assert.match(await p.locator('[data-bulk-status]').innerText(),/2 opened.*1 failed/);
assert(!launches.some(m=>['101','103','105'].includes(m.accountId)));assert(await p.getByRole('button',{name:/^Launch destination:/}).isEnabled());
// Stop lets the current request finish and never starts the remainder.
snapshot.clients=snapshot.clients.slice(0,1);await p.evaluate(s=>window.receive({type:'snapshot',snapshot:s}),snapshot);await p.getByRole('button',{name:'Launch all',exact:true}).click();await countIs(4);await p.getByRole('button',{name:'Stop queue',exact:true}).click();assert(await p.getByRole('button',{name:'Stop queue',exact:true}).isDisabled());await finish('102');await p.waitForFunction(()=>!bulkLaunch.active);assert.equal(launches.length,4);assert.match(await p.locator('[data-bulk-status]').innerText(),/Queue stopped/);
// Search limits the batch; current account order and chosen server are used.
const search=p.getByRole('textbox',{name:'Search usernames, nicknames, tags, games…',exact:true});await search.fill('After');await p.getByRole('button',{name:'Launch filtered',exact:true}).click();await countIs(5);assert.equal(launches[4].accountId,'106');assert.equal(launches[4].serverId,'second');await finish('106');await p.waitForFunction(()=>!bulkLaunch.active);
await search.fill('Notebook');assert(await p.getByRole('button',{name:'Launch filtered',exact:true}).isDisabled());await search.fill('');
// Losing MultiRoblox stops future requests, and mobile controls stay within the page.
snapshot.clients=snapshot.clients.slice(0,1);await p.evaluate(s=>window.receive({type:'snapshot',snapshot:s}),snapshot);await p.getByRole('button',{name:'Launch all',exact:true}).click();await countIs(6);snapshot.multi.running=false;await finish('102');await p.waitForFunction(()=>!bulkLaunch.active);assert.equal(launches.length,6);assert.match(await p.locator('[data-bulk-status]').innerText(),/MultiRoblox stopped/);
await p.setViewportSize({width:390,height:844});await p.waitForFunction(()=>document.body.scrollWidth<=innerWidth+1);await p.screenshot({path:path.join(out,'bulk-launch-phone-093.png'),fullPage:true});
assert(await p.locator('body').evaluate(e=>e.scrollWidth<=innerWidth+1));assert(!calls.some(c=>['client_close','multi_stop'].includes(c.action)));assert.deepEqual(errors,[]);console.log('PASS sequential native completion gating, listed order, pinned destination, running/login skips, duplicate-start guard, failure continuation, navigation, stop-after-current, search restriction, MultiRoblox interruption and phone layout. No Roblox launched.');
}finally{await browser.close();server.close();}})().catch(e=>{console.error(e);process.exitCode=1;server.close();});
