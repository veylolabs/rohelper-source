// Check the rendered menu against its trigger, including top-layer dialog menus.
const path=require('node:path'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const web=path.resolve(__dirname,'../web');
(async()=>{const browser=await chromium.launch({channel:'msedge',headless:true});try{
 const p=await browser.newPage({viewport:{width:1280,height:900}});
 await p.setContent('<!doctype html><html><body><div id="fixture"></div><dialog id="dialog"><div id="modal-fixture"></div></dialog></body></html>');
 await p.addStyleTag({path:path.join(web,'style.css')});
 await p.addScriptTag({path:path.join(web,'dropdowns.js')});
 await p.evaluate(()=>{window.originalShowPopover=HTMLElement.prototype.showPopover;window.icon=()=>{const n=document.createElement('span');n.textContent='★';return n;};});
 for(const zoom of [1,1.25,0.8])for(const kind of ['destination','bottom-right','modal','icon-grid','fallback']){
  await p.evaluate(({zoom,kind})=>{
   document.documentElement.style.zoom=zoom;
   const dialog=document.querySelector('dialog');if(dialog.open)dialog.close();
   document.querySelector('#fixture').replaceChildren();document.querySelector('#modal-fixture').replaceChildren();
   const host=document.createElement('div');host.style.cssText=kind==='bottom-right'?'position:fixed;right:18px;bottom:20px;width:180px':kind==='modal'||kind==='icon-grid'?'margin:100px 40px 160px;width:190px':'position:absolute;left:680px;top:220px;width:220px';
   const inModal=kind==='modal'||kind==='icon-grid';document.querySelector(inModal?'#modal-fixture':'#fixture').append(host);
   if(inModal)dialog.showModal();
   const select=document.createElement('select');select.id='sample';if(kind==='icon-grid')select.dataset.iconGrid='true';
   for(let i=0;i<(kind==='icon-grid'?16:5);i++)select.add(new Option('Destination '+i,String(i)));
   host.append(select);polishSelect(select,'Test selection');
   HTMLElement.prototype.showPopover=kind==='fallback'?undefined:window.originalShowPopover;
  },{zoom,kind});
  await p.locator('.select-trigger').click();
  const box=await p.evaluate(()=>{const b=document.querySelector('.select-trigger').getBoundingClientRect(),m=document.querySelector('.polished-menu').getBoundingClientRect();return {button:{left:b.left,top:b.top,bottom:b.bottom},menu:{left:m.left,top:m.top,right:m.right,bottom:m.bottom},width:innerWidth,height:innerHeight};});
  const gap=6*zoom,expectedLeft=Math.max(12*zoom,Math.min(box.button.left,box.width-(box.menu.right-box.menu.left)-12*zoom));
  assert(Math.abs(box.menu.left-expectedLeft)<2,`${kind} at ${zoom}: menu horizontal offset: ${JSON.stringify(box)}`);
  assert(Math.min(Math.abs(box.menu.top-box.button.bottom-gap),Math.abs(box.button.top-box.menu.bottom-gap))<2,`${kind} at ${zoom}: menu vertical offset: ${JSON.stringify(box)}`);
  assert(box.menu.left>=0&&box.menu.right<=box.width+1&&box.menu.top>=0&&box.menu.bottom<=box.height+1,`${kind} at ${zoom}: menu leaves viewport`);
  await p.keyboard.press('Escape');
 }
 console.log('PASS dropdown alignment, viewport edges, modal and icon-grid menus, CSS zoom, and non-popover fallback.');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
