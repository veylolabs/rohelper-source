#define NOMINMAX
#include <windows.h>
#include <cassert>
#include <iostream>
#include <deque>
#include "../native/Store.h"
#include "../native/Clients.h"
#include "../native/Macros.h"
#include "../native/AutomationPlatform.h"

// Exercise the actual scheduler and Lua VM with virtual time/windows/input.
// Nothing below discovers, focuses or sends input to a real application.
struct SimulatedAutomation {
    struct Event { ULONGLONG due; DWORD pid; bool up; };
    inline static ULONGLONG now=10000, failUntil=0;
    inline static HWND foreground=reinterpret_cast<HWND>(999);
    inline static std::set<DWORD> live, blocked;
    inline static std::map<DWORD,unsigned> presses, releases;
    inline static std::map<DWORD,ULONGLONG> last, gap;
    inline static std::deque<Event> queued;
    static DWORD Pid(HWND h){return static_cast<DWORD>(reinterpret_cast<ULONG_PTR>(h));}
    static ULONGLONG Now(){return now;}
    static void Begin(bool){}
    static void End(){}
    static bool Quiet(){return now-AutomationActivity::lastActivity.load()>=3000;}
    static bool Valid(const RosterClients::Client& c){return live.count(c.pid)!=0;}
    static HWND Foreground(){return foreground;}
    static bool Window(HWND){return true;}
    static void Focus(HWND h){if(!blocked.count(Pid(h)))foreground=h;}
    static UINT Send(UINT count,INPUT* inputs){
        if(now<failUntil)return 0;
        const auto pid=Pid(foreground);
        for(UINT i=0;i<count;++i){
            assert(inputs[i].type==INPUT_KEYBOARD);
            queued.push_back({now+20,pid,(inputs[i].ki.dwFlags&KEYEVENTF_KEYUP)!=0});
        }
        return count;
    }
    static void Deliver(){
        while(!queued.empty()&&queued.front().due<=now){
            const auto e=queued.front();queued.pop_front();
            // Queued SendInput must drain before focus is restored/switched.
            assert(Pid(foreground)==e.pid);
            AutomationActivity::Observe(true,AutomationActivity::inputTag,now);
            if(e.up)++releases[e.pid];
            else {++presses[e.pid];if(last[e.pid])gap[e.pid]=std::max(gap[e.pid],now-last[e.pid]);last[e.pid]=now;}
        }
    }
};
#define ROHELPER_AUTOMATION_PLATFORM SimulatedAutomation
#include "../native/Automation.h"
using Sim=SimulatedAutomation;
static json Options(double interval){return {{"volume",75},{"muted",false},{"enabled",true},{"mode","simple"},{"keys",json::array({"SPACE"})},{"minSeconds",interval},{"maxSeconds",interval},{"macroId",""},{"repeatSeconds",30},{"pauseOnActivity",true}};}
static void Run(ULONGLONG duration){const auto end=Sim::now+duration;for(;Sim::now<end;Sim::now+=20){Sim::Deliver();Automation::Tick();}}
static void Reset(){Sim::queued.clear();Automation::StopAll();Sim::queued.clear();Sim::live.clear();Sim::blocked.clear();Sim::presses.clear();Sim::releases.clear();Sim::last.clear();Sim::gap.clear();Sim::failUntil=0;Sim::foreground=reinterpret_cast<HWND>(999);Automation::cursor=0;AutomationActivity::lastActivity=0;}
static void Add(DWORD pid,double interval){Sim::live.insert(pid);Automation::Start({pid,"synthetic",reinterpret_cast<HWND>(static_cast<ULONG_PTR>(pid))},Options(interval),"");}
int main(int argc,char** argv){
    if(argc>1&&std::string(argv[1])=="--activity-monitor"){
        WindowsAutomationPlatform::Begin(true);
        assert(AutomationActivity::monitor);
        WindowsAutomationPlatform::Quiet();
        WindowsAutomationPlatform::End();
        assert(!AutomationActivity::monitor);
        std::cout<<"PASS native activity monitor startup and cleanup; no input injected or recorded.\n";
        return 0;
    }
    AutomationActivity::lastActivity=10;
    AutomationActivity::Observe(true,AutomationActivity::inputTag,100);
    assert(AutomationActivity::lastActivity==10);
    AutomationActivity::Observe(false,AutomationActivity::inputTag,200);
    assert(AutomationActivity::lastActivity==200);
    AutomationActivity::Observe(true,123,300);
    assert(AutomationActivity::lastActivity==300);
    Reset();
    // Even 40 clients competing at the minimum interval all keep getting turns.
    for(DWORD p=1;p<=40;++p)Add(p,.02);
    Run(180000);
    for(DWORD p=1;p<=40;++p){assert(Sim::presses[p]>=6);assert(Sim::gap[p]<30000);assert(Sim::releases[p]+1>=Sim::presses[p]);}
    std::cout<<"PASS 40 competing clients: fair turns, queued key releases retain target focus.\n";
    Reset();
    // Eight virtual hours with 40 accounts, staggered normal intervals, one
    // permanently blocked window and an initial transient SendInput failure.
    Sim::blocked.insert(7);Sim::failUntil=Sim::now+2000;
    for(DWORD p=1;p<=40;++p)Add(p,300+(p%4)*60);
    Run(8ULL*60*60*1000);
    for(DWORD p=1;p<=40;++p)if(p!=7){assert(Sim::presses[p]>=50);assert(Sim::gap[p]<510000);assert(!Automation::targets.at(p)->stopped);}
    assert(Sim::presses[7]==0);
    Sim::blocked.erase(7);Run(3000);assert(Sim::presses[7]>0);
    std::cout<<"PASS eight-hour simulation: all 39 reachable clients remain serviced; blocked and failed input retries recover.\n";
    Reset();for(DWORD p=1;p<=10;++p)Add(p,1);
    assert(Automation::Tracked({1,"synthetic",reinterpret_cast<HWND>(1)}));
    assert(!Automation::Tracked({1,"replacement-process",reinterpret_cast<HWND>(1)}));
    assert(!Automation::Tracked({1,"synthetic",reinterpret_cast<HWND>(1001)}));
    Run(10000);
    // User activity pauses every client, then activity-free time resumes them.
    Sim::queued.clear();AutomationActivity::Observe(false,0,Sim::now);
    Automation::Tick();Sim::queued.clear();
    const auto before=Sim::presses;
    for(auto& item:Automation::targets){assert(item.second->status=="Paused while you use the PC");assert(!Automation::Held(*item.second));}
    Run(2000);assert(Sim::presses==before);
    Run(15000);for(DWORD p=1;p<=10;++p)assert(Sim::presses[p]>before.at(p));
    // Closing a target and stopping all leave no scheduler owner behind.
    Sim::live.erase(4);Sim::queued.clear();Automation::Tick();Sim::queued.clear();assert(!Automation::targets.count(4));
    Reset();assert(!Automation::owner&&Automation::targets.empty());
    std::cout<<"PASS real activity pause/resume and cleanup; no Roblox processes or real inputs used.\n";
}
