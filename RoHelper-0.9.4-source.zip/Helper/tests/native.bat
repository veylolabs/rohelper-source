@echo off
setlocal
if defined ROHELPER_PYTHON (
  "%ROHELPER_PYTHON%" "%~dp0..\tools\test_native.py" %*
) else (
  python "%~dp0..\tools\test_native.py" %*
)
exit /b %errorlevel%
