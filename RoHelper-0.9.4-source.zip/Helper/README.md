# RoHelper

Current release: 0.9.4. Game catalogs update separately online, and account search includes games with saved account data. Dropdowns align with their controls, and tag icon pickers show icons with names on hover. A Windows app for managing Roblox accounts, running clients and game inventories.

Run `RoHelper.exe` with `WebView2Loader.dll` and the `web` folder beside it. Microsoft Edge WebView2 Runtime and the Visual C++ runtime are required. Every normal start uses `%LOCALAPPDATA%\RoHelper`. Fresh installations start empty. No other application data is imported automatically.

## Accounts and destinations

- Add account offers Roblox login, session import, and username-only tracking as equal choices. Tracking accounts show Log in instead of Play.
- Profile nicknames, colors, tags, search, custom ordering and compact view are stored per account. Click tag filters to include them; right-click to exclude.
- Saved servers support private links, specific public instances, and Any public server entries. Each belongs to a game. The selected destination is shared by individual Play actions. Bulk launch follows the listed account order and waits for each Roblox window. There is no automatic rejoin.
- Any public server resolves one instance and reuses it for subsequent individual launches in this app session. Edit that server and choose a fresh public destination to reset it.
- The native MultiRoblox module starts with RoHelper. The top banner shows when stopped, inaccessible, or held by another manager. Existing Roblox processes are never closed to establish the guard. Native launching uses the installed version matching the account's deployment; it does not run the Roblox installer.

## Running clients and settings

Default account settings are inherited by each account. Override individual settings on an account. Running clients provides session-only overrides, Windows audio controls, Mute all, focus/close controls and one Start/Stop automation button. Overrides disappear when that process closes. Audio-only changes do not restart automation.

Layouts use automatic tiling across selected displays. A main account is optional on multiple monitors. With one monitor, No main window is used and all identified clients tile. Main-window selection stays explicitly optional and is never inferred from tags. The manual Apply layout button is also available.

Closing minimizes to the tray by default; change this in Settings. Tray Quit always exits RoHelper. The sidebar and its account/game groups are collapsible, with saved state.

## Shared game tabs, helpers and events

GitHub game packs define each game's tab names, order, nested groups and built-in view types. SAB account subtabs are configured there too. Compatible tabs, reference sections, events and reward/island/fuse helpers can change without reinstalling. A new kind of behavior needs a built-in renderer in an app update; public game packs contain data, never executable JavaScript. Unknown view types show an update message while preserving saved progress.

SAB Event helpers includes Skull Lucky Block, Haunted Fuse and Jump for Eggs. Filters cover rarity, account, ownership and islands. Reward details use the mutation/trait editor to add a copy to a selected free slot. Reported recipes show saved input counts. Helpers never consume inventory, simulate fuses or display egg tiers. Conditional community maximum chances are not personalized probabilities; unknown costs, times and chances remain unknown.

Events & timers has Month, Week and List views, a selected-day agenda and a banner for ongoing events and the next 24 hours. Recurrences follow their IANA zones through DST changes and month ends. Shared schedules retain source/check dates and label estimated ends. Date-only announcements mark a known start date without invented countdowns. Unconfirmed Adopt Me times remain unscheduled until customized from the in-game countdown.

Personal timers, hidden events, skips and per-field overrides are stored in the local `eventTracker` workspace section. Editing a note keeps unmodified shared times following GitHub updates. Shared defaults and removed events can be restored. Opt-in reminders work while RoHelper is open or in the tray, use Windows notifications, and deduplicate across restarts in a private reminder file. Reading tabs/events never initializes account game data.

## Steal a Brainrot

Open the SAB overview for per-account income and occupied/free slots, then use Rebirth, Inventory, Gear and Index subtabs. A profile's Games notebook also links directly to its SAB inventory.

- Gear is stored separately in each account’s `gearInventory`, without consuming base slots or changing the brainrot index. The sourced public catalog has 70 named gear entries; unverified artwork and values stay unknown. Track ownership, edit with autosave, move, duplicate, delete and undo. Legacy quantity and note fields stay preserved without editors. Gear inventory in the sidebar searches all accounts.
- Reference details put Add to inventory between Close and Done. Choose an account, then click a free slot to add the brainrot with its selected mutation and traits. Occupied slots and full accounts cannot be selected. Adopt Me uses the same account picker and then opens its item editor.
- Inventory records use the online catalog: normal artwork with local mutation filters, trait icons, rarity, base income and calculated money/second. Unknown facts stay unknown. Mutation menus keep Gold, Diamond and Rainbow at the bottom; flag traits stay last. The add/detail dialog shows in-game buy/sell values, release information and attributed trading snapshots. Prices are not displayed on inventory cards.
- Edits autosave, including when closing the editor or app. Done & next opens the next free slot for initial setup. Cards offer edit, move, duplicate, delete and compare actions; right-click opens the action menu. Bulk selections support transfers, duplication, removal, mutation/trait edits and trading status. Undo/history covers recent SAB changes and protects against overwriting subsequent conflicting edits.
- Cross-inventory search supports accounts, mutations, traits, trading status and sorts by income, rarity, name or account. Search, index and comparison view choices are remembered on this device.
- Base layout follows the three physical floors (slots 1–10, 11–18, 19–28). Arrange mode moves/swaps slots by click or drag. Lowering a rebirth never deletes overflow items.
- The mutation-specific index automatically records inventory brainrots for their owning account. Recorded checks survive transfers and rebirths. Click to check/uncheck other entries; right-click or long-press for details, mutation/trait preview and one-click addition to a chosen free base slot. Index helper finds missing entries in other accounts and can queue session tasks. Totals, reward targets and source caveats are retained from the catalog; counters can be matched to the game manually.
- Rebirth requirements come from inventory. Click a required brainrot to choose a copy from another account or add one manually. Completing a rebirth consumes the selected copies; extra duplicates require choosing which one. The planner allocates distinct copies across future rebirths. The app records notebook changes; it does not inspect or modify Roblox game state.
- Compare up to four brainrots or compare accounts by income, slots, rebirth and running status. Quick command search and the account-linked session checklist are included.
- Community exist counts refresh from SABExistCount and retain source labels and cache timestamps. Eldorado comparisons use the exact brainrot/mutation and closest listed income (within 25%), in EUR, with one listing per seller. These are asking-price samples, not completed-sale values or trait-specific appraisals. Service failures are displayed without changing inventory.

The dedicated SAB backup interface has been removed. Existing snapshot files remain untouched. Automatic pre-change snapshots still protect saved SAB data and never contain Roblox sessions. They live in `%LOCALAPPDATA%/RoHelper/sab-backups`, alongside the previous-file protection for the whole workspace.


## Keyboard automation

Choose Simple anti-AFK or Lua macro mode. Simple mode chooses among enabled Jump/W/A/S/D inputs with configured minimum and maximum intervals. Start/Stop is a single visual toggle. There is no test/countdown control.

Macros run embedded Lua 5.4.9, with these RoHelper-provided commands:

```lua
hold("W", 2)       -- hold for two seconds, then release
press("SPACE")     -- tap for 0.15 seconds
press("E", 0.2)    -- explicit press duration
key_down("SHIFT")
press("W")
key_up("SHIFT")
wait(1)            -- seconds
wait_ms(250)       -- milliseconds
```

The editor lists supported uppercase key names. Lua loops, math, strings and tables work. Yield with `wait()` inside long loops; an instruction budget prevents non-yielding scripts from freezing the app. Individual waits are 0.02â€“3600 seconds. Script memory is bounded to 4 MB. OS/file/network/package libraries are not exposed; macros provide keyboard and mouse automation, not access to Roblox game state. The cycle-delay setting repeats a script after it finishes; an infinite Lua loop controls its own timing.

Stopping, exiting, losing the target, or pausing releases keys and mouse buttons held by the macro. Automation uses the existing focus-and-restore approach and, by default, waits while you use the PC. Windows accepting an input does not establish that a game acted on it. Foreground input scheduling is serialized across clients, so timings can be delayed by other clients or user activity.

## Data and builds

Public game catalogs live in `veylolabs/rohelper-game-data` on GitHub. The app checks on startup and every six hours, with a manual refresh in Settings. Hash-verified immutable JSON game packs are installed into a separate `%LOCALAPPDATA%/RoHelper/game-content.json` cache only after the complete update validates. Failed/offline updates keep the previous cache. Bundled content covers first offline startup. The content request never includes account data or session credentials.

Account â†’ Games and each game's overview show declarative game fields. Merely opening them reads defaults without saving anything. Editing a field creates that game's entry under that account's `gameData` map and autosaves. An explicitly saved default value (including zero/false/empty text) still counts as saved game data. Account search matches the names and aliases of only those saved games. Catalog updates cannot create, reset or remove account progress. Unknown fields remain intact.

Compatible game catalogs, defaults and notebook fields can be added online without another application release. New kinds of game UI or behavior still need an app update. SAB uses sourced public catalogs and the inventory/index workflows described below. Adopt Me has separate inventories for every catalog item category, account balances, pet growth and friendship, Fly/Ride and Normal/Neon/Mega controls, and a sourced AMTV trading-value snapshot. Public catalogs and official event helpers update from GitHub. Unknown facts remain unknown.

`%LOCALAPPDATA%/RoHelper/workspace.json` stores account metadata and settings. Session cookies are stored separately in `%LOCALAPPDATA%/RoHelper/sessions.bin`, protected for the current Windows account using DPAPI; they are never returned to the interface. Atomic file replacements and previous-file backups preserve the last workspace and vault. Application folders can be moved without moving user data. Back up the entire AppData directory. A protected session vault is tied to its Windows account.

`version.json` is the single version source. Run `python tools/bump.py patch`, `minor`, or `major` before a new release. `build.bat` creates `Output/RoHelper-<version>`, generating the executable resources and title version. Patch increments are used for small shipped updates, minor for larger feature sets, major for major overhauls. Repeated development builds of the same unreleased version do not increment it.

Source lives under `Helper`; the UI is ordinary HTML/CSS/JavaScript under `web`. `native` contains storage, macro scheduling, layout and Windows integration. `legacy` retains adapted RoPilot support with its original GPL provenance. The source tree includes its required SDK headers and Lua source.

Checks: `node tests/gear.cjs` exercises per-account gear saves, partial transfers, custom entries, undo and reference-to-slot addition. `node tests/sab.cjs` exercises SAB autosave, moves/bulk actions, index, floors, planner and comparison with synthetic accounts. `node tests/ui.cjs` exercises the interface with synthetic data. `tests/native.bat` checks actual protected storage, Lua execution and 1/3-monitor layout plans using isolated data and unique test mutex names. `node tests/host.cjs` runs an isolated native host with synthetic accounts, verifies persistence and validation, and never starts Roblox or sends keyboard input. Release archives exclude all user/test data.

Live Roblox joins, in-game key response, and audio on real running Roblox clients require manual verification using Play and Running clients. The automated checks exercise the actual native bridge and its data handling while keeping existing game sessions intact.

GPL-3.0 applies to the derived app. Dependency notices are shipped in LICENSES; Lua is MIT licensed. RoHelper's H icon is an original code-drawn asset.


## Adopt Me and reference catalogs (0.4.0)

Adopt Me inventories are stored separately as `account.gameData["adopt-me"].inventories[category]`. Balances use `money[currency]`; event checklist checks are account-scoped. Merely browsing never creates game progress. Stable item IDs, unknown fields and separate saved copies survive catalog refreshes. Moving a copy moves only its notebook record and keeps all its fields; no action trades, spends currency or consumes items in Roblox.

Only pets expose growth, Fly/Ride and Neon/Mega controls. Normal ages are Newborn through Full Grown; Neon ages are Reborn through Luminous. Mega Neons are fully grown. The rarity-specific task table reflects the September 2025 rebalance, with source and check dates. Fully grown pets can record friendship level and 0–29 tasks toward the next friendship level. Eggs and items use quantities; existing notes stay preserved without note editors. Optional paid-price notes are in euros; AMTV trading estimates remain explicitly labeled RP community snapshots, with no invented age/friendship multiplier.

Both games have a public browsing catalog, separate from account acquisition checks. SAB's dedicated Backups tab is removed; existing backup files and automatic storage protection remain intact. The events banner can be collapsed and remembers its state locally. Adopt Me event helpers use current official update notes and do not invent payouts, exact schedules or end dates.

`tools/build_adopt_catalog.py` reads saved public source evidence, then `tools/export_game_content.py` writes immutable public packs and the bundled fallback. `content/adopt-me-sources.json` records source hashes, counts and limitations. Catalogs are broad public reference lists; upstream omissions remain possible. `node tests/adopt.cjs` covers pet stages/tasks, eggs, friendship, money, separate inventories, move/delete/undo, event ownership, reload and banner collapse using synthetic data.


## Item editor polish (0.4.1)

Adopt Me item details and editing share a compact pet preview and trading-value card. Setup and growth/friendship progress are grouped side by side on desktop and stacked on smaller screens. Fly and Ride use keyboard-accessible toggle cards. Stage task totals and friendship bars update immediately without moving keyboard focus. Full reference facts, source links and growth tables remain available through expandable sections. Data fields and storage format are unchanged. Presentation lives in `web/adopt-editor.js` and `web/adopt-editor.css`.


## Full-width workspace (0.4.2)

Main pages fill the available width beside the sidebar, retaining the existing edge padding. Account grids, inventories, indexes and all other main page layouts can use wide monitors without the previous centered 1,770-pixel limit. Closing RoHelper for an update is followed by reopening it immediately.


Growth stage circles are clickable buttons and stay available for Normal and Neon pets when fully grown. Selecting another stage resets that stage's task count and updates the dropdown; clicking the current stage preserves its recorded tasks. The separate task-table date/source footer is removed. Catalog details put Add to inventory between Close and Done; it opens a searchable account picker, and one account click opens the Add pet/item editor.

## 0.5.0 changes

- Money controls identify their account explicitly. SAB Cash and Adopt Me currencies autosave under each account’s separate game data; no global balance is written.
- Non-pet Adopt Me items stack when their saved metadata matches. Pets remain individual. Hatched consumes one egg and adds a normal newborn from that egg’s verified current pool, with Undo. All 41 egg pools include source evidence; former pools are excluded.
- SAB gear is an ownership list, with no quantity, notes or custom-creation controls. Existing saved custom gear, quantities and notes remain lossless. The audited catalog includes Flying Carpet, Admin Powers and additional limited/event gear. Acquisition labels distinguish cash, Robux, wheels, codes and event rewards; speculative items stay marked unconfirmed. Exact wiki artwork associations are retained, but some CDN requests may be blocked.
- Account, game and inventory item note editors are removed; saved notes are retained.
- Mutation palettes, textures, glow, animation settings, colors, mutation order and trait order are public catalog data. Eclipse has an approximate dark/yellow preview and sun effect over the normal icon. No mutation artwork overrides or remote scripts are used.
- Play reports each launch stage on the account and retains startup errors there. It waits for a Roblox window rather than treating process creation as success. No existing Roblox client is closed.


## 0.6.0: seven more games and visual macros

Grow a Garden, Grow a Garden 2 (Strawberreh Squad), Fisch, Pet Simulator 99, Blox Fruits, Bee Swarm Simulator and Murder Mystery 2 use the shared collection engine. Every game has category inventories, cross-account search, account-scoped money, acquisition checklists, goals and manual timers. Browsing does not initialize progress. Catalogs, images, rarity, item fields, game icons, navigation and verified recipes are data from GitHub. Unknown facts stay unknown; catalog checklist totals are not asserted as exact in-game reward totals.

- Garden crops record weight and mutations, pets record level/weight, and seeds/eggs/gear stack separately. Grow a Garden supports multiple environmental mutations and a separate growth variant.
- Fisch records fish weight/mutation and rod enchants; source facts include available location and bait references.
- PS99 uses official BIG Games catalog and RAP snapshots, exact available asset thumbnails, pet variants/shiny, and per-variant acquisition checklists. RAP is diamonds, not euros or a guaranteed price.
- Blox Fruits records stored/permanent fruits, weapons/mastery/upgrades, currencies and verified material upgrade plans.
- Bee Swarm has a 25–50-slot visual hive, bee level/gifted flags, materials, honey/tickets and verified Blender/equipment plans. Crafting compares this account’s holdings and other-account supplies without spending anything.
- MM2 catalogs knives/guns/pets, coins/gems and explicitly attributed Supreme Values snapshots in SV units.

Visual macro blocks support key press/hold/down/up, timed waits, nested repeats, infinite loops and Custom Lua. Drag to reorder/nest, or use touch-friendly arrow controls. The visual editor compiles to the same Lua script executed by the existing keyboard-only runtime; text remains editable. Unsupported text scripts are preserved verbatim in a Custom Lua block. Existing macros and account overrides remain intact. Interface files: `web/collections.js`, `web/collections.css`, `web/macro-model.js`, `web/macro-visual.js`, `web/macro-visual.css`.

Public sources are reference snapshots; omitted upstream entries, unavailable artwork and unknown values can remain. New event schedules are not invented: manual account timers and existing shared event views remain available. `tests/collections.cjs`, `tests/macro-visual.cjs`, `tests/macro-model.cjs` and native tests cover isolation, lossless save/reload, transfer/undo, source choices, phone layout and actual Lua action equivalence.


## 0.6.1

Adopt Me and Steal a Brainrot now use their official Roblox game icons, with exact universe/place provenance in their shared GitHub packs. Existing game data is unchanged.


## 0.6.2

Shared color pickers use a compact panel with adjacent preset swatches in one row on desktop, wrapping only when the available width requires it. RGB sliders and hex entry remain available. Account cards show only Play or Log in in their action row; settings remain available in the Edit account dialog.


## 0.6.3

All game catalogs use All items followed by item-type tabs. SAB Catalog combines Brainrots and Gear, with read-only gear details and an account picker before adding gear. Adopt Me’s Item index is renamed Catalog. Catalog category state stays separate from inventory category state. Six missing gear images are exact verified images embedded in the shared catalog: official Roblox Flying Bee/Waverider, and Skibidi Games Bat/Rainbow Hammer/Christmas Coils/Demon’s Head. Unverified, tiny cover crops and generated illustrations are not substituted; four unresolved gear images remain unknown. Account data and stable item IDs are unchanged.


## 0.7.0: app updater

Settings checks stable releases from the separate public veylolabs/rohelper-releases repository. Checks run at startup and every twelve hours. Downloads and installation are opt-in. Pinned HTTPS GitHub URLs, semantic versions, package size and SHA-256 are validated. Install & restart saves the workspace, verifies the ZIP/file index and executable version, waits for this exact app process to exit normally, replaces only whitelisted app files, and reopens RoHelper. The helper never terminates Roblox processes or migrates user data. A failed file copy restores the previous application; staging, previous app files and a result report are retained under %LOCALAPPDATA%/RoHelper/app-updates. Unknown paths, traversal, reparse points, links, duplicate files and data directories are rejected. GitHub HTTPS/hash checks provide integrity, not independent publisher code signing.


## Storage separation (0.7.1)

Production data always uses Windows Local AppData: `%LOCALAPPDATA%\RoHelper`. There is no fallback to the application directory and no automatic migration. Accounts, inventory, settings, backups, catalog cache, update staging and browser profiles all live there. `workspace.json` is local plain JSON; `sessions.bin` is encrypted using Windows DPAPI for the current Windows account. AppData separation does not encrypt workspace records. Only isolated `--test` runs use their own test folder.


## Mouse macros (0.7.2)

Visual blocks support Mouse click (left, right, double-click), Hold mouse (left or right), and Release mouse. Origin selection is a three-by-three grid. Origins are top-left/top-center/top-right, center-left/center/center-right, and bottom-left/bottom-center/bottom-right. X offsets are positive from the left and negative from the right; Y offsets are positive from the top and negative from the bottom. Centered axes allow either sign. Values are whole pixels. Each action measures the target client area again, including after resizing or moving between monitors. Offsets outside the current client area stop the macro rather than clicking outside the client.

```lua
click("left", "top-right", -20, 30)
click("right", "center", 0, 0)
click("double", "bottom-left", 30, -20)
mouse_hold("left", "center", 0, 0)
wait(2)
mouse_release()
```

`mouse_release()` has no arguments and releases all mouse buttons held by that macro. Holds stay pressed across waits until Release mouse, Stop, pause, or macro completion. Double-click is two left clicks with a short interval. Mouse actions share the existing foreground-client scheduler; they do not send background game messages. Windows coordinate conversion uses the current client area in device pixels (https://learn.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-clienttoscreen). Saved data remains in Local AppData, outside release archives.


## Macro sharing and recording (0.8.0)

Macros can be exported individually as `.rhm.json` files or self-contained `RHM1` share codes. Codes use compact block tuples, DEFLATE in a zlib wrapper, base64url without padding, and the first eight bytes of a SHA-256 checksum of the compressed payload. This checksum detects damaged copies; it does not authenticate the author or encrypt the macro. Scripts and visual blocks are preserved, while local macro/block IDs and unrelated fields are excluded. No account credentials, account assignments, inventories, or settings are included. Imported files and codes are bounded to 256 KB of decompressed JSON, with the existing 64 KB script, 256-block and 12-level nesting limits. Imports are previewed, syntax-checked, assigned fresh IDs and saved as separate macros. They never run or become assigned to an account automatically. Code conversion is offline and has no external library dependency. Standard: https://compression.spec.whatwg.org/

Record macro chooses one running Roblox client, a 3x3 mouse origin and optional drag capture. Only input while that client is foreground is recorded; synthetic/injected input is ignored. Low-level input callbacks run on a dedicated message-loop thread and queue bounded events rather than performing UI or disk work. They always pass input onward. Recording pauses outside the selected client, closes recorded held states on focus loss, and resumes without adding the time spent in other windows. F8 stops recording; the result opens in the editor before any save. Closing the recording dialog discards it and removes the hooks. No recording files or input logs are written automatically. The chosen client's automation is stopped during recording and remains stopped afterward. Reference: https://learn.microsoft.com/en-us/windows/win32/winmsg/lowlevelkeyboardproc

Mouse events are converted into inward signed offsets using the client dimensions at each event. Holds, releases and drag movement become editable blocks. Playback measures the current client size again for each mouse action. Clicks retain their down/up timing; matching rapid left-click pairs become Double-click blocks. F8 is reserved during recording. Unsupported keys, mouse wheel/middle-button inputs and outside-client movement are skipped and reported. Simultaneous left/right mouse holds stop recording with an explicit message. Recordings stop at five minutes or the 256-block limit, retaining the valid captured actions for review. The recorder does not query or modify game memory.

## Build environment and release privacy

Use Python 3 on PATH or set `ROHELPER_PYTHON` to its executable. Install Visual Studio Build Tools with the x86 C++ toolchain; discovery uses vswhere, or set `ROHELPER_VCVARS32` to vcvars32.bat. Browser tests use ordinary Node resolution (`npm install --no-save playwright`, or `NODE_PATH` for an existing installation). Native tests resolve fixtures from the source directory and write isolated storage beneath the OS temporary directory. Run `node tests/macro-model.cjs` before native tests to generate action-equivalence fixtures.

`python tools/package.py` validates both archives before publishing either: private filenames, local absolute paths, known credential patterns, saved-account JSON and embedded PNG timestamp metadata block packaging. Optional `ROHELPER_PRIVATE_IDENTITY_TERMS` adds a comma-separated local deny list; values are never printed. Only exact bundled dependency binaries may retain their upstream debug records. Required third-party author and license notices remain intact.

## Account-session transfer (0.9.0)

Accounts has Import account cookies and Export account cookies. Export all or selected stored logins to a chosen local `.rhsessions.json` file. Acknowledge the file disclosure before saving: the file is unencrypted and contains login cookies, Roblox IDs and usernames only, without inventories, tags, account settings or other workspace data. Exports cannot overwrite the AppData storage directory. Session values are written directly by the native backend and never returned to the account interface. Expired stored sessions can be exported, but must pass online verification before another import.

Import a user-selected JSON/text file or paste one session per line (maximum 16 MB / 5,000 entries). RoHelper verifies each supplied session with Roblox, presents a review, and matches duplicates by the authenticated Roblox account ID. File-supplied account IDs are cross-checked. New accounts and existing tracking accounts can be selected; existing saved logins are kept unless replacement is explicitly enabled and those accounts are selected. Different sessions for the same account never create duplicate accounts. Existing game data, customization and settings are preserved. Closing cancels the check, and no accounts are added before confirmation. Network failures are distinguished from invalid logins. Credentials in the preview expire after 15 minutes. Browser cookie stores and profile encryption keys are not read.

The native session-import transaction keeps a Windows-DPAPI protected recovery journal in AppData until both the vault and workspace have saved. Failed writes roll back; a pending journal on next startup restores the pre-import files before loading accounts. Tests use synthetic credentials only. Export files and recovery journals are rejected by release privacy checks.

Application releases contain portable binaries, update metadata and a SOURCE.txt pointer. Matching GPL source snapshots are published separately in https://github.com/veylolabs/rohelper-source. They are audited independently of account data and include build scripts, vendored dependencies and required license notices. Do not upload local account-session exports to either public repository.


## 0.9.1: recovery contacts

Edit account → Profile has optional connected email, phone number and other recovery contact fields below Nickname. These are local reminders, not changes to Roblox account settings. They are stored separately for each account in the AppData workspace, remain off account cards and search, and are excluded from login-cookie exports. Contact metadata is stored as ordinary workspace JSON; only login sessions use the protected vault. Existing accounts do not need these fields.


## 0.9.3: sequential bulk launch

Accounts → Launch all starts listed, logged-in accounts one at a time in their saved order. Search and tags change the button to Launch filtered and restrict the batch. Already-running accounts, removed accounts and accounts without a usable saved login are skipped. Each native launch waits for its Roblox window before the next request. A failure stays on its account card and the queue proceeds; missing MultiRoblox, an unconfirmed request timeout or unavailable status stops the queue. Stop queue finishes the current launch and cancels the remainder. No running clients are closed.

The batch fixes its selected saved destination, even if navigation or account filters change. Single-account Play is disabled during the batch. The queue is held only in memory and is not resumed on restart. Existing inventory, recovery contacts and other account settings are unchanged.
