#pragma once
#include <chrono>
#include <iomanip>
#include <sstream>
#include "../SafeStorage.h"
#include "json.hpp"

// Account progress only. No sessions, credentials, game code, or executable paths.
namespace SabProgress {
using json=nlohmann::json;namespace fs=std::filesystem;
inline long long Now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();}
inline void Text(const json& x,const char* key,size_t limit){if(x.contains(key)&&(!x[key].is_string()||x[key].get<std::string>().size()>limit))throw std::runtime_error("Invalid SAB text field.");}
inline void Validate(const json& s,std::set<std::string>* allIds=nullptr){
 if(!s.is_object())throw std::runtime_error("Invalid SAB progress.");
 for(auto k:{"rebirth","level"})if(s.contains(k)&&(!s[k].is_number_integer()||s[k]<0||s[k]>10000))throw std::runtime_error("Invalid SAB rebirth.");Text(s,"notes",16000);
 if(s.contains("checks")){if(!s["checks"].is_object()||s["checks"].size()>4000)throw std::runtime_error("Invalid SAB requirements.");for(auto& v:s["checks"].items())if(!v.value().is_boolean())throw std::runtime_error("Invalid SAB requirement check.");}
 if(s.contains("inventory")){
  const auto& list=s["inventory"];if(!list.is_array()||list.size()>200)throw std::runtime_error("SAB inventories support up to 200 saved slots, including overflow.");std::set<int> slots;std::set<std::string> local;
  for(auto& i:list){Text(i,"id",80);Text(i,"brainrotId",120);Text(i,"name",160);Text(i,"mutation",80);Text(i,"notes",4000);auto id=i.at("id").get<std::string>();if(!std::regex_match(id,std::regex("[A-Za-z0-9_-]{1,80}"))||!local.insert(id).second||(allIds&&!allIds->insert(id).second))throw std::runtime_error("Duplicate SAB item ID.");
   if(!i.at("slot").is_number_integer()||i["slot"]<0||i["slot"]>199||!slots.insert(i["slot"].get<int>()).second)throw std::runtime_error("Invalid or occupied SAB slot.");
   if(!i.at("traits").is_array()||i["traits"].size()>200)throw std::runtime_error("Invalid SAB traits.");std::set<std::string> traits;for(auto& t:i["traits"])if(!t.is_string()||t.get<std::string>().size()>100||!traits.insert(t.get<std::string>()).second)throw std::runtime_error("Invalid SAB trait.");
   if(i.contains("tradeStatus")&&i["tradeStatus"]!="none"&&i["tradeStatus"]!="trade"&&i["tradeStatus"]!="keep")throw std::runtime_error("Invalid SAB trading status.");
  }
 }
 if(s.contains("money")){const auto& money=s["money"];if(!money.is_object()||money.size()>64)throw std::runtime_error("Invalid SAB balances.");for(auto& c:money.items())if(!std::regex_match(c.key(),std::regex("[a-z0-9-]{1,80}"))||!c.value().is_number()||!std::isfinite(c.value().get<double>())||c.value()<0||c.value()>1e30)throw std::runtime_error("Invalid SAB balance.");}
 if(s.contains("gearInventory")){
  const auto& list=s["gearInventory"];if(!list.is_array()||list.size()>2000)throw std::runtime_error("SAB gear supports up to 2,000 saved entries.");std::set<std::string> local;
  for(auto& i:list){if(!i.is_object())throw std::runtime_error("Invalid SAB gear entry.");Text(i,"id",80);Text(i,"gearId",120);Text(i,"name",160);Text(i,"notes",4000);
   auto id=i.at("id").get<std::string>();if(!std::regex_match(id,std::regex("[A-Za-z0-9_-]{1,80}"))||!local.insert(id).second||(allIds&&!allIds->insert(id).second))throw std::runtime_error("Duplicate SAB gear ID.");
   if(i.at("gearId").get<std::string>().empty()||i.at("name").get<std::string>().empty()||!i.at("quantity").is_number_integer()||i["quantity"]<1||i["quantity"]>1000000)throw std::runtime_error("Invalid SAB gear name or quantity.");
  }
 }
 for(auto k:{"index","indexTotals","indexRewards"})if(s.contains(k)){
  const auto& map=s[k];if(!map.is_object()||map.size()>80)throw std::runtime_error("Invalid SAB index.");for(auto& m:map.items()){
   if(m.key().empty()||m.key().size()>100)throw std::runtime_error("Invalid SAB index mutation.");
   if(std::string(k)=="index"){if(!m.value().is_object()||m.value().size()>4000)throw std::runtime_error("Invalid SAB index checks.");for(auto& c:m.value().items())if(c.key().empty()||c.key().size()>160||!c.value().is_boolean())throw std::runtime_error("Invalid SAB index check.");}
   else if(!m.value().is_number_integer()||m.value()<1||m.value()>4000)throw std::runtime_error("Invalid SAB index total.");
  }
 }
}
inline json Extract(const json& workspace){json rows=json::array();for(auto& a:workspace.at("accounts")){json s=nullptr;if(a.contains("gameData")&&a["gameData"].contains("sab"))s=a["gameData"]["sab"];rows.push_back({{"userId",a.at("userId")},{"username",a.at("username")},{"sab",s}});}return {{"format","rohelper-sab-progress"},{"schema",1},{"createdAt",Now()},{"accounts",rows}};}
inline json Read(const fs::path& path){if(!fs::exists(path)||fs::file_size(path)>32*1024*1024)throw std::runtime_error("SAB file is missing or exceeds 32 MB.");return json::parse(SafeStorage::Read(path));}
inline json Normalize(const json& input){
 if(!input.is_object()||!input.contains("accounts")||!input["accounts"].is_array()||input["accounts"].size()>5000)throw std::runtime_error("Choose a RoHelper SAB snapshot.");
 if(input.contains("format")&&(input["format"]!="rohelper-sab-progress"||input.value("schema",0)!=1))throw std::runtime_error("Unsupported SAB export format.");
 json rows=json::array();std::set<long long> users;std::set<std::string> importedIds;
 for(auto& a:input["accounts"]){auto uid=a.at("userId").get<long long>();if(uid<=0||!users.insert(uid).second)throw std::runtime_error("Duplicate or invalid account in SAB import.");json s=a.contains("sab")?a["sab"]:a.contains("gameData")?a["gameData"].value("sab",json(nullptr)):json(nullptr);if(!s.is_null()){Validate(s,&importedIds);if(s.contains("level")){if(!s.contains("rebirth"))s["rebirth"]=s["level"];s.erase("level");}}
  auto name=a.value("username",std::string());if(name.size()>100)throw std::runtime_error("Invalid import account name.");rows.push_back({{"userId",uid},{"username",name},{"sab",s}});
 }return {{"format","rohelper-sab-progress"},{"schema",1},{"accounts",rows}};
}
inline int Items(const json& doc){int n=0;for(auto& a:doc["accounts"])if(a["sab"].is_object()&&a["sab"].contains("inventory"))n+=(int)a["sab"]["inventory"].size();return n;}
inline fs::path BackupPath(const fs::path& dir,const std::string& id){if(!std::regex_match(id,std::regex("[0-9]+-[a-z]+\\.json")))throw std::runtime_error("Invalid SAB backup ID.");return dir/L"sab-backups"/fs::path(id);}
inline std::string Backup(const fs::path& dir,const json& workspace,const std::string& kind="manual"){
 fs::create_directories(dir/L"sab-backups");auto stamp=Now();auto id=std::to_string(stamp)+"-"+kind+".json";auto path=BackupPath(dir,id);while(fs::exists(path)){id=std::to_string(++stamp)+"-"+kind+".json";path=BackupPath(dir,id);}SafeStorage::Write(path,Extract(workspace).dump(2));return id;
}
inline void BeforeSave(const fs::path& dir,const json& next){auto path=dir/L"workspace.json";if(!fs::exists(path))return;auto before=Read(path),old=Extract(before),fresh=Extract(next);old.erase("createdAt");fresh.erase("createdAt");if(old==fresh)return;
 long long recent=0;auto backups=dir/L"sab-backups";if(fs::exists(backups))for(auto& e:fs::directory_iterator(backups)){auto name=e.path().filename().string();if(std::regex_match(name,std::regex("[0-9]+-auto\\.json")))try{recent=(std::max)(recent,std::stoll(name));}catch(...){}}
 if(Now()-recent>60*60*1000LL)Backup(dir,before,"auto");
}
inline json List(const fs::path& dir){json list=json::array();auto p=dir/L"sab-backups";if(!fs::exists(p))return list;std::vector<fs::path> files;for(auto& e:fs::directory_iterator(p))if(e.is_regular_file()&&std::regex_match(e.path().filename().string(),std::regex("[0-9]+-[a-z]+\\.json")))files.push_back(e.path());std::sort(files.rbegin(),files.rend());for(auto& f:files){try{auto doc=Normalize(Read(f));auto stamp=std::stoll(f.filename().string());auto seconds=(time_t)(stamp/1000);tm t{};localtime_s(&t,&seconds);std::ostringstream name;name<<std::put_time(&t,"%Y-%m-%d %H:%M:%S")<<" · "<<(f.filename().string().find("-auto")!=std::string::npos?"Automatic":"Saved");list.push_back({{"id",f.filename().string()},{"name",name.str()},{"items",Items(doc)}});}catch(...){}}return list;}
inline json Restore(const json& workspace,const json& doc,long long uid,bool inventoryOnly){auto next=workspace;bool matched=false;for(auto& src:doc["accounts"]){if(uid&&src["userId"]!=uid)continue;for(auto& a:next["accounts"])if(a["userId"]==src["userId"]){matched=true;if(inventoryOnly){if(src["sab"].is_object()&&src["sab"].contains("inventory"))a["gameData"]["sab"]["inventory"]=src["sab"]["inventory"];else if(a.contains("gameData")&&a["gameData"].contains("sab"))a["gameData"]["sab"].erase("inventory");}else if(src["sab"].is_null()){if(a.contains("gameData"))a["gameData"].erase("sab");}else a["gameData"]["sab"]=src["sab"];break;}}if(!matched)throw std::runtime_error("No matching accounts in this snapshot.");return next;}
}
