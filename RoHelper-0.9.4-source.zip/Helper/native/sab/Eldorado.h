#pragma once
#include <algorithm>
#include <cmath>
#include <functional>
#include <map>
#include <set>
#include <string>
#include "ExistCounts.h"
namespace Eldorado {
using json=nlohmann::json;
inline std::string Key(const std::string& text){std::string out;for(unsigned char c:text)if(c<128&&std::isalnum(c))out+=static_cast<char>(std::tolower(c));return out;}
inline std::string Encode(const std::string& text){static const char hex[]="0123456789ABCDEF";std::string out;for(unsigned char c:text){if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_')out+=c;else{out+='%';out+=hex[c>>4];out+=hex[c&15];}}return out;}
inline std::string Mutation(std::string s){s=Key(s);return s=="none"||s=="normal"?"default":s;}
inline std::string Filter(std::string s){s=Mutation(s);return s=="default"?"none":s=="yinyang"?"yin-yang":s;}
inline std::string SearchUrl(const std::string& name,const std::string& mutation){return "https://www.eldorado.gg/steal-a-brainrot-brainrots/i/259?searchQuery="+Encode(name)+"&steal-a-brainrot-mutations="+Filter(mutation);}
inline json Comparable(const json& raw,const std::string& name,const std::string& mutation,double target){
 try{
  const auto& o=raw.at("offer");if(o.at("gameId")!="259"||o.at("category")!="CustomItem"||o.at("offerState")!="Active"||o.value("minQuantity",1)>1||o.value("quantity",0)<=0)return nullptr;
  bool brainrot=false,type=false;for(const auto& t:o.at("tradeEnvironmentValues")){if(t.value("name","")=="Brainrot"&&Key(t.value("value",""))==Key(name))brainrot=true;if(t.value("name","")=="Item Type"&&t.value("value","")=="Brainrot")type=true;}if(!brainrot||!type)return nullptr;
  std::string found;double income=0;for(const auto& a:o.at("attributes")){
   auto id=a.value("id","");if(id=="steal-a-brainrot-mutations"&&a.at("value").is_object()){if(a.contains("values")&&a["values"].size()>1)return nullptr;found=Mutation(a["value"].value("id",""));}
   if(id=="steal-a-brainrot-ms-numeric"&&a.at("value").is_number())income=a["value"].get<double>();
  }
  if(found!=Mutation(mutation)||!std::isfinite(income)||income<=0)return nullptr;
  const auto& money=o.at("pricePerUnit");if(money.at("currency")!="EUR")return nullptr;double price=money.at("amount");if(!std::isfinite(price)||price<=0)return nullptr;
  auto id=o.at("id").get<std::string>(),seller=o.at("userId").get<std::string>();if(!std::regex_match(id,std::regex("[a-zA-Z0-9-]{1,100}"))||seller.empty())return nullptr;
  return {{"id",id},{"seller",seller},{"price",price},{"perSecond",income},{"distance",std::abs(income-target)/target}};
 }catch(...){return nullptr;}
}
inline json Summarize(const json& raw,const std::string& name,const std::string& mutation,double target,int total){
 if(!std::isfinite(target)||target<=0)throw std::runtime_error("A known income per second is needed for this comparison.");
 std::vector<json> candidates;std::set<std::string> ids;for(const auto& r:raw){auto item=Comparable(r,name,mutation,target);if(!item.is_null()&&ids.insert(item["id"]).second)candidates.push_back(item);}
 std::stable_sort(candidates.begin(),candidates.end(),[](const auto& a,const auto& b){double ad=a.at("distance"),bd=b.at("distance");if(ad!=bd)return ad<bd;return a.at("id").template get<std::string>()<b.at("id").template get<std::string>();});
 json matches=json::array();std::set<std::string> sellers;
 for(auto c:candidates){if(c["distance"].get<double>()>.25||!sellers.insert(c["seller"]).second)continue;c["url"]="https://www.eldorado.gg/steal-a-brainrot-brainrots/oi/"+c["id"].get<std::string>();matches.push_back(c);if(matches.size()==10)break;}
 json quote={{"matches",matches},{"sellers",sellers.size()},{"average",nullptr},{"median",nullptr},{"checkedAt",ExistCounts::Now()},{"url",SearchUrl(name,mutation)},{"scanned",raw.size()},{"total",total},{"targetIncome",target}};
 if(matches.empty()){quote["message"]="No matching listings within 25% of your income.";return quote;}
 if(matches.size()<3)quote["message"]="Small sample: fewer than 3 matching sellers.";
 std::vector<double> prices;double low=matches[0]["perSecond"],high=low,totalPrice=0;for(const auto& m:matches){double p=m["price"],income=m["perSecond"];prices.push_back(p);totalPrice+=p;low=(std::min)(low,income);high=(std::max)(high,income);}std::sort(prices.begin(),prices.end());
 quote["average"]=totalPrice/prices.size();quote["median"]=prices.size()%2?prices[prices.size()/2]:(prices[prices.size()/2-1]+prices[prices.size()/2])/2;quote["incomeMin"]=low;quote["incomeMax"]=high;return quote;
}
inline json Fetch(const std::string& name,const std::string& mutation,double target,const std::function<json(const std::string&)>& get){
 json raw=json::array();int pages=1,total=0;const auto started=ExistCounts::Now();
 for(int page=1;page<=pages&&page<=10;page++){
  if(page>1&&ExistCounts::Now()-started>45000)break;
  auto path="/api/v1/item-management/offers?gameId=259&category=CustomItem&pageSize=20&pageIndex="+std::to_string(page)+"&searchQuery="+Encode(name)+"&steal-a-brainrot-mutations="+Filter(mutation);
  auto response=get(path);if(!response.contains("results")||!response["results"].is_array()||response["results"].size()>100)throw std::runtime_error("Eldorado returned an unsupported listing format.");
  pages=response.value("totalPages",1);total=response.value("recordCount",0);for(const auto& r:response["results"])raw.push_back(r);
 }
 if(!raw.empty()&&std::none_of(raw.begin(),raw.end(),[](const json& r){return r.contains("offer")&&r["offer"].contains("pricePerUnit")&&r["offer"]["pricePerUnit"].value("currency","")=="EUR";}))throw std::runtime_error("Eldorado did not return euro prices. Try again later.");
 auto quote=Summarize(raw,name,mutation,target,total);quote["currency"]="EUR";return quote;
}
}
