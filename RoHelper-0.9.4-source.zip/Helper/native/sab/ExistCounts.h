#pragma once
#include <chrono>
#include <regex>
#include <set>
#include <tuple>
#include <vector>
#include "../SafeStorage.h"
#include "json.hpp"
namespace ExistCounts {
using json=nlohmann::json;
inline long long Now(){return std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();}
inline json Parse(const json& feed){
 if(!feed.is_object()||feed.value("schema_version",0)!=1||!feed.contains("rows")||!feed["rows"].is_array()||feed["rows"].empty()||feed["rows"].size()>10000)throw std::runtime_error("The count source returned an unsupported format. Saved counts were kept.");
 json result={{"version",1},{"source","https://sabexistcount.com/sab-exist-count-list"},{"sourceUpdatedAt",feed.value("generated_at","")},{"checkedAt",Now()},{"entries",json::array()}};
 if(result["sourceUpdatedAt"].get<std::string>().size()>80)throw std::runtime_error("Invalid count-source date.");
 std::set<std::string> slugs;
 for(const auto& r:feed["rows"]){
  auto slug=r.at("s").get<std::string>(),name=r.at("n").get<std::string>(),kind=r.at("k").get<std::string>();
  if(!std::regex_match(slug,std::regex("[a-z0-9-]{1,180}"))||name.empty()||name.size()>300||!slugs.insert(slug).second)throw std::runtime_error("Invalid count-source entry. Saved counts were kept.");
  auto label=r.value("ecs","");if(label.size()>100)throw std::runtime_error("Invalid count label.");
  json entry={{"slug",slug},{"name",name},{"status","unknown"},{"label","Unavailable"}};
  if((kind=="known"||kind=="estimated")&&!label.empty()&&label!="—"){entry["status"]=kind=="known"?"reported":"estimated";entry["label"]=label;}
  // Only the source's specifically named mutation/trait counts are exposed.
  // They are never treated as the count for an arbitrary combined inventory item.
  for(const auto& field:std::vector<std::tuple<const char*,const char*,const char*,const char*>>{{"mutation","mn","mc","mcr"},{"trait","tn","tc","tcr"}}){
   auto [target,n,l,v]=field;auto variant=r.value(n,"");
   if(!variant.empty()&&variant.size()<100&&r.contains(l)&&r[l].is_string()&&r[l].get<std::string>().size()<100&&r.contains(v)&&r[v].is_number()&&r[v].get<double>()>=0)entry[target]={{"name",variant},{"label",r[l]}};
  }
  result["entries"].push_back(entry);
 }
 return result;
}
inline json Cached(const std::filesystem::path& path){
 try{if(!std::filesystem::exists(path)||std::filesystem::file_size(path)>8*1024*1024)return nullptr;auto result=json::parse(SafeStorage::Read(path));if(result.value("version",0)!=1||!result.at("entries").is_array()||!result.at("checkedAt").is_number_integer())return nullptr;return result;}catch(...){return nullptr;}
}
}
