#pragma once
#include <windows.h>
#include <filesystem>
#include <fstream>
#include <string>
#include <stdexcept>

// No implicit recovery: callers keep the original bytes on every failure.
namespace SafeStorage {
inline std::string Read(const std::filesystem::path& path) {
    std::ifstream stream(path, std::ios::binary);
    if (!stream) throw std::runtime_error("Storage read failed");
    std::string bytes((std::istreambuf_iterator<char>(stream)), {});
    if (stream.bad()) throw std::runtime_error("Storage read failed");
    return bytes;
}
inline void Write(const std::filesystem::path& path, const std::string& bytes) {
    // Sibling temp + exclusive creation; never truncate the destination.
    auto temp = path;
    temp += L".tmp-" + std::to_wstring(GetCurrentProcessId()) + L"-" + std::to_wstring(GetTickCount64());
    HANDLE file = CreateFileW(temp.c_str(), GENERIC_WRITE, 0, nullptr, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, nullptr);
    if (file == INVALID_HANDLE_VALUE) throw std::runtime_error("Storage temporary file failed");
    DWORD written = 0;
    bool ok = bytes.size() <= MAXDWORD && WriteFile(file, bytes.data(), static_cast<DWORD>(bytes.size()), &written, nullptr)
        && written == bytes.size() && FlushFileBuffers(file);
    CloseHandle(file);
    if (!ok) { DeleteFileW(temp.c_str()); throw std::runtime_error("Storage flush failed"); }
    if (!MoveFileExW(temp.c_str(), path.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH)) {
        DeleteFileW(temp.c_str());
        throw std::runtime_error("Storage atomic replacement failed");
    }
}
}
