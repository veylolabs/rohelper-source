#pragma once
#include "Store.h"
#include <functional>
#include <sstream>

// Only explicitly supplied sessions and this application's vault are used here.
// No browser cookie stores, process memory or browser encryption keys are read.
namespace SessionTransfer {
constexpr size_t MaxBytes=16*1024*1024,MaxEntries=5000,MaxCookie=16384;
struct Input {size_t number=0;std::string cookie;long long claimedUserId=0;bool duplicate=false;std::string error;};
struct Identity {long long userId=0;std::string username,displayName,avatar;};
struct Verified {size_t number=0;std::string cookie;Identity identity;};
struct Review {json rows=json::array();std::vector<Verified> valid;bool cancelled=false;};
inline std::string Trim(std::string s){auto first=s.find_first_not_of(" \t\r\n");if(first==std::string::npos)return "";s.erase(0,first);s.erase(s.find_last_not_of(" \t\r\n")+1);return s;}
inline std::string Normalize(std::string cookie){cookie=Trim(cookie);if(cookie.size()>=2&&((cookie.front()=='"'&&cookie.back()=='"')||(cookie.front()=='\''&&cookie.back()=='\'')))cookie=cookie.substr(1,cookie.size()-2);const std::string prefix=".ROBLOSECURITY=";if(cookie.rfind(prefix,0)==0)cookie=cookie.substr(prefix.size());if(!cookie.empty()&&cookie.back()==';')cookie.pop_back();if(cookie.size()<16||cookie.size()>MaxCookie||std::any_of(cookie.begin(),cookie.end(),[](unsigned char c){return c<=32||c>=127||c==';'||c=='"'||c=='\\'||c==','||c=='%';}))throw std::runtime_error("Invalid session value.");return cookie;}
inline std::vector<Input> Parse(std::string text){
 if(text.size()>MaxBytes)throw std::runtime_error("Choose a session file or pasted batch under 16 MB.");if(text.rfind("\xef\xbb\xbf",0)==0)text.erase(0,3);text=Trim(text);if(text.empty())throw std::runtime_error("Choose a session file or paste at least one session.");
 std::vector<Input> result;std::set<std::string> seen;
 auto append=[&](std::string value,long long claimed=0){if(result.size()>=MaxEntries)throw std::runtime_error("Import at most 5,000 sessions at a time.");Input row;row.number=result.size()+1;row.claimedUserId=claimed;try{row.cookie=Normalize(value);row.duplicate=!seen.insert(row.cookie).second;}catch(...){row.error="Invalid session value.";}result.push_back(std::move(row));};
 if(text.front()=='{'||text.front()=='['){
  json document;try{document=json::parse(text);}catch(...){throw std::runtime_error("This session file is not valid JSON.");}
  const json* entries=&document;
  if(document.is_object()){if(document.value("format",std::string())!="rohelper-account-sessions"||!document.contains("version")||document["version"]!=1||!document.contains("accounts"))throw std::runtime_error("This is not a supported RoHelper account-session file.");entries=&document["accounts"];}
  if(!entries->is_array()||entries->empty()||entries->size()>MaxEntries)throw std::runtime_error("Choose a nonempty session batch with at most 5,000 entries.");
  for(const auto& entry:*entries){if(entry.is_string())append(entry);else if(entry.is_object()&&entry.contains("cookie")&&entry["cookie"].is_string()){long long claimed=0;if(entry.contains("userId")){if(!entry["userId"].is_number_integer()||entry["userId"]<=0)throw std::runtime_error("A session file contains an invalid account ID.");claimed=entry["userId"].get<long long>();}append(entry["cookie"],claimed);}else throw std::runtime_error("Each session entry must contain a cookie string.");}
 }else{std::istringstream lines(text);std::string line;while(std::getline(lines,line))if(!Trim(line).empty())append(line);}
 if(result.empty())throw std::runtime_error("No sessions were found in this batch.");return result;
}
using Lookup=std::function<Identity(const std::string&)>;
using Progress=std::function<void(const json&,size_t,size_t)>;
using Cancel=std::function<bool()>;
inline Review Verify(const std::vector<Input>& input,const json& accounts,const json& credentials,const Lookup& lookup,const Progress& progress={},const Cancel& cancel={}){
 Review result;std::set<long long> seen;std::map<std::string,Identity> identified;size_t completed=0;
 for(const auto& candidate:input){if(cancel&&cancel()){result.cancelled=true;break;}json row={{"number",candidate.number},{"userId",nullptr},{"username",""},{"displayName",""},{"status","invalid"},{"message",""},{"existing",false},{"hasStoredSession",false}};
  if(!candidate.error.empty())row["message"]=candidate.error;
  else if(candidate.duplicate&&!candidate.claimedUserId){row["status"]="duplicate";row["message"]="Repeated session in this batch.";}
  else try{auto identity=identified.count(candidate.cookie)?identified.at(candidate.cookie):lookup(candidate.cookie);identified[candidate.cookie]=identity;if(cancel&&cancel()){result.cancelled=true;break;}
   if(identity.userId<=0){row["message"]="Expired or invalid session.";}
   else if(identity.username.empty()||identity.username.size()>40||identity.displayName.size()>100||identity.avatar.size()>600000){row["status"]="unavailable";row["message"]="Roblox returned incomplete account details.";}
   else if(candidate.claimedUserId&&candidate.claimedUserId!=identity.userId){row["message"]="This session does not match the account ID in the file.";}
   else{row["userId"]=identity.userId;row["username"]=identity.username;row["displayName"]=identity.displayName;if(!seen.insert(identity.userId).second){row["status"]="duplicate";row["message"]="This Roblox account already appears in this batch.";}
    else{row["status"]="ready";row["message"]="New account";for(const auto& account:accounts)if(account["userId"]==identity.userId){row["existing"]=true;auto id=account["id"].get<std::string>();bool saved=credentials.contains(id)&&credentials[id].is_string()&&!credentials[id].get<std::string>().empty();row["hasStoredSession"]=saved;row["message"]=saved?"Already in RoHelper; existing login is kept unless selected for replacement.":"Connect login to existing account.";break;}result.valid.push_back({candidate.number,candidate.cookie,std::move(identity)});}
   }
  }catch(...){row["status"]="unavailable";row["message"]="Could not verify with Roblox. Try again later.";}
  result.rows.push_back(row);if(progress)progress(row,++completed,input.size());
 }return result;
}
inline json Export(const Store& store,const json& selected){
 if(store.blocked)throw std::runtime_error(store.error);if(!selected.is_array()||selected.empty()||selected.size()>MaxEntries)throw std::runtime_error("Select at least one account with a saved session.");json document={{"format","rohelper-account-sessions"},{"version",1},{"accounts",json::array()}};std::set<std::string> ids;
 for(const auto& value:selected){if(!value.is_string())throw std::runtime_error("Invalid account selection.");auto id=value.get<std::string>();if(!ids.insert(id).second)throw std::runtime_error("An account was selected more than once.");auto account=std::find_if(store.data["accounts"].begin(),store.data["accounts"].end(),[&](const json& a){return a["id"]==id;});if(account==store.data["accounts"].end()||!store.credentials.contains(id)||!store.credentials[id].is_string()||store.credentials[id].get<std::string>().empty())throw std::runtime_error("A selected account no longer has a saved session. Refresh the account list.");document["accounts"].push_back({{"userId",(*account)["userId"]},{"username",(*account)["username"]},{"cookie",Normalize(store.credentials[id])}});}
 if(document.dump().size()>MaxBytes)throw std::runtime_error("This export exceeds 16 MB. Select fewer accounts.");return document;
}
inline json Apply(Store& store,const Review& review,const json& selection,bool replace,long long expectedRevision){
 if(store.blocked)throw std::runtime_error(store.error);if(review.cancelled)throw std::runtime_error("This import was cancelled. Preview the batch again.");if(expectedRevision!=store.data.value("revision",0LL))throw std::runtime_error("Your accounts changed. Refresh the account list before importing.");if(!selection.is_array()||selection.empty()||selection.size()>MaxEntries)throw std::runtime_error("Select at least one verified account.");
 auto next=store.data,vault=store.credentials;std::set<size_t> selected;int added=0,connected=0,updated=0,skipped=0;
 for(const auto& value:selection){if(!value.is_number_unsigned()&&!value.is_number_integer())throw std::runtime_error("Invalid import selection.");auto n=value.get<long long>();if(n<=0||!selected.insert((size_t)n).second)throw std::runtime_error("Invalid or repeated import selection.");auto entry=std::find_if(review.valid.begin(),review.valid.end(),[&](const Verified& row){return row.number==(size_t)n;});if(entry==review.valid.end())throw std::runtime_error("Select only verified accounts.");const auto& identity=entry->identity;auto account=std::find_if(next["accounts"].begin(),next["accounts"].end(),[&](const json& a){return a["userId"]==identity.userId;});std::string id;
  if(account!=next["accounts"].end()){id=(*account)["id"];bool exists=vault.contains(id)&&vault[id].is_string()&&!vault[id].get<std::string>().empty();if(exists&&!replace){skipped++;continue;}if(exists)updated++;else connected++;(*account)["username"]=identity.username;(*account)["displayName"]=identity.displayName;if(!identity.avatar.empty())(*account)["avatar"]=identity.avatar;(*account)["sessionExpired"]=false;}
  else{id=Id();next["accounts"].push_back({{"id",id},{"userId",identity.userId},{"username",identity.username},{"displayName",identity.displayName},{"avatar",identity.avatar},{"nickname",""},{"color","#818cf8"},{"notes",""},{"tags",json::array()},{"settings",json::object()},{"gameData",json::object()},{"sessionExpired",false}});added++;}vault[id]=entry->cookie;
 }
 if(added+connected+updated)store.CommitSessions(next,vault);return {{"added",added},{"connected",connected},{"updated",updated},{"skipped",skipped},{"message",std::to_string(added)+" added · "+std::to_string(connected)+" connected · "+std::to_string(updated)+" logins updated · "+std::to_string(skipped)+" kept unchanged"}};
}
}
