#pragma once
namespace SessionTransferHost {
struct Job {
 std::string id=Id();std::mutex mutex;std::atomic_bool cancel{false};bool done=false;size_t completed=0,total=0;ULONGLONG finishedAt=0;json rows=json::array();SessionTransfer::Review review;
 ~Job(){for(auto& row:review.valid)if(!row.cookie.empty())SecureZeroMemory(row.cookie.data(),row.cookie.size());}
};
inline std::shared_ptr<Job> current;
inline void ClearSensitive(Job& job){for(auto& row:job.review.valid)if(!row.cookie.empty())SecureZeroMemory(row.cookie.data(),row.cookie.size());job.review.valid.clear();}
inline void Cancel(){if(current)current->cancel=true;}
inline void Reap(){if(!current)return;std::lock_guard<std::mutex> lock(current->mutex);if(current->done&&current->finishedAt&&GetTickCount64()-current->finishedAt>15*60*1000ULL){current->cancel=true;ClearSensitive(*current);}}
inline std::shared_ptr<Job> Find(const json& m){Reap();if(!current||m.value("job",std::string())!=current->id||current->cancel)throw std::runtime_error("This session preview expired or was cancelled. Preview the batch again.");return current;}
inline json Public(const std::shared_ptr<Job>& job){std::lock_guard<std::mutex> lock(job->mutex);return {{"job",job->id},{"done",job->done},{"completed",job->completed},{"total",job->total},{"cancelled",job->cancel.load()},{"rows",job->rows}};}
inline SessionTransfer::Identity Lookup(const std::string& cookie){
 DWORD status=0;auto bytes=RobloxAPI::HttpRequest(L"GET",L"users.roblox.com",L"/v1/users/authenticated",cookie,"","",nullptr,&status);if(status==401)return {};if(status!=200||bytes.size()>1024*1024)throw std::runtime_error("Account validation is unavailable.");
 auto info=json::parse(bytes);SessionTransfer::Identity result;result.userId=info.at("id");result.username=info.at("name");result.displayName=info.at("displayName");
 try{auto avatars=RobloxAPI::HttpRequest(L"GET",L"thumbnails.roblox.com",L"/v1/users/avatar-headshot?userIds="+std::to_wstring(result.userId)+L"&size=150x150&format=Png","");if(avatars.size()<1024*1024){auto image=json::parse(avatars);auto url=image.at("data").at(0).value("imageUrl",std::string());if(url.rfind("https://",0)==0&&url.size()<4000)result.avatar=url;}}catch(...){}
 return result;
}
inline json Start(const std::string& bytes){
 if(store->blocked)throw std::runtime_error("Saved storage is unavailable.");if(testMode)throw std::runtime_error("Online session validation is disabled in isolated test hosts.");
 if(current){std::lock_guard<std::mutex> lock(current->mutex);if(!current->done)throw std::runtime_error("A session check is still finishing. Try again shortly.");}
 auto entries=SessionTransfer::Parse(bytes);auto job=std::make_shared<Job>();job->total=entries.size();auto accounts=store->data["accounts"],credentials=json::object();for(const auto& account:accounts){auto id=account["id"].get<std::string>();if(store->credentials.contains(id)&&store->credentials[id].is_string()&&!store->credentials[id].get<std::string>().empty())credentials[id]="present";}current=job;
 std::thread([job,entries=std::move(entries),accounts,credentials]()mutable{
  auto result=SessionTransfer::Verify(entries,accounts,credentials,Lookup,[job](const json& row,size_t done,size_t){std::lock_guard<std::mutex> lock(job->mutex);job->rows.push_back(row);job->completed=done;},[job]{return job->cancel.load();});
  for(auto& row:entries)if(!row.cookie.empty())SecureZeroMemory(row.cookie.data(),row.cookie.size());
  {std::lock_guard<std::mutex> lock(job->mutex);job->review=std::move(result);if(job->cancel)ClearSensitive(*job);job->done=true;job->finishedAt=GetTickCount64();}
 }).detach();return Public(job);
}
inline bool InDirectory(const fs::path& path,const fs::path& directory){auto p=fs::weakly_canonical(path).wstring(),d=fs::weakly_canonical(directory).wstring();std::transform(p.begin(),p.end(),p.begin(),::towlower);std::transform(d.begin(),d.end(),d.begin(),::towlower);if(p==d)return true;if(!d.empty()&&d.back()!=L'\\')d+=L'\\';return p.rfind(d,0)==0;}
inline bool Handle(const json& m,json& reply){
 const auto action=m.at("action").get<std::string>();
 if(action=="session_export_file"){
  if(!m.value("acknowledged",false))throw std::runtime_error("Confirm that the export file contains account login cookies.");auto document=SessionTransfer::Export(*store,m.at("accounts"));
  wchar_t filename[32768]=L"RoHelper-account-sessions.rhsessions.json";OPENFILENAMEW dialog{sizeof(dialog)};dialog.hwndOwner=appWindow;dialog.lpstrFilter=L"RoHelper account sessions\0*.rhsessions.json\0JSON file\0*.json\0\0";dialog.lpstrFile=filename;dialog.nMaxFile=32768;dialog.lpstrDefExt=L"json";dialog.Flags=OFN_OVERWRITEPROMPT|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;reply["saved"]=false;
  if(GetSaveFileNameW(&dialog)){if(InDirectory(filename,store->dir))throw std::runtime_error("Choose an export location outside RoHelper's saved-data folder.");SafeStorage::Write(filename,document.dump(2)+"\n");reply["saved"]=true;reply["count"]=document["accounts"].size();}return true;
 }
 if(action=="session_import_file"){
  wchar_t filename[32768]=L"";OPENFILENAMEW dialog{sizeof(dialog)};dialog.hwndOwner=appWindow;dialog.lpstrFilter=L"Session files\0*.json;*.txt\0All files\0*.*\0\0";dialog.lpstrFile=filename;dialog.nMaxFile=32768;dialog.Flags=OFN_FILEMUSTEXIST|OFN_PATHMUSTEXIST|OFN_NOCHANGEDIR;reply["cancelled"]=true;
  if(GetOpenFileNameW(&dialog)){if(fs::file_size(filename)>SessionTransfer::MaxBytes)throw std::runtime_error("Choose a session file under 16 MB.");auto bytes=SafeStorage::Read(filename);reply["preview"]=Start(bytes);SecureZeroMemory(bytes.data(),bytes.size());reply["cancelled"]=false;}return true;
 }
 if(action=="session_import_text"){reply["preview"]=Start(m.at("sessions").get<std::string>());return true;}
 if(action=="session_import_status"){reply["preview"]=Public(Find(m));return true;}
 if(action=="session_import_cancel"){if(current&&m.value("job",std::string())==current->id){Cancel();std::lock_guard<std::mutex> lock(current->mutex);if(current->done)ClearSensitive(*current);}return true;}
 if(action=="session_import_apply"){
  auto job=Find(m);std::lock_guard<std::mutex> lock(job->mutex);if(!job->done)throw std::runtime_error("Wait for the session check to finish.");auto result=SessionTransfer::Apply(*store,job->review,m.at("selection"),m.value("replaceExisting",false),m.at("expectedRevision"));reply.update(result);job->cancel=true;ClearSensitive(*job);reply["data"]=store->Public();Changed();return true;
 }
 return false;
}
}
