#pragma once
#include "Macros.h"
#include "VisualMacro.h"
namespace MacroSharing {
inline void Validate(const json& m){
 if(!m.is_object()||!m.at("name").is_string()||m["name"].get<std::string>().empty()||m["name"].get<std::string>().size()>120||!m.at("script").is_string()||m["script"].get<std::string>().size()>65536)throw std::runtime_error("Invalid shared macro name or script.");
 VisualMacro::Validate(m);MacroVM::Check(m["script"]);
}
inline json StripIds(const json& b){json result={{"type",b.at("type")}};auto type=b.at("type").get<std::string>();for(auto k:{"key","seconds","milliseconds","count","code","button","origin","x","y"}){bool allowed=(std::string(k)=="key"&&(type=="press"||type=="hold"||type=="key_down"||type=="key_up"))||(std::string(k)=="seconds"&&(type=="press"||type=="hold"||type=="wait"))||(std::string(k)=="milliseconds"&&type=="wait_ms")||(std::string(k)=="count"&&type=="repeat")||(std::string(k)=="code"&&type=="lua")||(std::string(k)=="button"&&(type=="click"||type=="mouse_hold"))||((std::string(k)=="origin"||std::string(k)=="x"||std::string(k)=="y")&&(type=="click"||type=="mouse_hold"||type=="mouse_move"));if(allowed)result[k]=b.at(k);}if(type=="repeat"||type=="forever"){result["children"]=json::array();for(const auto& child:b.at("children"))result["children"].push_back(StripIds(child));}return result;}

inline json Portable(const json& m){Validate(m);json result={{"format","rohelper-macro"},{"version",1},{"name",m["name"]},{"script",m["script"]}};if(m.contains("visual")&&m.value("visualSource",std::string())==m["script"]){result["visual"]=json::array();for(auto b:m["visual"])result["visual"].push_back(StripIds(b));}if(result.dump().size()>262144)throw std::runtime_error("Macro file exceeds 256 KB.");return result;}
}
