#pragma once
#include "Store.h"
#include <optional>
#include <map>

// Three-way merge: stable IDs make account/item edits independent of array order.
// Ambiguous concurrent edits are rejected atomically, never last-writer-wins.
namespace HelperMerge {
struct Conflict : std::runtime_error {
 std::string path;
 explicit Conflict(const std::string& p):std::runtime_error("Concurrent changes affected "+p+". Choose which change to keep."),path(p){}
};
inline bool Equal(const json* a,const json* b){return a&&b?*a==*b:!a&&!b;}
inline const json* Field(const json* o,const std::string& k){if(!o||!o->is_object())return nullptr;auto i=o->find(k);return i==o->end()?nullptr:&*i;}
inline bool Keyed(const json& a){if(!a.is_array())return false;std::set<std::string> ids;for(const auto& x:a)if(!x.is_object()||!x.contains("id")||!x["id"].is_string()||!ids.insert(x["id"].get<std::string>()).second)return false;return true;}
inline std::optional<json> Merge(const json* base,const json* local,const json* remote,const std::string& path="workspace"){
 if(Equal(local,base))return remote?std::optional<json>(*remote):std::nullopt;
 if(Equal(remote,base)||Equal(local,remote))return local?std::optional<json>(*local):std::nullopt;
 if(local&&remote&&local->is_object()&&remote->is_object()&&(!base||base->is_object())){
  std::set<std::string> keys;for(const auto* x:{base,local,remote})if(x)for(const auto& p:x->items())keys.insert(p.key());
  json result=json::object();for(const auto& k:keys){auto value=Merge(Field(base,k),Field(local,k),Field(remote,k),path+"/"+k);if(value)result[k]=*value;}return result;
 }
 if(base&&local&&remote&&Keyed(*base)&&Keyed(*local)&&Keyed(*remote)){
  std::map<std::string,json> b,l,r;std::vector<std::string> bo,lo,ro;
  auto collect=[](const json& a,auto& map,auto& order){for(const auto& x:a){std::string id=x["id"];map[id]=x;order.push_back(id);}};
  collect(*base,b,bo);collect(*local,l,lo);collect(*remote,r,ro);
  std::set<std::string> ids;for(const auto* x:{&b,&l,&r})for(const auto& p:*x)ids.insert(p.first);
  std::map<std::string,json> merged;auto get=[](const auto& map,const auto& id)->const json*{auto i=map.find(id);return i==map.end()?nullptr:&i->second;};
  for(const auto& id:ids){auto value=Merge(get(b,id),get(l,id),get(r,id),path+"/"+id);if(value)merged[id]=*value;}
  // Compare relative order of surviving original IDs, ignoring additions/deletions.
  auto common=[&](const auto& order){std::vector<std::string> out;for(const auto& id:order)if(b.count(id)&&l.count(id)&&r.count(id)&&merged.count(id))out.push_back(id);return out;};
  auto bc=common(bo),lc=common(lo),rc=common(ro);if(lc!=bc&&rc!=bc&&lc!=rc)throw Conflict(path+"/order");
  const auto& preferred=lc!=bc?lo:ro;json result=json::array();std::set<std::string> added;
  const std::vector<std::string>* orders[]={&preferred,&lo,&ro};for(const auto* order:orders)for(const auto& id:*order)if(merged.count(id)&&added.insert(id).second)result.push_back(merged.at(id));return result;
 }
 throw Conflict(path);
}
inline json Document(json base,json proposed,json current){
 base.erase("_sync");proposed.erase("_sync");auto sync=current.value("_sync",json::object());current.erase("_sync");
 auto result=*Merge(&base,&proposed,&current);if(!sync.empty())result["_sync"]=sync;ValidateWorkspace(result);return result;
}
}
