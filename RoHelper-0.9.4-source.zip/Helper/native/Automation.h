#pragma once
#include "Clients.h"
#include "Macros.h"
#include "AutomationPlatform.h"
namespace Automation {
#ifdef ROHELPER_AUTOMATION_PLATFORM
using Platform = ROHELPER_AUTOMATION_PLATFORM;
#else
using Platform = WindowsAutomationPlatform;
#endif
struct Target{RosterClients::Client client;json options;std::string script,status="Waiting";std::unique_ptr<MacroVM> vm;std::set<WORD> held;std::set<std::string> mouseHeld;ULONGLONG due=0,lastInput=0;bool pending=false,stopped=false,draining=false;MacroAction action;};
inline std::map<DWORD,std::unique_ptr<Target>> targets;inline std::mt19937 rng(std::random_device{}());inline DWORD cursor=0;inline HWND previous=nullptr;inline DWORD owner=0;inline ULONGLONG settle=0;
inline bool Valid(const RosterClients::Client& c){return Platform::Valid(c);}
inline bool Tracked(const RosterClients::Client& c){auto it=targets.find(c.pid);return it!=targets.end()&&it->second->client.token==c.token&&it->second->client.window==c.window;}
inline INPUT Key(WORD key,bool up){INPUT in{};in.type=INPUT_KEYBOARD;in.ki.wScan=(WORD)MapVirtualKeyW(key,MAPVK_VK_TO_VSC);in.ki.dwFlags=KEYEVENTF_SCANCODE|(up?KEYEVENTF_KEYUP:0);if(key==VK_LEFT||key==VK_RIGHT||key==VK_UP||key==VK_DOWN||key==VK_HOME||key==VK_END||key==VK_DELETE||key==VK_INSERT||key==VK_PRIOR||key==VK_NEXT)in.ki.dwFlags|=KEYEVENTF_EXTENDEDKEY;return in;}
inline bool Held(const Target& t){return !t.held.empty()||!t.mouseHeld.empty();}
inline void ReleaseMouse(Target& t){bool sent=false;for(const auto& button:t.mouseHeld){auto input=MouseMacro::Button(button,true);sent=(Platform::Send(1,&input)==1)||sent;}t.mouseHeld.clear();}
inline void Release(Target& t){ReleaseMouse(t);bool sent=false;for(auto key:t.held){auto in=Key(key,true);sent=(Platform::Send(1,&in)==1)||sent;}t.held.clear();}
inline void Unfocus(Target& t){if(owner==t.client.pid){if(Platform::Foreground()==t.client.window&&previous&&Platform::Window(previous))Platform::Focus(previous);owner=0;previous=nullptr;}}
inline bool Quiet(){return Platform::Quiet();}
inline void Stop(DWORD pid,const std::string& token){auto it=targets.find(pid);if(it!=targets.end()&&it->second->client.token==token){Release(*it->second);Unfocus(*it->second);targets.erase(it);if(targets.empty())Platform::End();}}
inline void StopAll(){while(!targets.empty())Stop(targets.begin()->first,targets.begin()->second->client.token);}
inline void Start(const RosterClients::Client& client,const json& opts,const std::string& script){ValidateOptions(opts);if(!Valid(client))throw std::runtime_error("This client has closed.");if(opts["mode"]=="macro"){if(script.empty())throw std::runtime_error("Select a saved macro in this account’s settings.");MacroVM::Check(script);}Stop(client.pid,client.token);Platform::Begin(opts.value("pauseOnActivity",true));auto t=std::make_unique<Target>();t->client=client;t->options=opts;t->script=script;t->due=Platform::Now();targets[client.pid]=std::move(t);}
// Keep focus for a short drain after the last key/button release. SendInput
// queues input; restoring focus immediately can redirect that queued release.
inline void Drain(Target& t,ULONGLONG now){t.draining=true;t.due=now+100;}
inline void Tick(){auto now=Platform::Now();
 std::vector<DWORD> order;auto split=targets.upper_bound(cursor);
 for(auto it=split;it!=targets.end();++it)order.push_back(it->first);
 for(auto it=targets.begin();it!=split;++it)order.push_back(it->first);
 for(auto pid:order){auto it=targets.find(pid);if(it==targets.end())continue;auto& t=*it->second;
 if(!Valid(t.client)){Release(t);Unfocus(t);targets.erase(it);continue;}if(t.stopped)continue;
 try{
 if(t.options.value("pauseOnActivity",true)&&!Quiet()){Release(t);Unfocus(t);t.vm.reset();t.pending=false;t.draining=false;t.due=now+1000;t.status="Paused while you use the PC";continue;}
 if(owner==t.client.pid&&Platform::Foreground()!=t.client.window){Release(t);Unfocus(t);t.vm.reset();t.pending=false;t.draining=false;t.due=now+1000;t.status="Paused after focus changed";continue;}
 if(now<t.due)continue;if(owner&&owner!=t.client.pid)continue;
 if(t.draining){t.draining=false;Unfocus(t);continue;}
 if(!t.pending){if(!t.vm){auto code=t.script;if(t.options["mode"]=="simple"){auto keys=t.options["keys"];code="press(\""+keys[std::uniform_int_distribution<size_t>(0,keys.size()-1)(rng)].get<std::string>()+"\",0.2)";}t.vm=std::make_unique<MacroVM>(code);}if(!t.vm->Advance()){Release(t);Unfocus(t);t.vm.reset();double delay=t.options["repeatSeconds"].get<double>();if(t.options["mode"]=="simple")delay=std::uniform_real_distribution<double>(t.options["minSeconds"].get<double>(),t.options["maxSeconds"].get<double>())(rng);t.due=now+(ULONGLONG)(1000*delay);t.status="Waiting for next cycle";continue;}t.action=t.vm->next;t.pending=true;}
 auto action=t.action;if(action.kind=="mouse_release"){ReleaseMouse(t);t.pending=false;t.status="Mouse released";if(!Held(t))Drain(t,now);continue;}if(action.kind=="wait"){t.due=now+(ULONGLONG)(action.seconds*1000);t.pending=false;t.status=Held(t)?"Holding input":"Waiting";if(!Held(t))Unfocus(t);continue;}
 if(owner!=t.client.pid){previous=Platform::Foreground();cursor=t.client.pid;Platform::Focus(t.client.window);if(Platform::Foreground()!=t.client.window){previous=nullptr;t.status="Windows blocked focus; waiting";t.due=now+1000;continue;}owner=t.client.pid;settle=now+250;t.due=settle;continue;}if(now<settle)continue;
 if(action.kind=="mouse_move"||action.kind=="mouse_click"||action.kind=="mouse_double"||action.kind=="mouse_hold"){
 const auto point=MouseMacro::ScreenPosition(t.client.window,action.origin,action.x,action.y);auto hit=WindowFromPoint(point);
 if(hit!=t.client.window&&!IsChild(t.client.window,hit))throw std::runtime_error("Click location is covered by another window.");
 if(t.mouseHeld.count(action.button))throw std::runtime_error("Release the held mouse button before clicking it.");
 const RECT desktop{GetSystemMetrics(SM_XVIRTUALSCREEN),GetSystemMetrics(SM_YVIRTUALSCREEN),GetSystemMetrics(SM_XVIRTUALSCREEN)+GetSystemMetrics(SM_CXVIRTUALSCREEN),GetSystemMetrics(SM_YVIRTUALSCREEN)+GetSystemMetrics(SM_CYVIRTUALSCREEN)};
 if(action.kind=="mouse_move"){auto input=MouseMacro::Move(point,desktop);if(Platform::Send(1,&input)!=1)throw std::runtime_error("Windows blocked mouse movement.");t.lastInput=Platform::Now();t.pending=false;t.status="Running · mouse move";if(!Held(t))Drain(t,now);continue;}
 auto input=MouseMacro::Inputs(point,desktop,action.button,action.kind=="mouse_hold");t.mouseHeld.insert(action.button);
 if(Platform::Send((UINT)input.size(),input.data())!=input.size())throw std::runtime_error("Windows blocked mouse input.");
 if(action.kind!="mouse_hold")t.mouseHeld.erase(action.button);t.lastInput=Platform::Now();t.status=action.kind=="mouse_hold"?"Holding "+action.button+" mouse button":"Running · mouse click";
 if(action.kind=="mouse_double"){t.action.kind="mouse_click";t.due=now+std::max<DWORD>(20,std::min<DWORD>(80,GetDoubleClickTime()/4));continue;}
 t.pending=false;if(!Held(t))Drain(t,now);continue;
 }
 auto key=MacroVM::Key(action.key);auto in=Key(key,action.kind=="up");if(Platform::Send(1,&in)!=1)throw std::runtime_error("Windows blocked keyboard input.");if(action.kind=="down")t.held.insert(key);else t.held.erase(key);t.lastInput=Platform::Now();t.pending=false;t.status="Running · "+action.key;if(!Held(t))Drain(t,now);
 }catch(const std::exception& e){Release(t);Unfocus(t);t.vm.reset();t.pending=false;t.draining=false;if(t.options["mode"]=="simple"){t.due=now+1000;t.status=std::string("Retrying anti-AFK: ")+e.what();}else{t.stopped=true;t.status=e.what();}}}
 if(targets.empty())Platform::End();
}
inline json Status(){json result=json::array();for(auto& item:targets){auto& t=*item.second;result.push_back({{"pid",t.client.pid},{"token",t.client.token},{"running",!t.stopped},{"status",t.status+(t.options["mode"]=="simple"?(t.lastInput?" · last input "+std::to_string((Platform::Now()-t.lastInput)/1000)+"s ago":" · no input sent yet"):"")},{"mode",t.options["mode"]}});}return result;}
}
