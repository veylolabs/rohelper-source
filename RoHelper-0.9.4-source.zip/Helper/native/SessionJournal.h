#pragma once
// Included after Store's validation/DPAPI helpers. Fixed AppData paths only.
namespace SessionJournal {
inline std::string Hex(const std::string& bytes){std::string out;out.reserve(bytes.size()*2);for(unsigned char c:bytes){out+="0123456789abcdef"[c>>4];out+="0123456789abcdef"[c&15];}return out;}
inline std::string Unhex(const std::string& text){if(text.size()>40*1024*1024||text.size()%2)throw std::runtime_error("Invalid session recovery journal.");std::string out;out.reserve(text.size()/2);auto n=[](char c){if(c>='0'&&c<='9')return c-'0';if(c>='a'&&c<='f')return c-'a'+10;throw std::runtime_error("Invalid session recovery journal.");};for(size_t i=0;i<text.size();i+=2)out.push_back((char)((n(text[i])<<4)|n(text[i+1])));return out;}
inline fs::path Path(const fs::path& dir){return dir/L"session-import.pending.bin";}
inline json Capture(const fs::path& dir){json result={{"schema",1}};for(const auto* name:{"workspace.json","sessions.bin"}){auto path=dir/Wide(name);result[name]={{"exists",fs::exists(path)},{"bytes",fs::exists(path)?Hex(SafeStorage::Read(path)):""}};}return result;}
inline void Restore(const fs::path& dir,const json& document){
 if(!document.is_object()||document.at("schema")!=1)throw std::runtime_error("Invalid session recovery journal.");
 std::map<std::string,std::string> decoded;for(const auto* name:{"workspace.json","sessions.bin"}){const auto& row=document.at(name);if(!row.at("exists").is_boolean()||!row.at("bytes").is_string())throw std::runtime_error("Invalid session recovery journal.");decoded[name]=Unhex(row["bytes"]);}
 if(document["workspace.json"]["exists"].get<bool>())ValidateWorkspace(json::parse(decoded["workspace.json"]));
 if(document["sessions.bin"]["exists"].get<bool>()&&!json::parse(Unprotect(decoded["sessions.bin"])).is_object())throw std::runtime_error("Invalid session recovery journal.");
 for(const auto* name:{"sessions.bin","workspace.json"}){auto path=dir/Wide(name);if(document[name]["exists"].get<bool>()){if(!fs::exists(path)||SafeStorage::Read(path)!=decoded[name])SafeStorage::Write(path,decoded[name]);}else if(fs::exists(path)&&!DeleteFileW(path.c_str()))throw std::runtime_error("Session recovery could not restore storage.");}
 if(!DeleteFileW(Path(dir).c_str()))throw std::runtime_error("Session recovery could not finish. Keep the AppData files for recovery.");
}
inline void Recover(const fs::path& dir){auto path=Path(dir);if(!fs::exists(path))return;if(fs::file_size(path)>64*1024*1024)throw std::runtime_error("Session recovery journal is too large.");Restore(dir,json::parse(Unprotect(SafeStorage::Read(path))));}
}
