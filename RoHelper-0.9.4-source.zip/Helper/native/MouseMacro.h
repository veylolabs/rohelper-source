#pragma once
#include <windows.h>
#include <string>
#include <stdexcept>
#include <vector>

namespace MouseMacro {
inline int Origin(const std::string& origin){
    const char* names[]={"top-left","top-center","top-right","center-left","center","center-right","bottom-left","bottom-center","bottom-right"};
    for(int i=0;i<9;i++)if(origin==names[i])return i;
    throw std::runtime_error("Choose one of the nine mouse origins.");
}
inline void Validate(const std::string& button,const std::string& origin,int x,int y,bool hold=false){
    if(button!="left"&&button!="right"&&(hold||button!="double"))throw std::runtime_error("Choose left, right or double click; holds use left or right.");
    const auto i=Origin(origin),column=i%3,row=i/3;
    if(x < -100000 || x > 100000 || y < -100000 || y > 100000)throw std::runtime_error("Mouse offsets must be within 100,000 pixels.");
    if((column==0&&x<0)||(column==2&&x>0)||(row==0&&y<0)||(row==2&&y>0))throw std::runtime_error("Offsets point inward: left/top are positive, right/bottom negative; centered axes allow either.");
}
inline POINT Position(const std::string& origin,int x,int y,int width,int height){
    Validate("left",origin,x,y);if(width<1||height<1)throw std::runtime_error("The Roblox client area is empty.");
    const auto i=Origin(origin),column=i%3,row=i/3;
    POINT p{(column==0?0:column==1?width/2:width-1)+x,(row==0?0:row==1?height/2:height-1)+y};
    if(p.x<0||p.y<0||p.x>=width||p.y>=height)throw std::runtime_error("Mouse offset is outside the current Roblox client area.");
    return p;
}
inline POINT Offsets(const std::string& origin,POINT point,int width,int height){
    const auto anchor=Position(origin,0,0,width,height);
    if(point.x<0||point.y<0||point.x>=width||point.y>=height)throw std::runtime_error("Pointer is outside the Roblox client area.");
    POINT result{point.x-anchor.x,point.y-anchor.y};Validate("left",origin,result.x,result.y);return result;
}
inline POINT ScreenPosition(HWND window,const std::string& origin,int x,int y){
    RECT area{};if(!GetClientRect(window,&area))throw std::runtime_error("Cannot measure the Roblox client area.");
    auto p=Position(origin,x,y,area.right-area.left,area.bottom-area.top);
    if(!ClientToScreen(window,&p))throw std::runtime_error("Cannot locate the Roblox client area.");
    return p;
}
inline INPUT Button(const std::string& button,bool up){
    INPUT input{};input.type=INPUT_MOUSE;
    if(button=="left")input.mi.dwFlags=up?MOUSEEVENTF_LEFTUP:MOUSEEVENTF_LEFTDOWN;
    else if(button=="right")input.mi.dwFlags=up?MOUSEEVENTF_RIGHTUP:MOUSEEVENTF_RIGHTDOWN;
    else throw std::runtime_error("Unknown mouse button.");return input;
}
inline INPUT Move(POINT point,RECT desktop){
    const auto width=desktop.right-desktop.left,height=desktop.bottom-desktop.top;
    if(width<2||height<2||point.x<desktop.left||point.x>=desktop.right||point.y<desktop.top||point.y>=desktop.bottom)throw std::runtime_error("Click location is outside the Windows desktop.");
    INPUT input{};input.type=INPUT_MOUSE;input.mi.dwFlags=MOUSEEVENTF_MOVE|MOUSEEVENTF_ABSOLUTE|MOUSEEVENTF_VIRTUALDESK;
    input.mi.dx=MulDiv(point.x-desktop.left,65535,width-1);input.mi.dy=MulDiv(point.y-desktop.top,65535,height-1);return input;
}
inline std::vector<INPUT> Inputs(POINT point,RECT desktop,const std::string& button,bool hold){
    std::vector<INPUT> result={Move(point,desktop),Button(button,false)};if(!hold)result.push_back(Button(button,true));return result;
}
}
