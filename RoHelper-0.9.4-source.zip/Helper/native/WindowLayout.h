#pragma once
#include <windows.h>
#include <dwmapi.h>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <cmath>
#include <algorithm>
#include "json.hpp"
namespace WindowLayout {
using json=nlohmann::json;
inline json Defaults(){return {{"enabled",false},{"mainAccount",""},{"groups",json::object()},{"accounts",json::object()},{"order",json::array()},{"mode","manual"},{"positions",json::object()}};}
inline bool Valid(const json& v){try{
 if(!v.is_object()||!v.at("enabled").is_boolean()||!v.at("mainAccount").is_string()||!v.at("groups").is_object()||!v.at("accounts").is_object()||!v.at("order").is_array())return false;
 auto id=[](const std::string& s){return !s.empty()&&s.size()<=24&&s[0]!='0'&&s.find_first_not_of("0123456789")==std::string::npos;};
 const auto main=v["mainAccount"].get<std::string>();if(!main.empty()&&!id(main))return false;
 if(v["groups"].size()>500||v["accounts"].size()>2000||v["order"].size()>2000)return false;
 for(auto field:{"groups","accounts"})for(const auto& item:v[field].items()) {
  if(item.key().size()>256||(std::string(field)=="accounts"&&!id(item.key()))||!item.value().is_string())return false;
  auto value=item.value().get<std::string>();if(value.size()>512||value.find_first_of("\r\n")!=std::string::npos||value.find('\0')!=std::string::npos)return false;
 }
 std::set<std::string> seen;for(const auto& item:v["order"])if(!item.is_string()||!id(item.get<std::string>())||!seen.insert(item.get<std::string>()).second)return false;
 if(v.contains("mode")&&(!v["mode"].is_string()||(v["mode"]!="manual"&&v["mode"]!="grid")))return false;
 if(v.contains("positions")){
  if(!v["positions"].is_object()||v["positions"].size()>2000)return false;
  for(const auto& item:v["positions"].items()){
   const auto& r=item.value();if(!id(item.key())||!r.is_object()||!r.contains("monitor")||!r["monitor"].is_string())return false;
   const auto monitor=r["monitor"].get<std::string>();if(monitor.empty()||monitor.size()>512||monitor.find_first_of("\r\n")!=std::string::npos||monitor.find('\0')!=std::string::npos)return false;
   for(auto field:{"x","y","width","height"})if(!r.contains(field)||!r[field].is_number()||!std::isfinite(r[field].get<double>()))return false;
   const double x=r["x"],y=r["y"],w=r["width"],h=r["height"];
   if(x<0||y<0||w<.05||h<.05||x+w>1.000000001||y+h>1.000000001)return false;
  }
 }
 return true;
 }catch(...){return false;}}
struct Monitor {std::string id,label;RECT bounds,work;bool primary;};
struct Account {std::string id,group;};
struct Placement {std::string account,monitor;RECT rectangle;bool fullscreen=false;};
struct Plan {std::vector<Placement> placements;std::string error;};
inline std::string Utf8(const std::wstring& text){if(text.empty())return {};int size=WideCharToMultiByte(CP_UTF8,0,text.data(),static_cast<int>(text.size()),nullptr,0,nullptr,nullptr);std::string out(size,0);WideCharToMultiByte(CP_UTF8,0,text.data(),static_cast<int>(text.size()),out.data(),size,nullptr,nullptr);return out;}
// Monitor and window coordinates must use the same physical-pixel context.
struct DpiScope {using Set=HANDLE(WINAPI*)(HANDLE);Set set=nullptr;HANDLE previous=nullptr;
 DpiScope(){set=reinterpret_cast<Set>(GetProcAddress(GetModuleHandleW(L"user32.dll"),"SetThreadDpiAwarenessContext"));if(set)previous=set(reinterpret_cast<HANDLE>(-4));}
 ~DpiScope(){if(set&&previous)set(previous);}};
inline std::vector<Monitor> Monitors(){DpiScope dpi;std::vector<Monitor> out;
 EnumDisplayMonitors(nullptr,nullptr,[](HMONITOR monitor,HDC,LPRECT,LPARAM data)->BOOL{
  auto& result=*reinterpret_cast<std::vector<Monitor>*>(data);MONITORINFOEXW info{};info.cbSize=sizeof(info);if(!GetMonitorInfoW(monitor,&info))return TRUE;
  DISPLAY_DEVICEW device{};device.cb=sizeof(device);std::string id=Utf8(info.szDevice);
  if(EnumDisplayDevicesW(info.szDevice,0,&device,EDD_GET_DEVICE_INTERFACE_NAME)&&device.DeviceID[0])id=Utf8(device.DeviceID);
  result.push_back({id,Utf8(info.szDevice),info.rcMonitor,info.rcWork,(info.dwFlags&MONITORINFOF_PRIMARY)!=0});return TRUE;
 },reinterpret_cast<LPARAM>(&out));std::sort(out.begin(),out.end(),[](const auto& a,const auto& b){if(a.primary!=b.primary)return a.primary>b.primary;return a.label<b.label;});return out;}
inline std::vector<RECT> Grid(const RECT& area,size_t count){std::vector<RECT> cells;if(!count)return cells;
 int cols=count<=2?static_cast<int>(count):count<=4?2:count<=6?3:static_cast<int>(std::ceil(std::sqrt(static_cast<double>(count))));
 int rows=static_cast<int>((count+cols-1)/cols);for(size_t i=0;i<count;++i){int col=static_cast<int>(i%cols),row=static_cast<int>(i/cols);cells.push_back({area.left+col*(area.right-area.left)/cols,area.top+row*(area.bottom-area.top)/rows,area.left+(col+1)*(area.right-area.left)/cols,area.top+(row+1)*(area.bottom-area.top)/rows});}return cells;}
inline Plan Arrange(const json& rules,const std::vector<Monitor>& monitors,std::vector<Account> accounts){Plan plan;
 if(!Valid(rules)){plan.error="The saved window layout is invalid.";return plan;}
 const auto main=rules["mainAccount"].get<std::string>();const Monitor* primary=nullptr;std::map<std::string,const Monitor*> available;
 for(const auto& monitor:monitors){available[monitor.id]=&monitor;if(monitor.primary)primary=&monitor;}
 std::map<std::string,size_t> rank;size_t next=0;for(const auto& id:rules["order"])rank[id.get<std::string>()]=next++;
 std::stable_sort(accounts.begin(),accounts.end(),[&](const auto& a,const auto& b){auto ra=rank.count(a.id)?rank[a.id]:rank.size(),rb=rank.count(b.id)?rank[b.id]:rank.size();return ra<rb;});
 std::map<std::string,std::vector<Account>> assigned;
 for(const auto& account:accounts){
  if(account.id==main){if(!primary){plan.error="The primary monitor is unavailable.";plan.placements.clear();return plan;}plan.placements.push_back({account.id,primary->id,primary->bounds,true});continue;}
  // An explicit empty override leaves this account alone; absence inherits its group.
  auto monitor=rules["accounts"].contains(account.id)?rules["accounts"].value(account.id,""):rules["groups"].value(account.group,"");if(monitor.empty())continue;
  if(!available.count(monitor)){plan.error="An assigned monitor is disconnected. Refresh displays or change the assignment.";plan.placements.clear();return plan;}
  if(!main.empty()&&primary&&monitor==primary->id){plan.error="The primary monitor is reserved for the fullscreen main account. Assign other accounts to another monitor.";plan.placements.clear();return plan;}
  assigned[monitor].push_back(account);
 }
 for(const auto& group:assigned){const auto& area=available[group.first]->work;const auto cells=Grid(area,group.second.size());for(size_t i=0;i<cells.size();++i){
  auto rectangle=cells[i];const auto& id=group.second[i].id;
  if(rules.value("mode","grid")=="manual"&&rules.contains("positions")&&rules["positions"].contains(id)){
   const auto& r=rules["positions"][id];if(r["monitor"]==group.first){
    const double w=area.right-area.left,h=area.bottom-area.top,x=r["x"],y=r["y"],rw=r["width"],rh=r["height"];
    rectangle={area.left+static_cast<LONG>(std::lround(x*w)),area.top+static_cast<LONG>(std::lround(y*h)),area.left+static_cast<LONG>(std::lround((std::min)(1.,x+rw)*w)),area.top+static_cast<LONG>(std::lround((std::min)(1.,y+rh)*h))};
   }
  }
  plan.placements.push_back({id,group.first,rectangle,false});
 }}
 return plan;
}
inline HWND Find(DWORD pid){struct Search{DWORD pid;HWND window=nullptr;} search{pid};
 EnumWindows([](HWND window,LPARAM data)->BOOL{auto& search=*reinterpret_cast<Search*>(data);DWORD owner=0;GetWindowThreadProcessId(window,&owner);if(owner!=search.pid||!IsWindowVisible(window))return TRUE;wchar_t type[128]{};GetClassNameW(window,type,128);if(wcscmp(type,L"WINDOWSCLIENT")!=0)return TRUE;search.window=window;return FALSE;},reinterpret_cast<LPARAM>(&search));return search.window;
}
inline bool Place(HWND window,const Placement& placement){DpiScope dpi;if(!IsWindow(window))return false;
 if(IsIconic(window)||IsZoomed(window))ShowWindow(window,SW_RESTORE);
 auto style=GetWindowLongPtrW(window,GWL_STYLE);style&=~(WS_THICKFRAME|WS_CAPTION|WS_BORDER|WS_DLGFRAME);style|=WS_POPUP|WS_VISIBLE|WS_CLIPCHILDREN|WS_CLIPSIBLINGS;
 if(!placement.fullscreen)style|=WS_CAPTION|WS_SYSMENU;
 SetLastError(0);if(!SetWindowLongPtrW(window,GWL_STYLE,style)&&GetLastError())return false;
 const auto& r=placement.rectangle;return SetWindowPos(window,nullptr,r.left,r.top,r.right-r.left,r.bottom-r.top,SWP_NOZORDER|SWP_NOACTIVATE|SWP_FRAMECHANGED|SWP_SHOWWINDOW)!=FALSE;
}
}

