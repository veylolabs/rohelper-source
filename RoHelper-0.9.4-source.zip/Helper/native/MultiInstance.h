#pragma once
#include "../legacy/BackendProvider.h"
// The existing MultiRoblox implementation owns both named guards on one worker.
// Separate process: its lifetime and closing are visible without using an external app.
struct MultiInstance{std::unique_ptr<BackendCoordinator> backend;std::string error;bool Start(){if(!backend)backend=std::make_unique<BackendCoordinator>();std::string e;auto ready=backend->Prepare("multiroblox",false,e);error=e;return ready;}void Stop(){backend.reset();error="MultiRoblox is stopped.";}json Status(){auto s=backend?backend->State():BackendCoordinator::Status{};return {{"running",backend&&s.ready},{"error",!s.error.empty()?s.error:error}};}};
