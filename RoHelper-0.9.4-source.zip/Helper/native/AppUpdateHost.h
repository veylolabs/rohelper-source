#pragma once
// Included by main.cpp after its UI-thread helpers. State is only changed on UI.
json appUpdate={{"phase","idle"},{"currentVersion",ROHELPER_VERSION},{"release",nullptr},{"error",""},{"checkedAt",0},{"bytes",0}};
fs::path appUpdateStage;std::string appUpdateNonce;ULONGLONG appUpdateLast=0;
bool UpdateBusy(){auto p=appUpdate["phase"].get<std::string>();return p=="checking"||p=="downloading"||p=="preparing"||p=="ready";}
void PublishUpdate(){Reply({{"type","app_update"},{"appUpdate",appUpdate}});}
void CheckAppUpdate(json request=json::object()){
 if(UpdateBusy()||appUpdate["phase"]=="downloaded"){if(request.contains("requestId"))Reply({{"ok",true},{"requestId",request["requestId"]},{"appUpdate",appUpdate}});return;}
 appUpdate["phase"]="checking";appUpdate["error"]="";appUpdateLast=GetTickCount64();PublishUpdate();
 std::thread([request]{json release;std::string error;try{release=AppUpdates::Validate(json::parse(AppUpdates::Fetch(L"https://raw.githubusercontent.com/veylolabs/rohelper-releases/main/latest.json",65536)),ROHELPER_VERSION);}catch(const std::exception& e){error=e.what();}
  OnUi([request,release,error]{appUpdate["checkedAt"]=SabProgress::Now();appUpdate["error"]=error;if(error.empty()){appUpdate["release"]=release;appUpdate["phase"]=release["newer"].get<bool>()?"available":"current";}else appUpdate["phase"]="error";PublishUpdate();if(request.contains("requestId"))Reply({{"ok",true},{"requestId",request["requestId"]},{"appUpdate",appUpdate}});});
 }).detach();
}
std::string UpdateGuid(){GUID id;CoCreateGuid(&id);wchar_t b[40];StringFromGUID2(id,b,40);auto s=Utf8(b);s=s.substr(1,36);std::transform(s.begin(),s.end(),s.begin(),::tolower);return s;}
void DownloadAppUpdate(json request){
 if(UpdateBusy()||appUpdate["release"].is_null()||!appUpdate["release"].value("newer",false))throw std::runtime_error("Check for a newer app release first.");
 const auto release=appUpdate["release"];const auto directory=store->dir/L"app-updates"/Wide(UpdateGuid());appUpdate["phase"]="downloading";appUpdate["error"]="";appUpdate["bytes"]=0;PublishUpdate();
 std::thread([request,release,directory]{std::string error;try{auto bytes=AppUpdates::Fetch(Wide(release["url"]),release["size"].get<size_t>(),[](size_t n){OnUi([n]{appUpdate["bytes"]=n;PublishUpdate();});});AppUpdates::Verify(bytes,release);fs::create_directories(directory);SafeStorage::Write(directory/L"release.zip",bytes);}catch(const std::exception& e){error=e.what();}
  OnUi([request,directory,error]{appUpdate["error"]=error;appUpdate["phase"]=error.empty()?"downloaded":"error";if(error.empty())appUpdateStage=directory;PublishUpdate();Reply({{"ok",error.empty()},{"error",error},{"requestId",request["requestId"]},{"appUpdate",appUpdate}});});
 }).detach();
}
void PrepareAppUpdate(json request){
 if(MacroRecorder::Running())throw std::runtime_error("Stop and review the macro recording before updating RoHelper.");if(store->blocked)throw std::runtime_error(store->error);if(appUpdate["phase"]!="downloaded"||appUpdateStage.empty())throw std::runtime_error("Download and verify the update first.");if(launchBusy)throw std::runtime_error("Wait for the current Roblox launch to finish.");
 const auto release=appUpdate["release"];appUpdateNonce=UpdateGuid();const auto stage=appUpdateStage;const auto nonce=appUpdateNonce;
 auto job=json{{"schema",1},{"destination",root.u8string()},{"dataDirectory",store->dir.u8string()},{"version",release["version"]},{"sha256",release["sha256"]},{"size",release["size"]},{"parentPid",GetCurrentProcessId()},{"nonce",nonce},{"testMode",testMode}};
 fs::copy_file(root/L"update/Install-RoHelper.ps1",stage/L"installer.ps1",fs::copy_options::overwrite_existing);SafeStorage::Write(stage/L"job.json",job.dump());
 AppUpdates::LaunchInstaller(stage/L"installer.ps1",stage/L"job.json");appUpdate["phase"]="preparing";appUpdate["error"]="";PublishUpdate();
 std::thread([request,stage,nonce]{std::string error;bool ready=false;for(int i=0;i<600;i++){try{auto status=json::parse(SafeStorage::Read(stage/L"status.json"));if(status.value("nonce",std::string())!=nonce)throw std::runtime_error("Invalid installer response.");if(status["state"]=="ready"){ready=true;break;}if(status["state"]=="failed"||status["state"]=="rolled-back"){error=status.value("message",std::string("App preparation failed."));break;}}catch(...){}Sleep(200);}if(!ready&&error.empty())error="The installer did not become ready. RoHelper remains open; retry the download.";
  OnUi([request,ready,error]{appUpdate["phase"]=ready?"ready":"error";appUpdate["error"]=error;PublishUpdate();Reply({{"ok",ready},{"error",error},{"requestId",request["requestId"]},{"appUpdate",appUpdate}});});
 }).detach();
}
void CommitAppUpdate(const json& request){
 if(appUpdate["phase"]!="ready"||appUpdateStage.empty()||store->blocked)throw std::runtime_error("The app installer is not ready.");
 auto status=json::parse(SafeStorage::Read(appUpdateStage/L"status.json"));if(status["state"]!="ready"||status["nonce"]!=appUpdateNonce)throw std::runtime_error("The app installer expired. Download the update again.");
 if(request.at("expectedRevision")!=store->data["revision"])throw std::runtime_error("Account data changed. Save and try again.");
 store->Save();SafeStorage::Write(appUpdateStage/L"commit.txt",appUpdateNonce);OnUi([]{DestroyWindow(appWindow);});
}
