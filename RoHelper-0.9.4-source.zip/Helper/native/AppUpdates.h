#pragma once
#include <array>
#include <functional>
#include "GameContent.h"
// Public release metadata only. Never sends cookies or workspace data.
namespace AppUpdates {
inline const std::string Repository="veylolabs/rohelper-releases";
inline std::array<unsigned,3> Version(const std::string& s){
 if(!std::regex_match(s,std::regex("(0|[1-9][0-9]{0,4})\\.(0|[1-9][0-9]{0,4})\\.(0|[1-9][0-9]{0,4})")))throw std::runtime_error("Invalid app release version.");
 std::array<unsigned,3> v{};std::istringstream in(s);char dot;in>>v[0]>>dot>>v[1]>>dot>>v[2];for(auto n:v)if(n>65535)throw std::runtime_error("Invalid app release version.");return v;
}
inline json Validate(const json& r,const std::string& installed){
 if(!r.is_object()||r.at("schema")!=1||r.at("platform")!="windows-x86")throw std::runtime_error("This app release format is not supported.");
 auto version=r.at("version").get<std::string>();auto next=Version(version),current=Version(installed);
 auto expected="https://github.com/"+Repository+"/releases/download/v"+version+"/RoHelper-"+version+"-portable.zip";
 if(r.at("url")!=expected||!r.at("size").is_number_unsigned()||r["size"]<1000||r["size"]>100*1024*1024||!r.at("sha256").is_string()||!std::regex_match(r["sha256"].get<std::string>(),std::regex("[a-f0-9]{64}")))throw std::runtime_error("Invalid app release download.");
 if(!r.at("notes").is_string()||r["notes"].get<std::string>().size()>20000)throw std::runtime_error("Invalid release notes.");
 json out={{"version",version},{"platform","windows-x86"},{"url",expected},{"size",r["size"]},{"sha256",r["sha256"]},{"notes",r["notes"]},{"newer",next>current},{"releaseUrl","https://github.com/"+Repository+"/releases/tag/v"+version}};return out;
}
struct Handle{HINTERNET h=nullptr;explicit Handle(HINTERNET p):h(p){}~Handle(){if(h)WinHttpCloseHandle(h);}operator HINTERNET()const{return h;}};
inline bool Host(const std::wstring& s){return s==L"raw.githubusercontent.com"||s==L"github.com"||s==L"release-assets.githubusercontent.com"||s==L"objects.githubusercontent.com";}
inline std::string Fetch(std::wstring url,size_t maximum,const std::function<void(size_t)>& progress={}){
 Handle session(WinHttpOpen(L"RoHelper app updater/1",WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0));if(!session.h)throw std::runtime_error("App update connection failed.");WinHttpSetTimeouts(session,10000,10000,20000,20000);
 for(int redirect=0;redirect<6;redirect++){
  URL_COMPONENTS u{};u.dwStructSize=sizeof(u);u.dwHostNameLength=u.dwUrlPathLength=u.dwExtraInfoLength=u.dwUserNameLength=u.dwPasswordLength=(DWORD)-1;
  if(!WinHttpCrackUrl(url.c_str(),0,0,&u)||u.nScheme!=INTERNET_SCHEME_HTTPS||u.nPort!=443||u.dwUserNameLength||u.dwPasswordLength||!Host(std::wstring(u.lpszHostName,u.dwHostNameLength)))throw std::runtime_error("App update redirected outside approved GitHub download hosts.");
  auto host=std::wstring(u.lpszHostName,u.dwHostNameLength),path=std::wstring(u.lpszUrlPath,u.dwUrlPathLength)+std::wstring(u.lpszExtraInfo,u.dwExtraInfoLength);
  Handle connection(WinHttpConnect(session,host.c_str(),443,0));Handle request(WinHttpOpenRequest(connection,L"GET",path.c_str(),nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,WINHTTP_FLAG_SECURE));if(!connection.h||!request.h)throw std::runtime_error("App update request failed.");DWORD policy=WINHTTP_OPTION_REDIRECT_POLICY_NEVER;WinHttpSetOption(request,WINHTTP_OPTION_REDIRECT_POLICY,&policy,sizeof(policy));
  if(!WinHttpSendRequest(request,L"Accept: application/octet-stream\r\nCache-Control: no-cache\r\n",(DWORD)-1,nullptr,0,0,0)||!WinHttpReceiveResponse(request,nullptr))throw std::runtime_error("App updates are unavailable. RoHelper and your data are unchanged.");DWORD status=0,n=sizeof(status);WinHttpQueryHeaders(request,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,nullptr,&status,&n,nullptr);
  if(status==301||status==302||status==303||status==307||status==308){DWORD count=0;WinHttpQueryHeaders(request,WINHTTP_QUERY_LOCATION,nullptr,nullptr,&count,nullptr);if(!count||count>32768)throw std::runtime_error("Invalid update redirect.");std::wstring location(count/sizeof(wchar_t),L'\0');if(!WinHttpQueryHeaders(request,WINHTTP_QUERY_LOCATION,nullptr,location.data(),&count,nullptr))throw std::runtime_error("Invalid update redirect.");location.resize(count/sizeof(wchar_t));while(!location.empty()&&location.back()==0)location.pop_back();url=location;continue;}
  if(status!=200)throw std::runtime_error(status==404?"No public app release is available yet.":"App update download failed (HTTP "+std::to_string(status)+").");
  std::string result;char buffer[65536];DWORD got=0;for(;;){if(!WinHttpReadData(request,buffer,sizeof(buffer),&got))throw std::runtime_error("App update download was interrupted. Retry when connected.");if(!got)break;if(result.size()+got>maximum)throw std::runtime_error("App update exceeds its declared size.");result.append(buffer,got);if(progress)progress(result.size());}return result;
 }throw std::runtime_error("Too many app update redirects.");
}
inline void Verify(const std::string& bytes,const json& release){if(bytes.size()!=release.at("size").get<size_t>()||GameContent::Digest(bytes)!=release.at("sha256"))throw std::runtime_error("App update checksum does not match. Nothing was installed.");}
inline void LaunchInstaller(const fs::path& script,const fs::path& job){
 wchar_t system[32768];GetSystemDirectoryW(system,32768);auto exe=fs::path(system)/L"WindowsPowerShell/v1.0/powershell.exe";
 auto quote=[](const fs::path& p){auto s=p.wstring();if(s.find(L'"')!=std::wstring::npos)throw std::runtime_error("Invalid updater path.");return L"\""+s+L"\"";};
 std::wstring command=quote(exe)+L" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "+quote(script)+L" -JobFile "+quote(job);STARTUPINFOW si{sizeof(si)};si.dwFlags=STARTF_USESHOWWINDOW;si.wShowWindow=SW_HIDE;PROCESS_INFORMATION pi{};
 if(!CreateProcessW(exe.c_str(),command.data(),nullptr,nullptr,FALSE,CREATE_NO_WINDOW,nullptr,job.parent_path().c_str(),&si,&pi))throw std::runtime_error("Could not start the app installer. Your app remains open.");CloseHandle(pi.hThread);CloseHandle(pi.hProcess);
}
}
