#pragma once
#include <windows.h>
#include <tlhelp32.h>
#include <mmdeviceapi.h>
#include <audiopolicy.h>
#include <wrl/client.h>
#include <map>
#include <set>
#include <mutex>
#include <fstream>
#include <sstream>
#include "WindowLayout.h"

// External clients are identified by ownership of their player log, never by
// launch order or similar timestamps. No credentials or game memory are read.
namespace RosterClients {
using json=nlohmann::json;
using Microsoft::WRL::ComPtr;
struct Handle {HANDLE value=nullptr;explicit Handle(HANDLE v=nullptr):value(v){}~Handle(){if(value&&value!=INVALID_HANDLE_VALUE)CloseHandle(value);}Handle(const Handle&)=delete;};
inline unsigned long long Stamp(const FILETIME& f){return (static_cast<unsigned long long>(f.dwHighDateTime)<<32)|f.dwLowDateTime;}
inline std::string Token(HANDLE process){FILETIME c,e,k,u;if(!GetProcessTimes(process,&c,&e,&k,&u))return {};return std::to_string(Stamp(c));}
inline bool IsRoblox(HANDLE process){wchar_t path[32768]{};DWORD n=32768;return QueryFullProcessImageNameW(process,0,path,&n)&&_wcsicmp(std::filesystem::path(path).filename().c_str(),L"RobloxPlayerBeta.exe")==0;}
struct Client {DWORD pid;std::string token;HWND window;long long userId=0;std::wstring log;};
inline std::vector<Client> Windows(){std::vector<Client> result;Handle snapshot(CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS,0));PROCESSENTRY32W entry{};entry.dwSize=sizeof(entry);
 if(snapshot.value==INVALID_HANDLE_VALUE||!Process32FirstW(snapshot.value,&entry))return result;
 do{if(_wcsicmp(entry.szExeFile,L"RobloxPlayerBeta.exe"))continue;auto window=WindowLayout::Find(entry.th32ProcessID);if(!window)continue;Handle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,entry.th32ProcessID));if(!process.value||!IsRoblox(process.value)||WaitForSingleObject(process.value,0)!=WAIT_TIMEOUT)continue;auto token=Token(process.value);if(!token.empty())result.push_back({entry.th32ProcessID,token,window});}while(Process32NextW(snapshot.value,&entry));return result;
}
struct HandleEntry {PVOID object;ULONG_PTR pid,handle;ULONG access;USHORT trace,type;ULONG attributes,reserved;};
struct HandleTable {ULONG_PTR count,reserved;HandleEntry entries[1];};
inline std::vector<unsigned char> HandleBytes(){
 using Query=LONG(NTAPI*)(ULONG,PVOID,ULONG,PULONG);auto query=reinterpret_cast<Query>(GetProcAddress(GetModuleHandleW(L"ntdll.dll"),"NtQuerySystemInformation"));if(!query)return {};
 std::vector<unsigned char> bytes(1024*1024);ULONG needed=0;
 for(int i=0;i<8;i++){auto status=query(64,bytes.data(),static_cast<ULONG>(bytes.size()),&needed);if(status==0)return bytes;if(status!=static_cast<LONG>(0xc0000004))break;auto size=(std::max)(bytes.size()*2,static_cast<size_t>(needed)+65536);if(size>128*1024*1024)break;bytes.resize(size);}return {};
}
inline long long LogIdentity(const std::string& text){
 std::set<long long> ids;std::istringstream lines(text);std::string line;const std::regex user(R"(\buserid:\s*([0-9]{1,16})\b)",std::regex::icase);
 while(std::getline(lines,line)){if(line.find("[FLog::GameJoinLoadTime]")==std::string::npos)continue;std::smatch match;if(std::regex_search(line,match,user)){try{auto id=std::stoll(match[1]);if(id>0)ids.insert(id);}catch(...){}}}
 return ids.size()==1?*ids.begin():0;
}
inline std::vector<Client> Discover(){
 auto clients=Windows();if(clients.empty())return clients;auto bytes=HandleBytes();if(bytes.size()<offsetof(HandleTable,entries))return clients;
 auto table=reinterpret_cast<const HandleTable*>(bytes.data());auto count=(std::min)(static_cast<size_t>(table->count),(bytes.size()-offsetof(HandleTable,entries))/sizeof(HandleEntry));
 for(auto& client:clients){
  Handle process(OpenProcess(PROCESS_DUP_HANDLE|PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,client.pid));if(!process.value||Token(process.value)!=client.token)continue;
  std::set<std::wstring> logs;
  for(size_t i=0;i<count;i++){const auto& e=table->entries[i];if(e.pid!=client.pid)continue;HANDLE copy=nullptr;
   if(!DuplicateHandle(process.value,reinterpret_cast<HANDLE>(e.handle),GetCurrentProcess(),&copy,0,FALSE,DUPLICATE_SAME_ACCESS))continue;Handle handle(copy);if(GetFileType(copy)!=FILE_TYPE_DISK)continue;
   wchar_t path[32768]{};auto length=GetFinalPathNameByHandleW(copy,path,32768,FILE_NAME_NORMALIZED);if(!length||length>=32768)continue;
   std::wstring value(path),lower=value;std::transform(lower.begin(),lower.end(),lower.begin(),::towlower);
   if(lower.find(L"\\roblox\\logs\\")==std::wstring::npos||lower.find(L"_player_")==std::wstring::npos||std::filesystem::path(lower).extension()!=L".log")continue;logs.insert(value);
  }
  std::set<long long> identities;
  for(const auto& log:logs){std::ifstream in(std::filesystem::path(log),std::ios::binary);if(!in)continue;std::string text(2*1024*1024,'\0');in.read(text.data(),text.size());text.resize(static_cast<size_t>(in.gcount()));auto id=LogIdentity(text);if(id){identities.insert(id);client.log=log;}}
  if(identities.size()==1&&WaitForSingleObject(process.value,0)==WAIT_TIMEOUT&&Token(process.value)==client.token)client.userId=*identities.begin();
 }
 return clients;
}
struct Audio {ComPtr<ISimpleAudioVolume> control;DWORD pid;};
inline std::vector<Audio> AudioSessions(){
 std::vector<Audio> sessions;ComPtr<IMMDeviceEnumerator> devices;if(FAILED(CoCreateInstance(__uuidof(MMDeviceEnumerator),nullptr,CLSCTX_ALL,IID_PPV_ARGS(&devices))))return sessions;
 ComPtr<IMMDeviceCollection> endpoints;if(FAILED(devices->EnumAudioEndpoints(eRender,DEVICE_STATE_ACTIVE,&endpoints)))return sessions;UINT count=0;endpoints->GetCount(&count);
 for(UINT i=0;i<count;i++){ComPtr<IMMDevice> device;ComPtr<IAudioSessionManager2> manager;ComPtr<IAudioSessionEnumerator> list;
  if(FAILED(endpoints->Item(i,&device))||FAILED(device->Activate(__uuidof(IAudioSessionManager2),CLSCTX_ALL,nullptr,reinterpret_cast<void**>(manager.GetAddressOf())))||FAILED(manager->GetSessionEnumerator(&list)))continue;int n=0;list->GetCount(&n);
  for(int j=0;j<n;j++){ComPtr<IAudioSessionControl> session;ComPtr<IAudioSessionControl2> detail;ComPtr<ISimpleAudioVolume> volume;DWORD pid=0;AudioSessionState state;
   if(FAILED(list->GetSession(j,&session))||FAILED(session.As(&detail))||FAILED(session.As(&volume))||FAILED(detail->GetProcessId(&pid))||!pid||FAILED(session->GetState(&state))||state==AudioSessionStateExpired)continue;sessions.push_back({volume,pid});
  }
 }
 return sessions;
}
inline json Snapshot(const std::vector<Client>& clients){
 json result={{"clients",json::array()},{"monitors",json::array()}};auto audio=AudioSessions();WindowLayout::DpiScope dpi;
 for(const auto& c:clients){float volume=0;bool muted=true;int count=0;for(const auto& a:audio)if(a.pid==c.pid){float v;BOOL m;if(SUCCEEDED(a.control->GetMasterVolume(&v))&&SUCCEEDED(a.control->GetMute(&m))){count++;volume=(std::max)(v,volume);muted=muted&&m;}}
  result["clients"].push_back({{"pid",c.pid},{"token",c.token},{"userId",c.userId},{"username",""},{"audio",{{"available",count>0},{"volume",static_cast<int>(std::lround(volume*100))},{"muted",count>0&&muted}}}});
 }
 for(const auto& m:WindowLayout::Monitors())result["monitors"].push_back({{"id",m.id},{"label",m.label},{"primary",m.primary},{"width",m.bounds.right-m.bounds.left},{"height",m.bounds.bottom-m.bounds.top}});return result;
}
inline json previousAudio=json::array();
inline json SetAudio(const json& request){
 bool all=request.value("all",false);DWORD pid=all?0:request.at("pid").get<DWORD>();std::string token=all?"":request.at("token").get<std::string>();
 bool mute=request.value("muted",false);if(all&&(!request.contains("muted")||!mute||request.contains("volume")))throw std::runtime_error("The bulk audio action only supports mute all.");
 if(all&&previousAudio.empty()){auto snapshot=Snapshot(Discover());for(const auto& c:snapshot["clients"])if(c["audio"].value("available",false))previousAudio.push_back({{"pid",c["pid"]},{"token",c["token"]},{"volume",c["audio"]["volume"]},{"muted",c["audio"]["muted"]}});}
 float volume=0;if(request.contains("volume")){double v=request.at("volume");if(!std::isfinite(v)||v<0||v>100)throw std::runtime_error("Volume must be between 0 and 100.");volume=static_cast<float>(v/100);}
 if(!request.contains("volume")&&!request.contains("muted"))throw std::runtime_error("No audio change requested.");
 std::map<DWORD,std::unique_ptr<Handle>> processes;
 for(const auto& a:AudioSessions()){
  if(!all&&a.pid!=pid)continue;if(processes.count(a.pid))continue;
  auto h=std::make_unique<Handle>(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,a.pid));if(!h->value||!IsRoblox(h->value)||WaitForSingleObject(h->value,0)!=WAIT_TIMEOUT||(!all&&Token(h->value)!=token))continue;processes[a.pid]=std::move(h);
 }
 int changed=0,failed=0;
 for(const auto& a:AudioSessions()){auto it=processes.find(a.pid);if(it==processes.end()||WaitForSingleObject(it->second->value,0)!=WAIT_TIMEOUT)continue;
  HRESULT hr=S_OK;if(request.contains("volume"))hr=a.control->SetMasterVolume(volume,nullptr);if(SUCCEEDED(hr)&&request.contains("muted"))hr=a.control->SetMute(mute,nullptr);if(SUCCEEDED(hr))changed++;else failed++;
 }
 if(!changed&&!failed)throw std::runtime_error("This Roblox audio session is no longer available. Refresh clients.");return {{"changed",changed},{"failed",failed}};
}
inline json RestoreAudio(){if(previousAudio.empty())throw std::runtime_error("No pre-mute audio snapshot remains for this PC session.");int changed=0,failed=0;json retry=json::array();for(const auto& entry:previousAudio)try{auto r=SetAudio(entry);changed+=r.value("changed",0);failed+=r.value("failed",0);if(r.value("failed",0))retry.push_back(entry);}catch(...){failed++;retry.push_back(entry);}previousAudio=retry;return {{"changed",changed},{"failed",failed}};}
inline json Control(const std::vector<Client>& clients,const json& request){const auto command=request.at("command").get<std::string>();if(command!="focus-main"&&command!="label")throw std::runtime_error("Unsupported client window action.");int changed=0,failed=0;auto main=request.value("mainUserId",0LL);if(command=="focus-main"&&main<=0)throw std::runtime_error("Choose the main account first.");for(const auto& c:clients){if(command=="label"&&(c.pid!=request.at("pid").get<DWORD>()||c.token!=request.at("token").get<std::string>()))continue;Handle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,c.pid));DWORD owner=0;GetWindowThreadProcessId(c.window,&owner);if(!process.value||!IsRoblox(process.value)||Token(process.value)!=c.token||WaitForSingleObject(process.value,0)!=WAIT_TIMEOUT||owner!=c.pid){failed++;continue;}
 if(command=="focus-main"){if(!c.userId)continue;if(c.userId==main){ShowWindow(c.window,SW_RESTORE);if(!SetForegroundWindow(c.window))failed++;else changed++;}else{ShowWindow(c.window,SW_MINIMIZE);changed++;}}
 else{auto title=request.value("title",std::string());if(title.empty()||title.size()>120)throw std::runtime_error("Use a window label from 1 to 120 characters.");int n=MultiByteToWideChar(CP_UTF8,0,title.data(),(int)title.size(),nullptr,0);std::wstring w(n,0);MultiByteToWideChar(CP_UTF8,0,title.data(),(int)title.size(),w.data(),n);if(SetWindowTextW(c.window,w.c_str()))changed++;else failed++;}}
 return {{"changed",changed},{"failed",failed}};
}
inline json Apply(const std::vector<Client>& clients,const json& rules){
 auto main=rules.at("mainUserId").get<long long>();auto mainDisplay=rules.at("mainDisplay").get<std::string>(),otherDisplay=rules.at("otherDisplay").get<std::string>();
 if(main<=0||mainDisplay.empty()||otherDisplay.empty()||mainDisplay==otherDisplay)throw std::runtime_error("Choose a main account and two different displays.");
 auto monitors=WindowLayout::Monitors();const WindowLayout::Monitor *first=nullptr,*second=nullptr;for(const auto& m:monitors){if(m.id==mainDisplay)first=&m;if(m.id==otherDisplay)second=&m;}
 if(!first||!second)throw std::runtime_error("An assigned display is disconnected. Refresh displays.");
 std::vector<const Client*> others;std::vector<std::pair<const Client*,WindowLayout::Placement>> placements;
 for(const auto& c:clients){if(!c.userId)continue;if(c.userId==main)placements.push_back({&c,{std::to_string(c.userId),first->id,first->bounds,true}});else others.push_back(&c);}
 std::sort(others.begin(),others.end(),[](auto a,auto b){return a->userId<b->userId||(a->userId==b->userId&&a->pid<b->pid);});auto cells=WindowLayout::Grid(second->work,others.size());
 for(size_t i=0;i<others.size();i++)placements.push_back({others[i],{std::to_string(others[i]->userId),second->id,cells[i],false}});
 int moved=0,failed=0;for(const auto& [c,p]:placements){Handle process(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,c->pid));DWORD owner=0;GetWindowThreadProcessId(c->window,&owner);
  if(!process.value||WaitForSingleObject(process.value,0)!=WAIT_TIMEOUT||Token(process.value)!=c->token||!IsRoblox(process.value)||owner!=c->pid){failed++;continue;}
  if(WindowLayout::Place(c->window,p))moved++;else failed++;
 }
 return {{"moved",moved},{"failed",failed},{"unidentified",clients.size()-placements.size()}};
}
}
