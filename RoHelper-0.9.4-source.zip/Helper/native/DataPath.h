#pragma once
#include <windows.h>
#include <shlobj.h>
#include <filesystem>
#include <stdexcept>

// Production storage is independent of the executable and release archives.
// No legacy-directory detection, copying, or automatic account imports.
namespace HelperData {
inline std::filesystem::path Root(const std::filesystem::path& executableDirectory,bool testMode=false){
    if(testMode)return executableDirectory/L"helper-data"; // Isolated synthetic tests only.
    PWSTR value=nullptr;
    const HRESULT hr=SHGetKnownFolderPath(FOLDERID_LocalAppData,KF_FLAG_DEFAULT,nullptr,&value);
    if(FAILED(hr)||!value){CoTaskMemFree(value);throw std::runtime_error("Windows Local AppData is unavailable. RoHelper has not opened another data folder.");}
    const auto result=std::filesystem::path(value)/L"RoHelper";
    CoTaskMemFree(value);
    return result;
}
}
