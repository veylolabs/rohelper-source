#pragma once
#include "MacroRecording.h"
#include "Automation.h"
#include <deque>
#include <mutex>
#include <thread>
#include <atomic>

namespace MacroRecorder {
// Hooks live on a dedicated message-loop thread, never the WebView/UI thread.
// Callbacks queue bounded events and always pass input to the next hook.
struct Session;
inline Session* hooked=nullptr; // Accessed exclusively on the recorder thread.
inline LRESULT CALLBACK Keyboard(int,WPARAM,LPARAM);
inline LRESULT CALLBACK Mouse(int,WPARAM,LPARAM);
struct Raw {WPARAM message;DWORD vk=0;POINT point{};int width=0,height=0;ULONGLONG time=0;bool focused=false;};
struct Session {
 RosterClients::Client target;MacroRecording::Capture capture;std::thread worker;std::mutex mutex;
 HANDLE ready=nullptr;DWORD threadId=0;HHOOK keyboard=nullptr,mouse=nullptr;std::deque<Raw> queue;
 json state={{"running",false}},result;std::string startupError;bool overflow=false,systemKeys=false;std::atomic<bool> abortRequested{false};ULONGLONG started=0;
 explicit Session(const RosterClients::Client& client,const std::string& origin,bool drag):target(client),capture(origin,drag){ready=CreateEventW(nullptr,TRUE,FALSE,nullptr);if(!ready)throw std::runtime_error("Cannot start recorder.");worker=std::thread([this]{Run();});if(WaitForSingleObject(ready,5000)!=WAIT_OBJECT_0){abortRequested=true;PostThreadMessageW(threadId,WM_APP+12,0,0);worker.join();CloseHandle(ready);ready=nullptr;throw std::runtime_error("Recorder did not start.");}CloseHandle(ready);ready=nullptr;if(!startupError.empty()){worker.join();throw std::runtime_error(startupError);}}
 ~Session(){Stop();}
 bool Foreground()const{const auto window=GetForegroundWindow();return window==target.window||IsChild(target.window,window);}
 void Publish(){std::lock_guard<std::mutex> lock(mutex);state={{"running",!capture.ended},{"focused",capture.focused},{"blocks",capture.rows.size()},{"elapsed",(GetTickCount64()-started)/1000},{"origin",capture.origin},{"skipped",capture.skipped},{"note",capture.note}};}
 void Enqueue(Raw input){if(queue.size()>=2048){overflow=true;return;}queue.push_back(input);if(queue.size()==1)PostThreadMessageW(threadId,WM_APP+10,0,0);}
 static std::string KeyName(DWORD key){if(key>=VK_LSHIFT&&key<=VK_RSHIFT)return "SHIFT";if(key==VK_LCONTROL||key==VK_RCONTROL)return "CTRL";if(key==VK_LMENU||key==VK_RMENU)return "ALT";if((key>='A'&&key<='Z')||(key>='0'&&key<='9'))return std::string(1,(char)key);for(auto name:{"SPACE","ENTER","ESCAPE","TAB","SHIFT","CTRL","ALT","UP","DOWN","LEFT","RIGHT","BACKSPACE","DELETE","HOME","END","PAGEUP","PAGEDOWN","INSERT"})if(MacroVM::Key(name)==key)return name;for(int i=1;i<=24;i++)if(key==VK_F1+i-1)return "F"+std::to_string(i);return "";}
 void Process(){while(!queue.empty()&&!capture.ended){auto e=queue.front();queue.pop_front();capture.Focus(e.focused,e.time);if(!e.focused)continue;
  if(e.vk){auto key=KeyName(e.vk);if(key.empty()){capture.skipped++;continue;}capture.Key(key,e.message==WM_KEYDOWN||e.message==WM_SYSKEYDOWN,e.time);}
  else if(e.message==WM_MOUSEMOVE)capture.Move(e.point,e.width,e.height,e.time);
  else if(e.message==WM_LBUTTONDOWN||e.message==WM_LBUTTONUP||e.message==WM_RBUTTONDOWN||e.message==WM_RBUTTONUP)capture.Mouse(e.message==WM_LBUTTONDOWN||e.message==WM_LBUTTONUP?"left":"right",e.message==WM_LBUTTONDOWN||e.message==WM_RBUTTONDOWN,e.point,e.width,e.height,e.time);
  else capture.skipped++;
 }Publish();}
 void Run(){threadId=GetCurrentThreadId();MSG message;PeekMessageW(&message,nullptr,WM_USER,WM_USER,PM_NOREMOVE);started=GetTickCount64();capture.doubleSeconds=GetDoubleClickTime()/1000.0;hooked=this;
  keyboard=SetWindowsHookExW(WH_KEYBOARD_LL,Keyboard,GetModuleHandleW(nullptr),0);mouse=SetWindowsHookExW(WH_MOUSE_LL,Mouse,GetModuleHandleW(nullptr),0);
  if(!keyboard||!mouse){startupError="Windows could not start input recording.";if(keyboard)UnhookWindowsHookEx(keyboard);if(mouse)UnhookWindowsHookEx(mouse);hooked=nullptr;SetEvent(ready);return;}
  auto timer=SetTimer(nullptr,0,50,nullptr);if(!timer){startupError="Windows could not start the recorder timer.";UnhookWindowsHookEx(keyboard);UnhookWindowsHookEx(mouse);hooked=nullptr;SetEvent(ready);return;}Publish();SetEvent(ready);ULONGLONG checked=0;
  try{while(!capture.ended&&!abortRequested&&GetMessageW(&message,nullptr,0,0)>0){if(message.message==WM_APP+12){Process();capture.Finish(GetTickCount64());break;}if(message.message==WM_APP+10)Process();if(message.message==WM_TIMER){const auto now=GetTickCount64();Process();capture.Focus(Foreground()&&!systemKeys,now);if(overflow)capture.Finish(now,"Input recording stopped because its event buffer filled.");if(now-started>=300000)capture.Finish(now,"The five-minute recording limit was reached.");if(now>=checked+250){checked=now;if(!Automation::Valid(target))capture.Finish(now,"The selected Roblox client closed.");}Publish();}}
   Process();capture.Finish(GetTickCount64());auto macro=capture.Macro();{std::lock_guard<std::mutex> lock(mutex);result={{"macro",macro},{"note",capture.note},{"skipped",capture.skipped}};}
  }catch(const std::exception& e){capture.ended=true;capture.note=std::string("Recording stopped: ")+e.what();}
  KillTimer(nullptr,timer);UnhookWindowsHookEx(keyboard);UnhookWindowsHookEx(mouse);hooked=nullptr;Publish();
 }
 void Stop(){if(worker.joinable()){abortRequested=true;PostThreadMessageW(threadId,WM_APP+12,0,0);worker.join();}}
 json Status(){std::lock_guard<std::mutex> lock(mutex);return state;}
 json Result(){Stop();std::lock_guard<std::mutex> lock(mutex);if(result.is_null())throw std::runtime_error(capture.note.empty()?"No recording is available.":capture.note);return result;}
};
inline LRESULT CALLBACK Keyboard(int code,WPARAM message,LPARAM data){if(code==HC_ACTION&&hooked){const auto* e=reinterpret_cast<KBDLLHOOKSTRUCT*>(data);if(!(e->flags&LLKHF_INJECTED)){if(e->vkCode==VK_F8&&(message==WM_KEYDOWN||message==WM_SYSKEYDOWN))PostThreadMessageW(hooked->threadId,WM_APP+12,0,0);else if(e->vkCode!=VK_F8){const bool down=message==WM_KEYDOWN||message==WM_SYSKEYDOWN;
 if(e->vkCode==VK_LWIN||e->vkCode==VK_RWIN){hooked->systemKeys=down;Raw focus{};focus.time=GetTickCount64();hooked->Enqueue(focus);return CallNextHookEx(nullptr,code,message,data);}
 if(down&&(e->flags&LLKHF_ALTDOWN)&&(e->vkCode==VK_TAB||e->vkCode==VK_ESCAPE)){hooked->systemKeys=true;Raw focus{};focus.time=GetTickCount64();hooked->Enqueue(focus);return CallNextHookEx(nullptr,code,message,data);}
 if(hooked->systemKeys){if(!down&&(e->vkCode==VK_MENU||e->vkCode==VK_LMENU||e->vkCode==VK_RMENU))hooked->systemKeys=false;return CallNextHookEx(nullptr,code,message,data);}
 Raw r{};r.message=message;r.vk=e->vkCode;r.time=GetTickCount64();r.focused=hooked->Foreground();if(hooked->systemKeys){r.focused=false;}if(!r.focused){r.vk=0;r.message=0;}hooked->Enqueue(r);}}}return CallNextHookEx(nullptr,code,message,data);}
inline LRESULT CALLBACK Mouse(int code,WPARAM message,LPARAM data){if(code==HC_ACTION&&hooked){const auto* e=reinterpret_cast<MSLLHOOKSTRUCT*>(data);if(!(e->flags&LLMHF_INJECTED)){Raw r{};r.message=message;r.point=e->pt;r.time=GetTickCount64();r.focused=hooked->Foreground()&&!hooked->systemKeys;RECT area{};if(r.focused&&GetClientRect(hooked->target.window,&area)&&ScreenToClient(hooked->target.window,&r.point)){r.width=area.right;r.height=area.bottom;}else r.focused=false;if(!r.focused){r.message=0;r.point={};}hooked->Enqueue(r);}}return CallNextHookEx(nullptr,code,message,data);}
inline std::unique_ptr<Session> session;
inline void Cancel(){session.reset();}
inline json Status(){return session?session->Status():json{{"running",false}};}
inline bool Running(){return Status().value("running",false);}
inline json Stop(){if(!session)throw std::runtime_error("No macro recording is available.");auto result=session->Result();session.reset();return result;}
inline json Start(const RosterClients::Client& client,const std::string& origin,bool drag){if(Running())throw std::runtime_error("A macro recording is already running.");if(!Automation::Valid(client))throw std::runtime_error("The selected Roblox client has closed.");session.reset();session=std::make_unique<Session>(client,origin,drag);if(IsIconic(client.window))ShowWindow(client.window,SW_RESTORE);SetForegroundWindow(client.window);return session->Status();}
}
