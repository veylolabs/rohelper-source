#pragma once
#include <atomic>
#include <thread>

namespace AutomationActivity {
// Only a timestamp is retained. No key names, text, coordinates or events are stored.
inline constexpr ULONG_PTR inputTag = 0x52484146;
inline std::atomic<ULONGLONG> lastActivity{0};
inline void Observe(bool injected, ULONG_PTR tag, ULONGLONG now) {
    if (!injected || tag != inputTag) lastActivity = now;
}
inline LRESULT CALLBACK Keyboard(int code, WPARAM message, LPARAM data) {
    if (code == HC_ACTION) {
        const auto& e = *reinterpret_cast<KBDLLHOOKSTRUCT*>(data);
        Observe((e.flags & LLKHF_INJECTED) != 0, e.dwExtraInfo, GetTickCount64());
    }
    return CallNextHookEx(nullptr, code, message, data);
}
inline LRESULT CALLBACK Mouse(int code, WPARAM message, LPARAM data) {
    if (code == HC_ACTION) {
        const auto& e = *reinterpret_cast<MSLLHOOKSTRUCT*>(data);
        Observe((e.flags & LLMHF_INJECTED) != 0, e.dwExtraInfo, GetTickCount64());
    }
    return CallNextHookEx(nullptr, code, message, data);
}
class Monitor {
    HANDLE ready = nullptr;
    std::thread thread;
    std::atomic<bool> stopping{false}, available{false};
    void Run() {
        MSG message{};
        PeekMessageW(&message, nullptr, WM_USER, WM_USER, PM_NOREMOVE);
        LASTINPUTINFO info{sizeof(info)};
        const auto now = GetTickCount64();
        lastActivity = GetLastInputInfo(&info) ? now - std::min<ULONGLONG>(now, DWORD(GetTickCount() - info.dwTime)) : now;
        const auto keyboard = SetWindowsHookExW(WH_KEYBOARD_LL, Keyboard, GetModuleHandleW(nullptr), 0);
        const auto mouse = SetWindowsHookExW(WH_MOUSE_LL, Mouse, GetModuleHandleW(nullptr), 0);
        const auto timer = SetTimer(nullptr, 0, 100, nullptr);
        available = keyboard && mouse && timer;
        SetEvent(ready);
        while (available && !stopping && GetMessageW(&message, nullptr, 0, 0) > 0) {
            TranslateMessage(&message);
            DispatchMessageW(&message);
        }
        available = false;
        if (timer) KillTimer(nullptr, timer);
        if (keyboard) UnhookWindowsHookEx(keyboard);
        if (mouse) UnhookWindowsHookEx(mouse);
    }
public:
    Monitor() {
        ready = CreateEventW(nullptr, TRUE, FALSE, nullptr);
        if (!ready) throw std::runtime_error("Cannot monitor input activity.");
        try { thread = std::thread([this] { Run(); }); }
        catch (...) { CloseHandle(ready); throw; }
        if (WaitForSingleObject(ready, 5000) != WAIT_OBJECT_0 || !available) {
            stopping = true;
            thread.join();
            CloseHandle(ready);
            throw std::runtime_error("Windows could not monitor input activity. Anti-AFK was not started.");
        }
        CloseHandle(ready);
        ready = nullptr;
    }
    ~Monitor() { stopping = true; if (thread.joinable()) thread.join(); }
    bool Quiet() const { return available && GetTickCount64() - lastActivity.load() >= 3000; }
};
inline std::unique_ptr<Monitor> monitor;
}

struct WindowsAutomationPlatform {
    static ULONGLONG Now() { return GetTickCount64(); }
    static void Begin(bool pause) { if (pause && !AutomationActivity::monitor) AutomationActivity::monitor = std::make_unique<AutomationActivity::Monitor>(); }
    static void End() { AutomationActivity::monitor.reset(); }
    static bool Quiet() { return AutomationActivity::monitor && AutomationActivity::monitor->Quiet(); }
    static bool Valid(const RosterClients::Client& c) {
        RosterClients::Handle p(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | SYNCHRONIZE, FALSE, c.pid));
        DWORD pid = 0;
        GetWindowThreadProcessId(c.window, &pid);
        return p.value && pid == c.pid && RosterClients::IsRoblox(p.value) && RosterClients::Token(p.value) == c.token && WaitForSingleObject(p.value, 0) == WAIT_TIMEOUT;
    }
    static HWND Foreground() { return GetForegroundWindow(); }
    static bool Window(HWND h) { return IsWindow(h); }
    static void Focus(HWND h) {
        if (IsHungAppWindow(h)) return;
        if (IsIconic(h)) ShowWindowAsync(h, SW_RESTORE);
        SetForegroundWindow(h);
        if (GetForegroundWindow() == h) return;
        // Share foreground permission briefly; never send an ALT keystroke or
        // change the system foreground-lock setting. No macro input is held here.
        const auto foreground = GetForegroundWindow();
        if (!foreground || IsHungAppWindow(foreground)) return;
        const auto current = GetCurrentThreadId();
        const auto other = GetWindowThreadProcessId(foreground, nullptr);
        if (other && other != current && AttachThreadInput(current, other, TRUE)) {
            SetForegroundWindow(h);
            AttachThreadInput(current, other, FALSE);
        }
    }
    static UINT Send(UINT count, INPUT* inputs) {
        for (UINT i = 0; i < count; ++i) {
            if (inputs[i].type == INPUT_KEYBOARD) inputs[i].ki.dwExtraInfo = AutomationActivity::inputTag;
            if (inputs[i].type == INPUT_MOUSE) inputs[i].mi.dwExtraInfo = AutomationActivity::inputTag;
        }
        return SendInput(count, inputs, sizeof(INPUT));
    }
};
