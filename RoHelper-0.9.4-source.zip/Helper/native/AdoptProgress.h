#pragma once
#include "json.hpp"
#include <set>
#include <regex>
#include <cmath>
#include <stdexcept>
namespace AdoptProgress {
using json=nlohmann::json;
inline void Validate(const json& s,std::set<std::string>* global=nullptr){
 if(!s.is_object())throw std::runtime_error("Invalid Adopt Me progress.");
 if(s.contains("money")){if(!s["money"].is_object()||s["money"].size()>64)throw std::runtime_error("Invalid Adopt Me balances.");for(auto& v:s["money"].items())if(!std::regex_match(v.key(),std::regex("[a-z0-9-]{1,80}"))||!v.value().is_number()||!std::isfinite(v.value().get<double>())||v.value()<0||v.value()>1000000000000.0)throw std::runtime_error("Invalid Adopt Me balance.");}
 if(!s.contains("inventories"))return;auto& all=s["inventories"];if(!all.is_object()||all.size()>64)throw std::runtime_error("Invalid Adopt Me inventory categories.");std::set<std::string> local;size_t count=0;
 for(auto& group:all.items()){
  if(!std::regex_match(group.key(),std::regex("[a-z0-9-]{1,80}"))||!group.value().is_array())throw std::runtime_error("Invalid Adopt Me inventory.");
  for(auto& item:group.value()){
   if(++count>10000||!item.is_object())throw std::runtime_error("Too many Adopt Me items.");
   for(auto key:{"id","itemId"})if(!item.contains(key)||!item[key].is_string()||item[key].get<std::string>().empty()||item[key].get<std::string>().size()>120)throw std::runtime_error("Invalid Adopt Me item ID.");
   auto id=item["id"].get<std::string>();if(!local.insert(id).second||(global&&!global->insert(id).second))throw std::runtime_error("Duplicate Adopt Me item copy.");
   for(auto key:{"quantity","friendshipLevel","stageTasks","friendshipTasks","stage"})if(item.contains(key)&&(!item[key].is_number_integer()||item[key]<0||item[key]>1000000000LL))throw std::runtime_error("Invalid Adopt Me pet progress.");
   if(item.value("quantity",1)<1||item.value("quantity",1)>1000000)throw std::runtime_error("Invalid Adopt Me quantity.");
   for(auto key:{"ride","fly","favorite"})if(item.contains(key)&&!item[key].is_boolean())throw std::runtime_error("Invalid Adopt Me pet ability.");
   for(auto key:{"notes","nickname"})if(item.contains(key)&&(!item[key].is_string()||item[key].get<std::string>().size()>(std::string(key)=="notes"?8000:160)))throw std::runtime_error("Invalid Adopt Me item notes.");
   if(item.contains("variant")&&item["variant"]!="normal"&&item["variant"]!="neon"&&item["variant"]!="mega")throw std::runtime_error("Invalid Adopt Me variant.");
   if(item.contains("stage")&&item["stage"]>5)throw std::runtime_error("Invalid Adopt Me growth stage.");
   if(item.contains("paidEur")&&(!item["paidEur"].is_number()||!std::isfinite(item["paidEur"].get<double>())||item["paidEur"]<0||item["paidEur"]>1000000000))throw std::runtime_error("Invalid Adopt Me price note.");
   // Unknown/retired catalog IDs and future category fields remain lossless.
  }
 }
}
}
