#pragma once
#include "json.hpp"
#include <regex>
#include <set>
namespace HelperEventContent {
using json=nlohmann::json;
inline bool Id(const std::string& s){return std::regex_match(s,std::regex("[A-Za-z0-9_-]{1,100}"))&&s!="__proto__"&&s!="constructor"&&s!="prototype";}
inline void Text(const json& e,const char* k,size_t n,bool optional=true){if(!e.contains(k)){if(optional)return;throw std::runtime_error("Missing event text.");}if(!e[k].is_string()||e[k].get<std::string>().size()>n)throw std::runtime_error("Invalid event text.");}
inline void Fields(const json& e,bool partial=false,bool shared=false){
 if(!e.is_object())throw std::runtime_error("Invalid event record.");
 for(auto k:{"title","group","notes","zone","start","repeat","icon","color","packId"})if(e.contains(k)&&!(shared&&e[k].is_null()))Text(e,k,std::string(k)=="notes"?1200:std::string(k)=="title"?160:100);
 if(!partial){Text(e,"id",100,false);Text(e,"title",160,false);if(!Id(e["id"])||e["title"].get<std::string>().empty())throw std::runtime_error("Invalid event ID or name.");}
 for(auto k:{"enabled","estimatedEnd","scheduleConfirmed","remindStart","remindEnd"})if(e.contains(k)&&!e[k].is_boolean())throw std::runtime_error("Invalid event toggle.");
 if(e.contains("repeat")&&!std::set<std::string>{"once","daily","weekly","monthly","yearly"}.count(e["repeat"].get<std::string>()))throw std::runtime_error("Invalid event recurrence.");
 if(e.contains("start")&&!e["start"].is_null()&&!std::regex_match(e["start"].get<std::string>(),std::regex("[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}")))throw std::runtime_error("Invalid event start.");
 for(auto k:{"duration","reminderMinutes"})if(e.contains(k)&&!(shared&&e[k].is_null())){int limit=std::string(k)=="duration"?10080:1440;if(!e[k].is_number_integer()||e[k]<1||e[k]>limit)throw std::runtime_error("Invalid event duration or reminder lead.");}
 if(e.contains("color")&&!std::regex_match(e["color"].get<std::string>(),std::regex("#[0-9a-fA-F]{6}")))throw std::runtime_error("Invalid event color.");
 if(e.contains("skipped")){if(!e["skipped"].is_array()||e["skipped"].size()>1000)throw std::runtime_error("Invalid skipped event occurrences.");for(auto& v:e["skipped"])if(!v.is_number_integer()||v<0||v>8000000000000LL)throw std::runtime_error("Invalid skipped occurrence.");}
 for(auto k:{"dateStart","dateEnd"})if(e.contains(k)&&!e[k].is_null()&&(!e[k].is_string()||!std::regex_match(e[k].get<std::string>(),std::regex("[0-9]{4}-[0-9]{2}-[0-9]{2}"))))throw std::runtime_error("Invalid reference event date.");
 if(!partial&&e.value("scheduleConfirmed",false)){if(!e.contains("start")||!e["start"].is_string()||!e.contains("duration")||!e["duration"].is_number_integer()||!e.contains("zone")||e["zone"].get<std::string>().empty())throw std::runtime_error("A confirmed event needs start, duration and time zone.");}
 if(e.contains("source")&&(!e["source"].is_string()||e["source"].get<std::string>().size()>2000||e["source"].get<std::string>().rfind("https://",0)!=0))throw std::runtime_error("Event sources require HTTPS.");
}
inline void Tracker(const json& workspace){if(!workspace.contains("eventTracker"))return;auto& t=workspace["eventTracker"];if(!t.is_object()||t.dump().size()>4*1024*1024)throw std::runtime_error("Invalid personal event data.");std::set<std::string> ids;
 if(t.contains("custom")){if(!t["custom"].is_array()||t["custom"].size()>2000)throw std::runtime_error("Too many personal events.");for(auto& e:t["custom"]){Fields(e);if(!ids.insert(e["id"].get<std::string>()).second||e["id"].get<std::string>().rfind("shared-",0)==0)throw std::runtime_error("Duplicate or reserved personal event ID.");}}
 if(t.contains("hidden")){if(!t["hidden"].is_array()||t["hidden"].size()>3000)throw std::runtime_error("Invalid hidden events.");for(auto& id:t["hidden"])if(!id.is_string()||id.get<std::string>().size()>220)throw std::runtime_error("Invalid hidden event ID.");}
 if(t.contains("overrides")){if(!t["overrides"].is_object()||t["overrides"].size()>3000)throw std::runtime_error("Invalid event overrides.");const std::set<std::string> allowed={"title","group","start","zone","duration","repeat","icon","color","notes","enabled","estimatedEnd","scheduleConfirmed","remindStart","remindEnd","reminderMinutes","skipped"};for(auto& entry:t["overrides"].items()){if(entry.key().rfind("shared-",0)!=0||entry.key().size()>220||!entry.value().is_object())throw std::runtime_error("Invalid shared event override.");for(auto& f:entry.value().items())if(!allowed.count(f.key()))throw std::runtime_error("Unsupported personal event override.");Fields(entry.value(),true);}}
}
inline void Tabs(const json& tabs,std::set<std::string>& ids,int depth=0){if(!tabs.is_array()||tabs.size()>128||depth>4)throw std::runtime_error("Invalid game tab layout.");for(auto& t:tabs){Text(t,"id",100,false);Text(t,"name",160,false);if(!Id(t["id"])||!ids.insert(t["id"].get<std::string>()).second)throw std::runtime_error("Duplicate or invalid game tab.");Text(t,"icon",60);if(t.contains("children")){if(t.contains("view"))throw std::runtime_error("A game tab group cannot also be a view.");Tabs(t["children"],ids,depth+1);}else{Text(t,"view",80,false);if(!Id(t["view"]))throw std::runtime_error("Invalid game view type.");Text(t,"catalog",100);Text(t,"helper",100);}Text(t,"description",1200);}}
inline void Pack(const json& p){for(auto key:{"navigation","accountTabs"})if(p.contains(key)){std::set<std::string> ids;Tabs(p[key],ids);}
 if(p.contains("events")){if(!p["events"].is_array()||p["events"].size()>2000)throw std::runtime_error("Too many shared events.");std::set<std::string> ids;for(auto& e:p["events"]){Fields(e,false,true);if(!ids.insert(e["id"]).second)throw std::runtime_error("Duplicate shared event ID.");}}
 if(p.contains("helpers")){if(!p["helpers"].is_array()||p["helpers"].size()>128)throw std::runtime_error("Invalid event helpers.");std::set<std::string> ids;for(auto& h:p["helpers"]){for(auto key:{"id","name","type","catalog"})Text(h,key,160,false);if(!Id(h["id"])||!ids.insert(h["id"]).second||!std::set<std::string>{"rewards","fuse","islands","collection","crafting"}.count(h["type"].get<std::string>())||!p["catalogs"].contains(h["catalog"]))throw std::runtime_error("Invalid event helper type or catalog.");}}
}
}
