#pragma once
#include <cstdlib>
#include <cmath>
#include "MouseMacro.h"
extern "C" {
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
}
struct MacroAction{std::string kind,key;double seconds=0;std::string button,origin;int x=0,y=0;};
struct MacroVM {
 lua_State* state=nullptr;lua_State* thread=nullptr;size_t memory=0;int instructions=0;MacroAction next;bool emitted=false,done=false;
 static void* Allocate(void* ud,void* ptr,size_t old,size_t size){auto self=(MacroVM*)ud;if(!ptr)old=0;if(!size){self->memory-=old;free(ptr);return nullptr;}if(self->memory-old+size>4*1024*1024)return nullptr;auto p=realloc(ptr,size);if(p)self->memory=self->memory-old+size;return p;}
 static WORD Key(const std::string& s){if(s.size()==1&&((s[0]>='A'&&s[0]<='Z')||(s[0]>='0'&&s[0]<='9')))return (WORD)s[0];static const std::map<std::string,WORD> keys={{"SPACE",VK_SPACE},{"ENTER",VK_RETURN},{"ESCAPE",VK_ESCAPE},{"TAB",VK_TAB},{"SHIFT",VK_SHIFT},{"CTRL",VK_CONTROL},{"ALT",VK_MENU},{"UP",VK_UP},{"DOWN",VK_DOWN},{"LEFT",VK_LEFT},{"RIGHT",VK_RIGHT},{"BACKSPACE",VK_BACK},{"DELETE",VK_DELETE},{"HOME",VK_HOME},{"END",VK_END},{"PAGEUP",VK_PRIOR},{"PAGEDOWN",VK_NEXT},{"INSERT",VK_INSERT}};auto it=keys.find(s);if(it!=keys.end())return it->second;if(s.size()>=2&&s[0]=='F'){try{int n=std::stoi(s.substr(1));if(n>=1&&n<=24&&s=="F"+std::to_string(n))return VK_F1+n-1;}catch(...){}}return 0;}
 static void Hook(lua_State* l,lua_Debug*){auto self=*(MacroVM**)lua_getextraspace(l);self->instructions+=1000;if(self->instructions>50000)luaL_error(l,"Macro exceeded its instruction budget; add wait() inside long loops.");}
 static int Emit(lua_State* l){auto self=*(MacroVM**)lua_getextraspace(l);const char* kind=luaL_checkstring(l,1);if(!strcmp(kind,"mouse_move")){
 const char* origin=luaL_checkstring(l,2);const auto x=luaL_checkinteger(l,3),y=luaL_checkinteger(l,4);if(x < -100000 || x > 100000 || y < -100000 || y > 100000)return luaL_error(l,"Invalid mouse offsets.");char error[512]={};try{MouseMacro::Validate("left",origin,(int)x,(int)y);}catch(const std::exception& e){strncpy_s(error,e.what(),sizeof(error)-1);}if(error[0])return luaL_error(l,"%s",error);self->next={"mouse_move","",0,"",origin,(int)x,(int)y};
 }else if(!strcmp(kind,"mouse_release")){self->next={"mouse_release","",0};}else if(!strcmp(kind,"mouse_click")||!strcmp(kind,"mouse_hold")){
 const char* button=luaL_checkstring(l,2);const char* origin=luaL_checkstring(l,3);const auto x=luaL_checkinteger(l,4),y=luaL_checkinteger(l,5);
 if(x < -100000 || x > 100000 || y < -100000 || y > 100000)return luaL_error(l,"Mouse offsets must be within 100,000 pixels.");
 char error[512]={};try{MouseMacro::Validate(button,origin,(int)x,(int)y,!strcmp(kind,"mouse_hold"));}catch(const std::exception& e){strncpy_s(error,e.what(),sizeof(error)-1);}if(error[0])return luaL_error(l,"%s",error);
 self->next={!strcmp(button,"double")?"mouse_double":kind,"",0,!strcmp(button,"double")?"left":button,origin,(int)x,(int)y};
 }else if(!strcmp(kind,"wait")){double s=luaL_checknumber(l,2);if(!std::isfinite(s)||s<0.02||s>3600)return luaL_error(l,"Wait must be 0.02–3600 seconds.");self->next={"wait","",s};}else {const char* key=luaL_checkstring(l,2);if(!Key(key))return luaL_error(l,"Unknown key; use uppercase names such as W, SPACE, CTRL or F1.");self->next={kind,key,0};}self->emitted=true;return lua_yield(l,0);}
 explicit MacroVM(const std::string& code){state=lua_newstate(Allocate,this);if(!state)throw std::runtime_error("Could not start Lua.");*(MacroVM**)lua_getextraspace(state)=this;luaL_requiref(state,"_G",luaopen_base,1);lua_pop(state,1);luaL_requiref(state,"math",luaopen_math,1);lua_pop(state,1);luaL_requiref(state,"string",luaopen_string,1);lua_pop(state,1);luaL_requiref(state,"table",luaopen_table,1);lua_pop(state,1);for(auto name:{"dofile","loadfile","load","collectgarbage","print"}){lua_pushnil(state);lua_setglobal(state,name);}lua_pushcfunction(state,Emit);lua_setglobal(state,"__emit");thread=lua_newthread(state);*(MacroVM**)lua_getextraspace(thread)=this;lua_sethook(thread,Hook,LUA_MASKCOUNT,1000);
 const std::string prelude="local emit=__emit; __emit=nil\nfunction wait(seconds) emit('wait',seconds) end\nfunction key_down(key) emit('down',key) end\nfunction key_up(key) emit('up',key) end\nfunction hold(key,seconds) key_down(key);wait(seconds);key_up(key) end\nfunction press(key,seconds) hold(key,seconds or 0.15) end\nfunction wait_ms(ms) wait(ms/1000) end\nfunction click(button,origin,x,y) emit('mouse_click',button or 'left',origin or 'center',x or 0,y or 0) end\nfunction mouse_hold(button,origin,x,y) emit('mouse_hold',button or 'left',origin or 'center',x or 0,y or 0) end\nfunction mouse_move(origin,x,y) emit('mouse_move',origin or 'center',x or 0,y or 0) end\nfunction mouse_release(...) if select('#',...)~=0 then error('mouse_release() takes no arguments.') end; emit('mouse_release') end\n";
 if(luaL_loadbuffer(thread,(prelude+code).c_str(),prelude.size()+code.size(),"macro")!=LUA_OK){std::string error=lua_tostring(thread,-1);lua_close(state);state=nullptr;throw std::runtime_error(error);}}
 ~MacroVM(){if(state)lua_close(state);}MacroVM(const MacroVM&)=delete;MacroVM& operator=(const MacroVM&)=delete;
 bool Advance(){instructions=0;emitted=false;int n=0;int result=lua_resume(thread,nullptr,0,&n);if(result==LUA_OK){done=true;return false;}if(result!=LUA_YIELD||!emitted){auto text=lua_tostring(thread,-1);throw std::runtime_error(text?text:"Macro yielded incorrectly.");}return true;}
 static void Check(const std::string& code){MacroVM vm(code);}
};
