'use strict';
window.HelperAccountTransfer=(()=>{
 const stored=a=>a.hasStoredSession??a.hasSession;
 function exportSessions(initial){
  const accounts=db.accounts.filter(stored),chosen=new Set(initial?[initial]:accounts.map(a=>a.id));let query='';
  const m=modal('Export account cookies','Choose all or selected saved logins. Inventories, tags, settings and game progress are excluded.','Save session file',async()=>{
   const ids=accounts.filter(a=>chosen.has(a.id)).map(a=>a.id);if(!ids.length)throw Error('Select at least one account.');if(!ack.checked)throw Error('Confirm that the file contains login cookies.');const r=await action('session_export_file',{accounts:ids,acknowledged:true});if(r.saved){m.close();toast(r.count+' account sessions exported.');}
  }),search=input('Search export accounts'),list=node('div',undefined,'session-transfer-list'),summary=node('p','','help-text'),ack=input('I understand this file contains login cookies','','checkbox');
  search.placeholder='Search accounts…';search.autocomplete='off';
  const controls=node('div',undefined,'row wrap');controls.append(button('Select all',()=>{accounts.forEach(a=>chosen.add(a.id));draw();},'ghost'),button('Clear selection',()=>{chosen.clear();draw();},'ghost'),summary);
  const consent=node('label',undefined,'check-label session-transfer-consent');consent.append(ack,node('span','I understand this unencrypted file can be used to sign in to the selected accounts. Keep it private.'));
  m.body.append(search,controls,list,consent);search.oninput=()=>{query=search.value.toLowerCase();draw();};ack.onchange=sync;
  function sync(){summary.textContent=chosen.size+' of '+accounts.length+' selected';$('#modal-save').disabled=!chosen.size||!ack.checked;}
  function draw(){list.replaceChildren();for(const a of accounts.filter(a=>[a.username,a.displayName,a.nickname,String(a.userId)].some(v=>String(v||'').toLowerCase().includes(query)))){
   const row=node('label',undefined,'session-transfer-account'),toggle=input('Export @'+a.username,'','checkbox'),copy=node('span',undefined,'session-transfer-copy');toggle.checked=chosen.has(a.id);toggle.onchange=()=>{toggle.checked?chosen.add(a.id):chosen.delete(a.id);sync();};copy.append(node('strong',a.nickname||a.displayName||a.username),node('small','@'+a.username+' · '+a.userId+(a.sessionExpired?' · Needs sign-in':'')));row.append(toggle,avatar(a),copy);list.append(row);
  }if(!list.children.length)list.append(node('p',accounts.length?'No matching accounts.':'No saved logins to export. Connect a login first.','muted'));sync();}
  draw();
 }
 function importSessions(){
  let phase='input',job='',preview=null,timer=null,polling=false,closed=false,replace=false,selected=new Set();
  const m=modal('Import account sessions','Choose an exported session file or paste one login cookie per line. Accounts are verified with Roblox before import.','Check sessions',async()=>{
   if(phase==='input'){const raw=text.value;text.value='';await begin(()=>action('session_import_text',{sessions:raw}));}
   else if(phase==='review'){
    const r=await action('session_import_apply',{job,selection:[...selected],replaceExisting:replace,expectedRevision:db.revision});job='';if(closed)return;phase='done';m.body.replaceChildren(node('p',r.message,'notice'),node('p','Existing inventories, tags and settings were preserved.','help-text'));$('#modal-save').hidden=true;$('#modal-cancel').textContent='Done';await reloadSoon();
   }
  }),text=node('textarea',undefined,'session-transfer-input'),fileButton=button('Choose session file',()=>begin(()=>action('session_import_file')),'ghost','folder');
  const dialog=$('#modal');text.rows=7;text.spellcheck=false;text.autocomplete='off';text.maxLength=16*1024*1024;text.setAttribute('aria-label','Session cookies');text.placeholder='One .ROBLOSECURITY session per line';
  m.body.append(node('p','Files stay local. Only the supplied sessions are sent to Roblox to verify their account identities.','help-text'),fileButton,label('Or paste session cookies',text),node('p','Duplicates are matched by Roblox account ID, even when names or session cookies differ. Existing saved logins are kept by default.','help-text'));
  dialog.addEventListener('close',()=>{closed=true;clearInterval(timer);text.value='';if(job)rpc('session_import_cancel',{job}).catch(()=>{});},{once:true});
  async function begin(request){if(phase!=='input'||closed)return;phase='starting';fileButton.disabled=true;$('#modal-save').disabled=true;try{
   const r=await request();if(r.cancelled){phase='input';return;}job=r.preview.job;if(closed){await rpc('session_import_cancel',{job});return;}text.value='';phase='checking';preview=r.preview;paintProgress();if(phase==='checking')timer=setInterval(poll,600);
  }catch(e){if(!closed)$('#modal-error').textContent=e.message;phase='input';}finally{if(!closed){fileButton.disabled=false;if(phase==='input')$('#modal-save').disabled=false;}}}
  function paintProgress(){m.body.replaceChildren(node('h3','Checking account sessions'),node('p',preview.completed+' of '+preview.total+' checked','notice'),node('p','No accounts are added until you review and confirm the results. Closing this dialog cancels the check.','help-text'));$('#modal-save').hidden=true;if(preview.done)showReview();}
  async function poll(){if(polling||closed||phase!=='checking')return;polling=true;try{const r=await rpc('session_import_status',{job});if(closed)return;preview=r.preview;paintProgress();}catch(e){if(!closed){clearInterval(timer);m.body.replaceChildren(node('p',e.message,'notice'));$('#modal-save').hidden=true;phase='error';}}finally{polling=false;}}
  function eligible(row){return row.status==='ready'&&(!row.hasStoredSession||replace);}
  function showReview(){clearInterval(timer);phase='review';selected=new Set(preview.rows.filter(r=>r.status==='ready'&&!r.hasStoredSession).map(r=>r.number));const counts={ready:0,duplicate:0,invalid:0,unavailable:0};for(const row of preview.rows)counts[row.status]=(counts[row.status]||0)+1;
   m.body.replaceChildren(node('p',counts.ready+' verified · '+counts.duplicate+' duplicates · '+counts.invalid+' invalid/expired · '+counts.unavailable+' unavailable','notice'));
   const replaceToggle=check('Allow replacement of saved logins for selected existing accounts',replace,v=>{replace=v;for(const row of preview.rows)if(!eligible(row))selected.delete(row.number);draw();}),controls=node('div',undefined,'row wrap'),summary=node('span','','help-text'),list=node('div',undefined,'session-transfer-list');controls.append(button('Select all eligible',()=>{selected=new Set(preview.rows.filter(eligible).map(r=>r.number));draw();},'ghost'),button('Clear selection',()=>{selected.clear();draw();},'ghost'),summary);m.body.append(replaceToggle,controls,list);$('#modal-save').hidden=false;$('#modal-save').textContent='Import selected accounts';
   function draw(){list.replaceChildren();for(const row of preview.rows){const box=node('label',undefined,'session-transfer-account '+(row.status==='ready'?'':'session-transfer-muted')),toggle=input('Import row '+row.number,'','checkbox'),copy=node('span',undefined,'session-transfer-copy');toggle.disabled=!eligible(row);toggle.checked=selected.has(row.number);toggle.onchange=()=>{toggle.checked?selected.add(row.number):selected.delete(row.number);sync();};copy.append(node('strong',row.username?'@'+row.username:'Entry '+row.number),node('small',row.userId?String(row.userId)+' · '+row.message:row.message));box.append(toggle,copy,node('span',row.status==='ready'?(row.hasStoredSession?'Existing login':row.existing?'Connect':'New'):row.status,'session-transfer-badge'));list.append(box);}sync();}
   function sync(){summary.textContent=selected.size+' selected';$('#modal-save').disabled=!selected.size;}draw();
  }
 }
 return {exportSessions,importSessions};
})();
