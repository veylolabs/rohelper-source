(function(root){
 function income(item,catalog){
  const entry=catalog.brainrots.find(r=>r.id===item.brainrotId),brainrot=entry?.duplicateOf?catalog.brainrots.find(r=>r.id===entry.duplicateOf):entry,mutation=catalog.mutations.find(m=>m.id===(item.mutation||'default'));
  if(!Number.isFinite(brainrot?.baseIncome)||!Number.isFinite(mutation?.multiplier))return null;
  let extra=0,factor=1;for(const id of new Set(item.traits||[])){const t=catalog.traits.find(t=>t.id===id);if(!Number.isFinite(t?.modifier))return null;if(t.effect==='multiplyTotal')factor*=t.modifier;else extra+=t.modifier;}
  return {base:brainrot.baseIncome,mutation:mutation.multiplier,traits:extra,factor,perSecond:Math.floor(brainrot.baseIncome*(mutation.multiplier+extra)*factor+1e-8)};
 }
 root.RosterIncome={calculate:income};if(typeof module!=='undefined')module.exports=root.RosterIncome;
})(typeof window==='undefined'?globalThis:window);
