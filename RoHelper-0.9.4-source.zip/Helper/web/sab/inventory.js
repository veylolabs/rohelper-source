// Ported from local RoRoster (GPL-3.0).
window.SabPortFactories.push(bridge=>{
const {db,$,node,button,iconButton,input,select,label,panel,heading,empty,icon,avatar,modal,changed,render,rpc,toast,uid,navigate,openAccount,catalog}=bridge; const fatal="";
window.RosterInventory=(()=>{
 let data=null,error='',query='',mutationFilter='',traitFilter='',accountFilter='',tradeFilter='',sortFilter='income-desc';
 const byId=new Map(),normalize=s=>String(s).toLowerCase().replace(/[^a-z0-9]/g,'');
 const mutationColor=id=>data?.mutations.find(m=>m.id===id)?.color||'var(--secondary)';
 function mutationSelect(title,value,filter=false,showIcons=false){
  const s=select(title,[...(filter?[['','All mutations']]:[]),...data.mutations.map(m=>[m.id,m.name])],value);
  for(const o of s.options){o.dataset.color=mutationColor(o.value);if(data.mutations.find(m=>m.id===o.value)?.rainbowText)o.dataset.rainbow='true';const image=data.mutations.find(m=>m.id===o.value)?.image;if(showIcons&&image)o.dataset.image=image;}
  return s;
 }
 const slots=a=>data?.slotsByRebirth[Math.min(a.sab.level,data.slotsByRebirth.length-1)]??10;
 const inventory=a=>a.sab.inventory||[];
 const mutationName=id=>id==='default'?'Normal':data?.mutations.find(m=>m.id===id)?.name||id||'Normal';
 const traitName=id=>data?.traits.find(t=>t.id===id)?.name||id;
 const cash=n=>'$'+new Intl.NumberFormat(undefined,{notation:n>=1e6?'compact':'standard',maximumFractionDigits:2}).format(n);
 function rate(item){const value=RosterIncome.calculate(item,data),n=node('strong',value?cash(value.perSecond)+'/s':'Income unavailable','inventory-income');n.title=value?'$'+value.perSecond.toLocaleString()+'/s = '+cash(value.base)+' × ('+value.mutation+' mutation + '+value.traits+' traits)'+(value.factor!==1?' × '+value.factor:'')+'. Before account/base boosts.':'No published base income or modifier for this entry.';return n;}
 function traitIcon(id,selectable=false){const t=data.traits.find(t=>t.id===id),n=selectable?button('',null,'trait-choice'):node('span',undefined,'trait-pill');n.title=t?.name||id;if(!selectable)n.tabIndex=0;n.setAttribute('aria-label',t?.name||id);if(t?.image){const im=node('img');im.src=t.image;im.alt='';im.loading='lazy';n.append(im);}else n.append(icon('star'));return n;}
 function freeSlot(a){for(let i=0;i<slots(a);i++)if(!inventory(a).some(x=>x.slot===i))return i;return -1;}
 let menu=null,menuScroll=[];
 function closeMenu(){menu?.remove();menu=null;}
 document.addEventListener('pointerdown',e=>{if(menu&&!menu.contains(e.target))closeMenu();},true);document.addEventListener('keydown',e=>{if(e.key==='Escape')closeMenu();});window.addEventListener('resize',closeMenu);document.addEventListener('scroll',()=>{if(menu&&menuScroll.some(([el,x,y])=>el.scrollLeft!==x||el.scrollTop!==y))closeMenu();},true);
 function duplicate(a,item){const target=freeSlot(a);const copyId=uid();if(target<0){toast('No free inventory slots on this account.');return;}RosterHistory.commit('duplicate brainrot',[a],()=>{a.sab.inventory=[...inventory(a),{...structuredClone(item),id:copyId,slot:target}];});RosterPolish.noteItems(a.id,[copyId]);toast('Duplicated into slot '+(target+1)+'.');}
 function remove(a,item){if(!inventory(a).some(x=>x.id===item.id))return;RosterHistory.commit('delete brainrot',[a],()=>{a.sab.inventory=inventory(a).filter(x=>x.id!==item.id);});toast('Brainrot deleted. Use Undo to restore it.');}
 function move(a,item){const m=modal('Move brainrot','Choose an account with an available slot.','Move brainrot',({close})=>{const target=db.accounts.find(x=>x.id===chosen);const current=inventory(a).find(x=>x.id===item.id);if(!current)throw Error('This item is no longer on the original account.');if(!target||target===a)throw Error('Choose another account.');const slot=freeSlot(target);if(slot<0)throw Error('That account has no free slots.');RosterHistory.commit('move brainrot',[a,target],()=>{a.sab.inventory=inventory(a).filter(x=>x.id!==item.id);target.sab.inventory=[...inventory(target),{...current,slot}];});close();render();RosterPolish.noteItems(target.id,[item.id]);toast('Moved to '+(target.nickname||target.username)+' · slot '+(slot+1)+'.');});let chosen='';const q=input('Search destination accounts'),list=node('div',undefined,'move-accounts');q.placeholder='Search account names or usernames…';function draw(){list.replaceChildren();for(const target of db.accounts.filter(x=>x!==a&&[x.username,x.displayName,x.nickname].join(' ').toLowerCase().includes(q.value.toLowerCase()))){const available=Array.from({length:slots(target)},(_,i)=>i).filter(i=>!inventory(target).some(x=>x.slot===i)).length,b=button('',()=>{chosen=target.id;draw();},'move-account');b.disabled=!available;b.setAttribute('aria-pressed',String(chosen===target.id));b.append(avatar(target),node('strong',target.nickname||target.displayName||target.username),node('small','@'+target.username+' · '+available+' free slots'));list.append(b);}if(!list.children.length)list.append(node('p','No matching destination accounts.','muted'));}q.oninput=draw;m.body.append(q,list);draw();}
 function context(a,item,anchor,event){event?.preventDefault();closeMenu();menuScroll=[];for(let el=anchor;el;el=el.parentElement)menuScroll.push([el,el.scrollLeft,el.scrollTop]);const scroller=document.scrollingElement;if(scroller)menuScroll.push([scroller,scroller.scrollLeft,scroller.scrollTop]);menu=node('div',undefined,'inventory-context');menu.setAttribute('role','menu');menu.setAttribute('aria-label','Brainrot actions');menu.setAttribute('popover','manual');for(const [name,symbol,action,disabled] of [['Compare','trade',()=>RosterPlanning.addComparison(a,item),false],['Edit','edit',()=>edit(a,item.slot,item),false],['Move to account','trade',()=>move(a,item),db.accounts.length<2],['Duplicate','box',()=>duplicate(a,item),freeSlot(a)<0],['Delete','trash',()=>remove(a,item),false]]){const b=button(name,()=>{closeMenu();action();},name==='Delete'?'danger':'',symbol);b.setAttribute('role','menuitem');b.disabled=disabled;if(disabled)b.title=name==='Duplicate'?'No free inventory slots':'Add another account first';menu.append(b);}document.body.append(menu);menu.showPopover();const zoom=Number(getComputedStyle(document.documentElement).zoom)||1,r=anchor.getBoundingClientRect(),x=event?.clientX||r.left,y=event?.clientY||r.bottom;menu.style.left=Math.max(8,Math.min(x/zoom,innerWidth/zoom-220))+'px';menu.style.top=Math.max(8,Math.min(y/zoom,innerHeight/zoom-menu.offsetHeight-8))+'px';const buttons=[...menu.querySelectorAll('button:not(:disabled)')];menu.onkeydown=e=>{const i=buttons.indexOf(document.activeElement);if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();buttons[(i+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length].focus();}if(e.key==='Escape'){closeMenu();anchor.focus();}};buttons[0]?.focus({preventScroll:true});}
 function actions(card,a,item){card.tabIndex=0;card.oncontextmenu=e=>context(a,item,card,e);card.onkeydown=e=>{if(e.key==='ContextMenu'||e.shiftKey&&e.key==='F10')context(a,item,card,e);};card.dataset.item=item.id;RosterTools.checkbox(card,a,item);card.append(iconButton('more','Actions for '+(byId.get(item.brainrotId)?.name||item.name),e=>context(a,item,card,e)));}
 Object.assign(paths,{more:'M5 12h.01M12 12h.01M19 12h.01'});
 function picture(item,big=false){const rot=byId.get(item.brainrotId),mutation=item.mutation||'default';const box=node('div',undefined,'inventory-art'+(big?' big':''));const src=rot?.image;box.dataset.mutation=mutation;box.style.setProperty('--mutation-color',mutationColor(mutation));if(src&&/^https:\/\//.test(src)){const im=node('img');im.src=src;im.alt=rot.name;im.loading='lazy';box.append(im);RosterMutationEffects.apply(box,im,mutation,src);}else{box.append(icon('game'),node('small','Icon unavailable'));}return box;}
 function summary(item){const box=node('div',undefined,'inventory-summary');const rot=byId.get(item.brainrotId);box.append(node('strong',rot?.name||item.name||'Unknown brainrot'));if(rot?.rarity)box.append(node('small',rot.rarity,'brainrot-rarity'));const m=node('span',mutationName(item.mutation),'mutation-badge');m.style.color=mutationColor(item.mutation);box.append(m);const traits=node('div',undefined,'trait-list');for(const id of item.traits||[])traits.append(traitIcon(id));if(!(item.traits||[]).length)traits.append(node('small','No traits'));box.append(traits,rate(item),RosterTools.badge(item));return box;}
 function slotCard(a,i){const item=inventory(a).find(x=>x.slot===i);const card=node('article',undefined,'inventory-slot');card.dataset.slot=String(i);if(item)card.dataset.inventoryId=item.id;card.append(node('span','SLOT '+(i+1),'slot-label'));if(item){card.append(picture(item),summary(item));actions(card,a,item);card.append(button('Edit',()=>edit(a,i,item),'ghost','edit'));}else{const add=button('',()=>edit(a,i),'empty-slot');add.setAttribute('aria-label','Add brainrot to slot '+(i+1));add.append(icon('plus'),node('span','Add brainrot'));card.append(add);}return card;}
 function renderAccountInventory(main,a){const capacity=slots(a),items=inventory(a);const p=panel('SAB inventory',items.length+' stored · '+capacity+' slots · Rebirth '+a.sab.level);p.querySelector('.panel-head').append(button('Search all accounts',()=>{navigate('inventory');},'ghost','search'));if(!data){p.append(node('p',error||'Loading brainrot catalog…','muted'));main.append(p);return;}const info=node('div',undefined,'row wrap spread');info.append(node('small','Capacity follows your rebirth level. One brainrot per slot.'),button('Change rebirth',()=>openAccount(a,'sab'),'ghost'));p.append(info);if(items.some(i=>i.slot>=capacity))p.append(node('p','Some saved items exceed your current capacity. They are preserved below until you move or remove them.','error-box section-gap'));RosterTools.toolbar(p,a.id);RosterWorkspace.inventoryToolbar(info,a);const grid=node('div',undefined,'inventory-grid');if(db.settings.inventoryView!=='base')for(let i=0;i<capacity;i++)grid.append(slotCard(a,i));if(db.settings.inventoryView==='base')RosterWorkspace.baseLayout(p,a,slotCard);else p.append(grid);for(const item of items.filter(i=>i.slot>=capacity)){const overflow=node('article',undefined,'inventory-overflow');overflow.dataset.inventoryId=item.id;overflow.append(node('strong','Overflow · slot '+(item.slot+1)),picture(item),summary(item),button('Edit or move',()=>edit(a,item.slot,item),'ghost'));actions(overflow,a,item);p.append(overflow);}p.append(node('p',data.brainrots.length+' catalog entries · '+data.mutations.length+' mutations · '+data.traits.length+' traits. Artwork: SABRValues, then SABExistCount, then Fandom originals as a last resort. Income uses base rate, mutation and traits, before account/base boosts.','sab-banner'));main.append(p);}
 function edit(a,slot,existing,seed){
  if(!data)return;
  const draft=existing?structuredClone(existing):{id:uid(),slot,brainrotId:'',name:'',mutation:'default',traits:[],notes:''};
  if(seed)Object.assign(draft,{brainrotId:seed.id,name:seed.name,mutation:seed.mutation,traits:seed.traits||[]});
  let search='',rarity='',limit=48,traitSearch='';
  const m=modal(seed?'Brainrot details':existing?'Edit brainrot':'Add a brainrot',(seed?seed.name:'Slot '+(slot+1))+' · '+(a.nickname||a.displayName||a.username),seed?'Add to base':'Save brainrot',({close})=>{
   if(!db.accounts.includes(a))throw Error('This account is no longer in the roster.');
   if(!draft.brainrotId)throw Error('Choose a brainrot.');
   const target=Number(slotChoice.value);
   if(seed&&(slotChoice.selectedIndex<0||target<0||target>=slots(a)))throw Error('Choose a free slot in this account’s base.');
   if(inventory(a).some(i=>i.slot===target&&i.id!==draft.id))throw Error('That slot is already occupied.');
   Object.assign(draft,{mutation:mutation.value,slot:target,tradeStatus:trade.value});
   a.sab.inventory=inventory(a).filter(i=>i.id!==draft.id);
   a.sab.inventory.push(structuredClone(draft));changed();close();render();
  });
  m.dialog.classList.add('inventory-dialog');
  m.dialog.addEventListener('close',()=>m.dialog.classList.remove('inventory-dialog'),{once:true});
  let nextButton;
  const chooser=node('div'),searchInput=input('Search brainrot catalog');
  searchInput.placeholder='Search all '+data.brainrots.length+' brainrots…';
  const rarities=select('Brainrot rarity',[['','All rarities'],...[...new Set(data.brainrots.map(r=>r.rarity))].sort().map(r=>[r,r])],'');
  const toolbar=node('div',undefined,'toolbar');toolbar.append(searchInput,rarities);chooser.append(toolbar);
  const results=node('div',undefined,'brainrot-picker'),more=button('Show more',()=>{limit+=48;draw();},'ghost');
  chooser.append(results,more);
  const selectedBox=node('div',undefined,'chosen-brainrot');
  const preview=()=>{
   selectedBox.replaceChildren();
   if(nextButton)nextButton.disabled=!draft.brainrotId;
   if(!draft.brainrotId)return;
   selectedBox.append(picture(draft,true),summary(draft));
   if(!existing)selectedBox.append(price(byId.get(draft.brainrotId),true));
   selectedBox.append(button('Choose another',()=>{chooser.hidden=false;searchInput.focus();},'ghost'),RosterMarket.details(byId.get(draft.brainrotId),draft,data));
  };
  const draw=()=>{
   results.replaceChildren();
   const found=data.brainrots.filter(r=>!r.hiddenFromPicker&&(!rarity||r.rarity===rarity)&&normalize(r.name).includes(normalize(search)));
   for(const r of found.slice(0,limit)){
    const b=button('',()=>{draft.brainrotId=r.id;draft.name=r.name;chooser.hidden=true;preview();},'brainrot-choice');
    b.title=r.name;b.setAttribute('aria-label',r.name);
    b.append(picture({brainrotId:r.id,mutation:'default'}),node('span',r.name),node('small',r.rarity),rate({brainrotId:r.id,mutation:'default',traits:[]}));
    if(!existing)b.append(price(r));
    results.append(b);
   }
   more.hidden=found.length<=limit;
   if(!found.length)results.append(node('p','No matching brainrots.','muted'));
  };
  searchInput.oninput=()=>{search=searchInput.value;limit=48;draw();};
  rarities.onchange=()=>{rarity=rarities.value;limit=48;draw();};
  m.body.append(selectedBox,chooser);if(existing||seed)chooser.hidden=true;
  const grid=node('div',undefined,'form-grid section-gap'),mutation=mutationSelect('Mutation',draft.mutation,false,true);
  mutation.onchange=()=>{draft.mutation=mutation.value;preview();};
  const slotChoice=select('Inventory slot',Array.from({length:slots(a)},(_,i)=>[i,'Slot '+(i+1)+(inventory(a).some(x=>x.slot===i&&x.id!==draft.id)?' · occupied':'')]).concat(slot>=slots(a)?[[slot,'Overflow slot '+(slot+1)]]:[]),slot);
  for(const o of slotChoice.options)o.disabled=inventory(a).some(x=>x.slot===Number(o.value)&&x.id!==draft.id);
  const trade=RosterTools.tradeSelect('Trading status',draft.tradeStatus);trade.onchange=()=>{draft.tradeStatus=trade.value;preview();};grid.append(label('Mutation',mutation),label('Slot',slotChoice),label('Trading status',trade));m.body.append(grid,node('h3','Traits','section-gap'));
  const traitSearchInput=input('Search traits');traitSearchInput.placeholder='Search traits…';traitSearchInput.className='trait-search';
  const traitPicker=node('div',undefined,'trait-picker');
  const drawTraits=()=>{
   traitPicker.replaceChildren();
   for(const t of data.traits.filter(t=>t.name.toLowerCase().includes(traitSearch.toLowerCase()))){
    const b=traitIcon(t.id,true);
    b.onclick=()=>{draft.traits=draft.traits.includes(t.id)?draft.traits.filter(id=>id!==t.id):[...draft.traits,t.id];drawTraits();preview();};
    b.setAttribute('aria-pressed',String(draft.traits.includes(t.id)));traitPicker.append(b);
   }
  };
  traitSearchInput.oninput=()=>{traitSearch=traitSearchInput.value;drawTraits();};m.body.append(traitSearchInput,traitPicker);
  if(existing)m.foot.prepend(button('Remove from inventory',()=>{m.dialog.close();remove(a,existing);},'danger','trash'));
  else if(!seed){
   nextButton=button('Done & next',async()=>{
    nextButton.disabled=true;
    const done=await m.finish(()=>{
     // Start after the saved slot and wrap, skipping every occupied slot.
     const capacity=slots(a);
     for(let step=1;step<=capacity;step++){
      const next=(draft.slot+step)%capacity;
      if(!inventory(a).some(i=>i.slot===next)){edit(a,next);return;}
     }
     toast('Inventory is full. All slots are saved.');
    });
    if(!done)nextButton.disabled=false;
   },'ghost');
   nextButton.title='Save and open the next available slot';m.foot.append(nextButton);
  }
  if(seed){
   const quick=node('div',undefined,'row wrap section-gap');
   for(let i=0;i<slots(a);i++){const b=button('Add to slot '+(i+1),()=>{slotChoice.value=String(i);m.save.click();},'ghost');b.disabled=inventory(a).some(x=>x.slot===i);quick.append(b);}
   m.body.append(node('h3','Add directly to a slot','section-gap'),quick);
   if(freeSlot(a)<0){m.save.disabled=true;m.body.append(node('p','This base is full. You can still inspect details and try mutations and traits.','sab-banner'));}
  }
  draw();drawTraits();preview();if(!seed)m.enableAutosave(()=>!draft.brainrotId);
 }
 function fromIndex(a,id,mutation){const rot=byId.get(id);if(!rot){toast('This brainrot is not available in the inventory catalog yet.');return;}HelperCatalog.details(rot,null,{mutation});}
 function requirementPrompt(a,name){
  if(!data){toast('Wait for the inventory catalog to load.');return;}
  const rot=data.brainrots.find(r=>!r.hiddenFromPicker&&normalize(r.name)===normalize(name));
  const m=modal(name,'For @'+a.username+' · Choose a copy to move into the first free slot.','Add without transfer',({close})=>{
   if(!db.accounts.includes(a))throw Error('This account is no longer in the roster.');
   if(freeSlot(a)<0)throw Error('This account has no free slots.');
   if(!rot)throw Error('This brainrot is not available in the catalog.');
   m.dialog.addEventListener('close',()=>queueMicrotask(()=>fromIndex(a,rot.id,'default')),{once:true});close();
  });
  m.save.disabled=!rot||freeSlot(a)<0;
  const owned=requirementItems(a,name).length;
  if(owned)m.body.append(node('p',owned+' matching '+(owned===1?'copy is':'copies are')+' already in this account.','muted'));
  if(freeSlot(a)<0)m.body.append(node('p','This account has no free slots. Free a slot before adding or transferring.','error-box'));
  const list=node('div',undefined,'rebirth-copy-list');let count=0;
  for(const source of db.accounts){if(source.id===a.id)continue;for(const item of inventory(source)){
   if(normalize(byId.get(item.brainrotId)?.name||item.name)!==normalize(name))continue;
   count++;const transfer=button('',()=>{
    try{
     if(!db.accounts.includes(a)||!db.accounts.includes(source))throw Error('An account was removed. Reopen this prompt.');
     const current=inventory(source).find(i=>i.id===item.id);
     if(!current||normalize(byId.get(current.brainrotId)?.name||current.name)!==normalize(name))throw Error('This copy changed or moved. Reopen this prompt.');
     const slot=freeSlot(a);if(slot<0)throw Error('This account has no free slots.');
     RosterHistory.commit('rebirth transfer',[source,a],()=>{source.sab.inventory=inventory(source).filter(i=>i.id!==current.id);a.sab.inventory=[...inventory(a),{...current,slot}];});
     m.dialog.close();toast('Moved from @'+source.username+' to @'+a.username+' · slot '+(slot+1)+'.');
    }catch(e){m.error.textContent=e.message;}
   },'rebirth-copy');transfer.disabled=freeSlot(a)<0;transfer.setAttribute('aria-label','Transfer '+name+' from @'+source.username+' slot '+(item.slot+1));transfer.dataset.sourceAccount=source.id;transfer.dataset.sourceItem=item.id;
   const owner=node('div',undefined,'rebirth-copy-owner');owner.append(node('strong','@'+source.username),node('small','Slot '+(item.slot+1)+(item.slot>=slots(source)?' · overflow':'')),node('span','Transfer here','muted'));transfer.append(picture(item),owner,summary(item));list.append(transfer);
  }}
  if(!count)list.append(node('p','No matching copies in other accounts. Use Add without transfer to record a new one.','muted'));
  m.body.append(list,node('p','Transfers update your RoHelper inventories; move the brainrot in Roblox separately.','muted'));
 }
 function requirementItems(a,name){return inventory(a).filter(item=>item.slot<slots(a)&&normalize(byId.get(item.brainrotId)?.name||item.name)===normalize(name));}
 function requirements(a,r){const grouped=new Map();for(const name of r.brainrots)grouped.set(name,(grouped.get(name)||0)+1);return [...grouped].map(([name,needed])=>({name,needed,candidates:requirementItems(a,name)}));}
 function completeRebirth(a,r){if(!data){toast('Wait for the inventory catalog to load.');return;}const groups=requirements(a,r);if(groups.some(g=>g.candidates.length<g.needed)){toast('Add all required brainrots to available inventory slots first.');return;}
 const consume=chosen=>{if(a.sab.level!==r.level-1)throw Error('The rebirth level changed. Open the current requirements again.');const current=requirements(a,r);for(const g of current){const ids=chosen.get(g.name)||[];if(ids.length!==g.needed||ids.some(id=>!g.candidates.some(i=>i.id===id)))throw Error('Select the required copies for '+g.name+'.');}const ids=new Set([...chosen.values()].flat());RosterHistory.commit('rebirth '+r.level,[a],()=>{a.sab.inventory=inventory(a).filter(i=>!ids.has(i.id));a.sab.level=r.level;});toast('Rebirth '+r.level+' completed. Required brainrots removed.');};
 const chosen=new Map(groups.map(g=>[g.name,g.candidates.length===g.needed?g.candidates.map(i=>i.id):[]]));if(groups.every(g=>g.candidates.length===g.needed)){consume(chosen);return;}
 const m=modal('Choose brainrots for rebirth '+r.level,'Selected copies will be removed from this account’s inventory.','Complete rebirth',({close})=>{consume(chosen);close();});m.dialog.classList.add('rebirth-picker-dialog');m.dialog.addEventListener('close',()=>m.dialog.classList.remove('rebirth-picker-dialog'),{once:true});for(const g of groups){const section=node('section',undefined,'rebirth-choice-group');section.append(node('h3',g.name+' · choose '+g.needed));const grid=node('div',undefined,'rebirth-copy-grid');const draw=()=>{grid.replaceChildren();for(const item of g.candidates){const b=button('',()=>{let ids=chosen.get(g.name);if(ids.includes(item.id))ids=ids.filter(id=>id!==item.id);else if(g.needed===1)ids=[item.id];else if(ids.length<g.needed)ids=[...ids,item.id];chosen.set(g.name,ids);draw();},'rebirth-copy');b.dataset.item=item.id;b.setAttribute('aria-label',g.name+' · slot '+(item.slot+1)+' · '+mutationName(item.mutation));b.setAttribute('aria-pressed',String(chosen.get(g.name).includes(item.id)));b.append(node('small','Slot '+(item.slot+1)),picture(item),summary(item));grid.append(b);}};draw();section.append(grid);m.body.append(section);}}
 function price(r,detailed=false){
  const box=node('small',undefined,'brainrot-prices'+(detailed?' detailed':''));
  box.append(node('span',Number.isFinite(r.buyPrice)?'Buy '+cash(r.buyPrice):'Buy —'),node('span',Number.isFinite(r.buyPrice)?'Sell '+cash(r.buyPrice/2):'Sell —'));
  const release=r.releaseInfo,trade=r.tradeValue;
  const date=release?.date?new Date(release.date+'T12:00:00').toLocaleDateString(undefined,{year:'numeric',month:'short',day:'numeric'}):null;
  box.append(node('span',date?'Added '+date:release?.label?'Wiki release: '+release.label:'Added: unknown'));
  box.append(node('span',Number.isFinite(trade?.value)?'Base trade estimate: '+trade.value.toLocaleString()+' Robux':'Base trade estimate: unknown'));
  box.title='Buy/sell use in-game cash. Trade estimates are for the default version; mutations and traits are not priced.';
  if(detailed){
   const sources=node('span',undefined,'brainrot-detail-sources');
   const link=(text,url)=>{const a=node('a',text);a.href=url;a.target='_blank';a.rel='noopener noreferrer';return a;};
   if(release?.source)sources.append(link('Release source',release.source));
   if(trade?.source)sources.append(link('SABExistCount · checked '+trade.checkedOn,trade.source));
   box.append(sources,node('span','Trade estimate for Normal only; mutations and traits change trading value.','muted'));
  }
  return box;
 }
 function accountRate(a){const n=node('div',undefined,'account-income');if(!data){n.textContent='Loading income…';return n;}let total=0,unknown=0;for(const item of inventory(a).filter(i=>i.slot<slots(a))){const r=RosterIncome.calculate(item,data);if(r)total+=r.perSecond;else unknown++;}n.textContent=cash(total)+'/s'+(unknown?' + '+unknown+' unknown':'');n.title='Combined income of occupied slots, before account/base boosts. Overflow is excluded.';return n;}
 function overview(a){const p=panel('SAB inventory income','Before account/base boosts.');p.append(accountRate(a));const items=inventory(a);p.append(node('p',slots(a)+' slots · '+(slots(a)-items.filter(i=>i.slot<slots(a)).length)+' free','slot-summary'));if(!items.length)p.append(node('small','Add brainrots to calculate this account’s income.'));else if(data){const list=node('div',undefined,'overview-inventory');for(const item of items.slice(0,6)){const row=node('div',undefined,'overview-brainrot');row.append(picture(item),summary(item));actions(row,a,item);list.append(row);}p.append(list);}p.append(button('Open inventory',()=>openAccount(a,'inventory'),'ghost section-gap','box'));return p;}
 function renderSearch(main){main.append(heading('SAB inventory search','Find brainrots, mutations, and traits across all saved accounts.'));if(!data){main.append(node('p',error||'Loading brainrot catalog...','muted'));return;}const toolbar=node('div',undefined,'toolbar inventory-filters');const q=input('Search all inventories',query);q.placeholder='Brainrot, account, mutation...';const mutation=mutationSelect('Filter mutation',mutationFilter,true),trait=select('Filter trait',[['','All traits'],...data.traits.map(x=>[x.id,x.name])],traitFilter),account=select('Filter account',[['','All accounts'],...db.accounts.map(a=>[a.id,a.nickname||a.displayName||a.username])],accountFilter),sort=select('Sort inventory',[['income-desc','Money per second - high to low'],['income-asc','Money per second - low to high'],['rarity-desc','Rarity - high to low'],['rarity-asc','Rarity - low to high'],['name-asc','Brainrot name - A to Z'],['name-desc','Brainrot name - Z to A'],['account-asc','Account - A to Z']],sortFilter);const trade=RosterTools.tradeSelect('Filter trading status',tradeFilter);const all=node('option','All statuses');all.value='';trade.prepend(all);trade.value=tradeFilter;toolbar.append(q,mutation,trait,account,sort,trade);main.append(toolbar);RosterTools.toolbar(main,'all');const count=node('p','','muted'),grid=node('div',undefined,'inventory-grid');main.append(count,grid);const rarityRank={common:10,rare:20,epic:30,legendary:40,mythic:50,'brainrot god':60,'brainrot-god':60,secret:70,og:80,admin:90,other:5,'lucky block':1};const draw=()=>{grid.replaceChildren();const matches=[];for(const a of db.accounts){if(accountFilter&&a.id!==accountFilter)continue;for(const item of inventory(a)){const r=byId.get(item.brainrotId);if(tradeFilter&&(item.tradeStatus||'none')!==tradeFilter)continue;if(mutationFilter&&item.mutation!==mutationFilter||traitFilter&&!item.traits.includes(traitFilter))continue;const hay=[r?.name||item.name,a.username,a.nickname,a.displayName,mutationName(item.mutation),...item.traits.map(traitName)].join(' ').toLowerCase();if(query&&!hay.includes(query.toLowerCase()))continue;const income=RosterIncome.calculate(item,data)?.perSecond??-1;matches.push({a,item,r,income,name:(r?.name||item.name||'Unknown brainrot').toLowerCase(),rarity:rarityRank[String(r?.rarity||'').toLowerCase()]||0,account:(a.nickname||a.displayName||a.username||'').toLowerCase()});}}matches.sort((x,y)=>{if(sortFilter==='income-desc')return y.income-x.income||x.name.localeCompare(y.name);if(sortFilter==='income-asc')return x.income-y.income||x.name.localeCompare(y.name);if(sortFilter==='rarity-desc')return y.rarity-x.rarity||x.name.localeCompare(y.name);if(sortFilter==='rarity-asc')return x.rarity-y.rarity||x.name.localeCompare(y.name);if(sortFilter==='name-desc')return y.name.localeCompare(x.name);if(sortFilter==='account-asc')return x.account.localeCompare(y.account)||x.name.localeCompare(y.name);return x.name.localeCompare(y.name);});for(const {a,item} of matches){const c=node('article',undefined,'inventory-slot');c.dataset.account=a.id;actions(c,a,item);c.append(picture(item),summary(item),node('small','Slot '+(item.slot+1)+(item.slot>=slots(a)?' - over capacity':'')),button(a.nickname||a.displayName||a.username,()=>openAccount(a,'inventory'),'ghost','accounts'));grid.append(c);}count.textContent=matches.length+' matching brainrot'+(matches.length===1?'':'s');if(!matches.length){const hasItems=db.accounts.some(a=>inventory(a).length);grid.append(empty(hasItems?'No brainrots match these filters':'Your inventories are empty',hasItems?'Clear the filters or try a different name.':'Open an account to add your first brainrot.',hasItems?button('Clear inventory filters',()=>{query=mutationFilter=traitFilter=accountFilter=tradeFilter='';render();},'ghost'):button('Open accounts',()=>navigate('accounts'),'ghost'),'box'));}};q.oninput=()=>{query=q.value;draw();};mutation.onchange=()=>{mutationFilter=mutation.value;draw();};trait.onchange=()=>{traitFilter=trait.value;draw();};account.onchange=()=>{accountFilter=account.value;draw();};sort.onchange=()=>{sortFilter=sort.value;draw();};trade.onchange=()=>{tradeFilter=trade.value;draw();};draw();}
 function replaceCatalog(value){data=structuredClone(value);RosterCatalogOrder.apply(data);byId.clear();for(const r of data.brainrots)byId.set(r.id,r);for(const r of data.brainrots)if(r.duplicateOf&&byId.has(r.duplicateOf))byId.set(r.id,byId.get(r.duplicateOf));}
 function view(){return {query,mutationFilter,traitFilter,accountFilter,tradeFilter,sortFilter};}function restoreView(s){if(!s||typeof s!=='object')return;const str=k=>typeof s[k]==='string'?s[k].slice(0,1000):'';query=str('query');mutationFilter=str('mutationFilter');traitFilter=str('traitFilter');accountFilter=db.accounts.some(a=>a.id===s.accountFilter)?s.accountFilter:'';tradeFilter=['none','keep','trade'].includes(s.tradeFilter)?s.tradeFilter:'';sortFilter=['income-desc','income-asc','rarity-desc','rarity-asc','name-asc','name-desc','account-asc'].includes(s.sortFilter)?s.sortFilter:'income-desc';}
 return {price,replaceCatalog,edit,duplicate,remove,move,requirementPrompt,fromIndex,view,restoreView,catalog:()=>data,brainrot:id=>byId.get(id),normalize,freeSlot,picture,summary,traitIcon,mutationSelect,mutationColor,cash,renderAccount:renderAccountInventory,renderSearch,slots,accountRate,overview,requirementItems,requirements,completeRebirth};
})();

});
