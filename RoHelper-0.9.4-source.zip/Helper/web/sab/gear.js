'use strict';
window.HelperSabGear=(()=>{
 let owner='',query='',category='',sort='name';
 const catalog=()=>HelperGames.pack('sab')?.catalogs.gear;
 const entries=()=>catalog()?.entries||[];
 const items=a=>a.sab.gearInventory||[];
 const ref=item=>entries().find(g=>g.id===item.gearId)||{id:item.gearId,name:item.name||'Unknown gear',category:'custom'};
 function art(g){const box=node('div',undefined,'gear-art');if(g.image&&/^(https:\/\/|data:image\/(?:png|webp|jpeg);base64,)/.test(g.image)){const im=node('img');im.src=g.image;im.alt=g.name;im.loading='lazy';im.onerror=()=>{im.remove();box.append(icon('box'));box.title='Source artwork is temporarily unavailable';};box.append(im);}else{box.append(icon('box'));box.title='No verified artwork available';}return box;}
 function current(id){const a=HelperSab.workspace.accounts.find(a=>a.id===id);if(!a)throw Error('This account was removed.');return a;}
 function validate(item){if(!item.name?.trim()||item.name.length>160)throw Error('Invalid gear name.');}
 function editor(accountId,g,existing){
  let baseline=existing?structuredClone(existing):null,draft=baseline?structuredClone(baseline):{id:crypto.randomUUID(),gearId:g.id,name:g.name,quantity:1,notes:''};
  const a=current(accountId),m=HelperSab.dialog(existing?'Edit gear':'Add gear','@'+a.username+' · '+g.name,existing?'Done':'Add gear',async({close})=>{
   const target=current(accountId),live=items(target).find(i=>i.id===draft.id);validate(draft);
   if(baseline&&!live)throw Error('This gear was removed or moved while the editor was open.');
   const next=baseline?HelperMerge.merge(baseline,draft,live):structuredClone(draft);
   if(!baseline&&items(target).some(i=>i.gearId===g.id)){toast('This account already has '+g.name+'.');close();return;}RosterHistory.commit(existing?'edit gear':'add gear',[target],()=>{target.sab.gearInventory=[...items(target).filter(i=>i.id!==next.id),next];});
   await flush();baseline=structuredClone(next);draft=structuredClone(next);close();
  });
  m.dialog.classList.add('gear-dialog');
  const hero=node('div',undefined,'gear-editor-hero'),copy=node('div');copy.append(node('h3',g.name),node('p',g.group||catalog()?.categories?.find(c=>c.id===g.category)?.name||'Personal gear','muted'));hero.append(art(g),copy);m.body.append(hero);
  if(g.acquisition)m.body.append(node('p',g.acquisition,'help-text'));if(g.source){const source=node('a','Gear source');source.href=g.source;source.target='_blank';source.rel='noopener noreferrer';m.body.append(source);}if(g.confirmed===false)m.body.append(node('p','Unconfirmed availability','notice'));enhance(m.body);if(existing)m.enableAutosave();
 }
 function browse(accountId){
  const a=current(accountId),m=HelperSab.dialog('Add gear','@'+a.username+' · Choose gear from the catalog.','',null),search=input('Search gear catalog'),filter=select('Gear catalog category',[['','All gear'],...(catalog()?.categories||[]).map(c=>[c.id,c.name])],''),bar=node('div',undefined,'catalog-toolbar'),grid=node('div',undefined,'gear-picker');search.placeholder='Search gear…';bar.append(search,filter);m.body.append(bar,grid);m.dialog.classList.add('gear-dialog');
  function draw(){grid.replaceChildren();for(const g of entries().filter(g=>(!filter.value||g.category===filter.value)&&[g.name,g.group,...(g.aliases||[])].join(' ').toLowerCase().includes(search.value.toLowerCase()))){const pick=button('',()=>m.close().then(()=>editor(accountId,g)),'gear-choice');pick.dataset.gearId=g.id;pick.append(art(g),node('strong',g.name));pick.append(node('small',g.acquisition||g.group||'Source unknown'));grid.append(pick);}if(!grid.children.length)grid.append(node('p','No matching gear.','muted'));}
  const sources=node('details',undefined,'section-gap');sources.append(node('summary','Catalog sources'));for(const url of catalog()?.sources||[]){const link=node('a',new URL(url).hostname);link.href=url;link.target='_blank';link.rel='noopener noreferrer';const row=node('p',undefined,'help-text');row.append(link);sources.append(row);}m.body.append(sources);
  search.oninput=draw;filter.onchange=draw;draw();enhance(bar);
 }
 function remove(accountId,item){const a=current(accountId);RosterHistory.commit('delete gear',[a],()=>{a.sab.gearInventory=items(a).filter(i=>i.id!==item.id);});toast('Gear removed. Use Undo to restore it.');}

 function move(accountId,item){
  const g=ref(item);HelperItemDestinations.accounts({name:'Move '+g.name,onSelect:id=>{
   if(id===accountId){toast('Choose another account.');move(accountId,item);return;}
   const a=current(accountId),target=current(id),live=items(a).find(i=>i.id===item.id);if(!live){toast('This gear is no longer on the original account.');return;}
   if(items(target).some(i=>i.gearId===live.gearId)){toast('@'+target.username+' already has this gear.');return;}RosterHistory.commit('move gear',[a,target],()=>{a.sab.gearInventory=items(a).filter(i=>i.id!==live.id);target.sab.gearInventory=[...items(target),structuredClone(live)];});flush().catch(e=>toast(e.message));
  }});
 }
 function actions(a,item){const g=ref(item),m=HelperSab.dialog(g.name,'@'+a.username+' · Gear ownership','',null),bar=node('div',undefined,'row wrap');bar.append(button('Edit gear',()=>m.close().then(()=>editor(a.id,g,item)),'ghost','edit'),button('Move to account',()=>m.close().then(()=>move(a.id,item)),'ghost','trade'),button('Delete',()=>{m.close();remove(a.id,item);},'danger','trash'));m.body.append(bar);}
 function render(host,a){
  host.append(heading(a?'Gear inventory':'SAB gear inventory','Track gear separately from brainrots. Changes save per account.',[button('Add gear',()=>{if(a)browse(a.id);else if(owner)browse(owner);else HelperItemDestinations.accounts({name:'Add gear',onSelect:browse});},'primary','plus')]));
  const bar=node('div',undefined,'catalog-toolbar'),q=input('Search saved gear',query),filter=select('Gear category',[['','All gear'],...(catalog()?.categories||[]).map(c=>[c.id,c.name]),['custom','Custom']],category),order=select('Gear sort',[['name','Name A–Z'],['account','Account A–Z']],sort),grid=node('div',undefined,'gear-grid'),count=node('p','','muted');q.placeholder='Search gear or accounts…';bar.append(q,filter,order);
  let accounts;if(!a){if(owner&&!db.accounts.some(a=>a.id===owner))owner='';accounts=select('Gear account',[['','All accounts'],...db.accounts.map(a=>[a.id,'@'+a.username])],owner);bar.prepend(accounts);accounts.onchange=()=>{owner=accounts.value;draw();};}
  host.append(bar,count,grid);
  function draw(){grid.replaceChildren();const rows=HelperSab.workspace.accounts.filter(x=>a?x.id===a.id:!owner||x.id===owner).flatMap(a=>items(a).map(item=>({a,item,g:ref(item)}))).filter(({a,item,g})=>(!category||g.category===category)&&[g.name,item.name,a.username,a.nickname,a.displayName].join(' ').toLowerCase().includes(query.toLowerCase())).sort((x,y)=>sort==='account'?x.a.username.localeCompare(y.a.username)||x.g.name.localeCompare(y.g.name):x.g.name.localeCompare(y.g.name));count.textContent=rows.length+' saved gear entries';for(const {a,item,g} of rows){const card=node('article',undefined,'gear-card');card.dataset.gearItem=item.id;card.append(art(g),node('strong',item.name||g.name),node('small',g.acquisition||g.group||catalog()?.categories?.find(c=>c.id===g.category)?.name||'Custom gear','muted'),button('@'+a.username,()=>HelperSab.openAccount(a.id,'gear'),'ghost'));const buttons=node('div',undefined,'row');buttons.append(button('Edit',()=>editor(a.id,g,item),'ghost','edit'),iconButton('more','Actions for '+item.name,()=>actions(a,item)));card.append(buttons);card.oncontextmenu=e=>{e.preventDefault();actions(a,item);};grid.append(card);}if(!rows.length)grid.append(empty('No saved gear',query||category?'Try another search or category.':'Add your gear to this account.'));}
  q.oninput=()=>{query=q.value;draw();};filter.onchange=()=>{category=filter.value;draw();};order.onchange=()=>{sort=order.value;draw();};draw();enhance(bar);
 }
 function details(g){const m=HelperSab.dialog(g.name,'Gear reference','Done',({close})=>close()),hero=node('div',undefined,'gear-editor-hero'),copy=node('div');m.dialog.classList.add('gear-dialog');copy.append(node('h3',g.name),node('p',g.group||'Gear','muted'));hero.append(art(g),copy);m.body.append(hero);if(g.acquisition)m.body.append(node('p',g.acquisition,'help-text'));if(g.confirmed===false)m.body.append(node('p','Unconfirmed availability','notice'));for(const [name,url] of [['Gear source',g.source],['Artwork source',g.artwork?.source]])if(url){const link=node('a',name);link.href=url;link.target='_blank';link.rel='noopener noreferrer';const row=node('p');row.append(link);m.body.append(row);}const add=button('Add to inventory',()=>HelperItemDestinations.accounts({name:g.name,onSelect:id=>editor(id,g)}),'ghost','plus');m.foot.insertBefore(add,m.save);}
 return {render,browse,items,art,details};
})();
