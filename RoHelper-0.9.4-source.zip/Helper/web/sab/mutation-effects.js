// Renderer only. Palettes, textures, glow, cycles and menu order are public data.
window.RosterMutationEffects=(()=>{
 let data={effects:{}},svg=null;const motion=matchMedia('(prefers-reduced-motion: reduce)');
 const ns='http://www.w3.org/2000/svg',el=(tag,attrs={})=>{const n=document.createElementNS(ns,tag);for(const [k,v] of Object.entries(attrs))n.setAttribute(k,String(v));return n;};
 function accept(next){data=next||{effects:{}};svg?.remove();svg=null;}
 function filters(){if(svg)return;svg=el('svg',{id:'roster-mutation-filters',width:0,height:0,'aria-hidden':true});svg.style.position='absolute';const defs=el('defs');svg.append(defs);
  for(const [id,a] of Object.entries(data.effects||{})){if(!/^[a-z0-9_-]+$/.test(id)||!a.palette)continue;const f=el('filter',{id:'material-'+id,'color-interpolation-filters':'sRGB'});f.append(el('feColorMatrix',{type:'saturate',values:0}));const light=el('feComponentTransfer');for(const c of ['R','G','B'])light.append(el('feFunc'+c,{type:'gamma',amplitude:a.amplitude??1,exponent:a.gamma??1,offset:0}));f.append(light);
   if(a.cycle){const tint=el('feComponentTransfer');for(const [i,c] of ['R','G','B'].entries()){const values=a.cycle.channels[i],fn=el('feFunc'+c,{type:'linear',slope:values[0]});fn.append(el('animate',{attributeName:'slope',values:values.join(';'),dur:a.cycle.seconds+'s',repeatCount:'indefinite'}));tint.append(fn);}f.append(tint);}
   else if(a.table){const t=el('feComponentTransfer');for(const c of ['R','G','B'])t.append(el('feFunc'+c,{type:'table',tableValues:a.table.join(' ')}));f.append(t);}
   else{const [low,high]=a.palette,values=[...low.flatMap((v,i)=>{const span=high[i]-v;return [.2126*span,.7152*span,.0722*span,0,v];}),0,0,0,1,0];f.append(el('feColorMatrix',{type:'matrix',values:values.join(' ')}));}defs.append(f);
  }document.body.append(svg);if(motion.matches)svg.pauseAnimations();
 }
 motion.addEventListener('change',()=>{if(svg)motion.matches?svg.pauseAnimations():svg.unpauseAnimations();});
 function apply(box,im,mutation,src){if(mutation==='normal'||mutation==='default')return;const a=data.effects?.[mutation];if(!a){box.classList.add('variant-unavailable');box.title='No verified visual treatment yet; showing the base icon.';return;}filters();box.classList.add('material-art');box.title='Mutation appearance preview';im.style.filter='url(#material-'+mutation+')'+(a.glow?' drop-shadow('+a.glow+')':'');
  if(a.texture){const t=document.createElement('span');t.className='mutation-texture';for(const [k,v] of Object.entries(a.texture))if(['background','background-image','background-size','mix-blend-mode','opacity'].includes(k))t.style.setProperty(k,v);t.style.maskImage='url("'+src+'")';t.setAttribute('aria-hidden','true');box.append(t);}
  if(a.corona){const t=document.createElement('span');t.className='mutation-corona';t.style.setProperty('--corona-color',a.corona.color);t.style.setProperty('--corona-shadow',a.corona.shadow);t.setAttribute('aria-hidden','true');box.append(t);}
 }
 return {accept,apply};
})();
