'use strict';
window.SabPortFactories=[];
window.HelperSab=(()=>{
 const copy=x=>x===undefined?undefined:structuredClone(x),equal=(a,b)=>HelperMerge.equal(a,b),views=new Map();
 let pack=null,ready=false,selected=null,subtab='inventory',editor=null,renderPaused=0,orderUndo=null;
 const viewKey='rohelper.sab.views.v1';let remembered={};try{remembered=JSON.parse(localStorage.getItem(viewKey)||'{}');selected=remembered.selected||null;subtab=['rebirth','inventory','index','gear'].includes(remembered.subtab)?remembered.subtab:'inventory';}catch{}
 function saveViews(){if(!ready)return;try{localStorage.setItem(viewKey,JSON.stringify({selected,subtab,inventory:RosterInventory.view(),index:RosterIndex.view(),comparison:RosterPlanning.view()}));}catch{}}
 let viewTimer;for(const event of ['input','change','click'])document.addEventListener(event,()=>{clearTimeout(viewTimer);viewTimer=setTimeout(saveViews,100);});window.addEventListener('pagehide',saveViews);
 const real=()=>db,raw=a=>a.gameData?.sab;
 const defaults=()=>({level:pack?.fields.find(f=>f.id==='rebirth')?.default??0,checks:{},inventory:[],index:{}});
 function normalized(value){const result={...defaults(),...copy(value||{})};result.level=value?.rebirth??value?.level??result.level;delete result.rebirth;return result;}
 function accountViews(){
  const ids=new Set();const result=[];
  for(const account of real().accounts){ids.add(account.id);let entry=views.get(account.id);
   if(!entry){const a={};for(const key of Object.keys(account))if(key!=='gameData')Object.defineProperty(a,key,{enumerable:true,get:()=>real().accounts.find(x=>x.id===account.id)?.[key]});entry={a,source:undefined,baseline:undefined};views.set(account.id,entry);}
   const source=raw(account);
   if(!entry.baseline||!equal(source,entry.source)&&equal(entry.a.sab,entry.baseline)){entry.source=copy(source);entry.a.sab=normalized(source);entry.baseline=copy(entry.a.sab);}
   result.push(entry.a);
  }for(const id of views.keys())if(!ids.has(id))views.delete(id);return result;
 }
 const workspace={get accounts(){return accountViews();},get tags(){return real().tags;},get settings(){return real().settings;},get sessionChecklist(){return real().sabSessionChecklist;},set sessionChecklist(value){real().sabSessionChecklist=value;}};
 function validate(rows){const ids=new Set();for(const a of rows){const s=a.sab;if(!Number.isInteger(s.level)||s.level<0||s.level>10000||!Array.isArray(s.inventory)||s.inventory.length>200)throw Error('Invalid SAB progress.');const slots=new Set();for(const item of s.inventory){if(!item.id||ids.has(item.id)||!Number.isInteger(item.slot)||item.slot<0||item.slot>199||slots.has(item.slot)||!Array.isArray(item.traits))throw Error('Duplicate item ID or occupied inventory slot.');ids.add(item.id);slots.add(item.slot);}}}
 function sync(){
  const rows=accountViews();validate(rows);const staged=[];
  for(const a of rows){const entry=views.get(a.id);if(equal(a.sab,entry.baseline))continue;const base=entry.source||{},proposed=copy(base);
   for(const key of new Set([...Object.keys(entry.baseline),...Object.keys(a.sab)])){if(equal(a.sab[key],entry.baseline[key]))continue;const target=key==='level'?'rebirth':key;if(a.sab[key]===undefined)delete proposed[target];else proposed[target]=copy(a.sab[key]);}
   const actual=real().accounts.find(x=>x.id===a.id),current=raw(actual)||{};staged.push({actual,entry,next:HelperMerge.merge(base,proposed,current)});
  }
  for(const {actual,entry,next} of staged){actual.gameData??={};actual.gameData.sab=next;entry.source=copy(next);entry.a.sab=normalized(next);entry.baseline=copy(entry.a.sab);}
  return staged.length>0;
 }
 function changed(){window.RosterIndex?.observe(workspace);sync();mark();}
 function render(){if(!renderPaused)renderMain();}
 function privateCapture(accounts=workspace.accounts){return [...new Set(accounts.map(a=>a.id))].map(id=>({id,before:copy(raw(real().accounts.find(a=>a.id===id))),view:copy(views.get(id)?.a.sab)}));}
 function restore(rows){for(const row of rows){const a=real().accounts.find(a=>a.id===row.id);if(!a)continue;if(row.before===undefined){if(a.gameData){delete a.gameData.sab;if(!Object.keys(a.gameData).length)delete a.gameData;}}else{a.gameData??={};a.gameData.sab=copy(row.before);}views.delete(row.id);}accountViews();}
 const history=[];
 function updateHistory(){const b=document.querySelector('#sab-undo');if(b){b.disabled=!history.length;b.title=history.length?'Undo '+history.at(-1).name:'No SAB actions to undo';}}
 function record(name,before,token){const rows=before.map(row=>({id:row.id,before:row.before,after:copy(raw(real().accounts.find(a=>a.id===row.id)))})).filter(r=>!equal(r.before,r.after));if(!rows.length)return;
  if(token&&history.at(-1)?.token===token){const last=history.at(-1);for(const row of rows){const old=last.rows.find(r=>r.id===row.id);if(old)old.after=row.after;else last.rows.push(row);}}
  else{history.push({name,rows,token});if(history.length>20)history.shift();}updateHistory();
 }
 function undo(count=1){count=Number.isInteger(count)?Math.min(count,history.length):1;if(count<1)return;const staged=new Map(real().accounts.map(a=>[a.id,copy(raw(a))]));for(const action of history.slice(-count).reverse())for(const row of action.rows){if(!staged.has(row.id)||!equal(staged.get(row.id),row.after)){toast('This account changed afterward. Undo would overwrite newer progress.');return;}staged.set(row.id,copy(row.before));}
  const affected=new Set(history.slice(-count).flatMap(e=>e.rows.map(r=>r.id)));restore([...affected].map(id=>({id,before:staged.get(id)})));history.splice(-count);mark();render();updateHistory();toast('Undid '+count+' SAB action'+(count===1?'':'s')+'.');
 }
 function commit(name,accounts,fn){const before=privateCapture(accounts);try{fn();window.RosterIndex?.observe(workspace);sync();record(name,before);mark();}catch(e){restore(before);throw e;}render();}
 function showHistory(){const m=sabModal('SAB undo history','Recent inventory, index and rebirth changes on this device.','Done',({close})=>close());for(const [i,action] of [...history].reverse().entries()){const row=node('div',undefined,'settings-row');row.append(node('strong',action.name),button(i?'Undo through here':'Undo',()=>{undo(i+1);m.dialog.close();},'ghost'));m.body.append(row);}if(!history.length)m.body.append(node('p','No SAB changes to undo.','muted'));}
 window.RosterHistory={capture:privateCapture,record,commit,undo,show:showHistory,clear:()=>{history.length=0;updateHistory();},entries:()=>history.map(x=>({name:x.name,accounts:x.rows.map(r=>r.id)}))};
 function sabModal(title,subtitle,saveLabel,onSave){
  if(editor?.pending())throw Error('Finish the current inventory edit first.');
  const m=modal(title,subtitle,saveLabel,null),d=document.querySelector('#modal'),save=document.querySelector('#modal-save'),foot=document.querySelector('.modal-foot'),error=document.querySelector('#modal-error'),cancel=document.querySelector('#modal-cancel'),originalFoot=[...foot.children],state=node('span','','modal-autosave'),token=crypto.randomUUID();
  let auto=false,pending=false,working=null,timer=null,closed=false,canCloseEmpty=null,ownedEditor=null,unsavedBefore=null;
  save.hidden=!onSave;save.disabled=false;m.dialog=d;m.save=save;m.foot=foot;m.error=error;
  async function run(){clearTimeout(timer);if(working){await working;return pending&&!error.textContent?run():!pending;}if(!pending||closed)return true;
   working=(async()=>{while(pending&&!closed){pending=false;error.textContent='';state.textContent='Autosaving…';const before=unsavedBefore||privateCapture(),historySize=history.length;let wantsClose=false;
    try{renderPaused++;try{await onSave({close:()=>{wantsClose=true;},error,save,autosave:auto});}finally{renderPaused--;}await flush();if(history.length===historySize)record(title,before,token);unsavedBefore=null;state.textContent='Autosaved';if(!auto&&wantsClose)d.close();}
    catch(e){unsavedBefore=before;pending=true;error.textContent=e.message;state.textContent='Not saved — check fields';return false;}}
    return true;})();try{return await working;}finally{working=null;}
  }
  async function finish(after,force=false){if(force)pending=true;if(canCloseEmpty?.()||await run()){if(after)d.addEventListener('close',()=>queueMicrotask(after),{once:true});d.close();render();return true;}return false;}
  m.close=()=>{if(!auto){pending=false;d.close();return Promise.resolve(true);}return finish();};m.finish=after=>finish(after,true);
  const request=()=>{if(!auto||closed)return;pending=true;state.textContent='Waiting to autosave…';clearTimeout(timer);timer=setTimeout(run,400);};
  m.enableAutosave=empty=>{auto=true;canCloseEmpty=empty;cancel.hidden=true;save.replaceChildren(node('span','Done'));foot.prepend(state);state.textContent='Changes autosave';for(const e of ['input','change','click'])m.body.addEventListener(e,request);ownedEditor={flush:run,pending:()=>pending||!!working};editor=ownedEditor;};
  document.querySelector('#modal-form').onsubmit=async e=>{e.preventDefault();save.disabled=true;try{pending=true;await finish();}finally{save.disabled=false;}};
  d.oncancel=e=>{e.preventDefault();m.close();};d.addEventListener('close',()=>{closed=true;clearTimeout(timer);for(const child of [...foot.children])if(!originalFoot.includes(child))child.remove();if(editor===ownedEditor)editor=null;d.oncancel=null;cancel.hidden=false;}, {once:true});
  return m;
 }
 async function waitSaved(){document.activeElement?.blur();if(editor&&!await editor.flush())throw Error('Finish the highlighted inventory fields first.');await flush();}
 function navigate(id){if(id==='accounts'||id==='settings'||id==='clients'||id==='events'){nav(id);return;}if(id==='sab')id='overview';nav('sab-'+id,'109983668079237');}
 function openAccount(a,next='inventory'){selected=typeof a==='string'?a:a.id;const value=next==='sab'?'rebirth':next;subtab=(accountTabs().find(t=>t.id===value||t.view==='sab-'+value)||accountTabs()[0])?.id||value;navigate('account');}
 const catalog={get rebirths(){return pack?.catalogs.rebirths?.rebirths||[];},get images(){return pack?.catalogs.rebirths?.images||{};}};
 function accept(next){if(!next?.catalogs?.inventory)return;pack=next;RosterMutationEffects.accept(pack.catalogs.mutationEffects);
  if(!ready){ready=true;const actions=node('div',undefined,'row sab-actions');document.querySelector('#save-status').parentElement.prepend(actions);
   const bridge={db:workspace,$,node,button,iconButton,input,select,label,panel,heading,empty,icon,avatar,modal:sabModal,changed,render,rpc:(name,args)=>rpc(name==='clients_scan'?'scan':name,args),toast,uid:()=>crypto.randomUUID(),navigate,openAccount,catalog,actions,waitSaved};
   window.RosterPolish={noteItems:(accountId,ids)=>requestAnimationFrame(()=>{for(const id of ids){const el=document.querySelector('[data-item="'+CSS.escape(id)+'"]');if(el){el.classList.add('item-feedback');setTimeout(()=>el.classList.remove('item-feedback'),4500);}}}),info:text=>{const n=node('span','ⓘ','info-hint');n.tabIndex=0;n.title=text;n.setAttribute('aria-label',text);return n;},recordOrder:before=>orderUndo=before,canUndoOrder:()=>!!orderUndo,undoOrder:()=>{}};
   for(const factory of window.SabPortFactories)factory(bridge);
   actions.append(button('Undo',()=>undo(),'ghost','back'),button('History',showHistory,'ghost','clock'));actions.querySelectorAll('button')[actions.querySelectorAll('button').length-2].id='sab-undo';updateHistory();
  }
  RosterInventory.replaceCatalog(pack.catalogs.inventory);RosterIndex.replaceCatalog(pack.catalogs.index);if(remembered){RosterInventory.restoreView(remembered.inventory);RosterIndex.restoreView(remembered.index);RosterPlanning.restoreView(remembered.comparison);remembered=null;}accountViews();if(RosterIndex.observe(workspace)){sync();mark();}
 }
 function renderRebirth(main,a){const p=panel('Rebirth','Requirements follow this account’s inventory.'),levels=[[0,'Rebirth 0'],...catalog.rebirths.map(r=>[r.level,'Rebirth '+r.level])],level=select('Current rebirth',levels,a.sab.level);level.onchange=()=>commit('change rebirth',[a],()=>{a.sab.level=Number(level.value);});p.querySelector('.panel-head').append(level);main.append(p);
  const r=catalog.rebirths.find(r=>r.level===a.sab.level+1);if(!r){p.append(node('p','All listed rebirths are complete.','notice'));return;}
  const stats=node('div',undefined,'stat-row');for(const [name,value] of [['NEXT REBIRTH',r.level],['CASH REQUIRED','$'+r.cash]]){const n=node('div');n.append(node('span',name),node('strong',String(value)));stats.append(n);}p.append(stats);
  const requirements=node('div',undefined,'brainrots');for(const group of RosterInventory.requirements(a,r)){const rot=RosterInventory.catalog().brainrots.find(x=>RosterInventory.normalize(x.name)===RosterInventory.normalize(group.name)),b=button('',()=>RosterInventory.requirementPrompt(a,group.name),'brainrot');b.setAttribute('aria-label',group.name);b.setAttribute('aria-pressed',String(group.candidates.length>=group.needed));const picture=rot?RosterInventory.picture({brainrotId:rot.id,mutation:'default'}):node('div');if(group.candidates.length>=group.needed)picture.append(node('span','✓','check-overlay'));b.append(picture,node('span',group.name));requirements.append(b);}p.append(requirements,button('Complete rebirth '+r.level,()=>RosterInventory.completeRebirth(a,r),'primary section-gap','check'),node('p','Cash is checked manually. Required copies are consumed from inventory; choose which copy when you have extras.','help-text'));
  RosterPlanning.planner(main,a);RosterTools.planner(main,a,r);
 }
 function money(host,a,compact=false){HelperMoney.render(host,{pack,accountId:a.id,compact,read:()=>workspace.accounts.find(x=>x.id===a.id)?.sab.money||{},write:(id,value)=>{const current=workspace.accounts.find(x=>x.id===a.id);if(!current)return;const before=privateCapture([current]);current.sab.money??={};current.sab.money[id]=value;changed();record('change balance',before,'sab-money-'+a.id+'-'+id);}});}
 function accountTabs(){return pack?.accountTabs||[];}
 function renderAccount(main){const a=workspace.accounts.find(a=>a.id===selected);if(!a){navigate('overview');return;}main.append(button('SAB accounts',()=>navigate('overview'),'ghost','back'),heading(a.nickname||a.displayName||a.username,'@'+a.username+' · Steal a Brainrot'));const tabs=node('div',undefined,'tabs sab-subtabs');const current=accountTabs().find(t=>t.id===subtab||t.view==='sab-'+subtab)||accountTabs()[0];for(const t of accountTabs()){const b=button(t.name,()=>{subtab=t.id;render();},current?.id===t.id?'primary':'ghost');b.setAttribute('aria-pressed',String(current?.id===t.id));tabs.append(b);}money(main,a);main.append(tabs);if(current?.view==='sab-inventory')RosterInventory.renderAccount(main,a);else if(current?.view==='sab-gear')HelperSabGear.render(main,a);else if(current?.view==='sab-index')RosterIndex.render(main,a);else if(current?.view==='sab-rebirth')renderRebirth(main,a);else main.append(node('p','Choose an available account tab from the shared catalog.','muted'));}
 function overview(main){main.append(heading(pack.name,'Inventories, rebirths and index progress for each account.'));const grid=node('div',undefined,'account-grid');for(const a of workspace.accounts){const c=node('article',undefined,'account-card'),head=node('div',undefined,'row');head.append(avatar(a),node('strong',a.nickname||a.displayName||a.username));c.append(head,node('small','@'+a.username),RosterInventory.accountRate(a),node('p',RosterInventory.slots(a)+' slots · '+Math.max(0,RosterInventory.slots(a)-(a.sab.inventory||[]).filter(i=>i.slot<RosterInventory.slots(a)).length)+' free','slot-summary'));money(c,a,true);const links=node('div',undefined,'row wrap');for(const t of accountTabs())links.append(button(t.name,()=>{selected=a.id;subtab=t.id;navigate('account');},'ghost'));c.append(links);grid.append(c);}main.append(grid);}
 function renderPage(main,id){saveViews();if(!ready){main.append(node('p','SAB catalog is unavailable. Refresh game content in Settings.','notice'));return;}accountViews();main.classList.add('sab-workspace');if(id==='sab-account')renderAccount(main);else if(id==='sab-inventory')RosterInventory.renderSearch(main);else if(id==='sab-gear')HelperSabGear.render(main);else if(id==='sab-compare')RosterPlanning.comparison(main);else if(id==='sab-checklist')RosterWorkspace.checklist(main);else if(id==='sab-backups')renderBackups(main);else overview(main);requestAnimationFrame(()=>{enhance(main);});}
 function renderBackups(main){main.append(heading('SAB backups','Restore SAB progress without replacing accounts, logins, tags or other games.'));const actions=node('div',undefined,'row wrap');actions.append(button('Create backup',async()=>{try{await waitSaved();await rpc('sab_backup_create');render();}catch(e){toast(e.message);}},'primary','plus'),button('Export SAB progress',async()=>{try{await waitSaved();await rpc('sab_export_file');}catch(e){toast(e.message);}},'ghost'));main.append(actions);const list=node('div',undefined,'section-gap');main.append(list);rpc('sab_backup_list').then(r=>{for(const b of r.backups)list.append(button(b.name+' · '+b.items+' brainrots',()=>previewRestore(b.id),'ghost section-gap'));if(!r.backups.length)list.append(node('p','No SAB snapshots yet.','muted'));}).catch(e=>list.append(node('p',e.message,'notice')));}
 async function previewRestore(id){try{await waitSaved();const r=await rpc('sab_backup_preview',{id}),choice=select('Restore account',[['','All saved accounts'],...r.accounts.map(a=>[a.userId,'@'+a.username])],''),only=input('Restore inventory only','','checkbox'),m=sabModal('Restore SAB snapshot','Current SAB progress is backed up before restoring. Other game data and logins are untouched.','Restore',async({close})=>{const result=await rpc('sab_backup_restore',{id,userId:choice.value?Number(choice.value):0,inventoryOnly:only.checked,expectedRevision:real().revision});HelperMerge.reconcile(real(),result.data);savedBase=copy(real());views.clear();history.length=0;close();render();toast('SAB snapshot restored.');});m.body.append(choice,label('Inventory only',only),node('p',r.items+' brainrots in this snapshot.'));}catch(e){toast(e.message);}}
 function accountLinks(host,id,packId='sab'){if(!ready||packId!=='sab')return;host.append(button('Open SAB inventory',()=>{if(document.querySelector('#modal').open)document.querySelector('#modal').close();openAccount(id);},'ghost section-gap','box'));}
 new MutationObserver(()=>{for(const s of document.querySelectorAll('#modal select'))if(!s.closest('.polished-select'))polishSelect(s,s.getAttribute('aria-label')||'Choose');}).observe(document.documentElement,{childList:true,subtree:true});
 document.addEventListener('keydown',e=>{if(e.ctrlKey&&!e.shiftKey&&e.key.toLowerCase()==='z'&&!document.querySelector('dialog[open]')&&!e.target.closest('input,textarea,[contenteditable]')){e.preventDefault();undo();}});
 return {dialog:sabModal,accept,render:renderPage,openAccount,navigate,waitSaved,accountLinks,workspace,changed,sync,ready:()=>ready};
})();
