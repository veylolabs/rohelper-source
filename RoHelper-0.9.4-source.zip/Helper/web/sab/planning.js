// Ported from local RoRoster (GPL-3.0).
window.SabPortFactories.push(bridge=>{
const {db,$,node,button,iconButton,input,select,label,panel,heading,empty,icon,avatar,modal,changed,render,rpc,toast,uid,navigate,openAccount,catalog}=bridge; const fatal="";
window.RosterPlanning=(()=>{
 const api=()=>RosterInventory,inv=a=>a.sab.inventory||[];
 let comparisonTab='brainrots',arranging=false,dragged=null;
 const picked=[],targets=new Map(),key=(a,item)=>a.id+':'+item.id;
 function reorder(source,target,after=false){
  if(source===target)return;
  const from=db.accounts.findIndex(a=>a.id===source),to=db.accounts.findIndex(a=>a.id===target);
  if(from<0||to<0)return;
  const before=db.accounts.map(a=>a.id);const [account]=db.accounts.splice(from,1);db.accounts.splice(db.accounts.findIndex(a=>a.id===target)+(after?1:0),0,account);RosterPolish.recordOrder(before);changed();
 }
 function orderToolbar(host){const b=button(arranging?'Done arranging':'Arrange accounts',()=>{arranging=!arranging;render();},arranging?'primary':'ghost','accounts');b.setAttribute('aria-pressed',String(arranging));host.append(b);const undo=button('Undo order',()=>RosterPolish.undoOrder(),'ghost');undo.dataset.orderUndo='';undo.disabled=!RosterPolish.canUndoOrder();host.append(undo);}
 function orderCard(card,a,visible,draw){
  if(!arranging)return;
  card.classList.add('account-arranging');
  const grip=node('span','⠿','account-grip');grip.draggable=true;grip.title='Drag to reorder this account. Use Move earlier or Move later with the keyboard.';grip.setAttribute('aria-label','Drag '+a.username);grip.tabIndex=0;
  grip.ondragstart=e=>{dragged=a.id;e.dataTransfer.setData('text/plain',a.id);e.dataTransfer.effectAllowed='move';card.classList.add('dragging');};
  const clear=()=>document.querySelectorAll('.drop-before,.drop-after').forEach(el=>el.classList.remove('drop-before','drop-after'));
  card.ondragover=e=>{if(dragged&&dragged!==a.id){e.preventDefault();clear();e.dataTransfer.dropEffect='move';const r=card.getBoundingClientRect();card.classList.add(e.clientX>r.left+r.width/2?'drop-after':'drop-before');}};
  card.ondragleave=e=>{if(!card.contains(e.relatedTarget))clear();};
  card.ondrop=e=>{e.preventDefault();if(dragged){const r=card.getBoundingClientRect();reorder(dragged,a.id,e.clientX>r.left+r.width/2);dragged=null;clear();draw();}};
  grip.ondragend=()=>{dragged=null;clear();document.querySelectorAll('.dragging').forEach(el=>el.classList.remove('dragging'));};
  const row=node('div',undefined,'row wrap account-order-controls'),index=visible.indexOf(a);
  const move=(delta)=>{const target=visible[index+delta];if(target){reorder(a.id,target.id,delta>0);draw();const current=document.querySelector('[data-account="'+CSS.escape(a.id)+'"] .account-order-controls button:not(:disabled)');current?.focus();}};
  const earlier=button('Move earlier',()=>move(-1),'ghost'),later=button('Move later',()=>move(1),'ghost');earlier.disabled=index===0;later.disabled=index===visible.length-1;
  row.append(grip,earlier,later);card.append(row);
 }
 function plan(a,target){
  const available=db.accounts.flatMap(owner=>inv(owner).map(item=>({owner,item}))),used=new Set();
  const rate=x=>RosterIncome.calculate(x.item,api().catalog())?.perSecond??Infinity;
  available.sort((x,y)=>Number(y.owner===a)-Number(x.owner===a)||Number(x.item.tradeStatus==='keep')-Number(y.item.tradeStatus==='keep')||rate(x)-rate(y)||x.item.slot-y.item.slot);
  return catalog.rebirths.filter(r=>r.level>a.sab.level&&r.level<=target).map(r=>{
   const groups=[];for(const name of r.brainrots){let group=groups.find(g=>g.name===name);if(!group){group={name,needed:0,copies:[]};groups.push(group);}group.needed++;
    const found=available.find(x=>!used.has(key(x.owner,x.item))&&api().normalize(api().brainrot(x.item.brainrotId)?.name||x.item.name)===api().normalize(name));
    if(found){used.add(key(found.owner,found.item));group.copies.push(found);}
   }
   return {rebirth:r,groups,missing:groups.reduce((n,g)=>n+g.needed-g.copies.length,0)};
  });
 }
 function planner(host,a){
  if(!api().catalog())return;
  const remaining=catalog.rebirths.filter(r=>r.level>a.sab.level);if(!remaining.length)return;
  let target=targets.get(a.id)||Math.min(a.sab.level+3,remaining.at(-1).level);target=Math.max(remaining[0].level,Math.min(target,remaining.at(-1).level));
  const p=panel('Rebirth planner','Plan ahead using the brainrots stored across your accounts.');p.classList.add('rebirth-planner');
  const choice=select('Plan through rebirth',remaining.map(r=>[r.level,'Rebirth '+r.level]),target);
  choice.onchange=()=>{targets.set(a.id,Number(choice.value));draw();};p.querySelector('.panel-head').append(label('Plan through',choice));
  const content=node('div');p.append(node('p','Each stored copy is allocated once across this plan. Copies on this account are used first, then lower-income copies. Planning does not move or consume items.','sab-banner'),content);host.append(p);
  function draw(){content.replaceChildren();const steps=plan(a,Number(choice.value)),missing=steps.reduce((n,s)=>n+s.missing,0),away=steps.flatMap(s=>s.groups.flatMap(g=>g.copies)).filter(x=>x.owner!==a).length;
   content.append(node('p',steps.length+' rebirths planned · '+missing+' copies missing · '+away+' copies on other accounts','planner-total'));
   for(const step of steps){const card=node('section',undefined,'rebirth-plan-step');card.dataset.rebirth=step.rebirth.level;
    const capacity=api().slots({...a,sab:{...a.sab,level:step.rebirth.level}});
    card.append(node('h3','Rebirth '+step.rebirth.level),node('p','$'+step.rebirth.cash+' required · '+capacity+' slots after rebirth · '+(step.missing?step.missing+' copies missing':'Brainrots accounted for'),'muted'));
    for(const group of step.groups){const row=node('div',undefined,'rebirth-plan-requirement');row.append(node('strong',group.name+' · '+group.copies.length+' / '+group.needed));
     for(const {owner,item} of group.copies){const copy=node('div',undefined,'plan-copy');copy.append(api().picture(item),node('span',owner===a?'Here · slot '+(item.slot+1):'@'+owner.username+' · slot '+(item.slot+1)),node('small',(api().catalog().mutations.find(m=>m.id===item.mutation)?.name||item.mutation)+(item.tradeStatus==='keep'?' · Marked Keep':'')),button('View copy',()=>RosterWorkspace.openItem(owner.id,item.id),'ghost'));row.append(copy);}
     if(group.copies.length<group.needed)row.append(node('span',(group.needed-group.copies.length)+' still needed','plan-missing'));card.append(row);
    }content.append(card);
   }
   content.append(node('p','Cash requirements apply separately at each rebirth. Cash balances are not tracked here. Complete rebirths with the existing button above when you are ready.','muted'));
  }draw();
 }
 function selectedItems(){return picked.map(k=>db.accounts.flatMap(a=>inv(a).map(item=>({a,item}))).find(x=>key(x.a,x.item)===k)).filter(Boolean);}
 function chooseItem(){
  const m=modal('Choose a brainrot to compare','Select up to four stored brainrots across your accounts.','Done',({close})=>close());
  const search=input('Search comparison brainrots'),account=select('Comparison account',[['','All accounts'],...db.accounts.map(a=>[a.id,'@'+a.username])],''),mutation=api().mutationSelect('Comparison mutation','',true),bar=node('div',undefined,'toolbar comparison-picker-tools'),list=node('div',undefined,'comparison-picker');search.placeholder='Search brainrots, traits, accounts…';bar.append(search,account,mutation);m.body.append(bar,list);
  function draw(){list.replaceChildren();const q=search.value.toLowerCase().trim(),rows=db.accounts.filter(a=>!account.value||a.id===account.value).flatMap(a=>inv(a).map(item=>({a,item}))).filter(({a,item})=>(!mutation.value||item.mutation===mutation.value)&&[item.name,a.username,a.nickname,...item.traits.map(id=>api().catalog().traits.find(t=>t.id===id)?.name||id)].join(' ').toLowerCase().includes(q));
   if(!rows.length)list.append(node('p','No stored brainrots match.','muted'));
   for(const {a,item} of rows){const id=key(a,item),has=picked.includes(id),row=node('article',undefined,'comparison-picker-row'),text=node('div');text.append(node('strong',item.name),node('small','@'+a.username+' · slot '+(item.slot+1)),api().summary(item));
    const b=button(has?'Added':'Compare',()=>{if(picked.includes(id)||picked.length>=4)return;picked.push(id);m.dialog.close();render();},'ghost');b.disabled=has||picked.length>=4;row.append(api().picture(item),text,b);list.append(row);}
  }search.oninput=draw;account.onchange=draw;mutation.onchange=draw;draw();search.focus();
 }
 function comparison(main){
  const tabs=node('div',undefined,'tabs comparison-tabs');for(const [id,title] of [['brainrots','Brainrots'],['accounts','Accounts']]){const b=button(title,()=>{comparisonTab=id;render();},comparisonTab===id?'active':'');b.setAttribute('aria-pressed',String(comparisonTab===id));tabs.append(b);}main.append(tabs);
  if(comparisonTab==='accounts'){RosterTools.comparison(main);return;}
  const rows=selectedItems();picked.splice(0,picked.length,...rows.map(({a,item})=>key(a,item)));
  const add=button('Add brainrot',chooseItem,'primary','plus');add.disabled=!api().catalog()||rows.length>=4;
  main.append(heading('Brainrot comparison','Compare your stored copies, including their mutation and traits.',[add,button('Clear comparison',()=>{picked.length=0;render();},'ghost')]));
  if(!api().catalog()){main.append(node('p','Loading catalog…'));return;}
  if(!rows.length){main.append(empty('Choose brainrots to compare','Add up to four copies from any account. Compare income, rarity, exist counts and EUR asking prices.',null,'box'));return;}
  const incomes=rows.map(({item})=>RosterIncome.calculate(item,api().catalog())),known=incomes.filter(Boolean).map(r=>r.perSecond),max=known.length?Math.max(...known):0,baseline=incomes[0]?.perSecond;
  const grid=node('div',undefined,'brainrot-comparison-grid');main.append(grid);
  rows.forEach(({a,item},index)=>{const rot=api().brainrot(item.brainrotId),income=incomes[index],card=node('article',undefined,'panel brainrot-compare-card');card.dataset.compareItem=item.id;
   const head=node('div',undefined,'row spread');head.append(node('h2',rot?.name||item.name),iconButton('close','Remove '+item.name+' from comparison',()=>{picked.splice(picked.indexOf(key(a,item)),1);render();}));
   card.append(head,button('@'+a.username+' · slot '+(item.slot+1),()=>RosterWorkspace.openItem(a.id,item.id),'ghost'),api().picture(item));const mutationLabel=node('span',api().catalog().mutations.find(m=>m.id===item.mutation)?.name||item.mutation,'mutation-badge');mutationLabel.style.color=api().mutationColor(item.mutation);card.append(mutationLabel);
   const stats=node('dl',undefined,'comparison-stats');const stat=(name,value,cls='')=>stats.append(node('dt',name),node('dd',value,cls));
   stat('Rarity',rot?.rarity||'Unavailable');stat('Money / second',income?api().cash(income.perSecond)+'/s':'Unavailable',income?.perSecond===max?'stat-best':'');
   if(index===0)stat('Compared with first','Reference item');else if(income&&Number.isFinite(baseline)){const delta=income.perSecond-baseline;stat('Compared with first',(delta>=0?'+':'−')+api().cash(Math.abs(delta))+'/s'+(baseline?' ('+(delta>=0?'+':'')+(delta/baseline*100).toFixed(1)+'%)':''),'stat-difference');}else stat('Compared with first','Unavailable');
   const traits=node('div',undefined,'row wrap compare-traits');for(const id of item.traits)traits.append(api().traitIcon(id));if(!item.traits.length)traits.append(node('small','No traits','muted'));card.append(stats,traits);
   const meter=node('progress');meter.max=max||1;meter.value=income?.perSecond||0;meter.setAttribute('aria-label','Relative income for '+item.name);const meterBox=node('div',undefined,'comparison-meter');meterBox.append(meter,node('small',income?'Before account and base boosts.':'Income is unknown for this combination.','muted'));card.append(meterBox);
   const extra=node('div'),calc=node('details',undefined,'comparison-extra');calc.append(node('summary','Income calculation'));calc.append(node('p',income?api().cash(income.base)+'/s base × ('+income.mutation+' mutation + '+income.traits+' traits)'+(income.factor!==1?' × '+income.factor:''):'No reliable base income or multiplier is available.'));extra.append(calc);if(rot)extra.append(RosterMarket.details(rot,item,api().catalog()));card.append(extra);grid.append(card);
  });
 }
 function addComparison(a,item){const id=key(a,item);if(!picked.includes(id)){if(picked.length>=4){toast('Remove a comparison item first (maximum four).');return;}picked.push(id);}comparisonTab='brainrots';navigate('compare');}
 function view(){return {comparisonTab,picked:[...picked],targets:[...targets]};}
 function restoreView(s){if(!s||typeof s!=='object')return;if(['brainrots','accounts'].includes(s.comparisonTab))comparisonTab=s.comparisonTab;if(Array.isArray(s.picked))picked.splice(0,picked.length,...s.picked.filter(x=>typeof x==='string'&&x.length<300).slice(0,4));if(Array.isArray(s.targets))for(const entry of s.targets.slice(0,500)){if(Array.isArray(entry)&&typeof entry[0]==='string'&&Number.isInteger(entry[1]))targets.set(entry[0],entry[1]);}}
 return {view,restoreView,addComparison,orderToolbar,orderCard,reorder,plan,planner,comparison};
})();

});
