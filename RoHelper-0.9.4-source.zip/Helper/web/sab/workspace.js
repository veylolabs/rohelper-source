// Ported from local RoRoster (GPL-3.0).
window.SabPortFactories.push(bridge=>{
const {db,$,node,button,iconButton,input,select,label,panel,heading,empty,icon,avatar,modal,changed,render,rpc,toast,uid,navigate,openAccount,catalog}=bridge; const fatal="";
window.RosterWorkspace=(()=>{
 const inventory=a=>a.sab.inventory||[],name=a=>a.nickname||a.displayName||a.username;
 const arranging=new Set(),picked=new Map();let checklistFilter='all',removedTasks=null;
 function session(create=false){if(create&&!db.sessionChecklist)db.sessionChecklist={title:'This session',items:[]};return db.sessionChecklist||{title:'This session',items:[]};}
 function addTask(text,accountId=''){
  const s=session(true);text=text.trim();if(!text||text.length>300)throw Error('Use a task between 1 and 300 characters.');
  if(s.items.some(i=>!i.done&&i.text===text&&i.accountId===accountId)){toast('Already on your checklist.');return;}
  if(s.items.length>=500)throw Error('The checklist is full. Remove completed tasks first.');
  s.items.push({id:uid(),text,accountId,done:false});changed();toast('Added to your session checklist.');
 }
 function checklist(main){
  main.append(heading('Session checklist','A shared to-do list for your accounts. Autosaved and kept when RoHelper closes.'));
  const s=session(),title=input('Session name',s.title);title.maxLength=120;title.oninput=()=>{session(true).title=title.value;changed();};
  const p=panel('Your session'),progress=node('p','','muted'),bar=node('div',undefined,'toolbar session-add'),text=input('New session task');text.maxLength=300;text.placeholder='What do you want to finish?';
  const account=select('Task account',[['','Any account'],...db.accounts.map(a=>[a.id,name(a)+' · @'+a.username])],'');
  const add=()=>{try{addTask(text.value,account.value);text.value='';draw();text.focus();}catch(e){toast(e.message);}};
  text.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();add();}};bar.append(text,account,button('Add task',add,'primary','plus'));
  const filters=node('div',undefined,'row wrap'),view=select('Checklist filter',[['all','All tasks'],['open','To do'],['done','Completed']],checklistFilter);
  view.onchange=()=>{checklistFilter=view.value;draw();};
  const undo=button('Undo removal',()=>{if(!removedTasks)return;const target=session(true);if(target.items.length+removedTasks.length>500){toast('Not enough room to restore those tasks.');return;}target.items.push(...removedTasks.filter(i=>!target.items.some(t=>t.id===i.id)));removedTasks=null;changed();draw();},'ghost');
  const clear=button('Clear completed',()=>{const target=session(true),done=target.items.filter(i=>i.done);if(!done.length)return;removedTasks=structuredClone(done);target.items=target.items.filter(i=>!i.done);changed();draw();},'ghost');filters.append(view,clear,undo);
  const list=node('div',undefined,'session-list');p.append(label('Session name',title),progress,bar,filters,list);main.append(p);
  function draw(){const current=session();list.replaceChildren();const done=current.items.filter(i=>i.done).length;progress.textContent=done+' / '+current.items.length+' completed';clear.disabled=!done;undo.hidden=!removedTasks;
   for(const task of current.items.filter(i=>checklistFilter==='all'||i.done===(checklistFilter==='done'))){
    const row=node('article',undefined,'session-task'+(task.done?' completed':''));row.dataset.taskId=task.id;
    const check=input('Complete '+task.text,'','checkbox');check.checked=task.done;check.onchange=()=>{task.done=check.checked;window.RosterSessions?.completed(task);changed();draw();};
    const edit=input('Task text',task.text);edit.maxLength=300;edit.oninput=()=>{const value=edit.value.trim();if(!value)return;task.text=value;check.setAttribute('aria-label','Complete '+value);changed();};edit.onblur=()=>{if(!edit.value.trim())edit.value=task.text;};
    const owner=db.accounts.find(a=>a.id===task.accountId),link=owner?button('@'+owner.username,()=>openAccount(owner),'ghost'):node('small',task.accountId?'Account removed':'Any account','muted');
    row.append(check,edit,link,iconButton('trash','Remove task',()=>{removedTasks=[structuredClone(task)];session(true).items=current.items.filter(i=>i.id!==task.id);changed();draw();}));window.RosterSessions?.decorateTask(row,task,check);list.append(row);
   }
   if(!list.children.length)list.append(node('p',current.items.length?'No tasks in this view.':'Add a task above, or queue an item from the index helper.','muted section-gap'));
  }draw();
 }
 function inventoryToolbar(host,a){
  const group=node('div',undefined,'row inventory-view-switch');group.setAttribute('aria-label','Inventory view');
  for(const [value,label] of [['cards','Cards'],['base','Base layout']]){const b=button(label,()=>{db.settings.inventoryView=value;changed();render();},(db.settings.inventoryView||'cards')===value?'primary':'ghost');b.setAttribute('aria-pressed',String((db.settings.inventoryView||'cards')===value));group.append(b);}host.append(group);
 }
 function floors(capacity){const result=[],ends=[10,18,28];let start=0,n=0;while(start<capacity){const end=Math.min(capacity,ends[n]??start+10);result.push({number:++n,start,end});start=end;}return result;}
 function place(a,itemId,slot){
  const current=db.accounts.find(x=>x.id===a.id),item=current&&inventory(current).find(i=>i.id===itemId);
  if(!current||!item)throw Error('This item is no longer in that account.');
  if(!Number.isInteger(slot)||slot<0||slot>=RosterInventory.slots(current))throw Error('That slot is locked.');
  if(item.slot===slot){picked.delete(a.id);render();return;}
  const other=inventory(current).find(i=>i.slot===slot);
  RosterHistory.commit(other?'swap base slots':'move base slot',[current],()=>{const previous=item.slot;item.slot=slot;if(other)other.slot=previous;picked.delete(a.id);});RosterPolish.noteItems(a.id,[item.id,...(other?[other.id]:[])]);
 }
 function baseLayout(host,a,slotCard){
  const capacity=RosterInventory.slots(a),tools=node('div',undefined,'row wrap base-tools'),isArranging=arranging.has(a.id);
  const source=inventory(a).find(i=>i.id===picked.get(a.id));if(!source)picked.delete(a.id);
  const toggle=button(isArranging?'Finish arranging':'Arrange slots',()=>{isArranging?arranging.delete(a.id):arranging.add(a.id);picked.delete(a.id);render();},isArranging?'primary':'ghost','trade');tools.append(toggle,node('small',isArranging?(source?'Choose a destination. Occupied slots swap places.':'Choose Move slot, then a destination; or drag an item.'):'Slot changes update your local notebook.','muted'));host.append(tools);
  for(const floor of floors(capacity)){
   const section=node('section',undefined,'base-floor');section.dataset.floor=floor.number;
   const held=inventory(a).filter(i=>i.slot>=floor.start&&i.slot<floor.end),head=node('div',undefined,'row spread');head.append(node('h3','Floor '+floor.number),node('small',held.length+' / '+(floor.end-floor.start)+' occupied · '+(floor.end-floor.start-held.length)+' free'));
   const grid=node('div',undefined,'base-floor-grid');
   for(let slot=floor.start;slot<floor.end;slot++){
    const card=slotCard(a,slot),item=inventory(a).find(i=>i.slot===slot);const offset=slot-floor.start;card.style.gridColumn=offset<5?'1':'2';card.style.gridRow=String(offset<5?5-offset:floor.number===2||floor.number===3?10-offset:offset-4);card.classList.toggle('base-picked',!!item&&source?.id===item.id);
    if(isArranging){
     if(source)card.prepend(button(item?.id===source.id?'Cancel move':item?'Swap here':'Place here',()=>{try{place(a,source.id,slot);}catch(e){toast(e.message);}},'ghost base-arrange-action'));
     else if(item)card.prepend(button('Move slot',()=>{picked.set(a.id,item.id);render();},'ghost base-arrange-action'));
     card.draggable=!!item;card.addEventListener('dragstart',e=>{if(!item)return;e.dataTransfer.setData('application/x-roroster-slot',JSON.stringify({accountId:a.id,itemId:item.id}));e.dataTransfer.effectAllowed='move';});
     card.addEventListener('dragover',e=>{if([...e.dataTransfer.types].includes('application/x-roroster-slot')){e.preventDefault();e.dataTransfer.dropEffect='move';}});
     card.addEventListener('drop',e=>{e.preventDefault();try{const value=JSON.parse(e.dataTransfer.getData('application/x-roroster-slot'));if(value.accountId!==a.id)throw Error('Use Move to account for transfers between accounts.');place(a,value.itemId,slot);}catch(err){toast(err.message);}});
    }grid.append(card);
   }section.append(head,grid);host.append(section);
  }
 }
 function openItem(accountId,itemId){const a=db.accounts.find(x=>x.id===accountId),item=a&&inventory(a).find(i=>i.id===itemId);if(!item){toast('This item is no longer in that account.');return;}openAccount(a,'inventory');requestAnimationFrame(()=>{const el=document.querySelector('[data-inventory-id="'+CSS.escape(item.id)+'"]');if(el){el.scrollIntoView({block:'center'});el.classList.add('command-highlight');el.tabIndex=-1;el.focus({preventScroll:true});}});}
 const normalize=s=>String(s).normalize('NFKD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 const pages=[['accounts','Accounts'],['events','Events & timers'],['clients','Running clients'],['settings','Settings']];
 function searchCommands(value){const tokens=normalize(value).trim().split(/\s+/).filter(Boolean),results=[];let total=0;
  function add(label,detail,run,extra=''){if(!tokens.every(t=>normalize(label+' '+detail+' '+extra).includes(t)))return;total++;if(results.length<60)results.push({label,detail,run});}
  for(const [key,label] of pages)add(label,'Page',()=>navigate(key));
  for(const pack of HelperGames.packs())for(const tab of HelperGames.flatten(HelperGames.navigation(pack)))add(tab.name,'Game · '+pack.name,()=>HelperGames.open(pack.id,tab.id),pack.aliases.join(' '));
  for(const a of db.accounts){add(name(a),'Account · @'+a.username,()=>openAccount(a),a.displayName+' '+db.tags.filter(t=>a.tags.includes(t.id)).map(t=>t.name).join(' '));
   if(tokens.length)for(const item of inventory(a)){const rot=RosterInventory.brainrot(item.brainrotId),mutation=RosterInventory.catalog()?.mutations.find(m=>m.id===item.mutation)?.name||item.mutation;add(rot?.name||item.name,'@'+a.username+' · '+mutation+' · slot '+(item.slot+1),()=>openItem(a.id,item.id),name(a)+' '+(rot?.rarity||''));}
  }return {results,total};
 }
 let commandDialog=null;
 function quickSearch(){if(!db||fatal)return;if(commandDialog?.open){commandDialog.close();return;}if(document.querySelector('dialog[open]')){toast('Finish the current dialog before using quick search.');return;}
  const previous=document.activeElement,d=node('dialog',undefined,'command-dialog');d.id='command-palette';d.setAttribute('aria-label','Quick command search');commandDialog=d;
  const top=node('div',undefined,'row'),q=input('Quick command search');q.placeholder='Search accounts, stored brainrots, or pages…';q.autocomplete='off';q.setAttribute('role','combobox');q.setAttribute('aria-expanded','true');q.setAttribute('aria-controls','command-results');q.setAttribute('aria-autocomplete','list');top.append(icon('search'),q,iconButton('close','Close quick search',()=>d.close()));
  const list=node('div',undefined,'command-results');list.id='command-results';list.setAttribute('role','listbox');list.setAttribute('aria-label','Search results');const hint=node('small','','muted');hint.setAttribute('role','status');d.append(top,list,hint);document.body.append(d);
  let result=[],active=0;
  const activate=()=>{for(const [i,b] of [...list.children].entries()){b.setAttribute('aria-selected',String(i===active));}q.setAttribute('aria-activedescendant',result.length?'command-result-'+active:'');list.children[active]?.scrollIntoView({block:'nearest'});};
  const choose=()=>{const entry=result[active];if(entry){d.close();entry.run();}};
  const draw=()=>{const found=searchCommands(q.value);result=found.results;active=0;list.replaceChildren();for(const [i,r] of result.entries()){const b=button('',()=>{active=i;choose();},'command-result');b.id='command-result-'+i;b.setAttribute('role','option');b.tabIndex=-1;b.append(node('strong',r.label),node('small',r.detail));list.append(b);}hint.textContent=found.total?found.total+' results'+(found.total>60?' · showing first 60; refine your search':'')+' · ↑ ↓ to choose · Enter to open · Esc to close':'No matching accounts, stored brainrots, or pages.';activate();};
  q.oninput=draw;q.onkeydown=e=>{if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();if(result.length){active=(active+(e.key==='ArrowDown'?1:-1)+result.length)%result.length;activate();}}else if(e.key==='Enter'){e.preventDefault();choose();}};
  d.addEventListener('close',()=>{commandDialog=null;d.remove();if(previous?.isConnected)previous.focus({preventScroll:true});},{once:true});d.showModal();draw();q.focus();
 }
 const launch=button('Search',quickSearch,'ghost','search');launch.id='quick-command';launch.title='Quick search (Ctrl+K)';launch.append(node('kbd','Ctrl K'));bridge.actions.prepend(launch);
 document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&!e.altKey&&e.key.toLowerCase()==='k'){e.preventDefault();quickSearch();}});
 function reset(){arranging.clear();picked.clear();removedTasks=null;checklistFilter='all';commandDialog?.close();}
 function view(){return {checklistFilter};}function restoreView(s){if(s&&['all','open','done'].includes(s.checklistFilter))checklistFilter=s.checklistFilter;}
 return {view,restoreView,checklist,addTask,inventoryToolbar,baseLayout,floors,place,openItem,quickSearch,searchCommands,reset};
})();

});
