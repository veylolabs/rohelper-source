// Orders are maintained in the shared catalog. Stable IDs are untouched.
window.RosterCatalogOrder={apply(data){data.mutations.sort((a,b)=>(a.menuOrder??50)-(b.menuOrder??50));data.traits.sort((a,b)=>(a.menuOrder??500)-(b.menuOrder??500));}};
