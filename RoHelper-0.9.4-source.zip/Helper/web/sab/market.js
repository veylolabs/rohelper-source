// Ported from local RoRoster (GPL-3.0).
window.SabPortFactories.push(bridge=>{
const {db,$,node,button,iconButton,input,select,label,panel,heading,empty,icon,avatar,modal,changed,render,rpc,toast,uid,navigate,openAccount,catalog}=bridge; const fatal="";
window.RosterMarket=(()=>{
 let snapshot=null,busy=false,started=false,warning='',bySlug=new Map(),byName=new Map();
 const views=new Set(),normalize=s=>String(s).normalize('NFKD').toLowerCase().replace(/[^a-z0-9]/g,'');
 const date=value=>new Date(value).toLocaleString(undefined,{dateStyle:'medium',timeStyle:'short'});
 function lookup(rot){const slug=rot.page?.match(/^https:\/\/sabexistcount\.com\/products\/([a-z0-9-]+)/)?.[1];return bySlug.get(slug)||byName.get(normalize(rot.name));}
 function notify(){for(const v of views){if(v.el.isConnected)v.draw();else views.delete(v);}}
 async function refresh(force=false){
  if(busy)return;busy=true;started=true;notify();
  try{const r=await rpc('exist_counts',{force});warning=r.warning||'';if(r.snapshot){snapshot=r.snapshot;bySlug=new Map(snapshot.entries.map(e=>[e.slug,e]));byName=new Map();for(const e of snapshot.entries){const key=normalize(e.name);byName.set(key,byName.has(key)?null:e);}}}
  catch(e){warning=e.message;}finally{busy=false;notify();}
 }
 function sourceLink(text,url){const link=node('a',text);link.href=url;link.target='_blank';link.rel='noopener noreferrer';return link;}
 function details(rot,item,catalog){
  const el=node('section',undefined,'market-details'),count=node('div',undefined,'exist-details'),prices=node('div',undefined,'market-prices');
  el.addEventListener('click',e=>e.stopPropagation());
  const income=RosterIncome.calculate(item,catalog)?.perSecond??null;
  const mutation=item.mutation==='default'?'none':item.mutation==='yinyang'?'yin-yang':item.mutation;
  const marketUrl='https://www.eldorado.gg/steal-a-brainrot-brainrots/i/259?searchQuery='+encodeURIComponent(rot.name)+'&steal-a-brainrot-mutations='+encodeURIComponent(mutation);
  const draw=()=>{
   count.replaceChildren();const entry=lookup(rot);
   count.append(node('strong','Exist count'));
   const value=!started||busy&&!snapshot?'Checking…':entry?.status==='estimated'?'Estimated '+entry.label:entry?.status==='reported'?'Reported '+entry.label:'Unavailable';
   count.append(node('span',value,'exist-value'));
   if(entry?.mutation)count.append(node('small',(/^default$/i.test(entry.mutation.name)?'Normal':entry.mutation.name)+' mutation: '+entry.mutation.label));
   if(entry?.trait)count.append(node('small',entry.trait.name+' trait: '+entry.trait.label));
   if(item.traits.length||!['default','normal'].includes(item.mutation))count.append(node('small','Overall brainrot count; your exact combination may differ.'));
   if(snapshot){count.append(node('small','Checked '+date(snapshot.checkedAt)));if(snapshot.sourceUpdatedAt)count.append(node('small','Source snapshot '+date(snapshot.sourceUpdatedAt)));}
   const actions=node('div',undefined,'row wrap');const update=button(busy?'Refreshing…':'Refresh counts',()=>refresh(true),'ghost');update.disabled=busy;
   actions.append(update,sourceLink('SABExistCount',entry?'https://sabexistcount.com/products/'+entry.slug:'https://sabexistcount.com/sab-exist-count-list'));count.append(actions);
   if(warning)count.append(node('small',warning+(snapshot?' Showing saved counts.':''),'error-box'));
  };
  // Removing stale views here also keeps opening/closing editors bounded.
  for(const view of views)if(!view.el.isConnected)views.delete(view);
  views.add({el,draw});draw();el.append(count,prices);
   const check=button('Check Eldorado price',async()=>{
   check.disabled=true;prices.replaceChildren(node('strong','Checking Eldorado…'));
   try{
    const result=await rpc('eldorado_price',{brainrotId:rot.id,mutation:item.mutation,perSecond:income});
    renderPrice(prices,result.quote,check);
   }catch(e){prices.replaceChildren(node('small',e.message,'error-box'),sourceLink('Open Eldorado',marketUrl),check);}
   finally{check.disabled=false;}
  },'ghost');check.disabled=!Number.isFinite(income)||income<=0;
  prices.append(check,node('small',check.disabled?'No known income for this item. Choose a brainrot with a published rate.':'Closest income matches for the same brainrot and mutation. EUR asking prices.'));
  if(!started)queueMicrotask(()=>refresh());
  return el;
 }
 function renderPrice(el,quote,button){
  el.replaceChildren(node('strong','Eldorado asking prices'));
  const eur=n=>new Intl.NumberFormat(undefined,{style:'currency',currency:'EUR'}).format(n);
  if(quote.average!=null){el.append(node('span',eur(quote.average)+' average · '+eur(quote.median)+' median','market-value'),node('small',quote.matches.length+' closest listings · '+quote.sellers+' sellers'));
   el.append(node('small','Income range '+quote.incomeMin.toLocaleString()+'–'+quote.incomeMax.toLocaleString()+'/s'));
   if(quote.message)el.append(node('small',quote.message));
  }else el.append(node('small',quote.message||'No comparable listings found.'));
  if(quote.matches?.length){const list=node('details',undefined,'market-matches');list.append(node('summary','View comparable listings'));for(const offer of quote.matches)list.append(sourceLink(eur(offer.price)+' · '+offer.perSecond.toLocaleString()+'/s',offer.url));el.append(list);}
  if(quote.checkedAt)el.append(node('small','Checked '+date(quote.checkedAt)));
  el.append(node('small','Up to 10 nearest listings within 25% of your income; one listing per seller.'));
  if(quote.scanned<quote.total)el.append(node('small','Compared the first '+quote.scanned+' of '+quote.total+' search results.'));
  el.append(node('small','EUR asking prices before fees; not completed trades. Traits are represented by income.'),sourceLink('Open Eldorado',quote.url),button);
 }
 setInterval(()=>{if([...views].some(v=>v.el.isConnected))refresh();},30*60*1000);
 return {details,refresh};
})();

});
