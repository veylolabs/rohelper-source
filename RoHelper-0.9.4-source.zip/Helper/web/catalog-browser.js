'use strict';
// A global reference catalog is separate from each account's acquired index.
window.HelperCatalog=(()=>{
 let query='',rarity='',owner='',sort='name',type='';
 function render(host,pack){
  const catalog=pack.catalogs.inventory,gear=pack.catalogs.gear;if(!catalog||!HelperSab.ready()){host.append(empty('Catalog unavailable','Refresh game content in Settings.'));return;}
  if(owner&&!db.accounts.some(a=>a.id===owner))owner='';host.classList.add('sab-workspace');host.append(heading('Steal a Brainrot catalog','Browse brainrots and gear. Account ownership and index checks stay separate.'));
  const tabs=node('div',undefined,'row wrap catalog-tabs');for(const [id,name] of [['','All items'],['brainrots','Brainrots'],['gear','Gear']]){const pick=button(name,()=>{type=id;renderMain();},type===id?'primary':'ghost');pick.setAttribute('aria-pressed',String(type===id));tabs.append(pick);}host.append(tabs);
  const bar=node('div',undefined,'catalog-toolbar'),q=input('Search SAB catalog',query),r=select('Catalog rarity',[['','All rarities'],...[...new Set(catalog.brainrots.map(r=>r.rarity).filter(Boolean))].map(v=>[v,v])],rarity),a=select('Catalog account',[['','All accounts'],...db.accounts.map(a=>[a.id,'@'+a.username])],owner),order=select('Catalog order',[['name','Name A–Z'],['income','Base income: high to low'],['rarity','Rarity']],sort);q.placeholder='Search all items…';bar.append(q);if(type!=='gear')bar.append(r);bar.append(a,order);host.append(bar);const count=node('p','','muted'),grid=node('div',undefined,'catalog-grid');host.append(count,grid);
  function draw(){grid.replaceChildren();const rank=['Common','Rare','Epic','Legendary','Mythic','Brainrot God','Secret','OG'],rows=[...(type!=='gear'?catalog.brainrots.filter(r=>!r.hiddenFromPicker&&(!rarity||r.rarity===rarity)).map(ref=>({ref,type:'brainrots'})):[]),...(type!=='brainrots'&&(!rarity||type==='gear')?(gear?.entries||[]).map(ref=>({ref,type:'gear'})):[])].filter(x=>[x.ref.name,...(x.ref.aliases||[])].join(' ').toLowerCase().includes(query.toLowerCase())).sort((a,b)=>sort==='income'?(b.ref.baseIncome??-1)-(a.ref.baseIncome??-1):sort==='rarity'?rank.indexOf(b.ref.rarity)-rank.indexOf(a.ref.rarity):a.ref.name.localeCompare(b.ref.name));count.textContent=rows.length+' catalog entries';
   for(const row of rows){const ref=row.ref,isGear=row.type==='gear',c=button('',()=>isGear?HelperSabGear.details(ref):details(ref,pack),'catalog-card catalog-entry');c.dataset.catalogId=ref.id;c.dataset.catalogType=row.type;c.append(isGear?HelperSabGear.art(ref):RosterInventory.picture({brainrotId:ref.id,mutation:'default'}),node('strong',ref.name),node('small',isGear?'Gear · '+(ref.group||'Unknown source'):ref.rarity||'Unknown rarity'));if(isGear)c.append(node('small',ref.acquisition||'Source unknown'));else c.append(node('small',Number.isFinite(ref.baseIncome)?RosterInventory.cash(ref.baseIncome)+'/s':'Income unknown'));const held=HelperSab.workspace.accounts.filter(a=>!owner||a.id===owner).reduce((n,a)=>n+(isGear?HelperSabGear.items(a).filter(i=>i.gearId===ref.id).length:a.sab.inventory.filter(i=>i.brainrotId===ref.id).length),0);if(held)c.append(node('span',held+' in inventory','catalog-owned'));grid.append(c);}if(!rows.length)grid.append(empty('No matching items','Try another search, rarity or item type.'));
  }
  q.oninput=()=>{query=q.value;draw();};r.onchange=()=>{rarity=r.value;draw();};a.onchange=()=>{owner=a.value;draw();};order.onchange=()=>{sort=order.value;draw();};draw();enhance(bar);
 }

 function details(rot,pack,initial={}){
  const catalog=pack?.catalogs.inventory||RosterInventory.catalog(),draft={brainrotId:rot.id,mutation:initial.mutation||'default',traits:[...(initial.traits||[])]};
  const m=HelperSab.dialog(rot.name,'Brainrot reference','Done',({close})=>close()),preview=node('div',undefined,'catalog-detail-top'),mutation=RosterInventory.mutationSelect('Catalog mutation',draft.mutation,false,true),traitQuery=input('Search catalog traits'),traits=node('div',undefined,'trait-picker');
  m.dialog.classList.add('inventory-dialog');
  function show(){preview.replaceChildren();const info=node('div');info.append(RosterInventory.summary(draft),RosterInventory.price(rot,true),RosterMarket.details(rot,draft,catalog));preview.append(RosterInventory.picture(draft,true),info);}
  function drawTraits(){traits.replaceChildren();for(const t of catalog.traits.filter(t=>t.name.toLowerCase().includes(traitQuery.value.toLowerCase()))){const b=RosterInventory.traitIcon(t.id,true);b.setAttribute('aria-pressed',String(draft.traits.includes(t.id)));b.onclick=()=>{draft.traits=draft.traits.includes(t.id)?draft.traits.filter(id=>id!==t.id):[...draft.traits,t.id];show();drawTraits();};traits.append(b);}}
  mutation.onchange=()=>{draft.mutation=mutation.value;show();};traitQuery.oninput=drawTraits;
  const add=button('Add to inventory',()=>HelperItemDestinations.brainrot({...rot,mutation:draft.mutation,traits:[...draft.traits]}),'inventory-reference-add','plus');
  m.foot.insertBefore(add,m.save);m.body.append(preview,label('Mutation',mutation),label('Traits',traitQuery),traits);show();drawTraits();enhance(m.body);
 }
 return {render,details};
})();
