// Shared RoPilot accent control (GPL-3.0).
window.setupAccentPicker = function(input, button, panel) {
    panel.className = 'accent-palette'; panel.hidden = true;
    button.setAttribute('aria-expanded','false'); button.setAttribute('aria-label','Choose accent color');
    const title = document.createElement('div'); title.className = 'tile-dropdown-header'; title.textContent = 'Accent color'; panel.append(title);
    const swatches = document.createElement('div'); swatches.className = 'accent-swatches'; panel.append(swatches);
    const colors = ['#818cf8','#a78bfa','#c084fc','#f472b6','#fb7185','#f87171','#fb923c','#fbbf24','#a3e635','#34d399','#2dd4bf','#38bdf8'];
    const channels = [];
    function sync() {
        const valid = /^#[0-9a-fA-F]{6}$/.test(input.value), color = valid ? input.value : '#818cf8';
        button.style.setProperty('--swatch',color); button.title = valid ? color : 'Default accent';
        for (const chip of swatches.children) chip.setAttribute('aria-pressed',String(valid && chip.dataset.color.toLowerCase() === color.toLowerCase()));
        channels.forEach((range,i) => { range.value = parseInt(color.slice(1+i*2,3+i*2),16); range.nextElementSibling.textContent = range.value; });
    }
    for (const color of colors) {
        const chip = document.createElement('button'); chip.type = 'button'; chip.className = 'accent-swatch'; chip.dataset.color = color; chip.style.backgroundColor = color; chip.setAttribute('aria-label','Accent '+color);
        chip.onclick = () => { input.value = color; input.dispatchEvent(new Event('input',{bubbles:true})); sync(); };
        swatches.append(chip);
    }
    for (const [i,name] of ['Red','Green','Blue'].entries()) {
        const label = document.createElement('label'); label.className = 'accent-channel';
        const text = document.createElement('span'); text.textContent = name;
        const range = document.createElement('input'); range.type = 'range'; range.className = 'profile-range'; range.min = 0; range.max = 255; range.step = 1; range.setAttribute('aria-label',name+' component');
        const value = document.createElement('output'); label.append(text,range,value); panel.append(label); channels.push(range);
        range.oninput = () => { input.value = '#'+channels.map(c=>Number(c.value).toString(16).padStart(2,'0')).join(''); input.dispatchEvent(new Event('input',{bubbles:true})); sync(); };
    }
    button.onclick = () => { panel.hidden = !panel.hidden; button.setAttribute('aria-expanded',String(!panel.hidden)); };
    input.addEventListener('input',sync); sync();
    return {sync,close(){panel.hidden=true;button.setAttribute('aria-expanded','false');}};
};

window.enhanceRosterColor=function(input){
 const wrapper=node('div',undefined,'color-control'),row=node('div',undefined,'accent-inputs'),b=node('button',undefined,'accent-picker-button'),panel=node('div');
 input.before(wrapper);input.type='text';input.maxLength=7;input.pattern='#[0-9a-fA-F]{6}';input.classList.add('color-hex');b.type='button';row.append(b,input);wrapper.append(row,panel);setupAccentPicker(input,b,panel);b.setAttribute('aria-label','Choose '+input.getAttribute('aria-label').toLowerCase());
};
