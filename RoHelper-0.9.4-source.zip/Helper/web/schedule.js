// Adapted from the local RoPilot fork (GPL-3.0).

window.EventSchedule=(()=>{
 const formatters=new Map();
 function parts(time,zone){let f=formatters.get(zone);if(!f){f=new Intl.DateTimeFormat('en-CA',{timeZone:zone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});formatters.set(zone,f);}const p=Object.fromEntries(f.formatToParts(new Date(time)).filter(p=>p.type!=='literal').map(p=>[p.type,Number(p.value)]));return [p.year,p.month,p.day,p.hour,p.minute];}
 const utc=p=>Date.UTC(p[0],p[1]-1,p[2],p[3]||0,p[4]||0);
 const parse=s=>s.match(/\d+/g).map(Number);
 function instant(local,zone){
  try{const p=typeof local==='string'?parse(local):local,t=utc(p),offsets=new Set([-36,0,36].map(h=>{const x=t+h*3600000;return utc(parts(x,zone))-x;}));
   const matches=[...offsets].map(o=>t-o).filter(x=>parts(x,zone).every((n,i)=>n===p[i]));return matches.length?Math.min(...matches):NaN;
  }catch{return NaN;}
 }
 function localAt(event,index){const p=parse(event.start),d=new Date(utc(p));
  if(event.repeat==='daily'||event.repeat==='weekly'){d.setUTCDate(d.getUTCDate()+index*(event.repeat==='weekly'?7:1));return [d.getUTCFullYear(),d.getUTCMonth()+1,d.getUTCDate(),p[3],p[4]];}
  if(event.repeat==='monthly'||event.repeat==='yearly'){const month=p[1]-1+(event.repeat==='monthly'?index:0),year=p[0]+(event.repeat==='yearly'?index:0);const x=new Date(Date.UTC(year,month,1));const last=new Date(Date.UTC(x.getUTCFullYear(),x.getUTCMonth()+1,0)).getUTCDate();return [x.getUTCFullYear(),x.getUTCMonth()+1,Math.min(p[2],last),p[3],p[4]];}return p;
 }
 function state(event,now=Date.now()){
  try{if(event.scheduleConfirmed===false)return {status:'invalid'};const skipped=new Set(event.skipped||[]);const anchor=parse(event.start),current=parts(now,event.zone);let index=0;
   if(event.repeat==='daily'||event.repeat==='weekly')index=Math.floor((utc([...current.slice(0,3),0,0])-utc([...anchor.slice(0,3),0,0]))/86400000/(event.repeat==='weekly'?7:1));
   if(event.repeat==='monthly')index=(current[0]-anchor[0])*12+current[1]-anchor[1];
   if(event.repeat==='yearly')index=current[0]-anchor[0];
   const occurrences=[];const low=event.repeat==='once'?0:Math.max(0,index-8),high=event.repeat==='once'?0:Math.max(2,index+3+skipped.size);
   for(let i=low;i<=high;i++){const start=instant(localAt(event,i),event.zone);if(Number.isFinite(start)&&!skipped.has(start))occurrences.push({start,end:start+event.duration*60000});}
   const active=occurrences.filter(o=>o.start<=now&&o.end>now).at(-1),next=occurrences.find(o=>o.start>now),last=occurrences.filter(o=>o.end<=now).at(-1);
   const occurrence=active||next||last;return {status:!event.enabled?'paused':active?'active':next?'upcoming':'expired',occurrence,last};
  }catch{return {status:'invalid'};}
 }
 function countdown(ms){const seconds=Math.max(0,Math.ceil(ms/1000)),days=Math.floor(seconds/86400),hours=Math.floor(seconds/3600)%24,minutes=Math.floor(seconds/60)%60,s=seconds%60;return (days?days+'d ':'')+String(hours).padStart(2,'0')+':'+String(minutes).padStart(2,'0')+':'+String(s).padStart(2,'0');}
 // Enumerate the actual occurrences intersecting a bounded calendar range, preserving
 // the same time-zone, skipped-occurrence and month-end rules as the live timers.
 function occurrences(event,from,to){
  try{if(event.scheduleConfirmed===false||!Number.isFinite(from)||!Number.isFinite(to)||to<=from||to-from>370*86400000)return [];
   const anchor=parse(event.start),current=parts(from-event.duration*60000,event.zone);let index=0;
   if(event.repeat==='daily'||event.repeat==='weekly')index=Math.floor((utc([...current.slice(0,3),0,0])-utc([...anchor.slice(0,3),0,0]))/86400000/(event.repeat==='weekly'?7:1));
   if(event.repeat==='monthly')index=(current[0]-anchor[0])*12+current[1]-anchor[1];if(event.repeat==='yearly')index=current[0]-anchor[0];
   const result=[],skipped=new Set(event.skipped||[]),low=event.repeat==='once'?0:Math.max(0,index-1);
   for(let i=low;i<low+390;i++){const local=localAt(event,i),start=instant(local,event.zone);if(Number.isFinite(start)){if(start>=to)break;const end=start+event.duration*60000;if(end>from&&!skipped.has(start))result.push({start,end});}if(event.repeat==='once')break;}return result;
  }catch{return [];}
 }
 return {instant,state,countdown,parts,localAt,occurrences};
})();
