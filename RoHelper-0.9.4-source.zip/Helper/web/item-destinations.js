'use strict';
// Account and base-slot choices never write account data. Only the item editor saves.
window.HelperItemDestinations=(()=>{
 function accounts({name,onSelect,available}){
  const m=HelperSab.dialog('Choose an account',name+' · Select a destination.','',null);
  m.dialog.classList.add('item-destination-dialog');
  const search=input('Search destination accounts'),list=node('div',undefined,'item-account-list');
  search.placeholder='Search accounts…';search.className='item-account-search';m.body.append(search,list);
  function draw(){
   list.replaceChildren();const q=search.value.trim().toLowerCase();
   for(const a of db.accounts.filter(a=>[a.username,a.displayName,a.nickname].join(' ').toLowerCase().includes(q))){
    const capacity=available?.(a),pick=button('',()=>m.close().then(()=>onSelect(a.id)),'item-account-choice');
    pick.setAttribute('aria-label','Choose @'+a.username);
    const copy=node('span');copy.append(node('strong',a.nickname||a.displayName||a.username),node('small','@'+a.username));
    if(capacity!==undefined)copy.append(node('small',capacity+' free slot'+(capacity===1?'':'s')));
    pick.disabled=capacity===0;pick.append(avatar(a),copy,icon('chevron'));list.append(pick);
   }
   if(!list.children.length)list.append(node('p',db.accounts.length?'No matching accounts.':'Add an account to RoHelper first.','muted'));
  }
  search.oninput=draw;draw();return m;
 }
 function slots({accountId,name,onSelect}){
  const a=HelperSab.workspace.accounts.find(a=>a.id===accountId);if(!a){toast('This account was removed.');return;}
  const m=HelperSab.dialog('Choose a base slot',name+' · @'+a.username,'',null);
  m.dialog.classList.add('item-destination-dialog');
  const grid=node('div',undefined,'item-slot-list');
  for(let slot=0;slot<RosterInventory.slots(a);slot++){
   const held=a.sab.inventory.find(i=>i.slot===slot),b=button('',()=>{
    const current=HelperSab.workspace.accounts.find(a=>a.id===accountId);
    if(!current){m.error.textContent='This account was removed.';return;}
    if(slot>=RosterInventory.slots(current)||current.sab.inventory.some(i=>i.slot===slot)){m.error.textContent='That slot is no longer available.';return;}
    m.close().then(()=>onSelect(current,slot));
   },'item-slot-choice');
   b.setAttribute('aria-label','Choose slot '+(slot+1));b.disabled=!!held;
   b.append(icon(held?'box':'plus'),node('strong','Slot '+(slot+1)),node('small',held?(RosterInventory.brainrot(held.brainrotId)?.name||held.name||'Occupied'):'Available'));
   grid.append(b);
  }
  m.body.append(button('Change account',()=>accounts({name,onSelect:id=>slots({accountId:id,name,onSelect}),available:a=>freeSlots(a.id)}),'ghost','back'),grid);
  if(!freeSlots(a.id))m.body.append(node('p','This base is full. Choose another account or free a slot.','notice'));
  return m;
 }
 function freeSlots(id){const a=HelperSab.workspace.accounts.find(a=>a.id===id);return a?Array.from({length:RosterInventory.slots(a)},(_,i)=>i).filter(i=>!a.sab.inventory.some(item=>item.slot===i)).length:0;}
 function brainrot(seed){accounts({name:seed.name,available:a=>freeSlots(a.id),onSelect:id=>slots({accountId:id,name:seed.name,onSelect:(a,slot)=>{
  const item={id:crypto.randomUUID(),brainrotId:seed.id,name:seed.name,slot,mutation:seed.mutation||'default',traits:[...(seed.traits||[])],notes:''};
  RosterHistory.commit('add brainrot',[a],()=>{a.sab.inventory=[...a.sab.inventory,item];});toast('Added to @'+a.username+' · slot '+(slot+1)+'.');
 }})});}
 return {accounts,slots,brainrot,freeSlots};
})();
