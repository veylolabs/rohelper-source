'use strict';
// The item editor's presentation is kept separate from inventory storage/actions.
window.AdoptItemEditor=(()=>{
 const rarityColors={'Common':'#b8c0d4','Uncommon':'#61cfa1','Rare':'#73adf7','Ultra-Rare':'#bf9cf5','Legendary':'#edc56b','Event':'#f0a0c2'};
 const date=value=>value&&/^\d{4}-\d{2}-\d{2}$/.test(value)?new Date(value+'T12:00:00').toLocaleDateString(undefined,{day:'numeric',month:'short',year:'numeric'}):value||'Unknown';
 function link(title,url){const a=node('a',title,'adopt-source-link');a.href=url;a.target='_blank';a.rel='noopener noreferrer';a.append(icon('arrow'));return a;}
 function section(title,symbol){const box=node('section',undefined,'adopt-editor-section'),head=node('div',undefined,'adopt-section-heading');head.append(icon(symbol),node('h3',title));box.append(head);return box;}
 function disclosure(title,cls){const d=node('details',undefined,cls),summary=node('summary');summary.append(node('span',title),icon('chevron'));d.append(summary);return d;}
 function summary(ref,item,api){
  const hero=node('section',undefined,'adopt-item-hero');hero.style.setProperty('--item-color',rarityColors[ref.rarity]||'var(--accent)');hero.dataset.variant=item.variant||'normal';
  const art=node('div',undefined,'adopt-hero-art');art.append(api.image(ref));const content=node('div',undefined,'adopt-hero-copy'),badges=node('div',undefined,'adopt-item-badges');
  badges.append(node('span',ref.rarity||'Rarity unknown','adopt-rarity'));
  if(ref.category==='pets'){
   const v=node('span',item.variant==='mega'?'Mega Neon':item.variant==='neon'?'Neon':'Normal','adopt-variant-chip');v.dataset.variant=item.variant||'normal';badges.append(v);
   for(const [key,text] of [['ride','R'],['fly','F']])if(item[key]){const badge=node('span',text,'adopt-potion-badge '+key);badge.title=key==='ride'?'Ride':'Fly';badge.setAttribute('aria-label',badge.title);badges.append(badge);}
  }
  content.append(badges,node('h2',ref.name));if(ref.origin){const origin=node('p',undefined,'adopt-origin');origin.append(icon(ref.category==='pets'?'egg':'box'),node('span',ref.origin));content.append(origin);}
  if(ref.buy){const buy=node('p',api.money(ref.buy.amount)+' '+ref.buy.currency+' to obtain','adopt-buy-reference');content.append(buy);}
  const value=node('div',undefined,'adopt-value-card'),number=api.value(ref,item),amount=node('div',undefined,'adopt-value-amount');amount.append(node('strong',number===null?'Unknown':api.money(number)));if(number!==null)amount.append(node('span','RP'));value.append(node('span','Trading estimate','adopt-eyebrow'),amount,node('small','AMTV · '+(ref.valueCheckedOn?'checked '+date(ref.valueCheckedOn):'Value unavailable')));
  hero.append(art,content,value);
  const source=disclosure('Reference & sources','adopt-reference'),facts=node('div',undefined,'adopt-reference-facts');
  const buy=ref.buy?api.money(ref.buy.amount)+' '+ref.buy.currency:ref.purchaseReference?ref.purchaseReference+(ref.purchaseCurrencies?.length?' ('+ref.purchaseCurrencies.join(', ')+')':''):'Unknown';
  for(const [title,text] of [['Added',date(ref.added)],['Buy / obtain',buy],['Sell','Unknown']]){const fact=node('div');fact.append(node('small',title),node('strong',text));facts.append(fact);}
  const links=node('div',undefined,'adopt-source-links');for(const [title,url] of [['Item source',ref.source],['Trading values',ref.valueSource],['Release source',ref.addedSource]])if(url)links.append(link(title,url));
  source.append(facts,node('p','AMTV values are community estimates in Ride Potions (RP). Growth and friendship have no verified value adjustment.','help-text'),links);hero.append(source);return hero;
 }
 function ability(title,key,draft,change){const c=input(title,'','checkbox');c.checked=!!draft()[key];const label=node('label',undefined,'adopt-ability '+key),badge=node('span',key==='ride'?'R':'F','adopt-ability-icon'),copy=node('span',undefined,'adopt-ability-copy'),track=node('span',undefined,'adopt-switch');badge.setAttribute('aria-hidden','true');track.setAttribute('aria-hidden','true');const state=node('small');copy.append(node('strong',title),state);label.append(c,badge,copy,track);function update(){label.classList.toggle('is-on',c.checked);state.textContent=c.checked?'Enabled':'Not applied';}c.onchange=()=>{draft()[key]=c.checked;update();change();};update();return label;}
 function mount(m,ref,options){
  const {api,existing}=options,draft=()=>options.draft();m.dialog.classList.add('catalog-dialog','adopt-item-dialog');m.body.classList.add('adopt-editor-body');
  const hero=node('div',undefined,'adopt-editor-preview'),columns=node('div',undefined,'adopt-editor-columns'),left=node('div',undefined,'adopt-editor-stack'),pet=node('div',undefined,'adopt-editor-stack');columns.append(left);if(ref.category==='pets')columns.append(pet);else columns.classList.add('is-item');m.body.append(hero,columns);
  const setup=section(ref.category==='pets'?'Pet setup':'Item details',ref.category==='pets'?'paw':'box'),fields=node('div',undefined,'adopt-setup-fields');setup.append(fields);left.append(setup);
  function preview(){const opened=hero.querySelector('details')?.open;hero.replaceChildren(summary(ref,draft(),api));if(opened)hero.querySelector('details').open=true;}
  let refreshProgress=()=>{},refreshStages=()=>{};
  function chooseStage(stage,fromCircle=false){if(!Number.isInteger(stage)||stage<0||stage>5||draft().variant==='mega'||stage===(draft().stage||0))return;draft().stage=stage;draft().stageTasks=0;if(fromCircle)refreshStages();progress();if(fromCircle)pet.querySelector('.adopt-growth-stop[aria-current="step"]')?.focus({preventScroll:true});}
  function numeric(title,key,max=1e9){const control=input(title,draft()[key]??0,'number');control.min=0;control.max=max;control.step=1;control.oninput=()=>{draft()[key]=control.value===''?0:Number(control.value);refreshProgress();};return control;}
  function progress(){
   pet.replaceChildren();if(ref.category!=='pets')return;
   const g=api.growth(draft(),ref),table=catalogGrowth(),box=section(g.full?'Friendship':'Growth progress',g.full?'heart':'leaf');pet.append(box);
   const caption=node('div',undefined,'adopt-growth-caption'),title=node('strong'),sub=node('p'),meter=node('progress',undefined,'adopt-growth-meter');meter.setAttribute('aria-label',g.full?'Friendship progress':'Current growth stage progress');caption.append(title,sub);box.append(caption,meter);
   if(g.full){
    const controls=node('div',undefined,'adopt-setup-fields');controls.append(label('Friendship level',numeric('Friendship level','friendshipLevel')),label('Tasks this level',numeric('Tasks toward next friendship level','friendshipTasks',29)));box.append(controls,node('p','Every 30 tasks earns the next friendship level.','adopt-section-note'));
    refreshProgress=()=>{const value=draft();title.textContent='Level '+(value.friendshipLevel||0);sub.textContent=(value.friendshipTasks||0)+' / 30 tasks toward the next level';meter.max=30;meter.value=Math.min(30,Math.max(0,value.friendshipTasks||0));};
    const note=disclosure('About friendship','adopt-inline-details');note.append(node('p','Friendship is available on fully grown pets. In-game trades reset it; moving a saved record here preserves its progress.','help-text'));box.append(note);
   }else{
    const text=node('p',g.required===null?'Task requirement unknown':g.required+' tasks from '+g.labels[g.stage]+' to '+g.labels[g.stage+1],'adopt-section-note');
    box.append(label('Tasks completed in this stage',numeric('Tasks completed in this growth stage','stageTasks',g.required??1000000)),text);
    refreshProgress=()=>{const value=draft(),now=api.growth(value,ref),completed=Math.max(0,value.stageTasks||0);title.textContent=now.labels[now.stage]+' → '+now.labels[now.stage+1];sub.textContent=now.remaining===null?'Remaining tasks unknown':Math.max(0,now.remaining)+' tasks remaining to '+now.labels[5];meter.max=now.required||1;meter.value=Math.min(meter.max,completed);};
   }
   if(draft().variant!=='mega'){
    const stops=node('div',undefined,'adopt-growth-stages');for(const [i,name] of g.labels.entries()){const stop=button('',()=>chooseStage(i,true),'adopt-growth-stop');stop.dataset.state=i<g.stage?'complete':i===g.stage?'current':'next';stop.title=name;stop.setAttribute('aria-label','Set growth stage to '+name);stop.setAttribute('aria-pressed',String(i===g.stage));const dot=node('span',i<g.stage?'✓':String(i+1));stop.append(dot,node('small',name));if(i===g.stage)stop.setAttribute('aria-current','step');stops.append(stop);}box.append(stops);
    const breakdown=disclosure('Growth task breakdown','adopt-growth-breakdown'),counts=table.tasks[ref.rarity],rows=node('table',undefined,'growth-table');
    rows.setAttribute('aria-label','Tasks between growth stages');for(let i=0;i<5;i++){const row=node('tr');row.classList.toggle('current',!g.full&&i===g.stage);row.append(node('td',g.labels[i]+' → '+g.labels[i+1]),node('td',counts?counts[i]+' tasks':'Unknown'));rows.append(row);}breakdown.append(rows);box.append(breakdown);
   }
   refreshProgress();
  }
  function catalogGrowth(){return api.catalog().growth;}
  if(ref.category==='pets'){
   const variant=select('Pet variant',[['normal','Normal'],...(ref.variants?[['neon','Neon'],['mega','Mega Neon']]:[])],draft().variant||'normal'),stages=node('div');
   for(const option of variant.options)if(option.value!=='normal')option.dataset.color=option.value==='neon'?'#8bd5a4':'#c3a6ff';
   function drawStages(){stages.replaceChildren();const value=draft(),g=api.growth(value,ref);if(value.variant==='mega'){const full=node('div',undefined,'adopt-grown-state');full.append(icon('check'),node('span','Fully grown'));stages.append(label('Growth stage',full));return;}const control=select('Growth stage',g.labels.map((name,i)=>[i,name]),value.stage||0);control.onchange=()=>chooseStage(Number(control.value));stages.append(label('Growth stage',control));enhance(stages);}
   refreshStages=drawStages;
   variant.onchange=()=>{draft().variant=variant.value;draft().stageTasks=0;if(variant.value==='mega')draft().stage=5;drawStages();progress();preview();};fields.append(label('Variant',variant),stages);
   const nickname=input('Pet nickname',draft().nickname||'');nickname.maxLength=160;nickname.placeholder='Optional nickname';nickname.oninput=()=>draft().nickname=nickname.value;fields.append(label('Nickname',nickname));
   drawStages();
  }else{const quantity=numeric('Quantity','quantity',1e6);quantity.min=1;fields.append(label('Quantity',quantity));}
  const paid=input('Paid price (€)',draft().paidEur??'','number');paid.min=0;paid.max=1e9;paid.step='.01';paid.placeholder='Not recorded';paid.oninput=()=>{if(paid.value==='')delete draft().paidEur;else draft().paidEur=Number(paid.value);};fields.append(label('Paid price (€) · optional',paid));
  if(ref.category==='pets'){
   const abilities=node('div',undefined,'adopt-abilities');abilities.setAttribute('role','group');abilities.setAttribute('aria-label','Pet abilities');abilities.append(ability('Ride','ride',draft,preview),ability('Fly','fly',draft,preview));setup.append(abilities);
  }
  preview();progress();enhance(m.body);if(!existing){m.save.replaceChildren(icon('plus'),node('span',ref.category==='pets'?'Add pet':'Add item'));}else m.enableAutosave();
 }
 function details(m,ref,api,add){m.dialog.classList.add('adopt-item-dialog','adopt-details-dialog');m.body.classList.add('adopt-editor-body');m.body.append(summary(ref,{},api));add.classList.add('adopt-inventory-add');m.foot.insertBefore(add,m.save);enhance(m.body);}
 return {mount,details};
})();
