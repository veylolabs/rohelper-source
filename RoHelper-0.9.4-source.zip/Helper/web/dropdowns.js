// Adapted from the local RoPilot fork (GPL-3.0).

(() => {
    const enhanced = new WeakMap();
    let opened = null, nextId = 0;
    const chevron = '<svg class="select-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>';
    const check = '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>';
    function close(restore = false) {
        if (!opened) return;
        const old = opened; opened = null;
        old.button.setAttribute('aria-expanded', 'false');
        old.button.removeAttribute('aria-controls');
        old.menu.remove();
        if (restore && old.button.isConnected) old.button.focus({preventScroll:true});
    }
    document.addEventListener('pointerdown', event => {
        if (opened && !opened.menu.contains(event.target) && !opened.button.contains(event.target)) close();
    }, true);
    document.addEventListener('keydown', event => {
        if (!opened) return;
        if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); close(true); }
        else if (event.key === 'Tab') close(true);
    }, true);
    window.addEventListener('resize', () => close());
    document.addEventListener('scroll', event => {
        if (!opened || opened.menu.contains(event.target)) return;
        const rect=opened.button.getBoundingClientRect();
        // A queued scroll event from bringing the trigger into view must not
        // immediately dismiss a menu that was positioned after that scroll.
        if(Math.abs(rect.top-opened.anchorRect.top)>1||Math.abs(rect.left-opened.anchorRect.left)>1)close();
    }, true);
    window.polishSelect = function(select, title) {
        if (enhanced.has(select)) { enhanced.get(select).sync(); return; }
        const wrapper = document.createElement('span'); wrapper.className = 'polished-select';
        select.before(wrapper); wrapper.append(select); select.hidden = true;
        const button = document.createElement('button'); button.type = 'button'; button.className = 'rp-control select-trigger';
        button.id = (select.id || 'profile-select-' + ++nextId) + '-trigger';
        button.setAttribute('aria-haspopup', 'listbox'); button.setAttribute('aria-expanded', 'false');
        const label = document.createElement('span'); label.className = 'select-value'; button.append(label);
        button.insertAdjacentHTML('beforeend', chevron); wrapper.append(button);
        function sync() {
            const selected = select.options[select.selectedIndex];
            const selectedName = selected?.textContent || 'Choose an option';
            label.textContent = select.dataset.iconGrid ? '' : selectedName;
            if(select.dataset.iconGrid&&selected)label.append(icon(selected.value));
            label.style.color = selected?.dataset.color || '';
            label.classList.toggle('rainbow-text', selected?.dataset.rainbow === 'true');
            button.disabled = select.disabled;
            button.title = selected?.title || select.title || selectedName;
            button.setAttribute('aria-label', title + ': ' + selectedName);
            if (opened?.select === select) close();
        }
        function open() {
            if (opened?.select === select) { close(true); return; }
            close(); sync();
            document.getElementById('tile-dropdown-menu')?.classList.remove('show');
            const menu = document.createElement('div'); menu.className = 'tile-dropdown-menu polished-menu show';
            const columns=select.dataset.originGrid?3:select.dataset.iconGrid?4:select.options.length>8?2:1;menu.style.setProperty('--menu-columns',columns);if(select.dataset.iconGrid)menu.classList.add('icon-grid-menu');if(select.dataset.originGrid)menu.classList.add('macro-origin-menu');
            menu.id = button.id + '-list'; menu.setAttribute('role', 'listbox'); menu.setAttribute('aria-label', title);
            menu.setAttribute('popover', 'manual');
            const heading = document.createElement('div'); heading.className = 'tile-dropdown-header'; heading.textContent = title; heading.setAttribute('role','presentation'); menu.append(heading);
            const items = [];
            Array.from(select.options).forEach((option, index) => {
                const item = document.createElement('button'); item.type = 'button'; item.className = 'tile-dropdown-item polished-option';
                item.setAttribute('role','option'); item.tabIndex = -1; item.disabled = option.disabled;
                item.setAttribute('aria-selected', String(index === select.selectedIndex));
                const copy = document.createElement('span'); copy.className = 'option-copy';
                const text = document.createElement('span');
                const parts = option.textContent.split(' — '); text.textContent = parts[0]; copy.append(text);
                text.style.color = option.dataset.color || '';
                text.classList.toggle('rainbow-text', option.dataset.rainbow === 'true');
                const detail = option.title || parts.slice(1).join(' — ');
                if (detail) { const sub = document.createElement('small'); sub.textContent = detail; copy.append(sub); item.title = detail; }
                if(select.dataset.iconGrid){item.append(icon(option.value));item.title=option.title||option.textContent;item.setAttribute('aria-label',option.textContent);}
                if(option.dataset.image){const image=document.createElement('img');image.src=option.dataset.image;image.alt='';image.className='mutation-option-icon';image.width=26;image.height=26;item.append(image);}
                if(select.dataset.originGrid){const marker=document.createElement('span');marker.className='macro-origin-symbol';marker.textContent=['↖','↑','↗','←','•','→','↙','↓','↘'][index];marker.setAttribute('aria-hidden','true');item.append(marker);item.setAttribute('aria-label',option.textContent);}if(!select.dataset.iconGrid)item.append(copy);
                const mark = document.createElement('span'); mark.className = 'option-check'; mark.innerHTML = check; item.append(mark);
                item.onclick = () => {
                    if (option.disabled) return;
                    const changed = select.selectedIndex !== index;
                    select.selectedIndex = index; close(true); sync();
                    if (changed) { select.dispatchEvent(new Event('input', {bubbles:true})); select.dispatchEvent(new Event('change', {bubbles:true})); }
                };
                menu.append(item); if (!option.disabled) items.push(item);
            });
            // A modal dialog owns its menus so keyboard focus stays in the modal.
            (select.closest('dialog') || document.body).append(menu);
            if (menu.showPopover) menu.showPopover();
            const rect = button.getBoundingClientRect();
            const zoom=Number(getComputedStyle(document.documentElement).zoom)||1;const viewWidth=window.innerWidth/zoom,viewHeight=window.innerHeight/zoom;const anchor={left:rect.left/zoom,top:rect.top/zoom,bottom:rect.bottom/zoom,width:rect.width/zoom};
            const width = Math.min(Math.max(anchor.width, columns===4?380:columns===3?320:columns===2?360:238), viewWidth - 24);
            menu.style.width = width + 'px';
            menu.style.left = Math.min(Math.max(12, anchor.left), viewWidth - width - 12) + 'px';
            const below = viewHeight - anchor.bottom - 18, above = anchor.top - 18;
            const upward = below < 230 && above > below;
            menu.style.maxHeight = Math.max(80, Math.min(340, upward ? above : below)) + 'px';
            const height = menu.getBoundingClientRect().height/zoom;
            menu.style.top = (upward ? anchor.top - height - 6 : anchor.bottom + 6) + 'px';
            opened = {select, button, menu, anchorRect:rect};
            button.setAttribute('aria-controls',menu.id); button.setAttribute('aria-expanded','true');
            const focus = items.find(item => item.getAttribute('aria-selected') === 'true') || items[0];
            function reveal(item) {
                const top=item.offsetTop,bottom=top+item.offsetHeight;
                if(top<menu.scrollTop)menu.scrollTop=top;
                else if(bottom>menu.scrollTop+menu.clientHeight)menu.scrollTop=bottom-menu.clientHeight;
            }
            focus?.focus({preventScroll:true}); if(focus)reveal(focus);
            let typed = '', typedAt = 0;
            menu.addEventListener('keydown', event => {
                let index = items.indexOf(document.activeElement), target;
                if (event.key === 'ArrowDown') target = items[(index + columns) % items.length];
                else if (event.key === 'ArrowUp') target = items[(index - columns + items.length) % items.length];
                else if(event.key==='ArrowRight')target=items[(index+1)%items.length];else if(event.key==='ArrowLeft')target=items[(index-1+items.length)%items.length];
                else if (event.key === 'Home') target = items[0];
                else if (event.key === 'End') target = items[items.length - 1];
                else if (event.key.length === 1 && event.key !== ' ' && !event.ctrlKey && !event.metaKey && !event.altKey) {
                    typed = (Date.now() - typedAt < 700 ? typed : '') + event.key.toLowerCase(); typedAt = Date.now();
                    target = items.find(item => (item.getAttribute('aria-label')||item.textContent).toLowerCase().startsWith(typed));
                }
                if (target) { event.preventDefault(); target.focus({preventScroll:true}); reveal(target); }
            });
        }
        button.onclick = open;
        button.onkeydown = event => { if (event.key === 'ArrowDown' || event.key === 'ArrowUp') { event.preventDefault(); open(); } };
        select.addEventListener('change',sync);
        new MutationObserver(sync).observe(select,{childList:true,subtree:true,attributes:true,characterData:true});
        enhanced.set(select,{sync}); sync();
    };
    window.refreshPolishedSelect = select => enhanced.get(select)?.sync();
})();
