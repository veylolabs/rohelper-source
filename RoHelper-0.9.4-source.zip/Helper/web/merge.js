'use strict';
// Same rules as Merge.h. Pure module, also exercised in Node tests.
(() => {
 const copy=x=>x===undefined?undefined:structuredClone(x);
 const object=x=>x!==null&&typeof x==='object'&&!Array.isArray(x);
 const equal=(a,b)=>{if(a===b)return true;if(Array.isArray(a)&&Array.isArray(b))return a.length===b.length&&a.every((v,i)=>equal(v,b[i]));if(object(a)&&object(b)){const k=Object.keys(a);return k.length===Object.keys(b).length&&k.every(k=>Object.hasOwn(b,k)&&equal(a[k],b[k]));}return false;};
 const keyed=a=>Array.isArray(a)&&a.every(x=>object(x)&&typeof x.id==='string')&&new Set(a.map(x=>x.id)).size===a.length;
 function merge(base,local,remote,path='workspace',choice=null){
  if(equal(local,base))return copy(remote);
  if(equal(remote,base)||equal(local,remote))return copy(local);
  if(object(local)&&object(remote)&&(base===undefined||object(base))){const out={};for(const key of new Set([...Object.keys(base||{}),...Object.keys(local),...Object.keys(remote)])){const v=merge(base?.[key],local[key],remote[key],path+'/'+key,choice);if(v!==undefined)Object.defineProperty(out,key,{value:v,enumerable:true,configurable:true,writable:true});}return out;}
  if(keyed(base)&&keyed(local)&&keyed(remote)){
   const maps=[base,local,remote].map(a=>new Map(a.map(x=>[x.id,x]))),[b,l,r]=maps,merged=new Map();
   for(const id of new Set(maps.flatMap(m=>[...m.keys()]))){const value=merge(b.get(id),l.get(id),r.get(id),path+'/'+id,choice);if(value!==undefined)merged.set(id,value);}
   const common=a=>a.map(x=>x.id).filter(id=>b.has(id)&&l.has(id)&&r.has(id)&&merged.has(id));const [bc,lc,rc]=[base,local,remote].map(common);
   const orderConflict=!equal(lc,bc)&&!equal(rc,bc)&&!equal(lc,rc);if(orderConflict&&!choice)throw Object.assign(Error('Concurrent changes affected '+path+'/order'),{path:path+'/order'});
   const preferred=orderConflict?(choice==='local'?local:remote):!equal(lc,bc)?local:remote;const order=[...preferred,...local,...remote].map(x=>x.id);return [...new Set(order)].filter(id=>merged.has(id)).map(id=>merged.get(id));
  }
  if(choice)return copy(choice==='local'?local:remote);throw Object.assign(Error('Concurrent changes affected '+path+'. Your edits are kept for review.'),{path});
 }
 // Keep existing account/item references alive for open editors and event handlers.
 function reconcile(target,next){
  if(Array.isArray(target)&&Array.isArray(next)){const old=keyed(target)&&keyed(next)?new Map(target.map(x=>[x.id,x])):null;target.splice(0,target.length,...next.map((x,i)=>{const prev=old?old.get(x.id):target[i];return (object(prev)&&object(x))?reconcile(prev,x):copy(x);}));return target;}
  if(object(target)&&object(next)){for(const k of Object.keys(target))if(!Object.hasOwn(next,k))delete target[k];for(const k of Object.keys(next)){if(k==='__proto__'||k==='constructor'||k==='prototype')continue;if((object(target[k])&&object(next[k]))||(Array.isArray(target[k])&&Array.isArray(next[k])))reconcile(target[k],next[k]);else target[k]=copy(next[k]);}return target;}
  return copy(next);
 }
 const api={merge,equal,reconcile};if(typeof module!=='undefined')module.exports=api;else window.HelperMerge=api;
})();
