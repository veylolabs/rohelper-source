'use strict';
window.HelperMoney=(()=>{
 function render(host,{pack,accountId,read,write,compact=false}){
  const currencies=(pack.currencies||[]).slice(0,compact?1:64);if(!currencies.length)return;
  const box=node('section',undefined,'game-money'+(compact?' compact-money':''));box.setAttribute('aria-label',pack.name+' balances');
  const account=db.accounts.find(a=>a.id===accountId);if(!account)return;box.dataset.moneyOwner=accountId;box.append(node(compact?'small':'h3','Money · @'+account.username));if(!compact)box.append(node('p','Saved for this account in '+pack.name+'.','help-text'));
  const grid=node('div',undefined,'money-counters');
  for(const c of currencies){
   const cell=node('div',undefined,'money-counter'),value=read()[c.id]??c.default??0,control=input(c.name,value,'number'),display=node('output');
   control.min=0;control.max=c.max??1e12;control.step='any';control.setAttribute('data-money-account',accountId);control.setAttribute('data-money-currency',c.id);
   const show=n=>display.textContent=new Intl.NumberFormat(undefined,{notation:n>=1e6?'compact':'standard',maximumFractionDigits:2}).format(n);
   control.oninput=()=>{if(control.value===''||!control.checkValidity())return;const n=Number(control.value);if(!Number.isFinite(n))return;write(c.id,n);show(n);};
   show(value);cell.append(label(c.name,control),display);grid.append(cell);
  }
  box.append(grid);host.append(box);
 }
 return {render};
})();
