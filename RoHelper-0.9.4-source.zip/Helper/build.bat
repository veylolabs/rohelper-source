@echo off
setlocal
if defined ROHELPER_PYTHON (
  "%ROHELPER_PYTHON%" "%~dp0tools\build.py" %*
) else (
  python "%~dp0tools\build.py" %*
)
exit /b %errorlevel%
