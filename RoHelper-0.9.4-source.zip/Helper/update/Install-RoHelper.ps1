﻿param([Parameter(Mandatory=$true)][string]$JobFile)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.IO.Compression.FileSystem
$taskChanged=[Collections.Generic.List[string]]::new()
$taskBackup=@{}
$taskExited=$false
$taskOutcome='failed'
$taskMessage=''
$taskJob=$null
$taskValidated=$false
function Get-UpdateHash([string]$LiteralPath,[string]$Algorithm='SHA256'){
 $taskHasher=[Security.Cryptography.SHA256]::Create();$taskHashStream=[IO.File]::OpenRead($LiteralPath)
 try{return [pscustomobject]@{Hash=([BitConverter]::ToString($taskHasher.ComputeHash($taskHashStream))).Replace('-','')}}finally{$taskHashStream.Dispose();$taskHasher.Dispose()}
}
function Write-State([string]$state,[string]$message){
 $taskPayload=@{state=$state;message=$message;version=$taskJob.version;nonce=$taskJob.nonce}|ConvertTo-Json -Compress
 [IO.File]::WriteAllText((Join-Path $taskStage 'status.json'),$taskPayload)
}
function Assert-NormalPath([string]$path){
 $taskCursor=$path
 while($taskCursor){
  if((Test-Path -LiteralPath $taskCursor) -and ((Get-Item -LiteralPath $taskCursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Update paths cannot contain junctions or symbolic links.'}
  $taskNext=Split-Path -Parent $taskCursor
  if($taskNext -eq $taskCursor){break};$taskCursor=$taskNext
 }
}
function Allowed-File([string]$relative){
 if($relative -match '[\\:]' -or $relative -match '(^|/)\.\.?(/|$)' -or $relative -match '[\x00-\x1f]' -or $relative -match '(^|/)[^/]*[ .](/|$)' -or $relative.StartsWith('/')){return $false}
 if($relative -match '(^|/)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])([.]|/|$)'){return $false}
 return $relative -cmatch '^(RoHelper\.exe|WebView2Loader\.dll|README\.md|LICENSE|update-files\.json|(?:web|LICENSES|update)/[^/].*)$'
}
try{
 $taskJobPath=[IO.Path]::GetFullPath($JobFile);$taskStage=Split-Path -Parent $taskJobPath
 $taskJob=Get-Content -LiteralPath $taskJobPath -Raw -Encoding UTF8|ConvertFrom-Json
 $taskDestination=[IO.Path]::GetFullPath($taskJob.destination).TrimEnd('\')
 $taskData=Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'RoHelper'
 if($taskJob.testMode){$taskData=Join-Path $taskDestination 'helper-data'}
 if([IO.Path]::GetFullPath($taskJob.dataDirectory).TrimEnd('\') -ne $taskData){throw 'Invalid app data directory.'}
 $taskExpectedParent=Join-Path $taskData 'app-updates' 
 if((Split-Path -Parent $taskStage) -ne $taskExpectedParent -or (Split-Path -Leaf $taskStage) -notmatch '^[a-f0-9-]{36}$' -or $taskJob.schema -ne 1 -or $taskJob.nonce -notmatch '^[a-f0-9-]{36}$' -or $taskJob.version -notmatch '^\d{1,5}\.\d{1,5}\.\d{1,5}$'){throw 'Invalid app update job.'}
 Assert-NormalPath $taskDestination;Assert-NormalPath $taskStage
 $taskValidated=$true
 $taskExe=Join-Path $taskDestination 'RoHelper.exe';$taskParent=Get-Process -Id $taskJob.parentPid -ErrorAction SilentlyContinue
 if($taskParent -and $taskParent.Path -ne $taskExe){throw 'The updater parent is not this RoHelper installation.'}
 $taskZip=Join-Path $taskStage 'release.zip'
 if((Get-Item -LiteralPath $taskZip).Length -ne $taskJob.size -or (Get-UpdateHash -LiteralPath $taskZip -Algorithm SHA256).Hash.ToLowerInvariant() -cne $taskJob.sha256){throw 'App package checksum does not match.'}
 $taskExtract=Join-Path $taskStage ('extracted-'+$taskJob.nonce);New-Item -ItemType Directory -Path $taskExtract|Out-Null
 $taskArchive=[IO.Compression.ZipFile]::OpenRead($taskZip)
 $taskFiles=@{};$taskSize=0L
 try{
  if($taskArchive.Entries.Count -gt 5000){throw 'Too many app package entries.'}
  foreach($taskEntry in $taskArchive.Entries){
   $taskName=$taskEntry.FullName
   if(-not $taskName.StartsWith('RoHelper/')){throw 'Invalid app package root.'}
   $taskRelative=$taskName.Substring(9)
   if(-not $taskRelative -and $taskName.EndsWith('/')){continue}
   if($taskName.EndsWith('/')){if(-not (Allowed-File ($taskRelative+'placeholder'))){throw 'Invalid package directory.'};continue}
   if(-not (Allowed-File $taskRelative) -or $taskFiles.ContainsKey($taskRelative)){throw 'Unsafe or duplicate app package path.'}
   $taskMode=($taskEntry.ExternalAttributes -shr 16) -band 61440
   if($taskMode -eq 40960 -or ($taskEntry.ExternalAttributes -band 1024)){throw 'Linked package files are not allowed.'}
   $taskSize+=$taskEntry.Length;if($taskEntry.Length -gt 64MB -or $taskSize -gt 256MB){throw 'Expanded app package is too large.'}
   $taskOutput=[IO.Path]::GetFullPath((Join-Path $taskExtract $taskRelative))
   if(-not $taskOutput.StartsWith($taskExtract+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Package file escapes staging.'}
   New-Item -ItemType Directory -Path (Split-Path -Parent $taskOutput) -Force|Out-Null
   $taskInput=$taskEntry.Open();$taskStream=[IO.File]::Open($taskOutput,[IO.FileMode]::CreateNew)
   try{$taskInput.CopyTo($taskStream)}finally{$taskStream.Dispose();$taskInput.Dispose()}
   if((Get-Item -LiteralPath $taskOutput).Length -ne $taskEntry.Length){throw 'Incomplete app package file.'};$taskFiles[$taskRelative]=$taskOutput
  }
 }finally{$taskArchive.Dispose()}
 foreach($taskRequired in @('RoHelper.exe','WebView2Loader.dll','web/index.html','update/Install-RoHelper.ps1','update-files.json')){if(-not $taskFiles.ContainsKey($taskRequired)){throw "Missing app file: $taskRequired"}}
 $taskIndex=Get-Content -LiteralPath $taskFiles['update-files.json'] -Raw -Encoding UTF8|ConvertFrom-Json
 if($taskIndex.version -ne $taskJob.version -or $taskIndex.schema -ne 1 -or @($taskIndex.files.PSObject.Properties).Count -ne ($taskFiles.Count-1)){throw 'Invalid package file index.'}
 foreach($taskRelative in $taskFiles.Keys){
  if($taskRelative -eq 'update-files.json'){continue}
  $taskHash=$taskIndex.files.PSObject.Properties[$taskRelative].Value
  if($taskHash -notmatch '^[a-f0-9]{64}$' -or (Get-UpdateHash -LiteralPath $taskFiles[$taskRelative]).Hash.ToLowerInvariant() -cne $taskHash){throw "Invalid package file hash: $taskRelative"}
  Assert-NormalPath (Join-Path $taskDestination $taskRelative)
 }
 if((Get-Item -LiteralPath $taskFiles['RoHelper.exe']).VersionInfo.FileVersion -ne $taskJob.version){throw 'App executable version does not match the release.'}
 Write-State 'ready' 'Package verified. Waiting for RoHelper to save and close.'
 $taskUntil=[DateTime]::UtcNow.AddSeconds(120);$taskCommit=Join-Path $taskStage 'commit.txt'
 while(-not (Test-Path -LiteralPath $taskCommit)){if((Test-Path -LiteralPath (Join-Path $taskStage 'cancel.txt')) -and [IO.File]::ReadAllText((Join-Path $taskStage 'cancel.txt')) -ceq $taskJob.nonce){throw 'Update cancelled. App files were not changed.'};if([DateTime]::UtcNow -gt $taskUntil){throw 'RoHelper did not commit the update. No app files were changed.'};Start-Sleep -Milliseconds 200}
 if([IO.File]::ReadAllText($taskCommit) -cne $taskJob.nonce){throw 'Invalid update commit.'}
 if($taskParent -and -not $taskParent.WaitForExit(120000)){throw 'RoHelper did not exit. No app files were changed.'}
 $taskExited=$true
 if(Get-Process -Name RoHelper -ErrorAction SilentlyContinue|Where-Object Path -eq $taskExe){throw 'Another RoHelper window is using this installation.'}
 $taskDataHashes=@{};foreach($taskName in @('workspace.json','workspace.previous.json','sessions.bin','sessions.previous.bin')){ $taskPath=Join-Path $taskData $taskName;if(Test-Path -LiteralPath $taskPath){$taskDataHashes[$taskName]=(Get-UpdateHash -LiteralPath $taskPath).Hash}}
 $taskBackupRoot=Join-Path $taskStage ('previous-app-'+$taskJob.nonce);New-Item -ItemType Directory -Path $taskBackupRoot|Out-Null
 foreach($taskRelative in ($taskFiles.Keys|Sort-Object)){
  $taskTarget=Join-Path $taskDestination $taskRelative;Assert-NormalPath $taskTarget
  if(Test-Path -LiteralPath $taskTarget){$taskOld=Join-Path $taskBackupRoot $taskRelative;New-Item -ItemType Directory -Path (Split-Path -Parent $taskOld) -Force|Out-Null;Copy-Item -LiteralPath $taskTarget -Destination $taskOld;$taskBackup[$taskRelative]=$taskOld}
 }
 Write-State 'installing' 'Installing verified app files.'
 foreach($taskRelative in ($taskFiles.Keys|Sort-Object)){
  $taskTarget=Join-Path $taskDestination $taskRelative;New-Item -ItemType Directory -Path (Split-Path -Parent $taskTarget) -Force|Out-Null
  $taskChanged.Add($taskRelative);Copy-Item -LiteralPath $taskFiles[$taskRelative] -Destination $taskTarget -Force
  if((Get-UpdateHash -LiteralPath $taskTarget).Hash -ne (Get-UpdateHash -LiteralPath $taskFiles[$taskRelative]).Hash){throw "Installed file mismatch: $taskRelative"}
 }
 foreach($taskName in $taskDataHashes.Keys){if((Get-UpdateHash -LiteralPath (Join-Path $taskData $taskName)).Hash -ne $taskDataHashes[$taskName]){throw 'Saved account data changed unexpectedly.'}}
 $taskOutcome='installed';$taskMessage='RoHelper '+$taskJob.version+' installed. Saved data was preserved.'
}catch{
 $taskMessage=$_.Exception.Message
 if($taskChanged.Count){
  $taskRollbackErrors=@();foreach($taskRelative in $taskChanged){try{$taskTarget=Join-Path $taskDestination $taskRelative;if($taskBackup.ContainsKey($taskRelative)){if((Get-UpdateHash -LiteralPath $taskTarget).Hash -ne (Get-UpdateHash -LiteralPath $taskBackup[$taskRelative]).Hash){Copy-Item -LiteralPath $taskBackup[$taskRelative] -Destination $taskTarget -Force}}else{Remove-Item -LiteralPath $taskTarget -Force}}catch{$taskRollbackErrors+=$taskRelative}}
  if($taskRollbackErrors.Count){$taskMessage+=' Rollback needs attention: '+($taskRollbackErrors -join ', ')}else{$taskOutcome='rolled-back';$taskMessage+=' The previous app was restored.'}
 }
}finally{
 if($taskValidated -and $taskJob -and $taskStage -and (Test-Path -LiteralPath $taskStage)){
  Write-State $taskOutcome $taskMessage
  if($taskExited){
   $taskResult=@{state=$taskOutcome;message=$taskMessage;version=$taskJob.version}|ConvertTo-Json -Compress
   [IO.File]::WriteAllText((Join-Path $taskData 'app-update-result.json'),$taskResult)
   if(-not (Get-Process -Name RoHelper -ErrorAction SilentlyContinue|Where-Object Path -eq $taskExe)){
    if($taskJob.testMode){Start-Process -FilePath $taskExe -ArgumentList '--test' -WorkingDirectory $taskDestination -WindowStyle Hidden}else{Start-Process -FilePath $taskExe -WorkingDirectory $taskDestination -WindowStyle Normal}
   }
  }
 }
}
if($taskOutcome -ne 'installed'){exit 1}
