"""Cache public LT2 reference material and exact LT2Tracker artwork; no account APIs."""
import concurrent.futures
import json
from pathlib import Path
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[2]
CACHE = ROOT / 'Output/lumber-tycoon-2'
CACHE.mkdir(parents=True, exist_ok=True)


def fetch(url, dest):
    if not dest.exists():
        request = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0', 'Referer': 'https://lt2tracker.com/'})
        with urllib.request.urlopen(request, timeout=60) as response:
            data = response.read()
        dest.write_bytes(data)
    return dest.read_bytes()


def wiki(params, name):
    url = 'https://lumber-tycoon-2.fandom.com/api.php?' + urllib.parse.urlencode(
        {**params, 'format': 'json'})
    return json.loads(fetch(url, CACHE / name))


def main():
    raw = json.loads(fetch('https://lt2tracker.com/data.json', CACHE / 'tracker-data.json'))
    entries = [i for g in raw['groups'] for i in g['items']]
    images = sorted({raw['img'][i['i']] for i in entries if i.get('i')})
    image_dir = CACHE / 'images'
    image_dir.mkdir(exist_ok=True)
    def image(name):
        data = fetch('https://lt2tracker.com/img/' + name, image_dir / name)
        assert data[:4] == b'RIFF' and data[8:12] == b'WEBP', name
        return len(data)
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        sizes = list(pool.map(image, images))
    print('Verified', len(images), 'WebP images;', sum(sizes), 'bytes')
    titles = sorted({i.get('w') or i['n'] for i in entries})
    for n in range(0, len(titles), 40):
        wiki(dict(action='query', titles='|'.join(titles[n:n+40]), redirects=1,
                  prop='revisions', rvprop='content|timestamp', rvslots='main'),
             'item-pages-' + str(n // 40) + '.json')
    for title in ['Bridge', 'Haunted Hatchet', 'Carved Pumpkin', 'Burnt Bag of Candy',
                  'End Times Event', 'The Den', 'Ferry', 'Halloween Events', 'Category:Wood', 'Category:Axes',
                  'Christmas Events', 'Thanksgiving Events']:
        wiki(dict(action='parse', page=title, prop='text|wikitext', redirects=1),
             title.lower().replace(' ', '-').replace(':', '-') + '.json')
    universe = json.loads(fetch('https://apis.roblox.com/universes/v1/places/13822889/universe', CACHE / 'universe.json'))
    fetch('https://thumbnails.roblox.com/v1/games/icons?universeIds=' + str(universe['universeId']) +
          '&returnPolicy=PlaceHolder&size=150x150&format=Png&isCircular=false', CACHE / 'game-icon.json')
    print('Cached wiki entries, event/timer references and official game icon.')


if __name__ == '__main__':
    main()
