"""Build only the LT2 public pack. Existing packs, achievements and private data are untouched.

Run research_lt2.py first. Artwork is bundled into the hashed GitHub pack for offline use.
Item names/numbers are reference facts; source descriptions and flavor text are not copied.
"""
import base64
import hashlib
import html
import json
from pathlib import Path
import re
from urllib.parse import quote
from build_collection_games import Document, grid

ROOT = Path(__file__).resolve().parents[1]
CACHE = ROOT.parent / 'Output/lumber-tycoon-2'
PUBLIC = ROOT.parent / 'GameCatalog'
CHECKED = '2026-10-31'
WIKI = 'https://lumber-tycoon-2.fandom.com/wiki/'
read = lambda p: json.loads(p.read_text(encoding='utf-8'))
digest = lambda data: hashlib.sha256(data).hexdigest()
url = lambda title: WIKI + quote(title.replace(' ', '_'), safe='/#')


def clean(value):
    value = re.sub(r'<br\s*/?>', '; ', value, flags=re.I)
    value = re.sub(r'<ref\b[^>]*>.*?</ref>', '', value, flags=re.S)
    value = re.sub(r'<[^>]+>', '', value)
    value = re.sub(r'\[\[([^\]|]+)(?:\|([^\]]+))?\]\]', lambda m: m[2] or m[1], value)
    value = re.sub(r'\{\{Money\|([^|}]+)(?:\|[^}]*)?\}\}', lambda m: '$' + m[1], value, flags=re.I)
    value = re.sub(r'\{\{[^{}]*\}\}', '', value)
    value = re.sub(r"''+", '', value)
    return re.sub(r'\s+', ' ', html.unescape(value)).strip(' ;}')


def fields(text):
    return {m[1].strip().lower(): clean(m[2]) for m in re.finditer(
        r'^\|([^=\n]+)\s*=\s*(.*?)(?=^\||^\}\}|\Z)', text.split('\n==')[0], re.M | re.S)
        if len(clean(m[2])) <= 400}


def category(group, item):
    kind = item.get('ty')
    types = {'axes':'axes', 'wood':'wood', 'vehicles':'vehicles', 'art':'paintings',
             'food':'food', 'candy':'food', 'home':'furniture', 'lights':'lighting'}
    if kind:
        return types.get(kind, 'collectibles')
    g, k = group['name'], item['k']
    if 'Axes' in g: return 'axes'
    if 'Sawmills' in g: return 'machinery'
    if 'Conveyors' in g: return 'conveyors'
    if g == 'Boxed Cars' or k == 'utility-vehicle': return 'vehicles'
    if 'Glass' in g: return 'glass'
    if g == "Link's Logic" or k in ('wire', 'button', 'lever', 'pressure-plate'): return 'wiring'
    if g == 'Fine Arts Shop': return 'paintings'
    if k in ('worklight','lamp','floor-lamp','wall-light','floodlight','lightbulb','icicle-lights'): return 'lighting'
    if g == 'Fancy Furnishings': return 'furniture'
    return 'collectibles'


def main():
    raw = read(CACHE / 'tracker-data.json')
    pages, redirects = {}, {}
    for path in CACHE.glob('item-pages-*.json'):
        query = read(path)['query']
        redirects.update({r['from']: r['to'] for r in query.get('normalized', []) + query.get('redirects', [])})
        for page in query['pages'].values():
            assert 'missing' not in page, page['title']
            pages[page['title']] = page
    def page_for(title):
        for _ in range(10):
            if title not in redirects: break
            title = redirects[title]
        return pages[title]
    wood_table = {}
    for table in Document(read(CACHE/'category-wood.json')['parse']['text']['*']).root.all('table'):
        rows = grid(table)
        if rows and 'M/u Log' in [c.text() if c else '' for c in rows[0]]:
            for row in rows[1:]:
                if len(row) == 8 and row[1] and row[2] and row[2].text().startswith('$'):
                    wood_table[row[1].text()+' Wood'] = (row[2].text(),row[3].text())
    result, conflicts = [], []
    for group in raw['groups']:
        for item in group['items']:
            page = page_for(item.get('w') or item['n'])
            text = page['revisions'][0]['slots']['main']['*']
            f = fields(text)
            collection = group['name'].replace(' · on sale now', '')
            facts = {'Collection': collection}
            if item.get('s'): facts['Gift / alternate name'] = item['s']
            if f.get('location'): facts['Location / original shop'] = f['location']
            price_label = 'Original gift price' if item.get('s') and '@gift' in str(item['x']) else 'Original listed price'
            price = item.get('p','')
            wiki_price = re.findall(r'\$[\d,]+(?:\.\d+)?', f.get('cost',''))
            if price and len(wiki_price)==1 and price.replace(',','')!=wiki_price[0].replace(',',''):
                conflicts.append({'id':item['k'],'field':price_label,'tracker':price,'wiki':wiki_price[0],
                                  'sources':['https://lt2tracker.com',url(page['title'])]})
                price = ''
                facts[price_label] = 'Unconfirmed · sources disagree'
            elif price:
                facts[price_label] = price
            mapping = {'damage':'Chop damage', 'range':'Chop range', 'swing cooldown':'Swing cooldown',
                       'hardness':'Wood hardness', 'average growth time':'Average growth time',
                       'moneyperlog':'Log sale per unit', 'moneyperplank':'Plank sale per unit'}
            for key, label in mapping.items():
                if f.get(key): facts[label] = f[key]
            if item['n'] in wood_table:
                for n, (key,label) in enumerate([('moneyperlog','Log sale per unit'),('moneyperplank','Plank sale per unit')]):
                    if f.get(key) and f[key] != wood_table[item['n']][n]:
                        conflicts.append({'id':item['k'], 'field':label, 'article':f[key], 'summary':wood_table[item['n']][n], 'sources':[url(page['title']),url('Category:Wood')]})
                        facts[label] = 'Unconfirmed · wiki sources disagree'
            if 'Average growth time' in facts: facts['Average growth time'] += ' · average, not a respawn countdown'
            forms = [x[1] for x in item['x']]
            if len(forms)>1: facts['Forms / variants'] = ', '.join(forms)
            historical = group['name'] == 'Removed & unobtainable'
            if historical: facts['Availability'] = 'Removed / unobtainable reference'
            elif 'Christmas' in collection or 'Thanksgiving' in collection or 'Halloween' in collection: facts['Availability'] = 'Seasonal collection · check the original event/shop'
            elif group['sec'] == 'shop': facts['Availability'] = 'Shop catalog'
            else: facts['Availability'] = collection
            name = raw['img'][item['i']]
            image = (CACHE/'images'/name).read_bytes()
            assert image[:4] == b'RIFF' and image[8:12] == b'WEBP'
            entry = dict(id=item['k'],name=item['n'],category=category(group,item),collection=collection,
                         image='data:image/webp;base64,'+base64.b64encode(image).decode(),source=url(page['title']),
                         imageSource='https://lt2tracker.com/img/'+name,
                         artwork={'provider':'LT2Tracker','sha256':digest(image),'checkedOn':CHECKED},
                         facts=facts,checkedOn=CHECKED,indexObtainable=not historical)
            # Sort by the stated original purchase price, never imply a trading value.
            if re.fullmatch(r'\$[\d,]+(?:\.\d+)?',price):
                entry['purchasePrice']=float(price[1:].replace(',',''))
            result.append(entry)
    assert len(result)==len({e['id'] for e in result})
    categories=[{'id':k,'name':v,'stackable':False,'fields':[]} for k,v in [
        ('axes','Axes'),('wood','Wood'),('vehicles','Vehicles & trailers'),('machinery','Sawmills & tools'),
        ('conveyors','Conveyors'),('wiring','Logic & wiring'),('furniture','Furniture'),('lighting','Lighting'),
        ('glass','Glass'),('paintings','Paintings'),('food','Food & candy'),('collectibles','Collectibles')]]
    def event(id,title,source,notes,start,end=None):
        return dict(id=id,title=title,group='Lumber Tycoon 2',source=url(source),notes=notes,
                    checkedOn=CHECKED,confidence='community',icon='calendar',color='#f59e0b',start=None,
                    dateStart=start,dateEnd=end,zone='UTC',duration=None,repeat='once',enabled=False,
                    scheduleConfirmed=False,estimatedEnd=False,remindStart=False,remindEnd=False,reminderMinutes=10,skipped=[])
    events=[event('halloween-2026','Halloween 2026','Halloween Events#2026 Halloween Event',
                  "October 1 release: Haunted Hatchet at Wood R Us ($16,661), Carved Pumpkin at Bob's Shack ($702), Burnt Bag of Candy at Fancy Furnishings ($1,009). Exact closing hour is unconfirmed.", '2026-10-01'),
            event('end-times-2026','End Times · October 31','End Times Event',
                  'The wiki lists an annual October 31 event. The Den awards the End Times Axe instead of Rukiryaxe. Exact server activation/closing hours are unconfirmed.', '2026-10-31','2026-10-31')]
    timers=[]
    for id,title,seconds,source,notes in [
        ('ferry-departure','Ferry departure cycle',360,'Ferry','Start at an observed departure from either dock. Passengers without tickets can delay departure. This is a server-relative reminder.'),
        ('ferry-crossing','Ferry crossing',132,'Ferry','Start when the ferry leaves. The wiki gives a 2 minute 12 second crossing; lag may affect the trip.'),
        ('bridge-toll','Bridge lowered',180,'Bridge','Start when paying the $100 toll. Each additional payment adds 3 minutes; restart or adjust your timer to match.')]:
        timers.append(dict(id=id,title=title,seconds=seconds,scope='server',clock='wall',source=url(source),checkedOn=CHECKED,confidence='community',notes=notes))
    guides={'sections':[
        {'title':'Halloween 2026','description':'Verified item releases; exact closing time remains unknown.','entries':[
            {'name':'Haunted Hatchet','description':'Wood R Us · $16,661. Specialized for Spooky and Sinister wood. Added October 1, 2026.','source':url('Haunted Hatchet')},
            {'name':'Carved Pumpkin','description':"Bob's Shack · $702. Unboxing gives a random size. Added October 1, 2026.",'source':url('Carved Pumpkin')},
            {'name':'Burnt Bag of Candy','description':'Fancy Furnishings · $1,009. Contains eight candy designs, including a rare unlabeled black bar; its drop chance is unverified.','source':url('Burnt Bag of Candy')}]},
        {'title':'Travel & quests','entries':[
            {'name':'Ferry','description':'$400 per crossing. The departure cycle is 6 minutes from a departure at either dock; crossing time is 2 minutes 12 seconds. Start a timer from the Events & timers tab when you observe the departure.','source':url('Ferry')},
            {'name':'Bridge','description':'$100 lowers the bridge for 3 minutes. Additional toll payments stack. Super Bridge owners can lower it free.','source':url('Bridge')},
            {'name':'The Den','description':'The standard axe quest uses a Bag of Sand, Can of Worms and Lightbulb. On October 31, the reward changes from Rukiryaxe to End Times Axe.','source':url('The Den')}]},
        {'title':'Seasonal reference','entries':[
            {'name':'Christmas gifts','description':'Browse the past gift collections by year in the catalog. New 2026 gift dates and items have not been verified.','source':url('Christmas Events')},
            {'name':'Thanksgiving collectibles','description':'Past seasonal food and collectible items are included. The 2026 release schedule has not been verified.','source':url('Thanksgiving Events')}]}]}
    evidence=[]
    for path in sorted(CACHE.glob('*.json')):
        if path.name.startswith('item-pages-') or path.name in ['tracker-data.json','bridge.json','ferry.json','halloween-events.json','end-times-event.json','christmas-events.json','thanksgiving-events.json']:
            evidence.append({'reference':path.stem,'responseSha256':digest(path.read_bytes()),'checkedOn':CHECKED})
    pack=dict(schema=1,id='lumber-tycoon-2',name='Lumber Tycoon 2',aliases=['LT2','Lumber Tycoon'],placeIds=['13822889'],
              icon=read(CACHE/'game-icon.json')['data'][0]['imageUrl'],fields=[],inventoryEngine='checklist',currencies=[],
              catalogs={'collection':dict(schema=1,categories=categories,entries=result,sources=['https://lt2tracker.com',url('')],
                          sourceEvidence=evidence,conflictingFacts=conflicts,
                          attribution='Catalog facts and exact artwork from LT2Tracker, cross-checked against the Lumber Tycoon 2 Wiki. Wiki contributions are CC BY-SA; artwork belongs to its creators.'), 'guides':guides},
              events=events,timerPresets=timers,helpers=[],sources=['https://lt2tracker.com',url(''),'https://www.roblox.com/games/13822889'],
              contentNote='Public catalog with account-specific owned checks. Original prices are in-game money, not trading prices. Removed items remain historical references.',
              navigation=[{'id':id,'name':name,'icon':icon,'view':view,**extra} for id,name,icon,view,extra in [
                  ('catalog','Catalog','book','checklist-catalog',{}),('owned','Owned checklist','check','checklist-owned',{}),
                  ('overview','Accounts','users','checklist-overview',{}),('guides','Guides & events','book','reference',{'catalog':'guides'}),
                  ('events','Events & timers','calendar','events',{}),('servers','Servers','flag','servers',{})]])
    (ROOT/'content/collections/lumber-tycoon-2.json').write_text(json.dumps(pack,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    definitions=read(ROOT/'content/event-schedules.json');definitions['games'][pack['id']]={'events':events,'timerPresets':timers}
    (ROOT/'content/event-schedules.json').write_text(json.dumps(definitions,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
    content=(json.dumps(pack,ensure_ascii=False,separators=(',',':'))+'\n').encode();sha=digest(content)
    descriptor={'id':pack['id'],'file':'game-lumber-tycoon-2-'+sha[:16]+'.json','sha256':sha};(PUBLIC/descriptor['file']).write_bytes(content)
    manifest=read(PUBLIC/'manifest.json');manifest['games']=[g for g in manifest['games'] if g['id']!=pack['id']]+[descriptor]
    manifest['revision']='content-'+digest(json.dumps({'games':manifest['games'],'achievements':manifest['achievements']},sort_keys=True).encode())[:12]
    (PUBLIC/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf8')
    bundle=read(ROOT/'web/game-content.json');bundle['manifest']=manifest;bundle['packs'][pack['id']]=pack
    (ROOT/'web/game-content.json').write_text(json.dumps(bundle,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf8')
    print(len(result),'catalog items,',sum(e['indexObtainable'] for e in result),'checkable;',len(conflicts),'conflicting facts left unconfirmed;',len(content),'pack bytes')


if __name__=='__main__':
    main()
