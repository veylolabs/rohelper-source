'use strict';
// Data-driven collections without inventory copies, quantities, or account initialization on browse.
window.HelperChecklists=(()=>{
 const states=new Map(),account=id=>db.accounts.find(a=>a.id===id),catalog=p=>p.catalogs.collection;
 const state=p=>{if(!states.has(p.id))states.set(p.id,{owner:'',category:'',group:'',query:'',ownership:'all',sort:'name'});return states.get(p.id);};
 const checks=(a,p)=>a?.gameData?.[p.id]?.index?.normal||{};
 const entries=p=>catalog(p).entries.filter(e=>e.indexObtainable!==false);
 function setOwned(p,id,e,value){
  const a=account(id);if(!a){toast('This account was removed.');return false;}
  if(e.indexObtainable===false)return false;
  HelperCollections.mutate(p,value?'mark owned':'uncheck owned',[a],()=>{
   a.gameData??={};const d=a.gameData[p.id]??={_collectionSchema:1};d.index??={};d.index.normal??={};d.index.normal[e.id]=value;
  });return true;
 }
 function choose(p,e,done){
  HelperItemDestinations.accounts({name:e.name,onSelect:id=>{state(p).owner=id;if(setOwned(p,id,e,true)){renderMain();done?.(id);}}});
 }
 function details(p,e){
  const s=state(p),a=account(s.owner),m=HelperSab.dialog(e.name,a?'@'+a.username+' · '+p.name:p.name+' catalog','Done',({close})=>close());
  m.dialog.classList.add('catalog-dialog');HelperCollections.facts(m.body,p,e);
  if(e.indexObtainable===false){m.body.append(node('p','Historical reference · excluded from the owned checklist.','help-text'));return;}
  const b=button('',()=>{
   if(!account(s.owner)){m.close().then(()=>choose(p,e));return;}
   if(setOwned(p,s.owner,e,!checks(account(s.owner),p)[e.id])){update();renderMain();}
  },'ghost');
  function update(){const a=account(s.owner),owned=!!checks(a,p)[e.id];b.textContent=a?(owned?'Uncheck owned':'Mark as owned'):'Mark owned for an account';b.setAttribute('aria-pressed',String(owned));}
  update();m.foot.insertBefore(b,m.save);
 }
 function openAccount(id,game){const p=HelperGames.pack(game);state(p).owner=id;HelperGames.open(game,'owned');}
 function accountLinks(host,id,p){host.append(button('Open '+p.name+' owned checklist',()=>{document.querySelector('#modal[open]')?.close();openAccount(id,p.id);},'ghost section-gap','check'));}
 function overview(host,p){
  host.append(heading(p.name,'Owned items are saved separately for every account.'));
  const grid=node('div',undefined,'account-grid'),all=entries(p);
  for(const a of db.accounts){const card=node('article',undefined,'account-card'),head=node('div',undefined,'row'),n=all.filter(e=>checks(a,p)[e.id]===true).length;
   head.append(avatar(a),node('strong',a.nickname||a.displayName||a.username));card.append(head,node('small','@'+a.username),node('p',n+' / '+all.length+' owned','collection-progress'),button('Owned checklist',()=>openAccount(a.id,p.id),'ghost','check'));grid.append(card);
  }
  host.append(grid);if(!db.accounts.length)host.append(empty('No accounts yet','Add an account to save an owned checklist.'));
 }
 function browse(host,p,t){
  const s=state(p),isChecklist=t.view==='checklist-owned',bar=node('div',undefined,'catalog-toolbar'),tabs=node('div',undefined,'row wrap catalog-tabs'),body=node('div');
  host.append(heading(p.name+(isChecklist?' · Owned checklist':' catalog'),isChecklist?'Click an item to check or uncheck it. Right-click for details.':'Browse all items, shops and seasonal collections.',[button('Undo',()=>HelperCollections.undo(p),'ghost','back')]),tabs,bar,body);
  for(const c of [{id:'',name:'All items'},...catalog(p).categories]){const b=button(c.name,()=>{s.category=c.id;renderMain();},s.category===c.id?'primary':'ghost');b.setAttribute('aria-pressed',String(s.category===c.id));tabs.append(b);}
  const owner=select(p.name+' account',[['','Choose an account'],...db.accounts.map(a=>[a.id,'@'+a.username])],s.owner),q=input('Search '+p.name,s.query),filter=select('Ownership',[['all','All items'],['owned','Owned'],['missing','Missing']],s.ownership),group=select('Item collection',[['','All collections'],...[...new Set(catalog(p).entries.map(e=>e.collection).filter(Boolean))].map(g=>[g,g])],s.group),sort=select('Sort items',[['name','Name A–Z'],['price','Original price: high to low']],s.sort);
  q.placeholder='Search items, gifts, shops or locations…';bar.append(owner,q,filter,group,sort);
  owner.onchange=()=>{s.owner=owner.value;draw();};q.oninput=()=>{s.query=q.value;draw();};filter.onchange=()=>{s.ownership=filter.value;draw();};group.onchange=()=>{s.group=group.value;draw();};sort.onchange=()=>{s.sort=sort.value;draw();};
  function draw(){
   body.replaceChildren();const a=account(s.owner),owned=checks(a,p),all=entries(p),n=all.filter(e=>owned[e.id]===true).length;
   if(!a&&(isChecklist||s.ownership!=='all')){body.append(empty('Choose an account','Owned checks belong to that account only.'));return;}
   if(a)body.append(node('p',n+' / '+all.length+' owned · @'+a.username,'collection-progress'));
   const list=(isChecklist?all:catalog(p).entries).filter(e=>(!s.category||e.category===s.category)&&(!s.group||e.collection===s.group)&&[e.name,...Object.values(e.facts||{})].join(' ').toLowerCase().includes(s.query.toLowerCase())&&(s.ownership==='all'||e.indexObtainable!==false&&(s.ownership==='owned'?owned[e.id]===true:owned[e.id]!==true)));
   list.sort((a,b)=>(s.sort==='price'?(b.purchasePrice??-1)-(a.purchasePrice??-1):0)||a.name.localeCompare(b.name));
   body.append(node('p',list.length+' matching items','muted'));const grid=node('div',undefined,'catalog-grid collection-index');
   for(const e of list){const held=owned[e.id]===true,b=button('',()=>{if(isChecklist){if(setOwned(p,a.id,e,!held))draw();}else details(p,e);},'catalog-card'+(held?' obtained':''));
    b.dataset.checklistItem=e.id;b.setAttribute('aria-label',e.name+(isChecklist?(held?' · Owned':' · Missing'):''));if(isChecklist)b.setAttribute('aria-pressed',String(held));
    b.append(HelperCollections.image(e),node('strong',e.name),node('small',catalog(p).categories.find(c=>c.id===e.category)?.name||''));
    if(e.collection)b.append(node('small',e.collection));if(e.indexObtainable===false)b.append(node('small','Historical reference'));
    if(held)b.append(node('span','✓','collection-acquired'));b.oncontextmenu=ev=>{ev.preventDefault();details(p,e);};grid.append(b);
   }
   if(!list.length)grid.append(empty('No matching items','Try another category, collection or search.'));body.append(grid);
  }
  draw();enhance(bar);
 }
 function render(host,p,t){const s=state(p);if(s.owner&&!account(s.owner))s.owner='';if(!catalog(p)){host.append(empty('Catalog unavailable','Refresh game content in Settings.'));return;}if(t.view==='checklist-overview')overview(host,p);else browse(host,p,t);}
 return {render,openAccount,accountLinks};
})();
