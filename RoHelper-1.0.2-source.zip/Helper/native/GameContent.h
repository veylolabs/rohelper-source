#pragma once
#include "Store.h"
#include "AchievementContent.h"
#include <winhttp.h>
#include <functional>

// Public, data-only content. This class has no access to sessions or accounts.
namespace GameContent {
inline bool ValidId(const std::string& value){return std::regex_match(value,std::regex("[a-z0-9][a-z0-9_-]{0,79}"))&&value!="constructor"&&value!="prototype"&&value!="__proto__";}
inline std::string Digest(const std::string& bytes){BYTE hash[32];DWORD size=sizeof(hash);if(!CryptHashCertificate2(L"SHA256",0,nullptr,(const BYTE*)bytes.data(),(DWORD)bytes.size(),hash,&size))throw std::runtime_error("Content checksum failed.");std::string out;for(auto b:hash){out+="0123456789abcdef"[b>>4];out+="0123456789abcdef"[b&15];}return out;}
inline void Text(const json& x,const char* key,size_t limit){if(!x.contains(key)||!x[key].is_string()||x[key].get<std::string>().size()>limit)throw std::runtime_error("Invalid game content text.");}
inline bool Artwork(const json& value){if(!value.is_string())return false;auto s=value.get<std::string>();if(s.rfind("https://",0)==0)return s.size()<=4000;for(auto prefix:{"data:image/png;base64,","data:image/webp;base64,","data:image/jpeg;base64,"})if(s.rfind(prefix,0)==0)return s.size()<=1000000&&std::all_of(s.begin()+strlen(prefix),s.end(),[](unsigned char c){return std::isalnum(c)||c=='+'||c=='/'||c=='=';});return false;}
#include "CollectionContent.h"
inline void MutationEffects(const json& catalog){
 if(catalog.at("schema")!=1||!catalog.at("effects").is_object()||catalog["effects"].size()>100)throw std::runtime_error("Invalid mutation effects.");
 for(auto& row:catalog["effects"].items()){if(!ValidId(row.key()))throw std::runtime_error("Invalid mutation effect ID.");auto& a=row.value();auto& palette=a.at("palette");if(!palette.is_array()||palette.size()!=2)throw std::runtime_error("Invalid mutation palette.");for(auto& rgb:palette){if(!rgb.is_array()||rgb.size()!=3)throw std::runtime_error("Invalid mutation palette.");for(auto& n:rgb)if(!n.is_number()||!std::isfinite(n.get<double>())||n<0||n>1)throw std::runtime_error("Invalid mutation color.");}
  for(auto k:{"gamma","amplitude"})if(a.contains(k)&&(!a[k].is_number()||!std::isfinite(a[k].get<double>())||a[k]<=0||a[k]>10))throw std::runtime_error("Invalid mutation filter.");
  if(a.contains("glow"))Text(a,"glow",120);
  if(a.contains("texture")){if(!a["texture"].is_object()||a["texture"].size()>5)throw std::runtime_error("Invalid mutation texture.");for(auto& t:a["texture"].items()){if(t.key()!="background"&&t.key()!="background-image"&&t.key()!="background-size"&&t.key()!="mix-blend-mode"&&t.key()!="opacity")throw std::runtime_error("Invalid texture property.");if(!t.value().is_string()||t.value().get<std::string>().size()>6000)throw std::runtime_error("Invalid texture data.");auto v=t.value().get<std::string>();if(v.find("url(")!=std::string::npos&&v.find("url(\"data:image/svg+xml,")!=0)throw std::runtime_error("Invalid texture image.");}}
  if(a.contains("cycle")){auto& c=a["cycle"];if(!c.at("seconds").is_number()||c["seconds"]<1||c["seconds"]>300||!c.at("channels").is_array()||c["channels"].size()!=3)throw std::runtime_error("Invalid mutation cycle.");for(auto& values:c["channels"]){if(!values.is_array()||values.empty()||values.size()>32)throw std::runtime_error("Invalid mutation cycle.");for(auto& n:values)if(!n.is_number()||!std::isfinite(n.get<double>())||n<0||n>1)throw std::runtime_error("Invalid mutation cycle.");}}
  if(a.contains("table")){if(!a["table"].is_array()||a["table"].empty()||a["table"].size()>32)throw std::runtime_error("Invalid mutation tone table.");for(auto& n:a["table"])if(!n.is_number()||!std::isfinite(n.get<double>())||n<0||n>1)throw std::runtime_error("Invalid mutation tone table.");}
  if(a.contains("corona"))for(auto k:{"color","shadow"}){Text(a["corona"],k,9);if(!std::regex_match(a["corona"][k].get<std::string>(),std::regex("#[a-fA-F0-9]{6}([a-fA-F0-9]{2})?")))throw std::runtime_error("Invalid mutation glow.");}
 }
}
inline void ValidateAchievementLocation(const json& m){if(!m.contains("achievements"))return;const auto& a=m["achievements"];if(!a.at("file").is_string()||!std::regex_match(a["file"].get<std::string>(),std::regex("achievements-[a-f0-9]{16}\\.json"))||!a.at("sha256").is_string()||!std::regex_match(a["sha256"].get<std::string>(),std::regex("[a-f0-9]{64}")))throw std::runtime_error("Invalid achievement catalog location.");}
inline void ValidateManifest(const json& m){ValidateAchievementLocation(m);
 if(m.at("schema")!=1||m.at("engineVersion")!=1)throw std::runtime_error("This game catalog needs a newer RoHelper version.");
 Text(m,"revision",100);if(!m.at("games").is_array()||m["games"].size()>100)throw std::runtime_error("Invalid game catalog manifest.");
 std::set<std::string> ids;for(auto& g:m["games"]){Text(g,"id",80);auto id=g["id"].get<std::string>();if(!ValidId(id)||!ids.insert(id).second)throw std::runtime_error("Duplicate game ID.");Text(g,"file",200);Text(g,"sha256",64);
  if(!std::regex_match(g["file"].get<std::string>(),std::regex("game-[a-z0-9_-]+-[a-f0-9]{16}\\.json"))||!std::regex_match(g["sha256"].get<std::string>(),std::regex("[a-f0-9]{64}")))throw std::runtime_error("Invalid game content location or checksum.");}
}
inline void ValidatePack(const json& p,const std::string& expected){
 HelperEventContent::Pack(p);if(p.value("inventoryEngine",std::string())=="collection"||p.value("inventoryEngine",std::string())=="checklist")ValidateCollection(p);
 if(p.at("schema")!=1||p.at("id")!=expected||!ValidId(expected))throw std::runtime_error("Invalid game pack ID or format.");
 Text(p,"name",160);Text(p,"icon",2000);auto icon=p["icon"].get<std::string>();if(!icon.empty()&&icon.rfind("https://",0)!=0)throw std::runtime_error("Game icons require HTTPS.");
 if(!p.at("aliases").is_array()||p["aliases"].size()>64||!p.at("placeIds").is_array()||p["placeIds"].size()>32||!p.at("fields").is_array()||p["fields"].size()>128||!p.at("catalogs").is_object()||p.dump().size()>12*1024*1024)throw std::runtime_error("Invalid game pack.");
 for(auto& a:p["aliases"])if(!a.is_string()||a.get<std::string>().size()>160)throw std::runtime_error("Invalid game alias.");
 for(auto& a:p["placeIds"])if(!a.is_string()||!std::regex_match(a.get<std::string>(),std::regex("[1-9][0-9]{0,23}")))throw std::runtime_error("Invalid game place ID.");
 std::set<std::string> ids;for(auto& f:p["fields"]){Text(f,"id",80);auto id=f["id"].get<std::string>();if(!ValidId(id)||!ids.insert(id).second)throw std::runtime_error("Invalid game field ID.");Text(f,"name",120);auto type=f.at("type").get<std::string>();auto& value=f.at("default");
  if(type=="text"){if(!value.is_string()||value.get<std::string>().size()>16000)throw std::runtime_error("Invalid game text default.");}
  else if(type=="check"){if(!value.is_boolean())throw std::runtime_error("Invalid game checkbox default.");}
  else if(type=="number"){if(!value.is_number()||!std::isfinite(value.get<double>()))throw std::runtime_error("Invalid game number default.");for(auto k:{"min","max","step"})if(f.contains(k)&&(!f[k].is_number()||!std::isfinite(f[k].get<double>())))throw std::runtime_error("Invalid game field bounds.");if(f.contains("min")&&value<f["min"]||f.contains("max")&&value>f["max"]||f.contains("step")&&f["step"]<=0||f.contains("min")&&f.contains("max")&&f["min"]>f["max"])throw std::runtime_error("Invalid game field bounds.");}
  else throw std::runtime_error("This game field type needs a newer RoHelper version.");
 }
 if(p.contains("catalogs")&&p["catalogs"].contains("gear")){
  const auto& g=p["catalogs"]["gear"];if(!g.at("entries").is_array()||g["entries"].size()>2000||!g.at("categories").is_array()||g["categories"].size()>64)throw std::runtime_error("Invalid gear catalog.");std::set<std::string> categories,entries;
  for(auto& c:g["categories"]){Text(c,"id",80);Text(c,"name",160);auto id=c["id"].get<std::string>();if(!ValidId(id)||!categories.insert(id).second)throw std::runtime_error("Invalid gear category.");}
  for(auto& i:g["entries"]){Text(i,"id",80);Text(i,"name",160);Text(i,"category",80);auto id=i["id"].get<std::string>();if(!ValidId(id)||!entries.insert(id).second||!categories.count(i["category"].get<std::string>()))throw std::runtime_error("Invalid gear item.");if(i.contains("image")&&!i["image"].is_null()&&!Artwork(i["image"]))throw std::runtime_error("Invalid gear artwork.");}
 }
 if(p.at("catalogs").contains("mutationEffects"))MutationEffects(p["catalogs"]["mutationEffects"]);
 if(p.value("inventoryEngine",std::string())=="adopt-me"){
  auto& c=p.at("catalogs").at("items");if(!c.at("entries").is_array()||c["entries"].size()>15000||!c.at("categories").is_array()||c["categories"].size()>64)throw std::runtime_error("Invalid Adopt Me catalog.");
  std::set<std::string> categories,entries;for(auto& cat:c["categories"]){Text(cat,"id",80);Text(cat,"name",160);auto id=cat["id"].get<std::string>();if(!ValidId(id)||!categories.insert(id).second)throw std::runtime_error("Invalid Adopt Me category.");}
  for(auto& item:c["entries"]){for(auto key:{"id","name","category"})Text(item,key,std::string(key)=="name"?160:100);auto id=item["id"].get<std::string>();if(!ValidId(id)||!entries.insert(id).second||!categories.count(item["category"].get<std::string>()))throw std::runtime_error("Invalid Adopt Me item.");if(item.contains("image")&&!item["image"].is_null()&&(!item["image"].is_string()||item["image"].get<std::string>().rfind("https://",0)!=0||item["image"].get<std::string>().size()>4000))throw std::runtime_error("Invalid Adopt Me artwork.");if(item.contains("tradeValues")){auto& v=item["tradeValues"];if(!v.is_array()||(v.size()!=0&&v.size()!=1&&v.size()!=12))throw std::runtime_error("Invalid Adopt Me value variants.");for(auto& n:v)if(!n.is_number()||!std::isfinite(n.get<double>())||n<0)throw std::runtime_error("Invalid Adopt Me value.");}}
  auto& growth=c.at("growth");for(auto key:{"normal","neon"}){if(!growth.at(key).is_array()||growth[key].size()!=6)throw std::runtime_error("Invalid pet growth stages.");for(auto& s:growth[key])if(!s.is_string()||s.get<std::string>().size()>80)throw std::runtime_error("Invalid pet growth label.");}for(auto& r:growth.at("tasks").items()){if(!r.value().is_array()||r.value().size()!=5)throw std::runtime_error("Invalid pet task table.");for(auto& n:r.value())if(!n.is_number_integer()||n<0||n>10000)throw std::runtime_error("Invalid growth task count.");}
  if(c.contains("hatchPools")){std::set<std::string> pets,eggs;for(auto& e:c["entries"]){if(e["category"]=="pets")pets.insert(e["id"]);if(e["category"]=="eggs")eggs.insert(e["id"]);}auto& pools=c["hatchPools"].at("pools");if(!pools.is_object()||pools.size()>500)throw std::runtime_error("Invalid hatch pools.");for(auto& p:pools.items()){if(!eggs.count(p.key())||!p.value().at("petIds").is_array()||p.value()["petIds"].size()>1000)throw std::runtime_error("Invalid egg hatch pool.");std::set<std::string> seen;for(auto& id:p.value()["petIds"])if(!id.is_string()||!pets.count(id.get<std::string>())||!seen.insert(id.get<std::string>()).second)throw std::runtime_error("Invalid hatchable pet.");}}
 }
}
inline void ValidateBundle(const json& b){ValidateManifest(b.at("manifest"));if(b.contains("achievements"))AchievementContent::Validate(b["achievements"]);if(b["manifest"].contains("achievements")&&!b.contains("achievements"))throw std::runtime_error("Achievement catalog is missing.");if(!b.at("packs").is_object()||b.dump().size()>32*1024*1024)throw std::runtime_error("Invalid content bundle.");for(auto& d:b["manifest"]["games"]){auto id=d["id"].get<std::string>();ValidatePack(b["packs"].at(id),id);}}
struct HttpHandle {HINTERNET value=nullptr;explicit HttpHandle(HINTERNET v):value(v){}~HttpHandle(){if(value)WinHttpCloseHandle(value);}operator HINTERNET()const{return value;}};
inline std::string Download(const std::string& file){
 // Fixed public endpoint, GET only, no credentials, no redirect or private-data payload.
 HttpHandle session(WinHttpOpen(L"RoHelper game content/1",WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,WINHTTP_NO_PROXY_NAME,WINHTTP_NO_PROXY_BYPASS,0));if(!session.value)throw std::runtime_error("Game content connection failed.");WinHttpSetTimeouts(session,5000,5000,10000,10000);
 HttpHandle connection(WinHttpConnect(session,L"raw.githubusercontent.com",INTERNET_DEFAULT_HTTPS_PORT,0));if(!connection.value)throw std::runtime_error("Game content connection failed.");auto path=L"/veylolabs/rohelper-game-data/main/"+Wide(file);
 HttpHandle request(WinHttpOpenRequest(connection,L"GET",path.c_str(),nullptr,WINHTTP_NO_REFERER,WINHTTP_DEFAULT_ACCEPT_TYPES,WINHTTP_FLAG_SECURE));if(!request.value)throw std::runtime_error("Game content request failed.");DWORD redirect=WINHTTP_OPTION_REDIRECT_POLICY_NEVER;WinHttpSetOption(request,WINHTTP_OPTION_REDIRECT_POLICY,&redirect,sizeof(redirect));
 if(!WinHttpSendRequest(request,L"Accept: application/json\r\nCache-Control: no-cache\r\n",(DWORD)-1,nullptr,0,0,0)||!WinHttpReceiveResponse(request,nullptr))throw std::runtime_error("Game content is unavailable. The last working catalog is kept.");DWORD status=0,size=sizeof(status);if(!WinHttpQueryHeaders(request,WINHTTP_QUERY_STATUS_CODE|WINHTTP_QUERY_FLAG_NUMBER,WINHTTP_HEADER_NAME_BY_INDEX,&status,&size,WINHTTP_NO_HEADER_INDEX)||status!=200)throw std::runtime_error("Game content update failed (HTTP "+std::to_string(status)+"). The last working catalog is kept.");
 std::string bytes;char buffer[16384];DWORD count=0;for(;;){if(!WinHttpReadData(request,buffer,sizeof(buffer),&count))throw std::runtime_error("Game content download was interrupted.");if(!count)break;if(bytes.size()+count>12*1024*1024)throw std::runtime_error("Game content download is too large.");bytes.append(buffer,count);}return bytes;
}
using Fetch=std::function<std::string(const std::string&)>;
inline json Refresh(const json& old,const Fetch& fetch=Download){
 auto manifest=json::parse(fetch("manifest.json"));ValidateManifest(manifest);json result={{"manifest",manifest},{"packs",json::object()}};
 if(old.contains("manifest")&&manifest.value("layoutVersion",0)<old["manifest"].value("layoutVersion",0))throw std::runtime_error("The online catalog is older than the bundled game layout. The current catalog is kept.");
 for(auto& d:manifest["games"]){auto id=d["id"].get<std::string>();bool reuse=false;
  if(old.contains("manifest")&&old.contains("packs")&&old["packs"].contains(id))for(auto& before:old["manifest"]["games"])if(before["id"]==id&&before["sha256"]==d["sha256"])reuse=true;
  if(reuse)result["packs"][id]=old["packs"][id];else{auto bytes=fetch(d["file"]);if(Digest(bytes)!=d["sha256"])throw std::runtime_error("Game content checksum does not match. The last working catalog is kept.");auto pack=json::parse(bytes);ValidatePack(pack,id);result["packs"][id]=std::move(pack);}
 }
 if(manifest.contains("achievements")){auto descriptor=manifest["achievements"];if(old.contains("achievements")&&old.contains("manifest")&&old["manifest"].value("achievements",json())==descriptor)result["achievements"]=old["achievements"];else{auto bytes=fetch(descriptor["file"]);if(Digest(bytes)!=descriptor["sha256"])throw std::runtime_error("Achievement checksum does not match; cached content is kept.");result["achievements"]=json::parse(bytes);}}
 else if(old.contains("achievements"))result["achievements"]=old["achievements"];
 ValidateBundle(result);return result;
}
struct Cache {
 fs::path path;json bundle={{"manifest",{{"schema",1},{"engineVersion",1},{"revision","none"},{"games",json::array()}}},{"packs",json::object()}};std::string message;bool refreshing=false;ULONGLONG lastAttempt=0;
 Cache(const fs::path& directory,const fs::path& fallback):path(directory/L"game-content.json"){
  try{auto base=json::parse(SafeStorage::Read(fallback));ValidateBundle(base);bundle=std::move(base);}catch(...){message="Bundled game content is unavailable.";}
  if(fs::exists(path))try{auto cached=json::parse(SafeStorage::Read(path));ValidateBundle(cached);if(cached["manifest"].value("layoutVersion",0)>=bundle["manifest"].value("layoutVersion",0)){if(!cached.contains("achievements")&&bundle.contains("achievements"))cached["achievements"]=bundle["achievements"];bundle=std::move(cached);}}catch(...){message="The game content cache could not be read. Bundled content is in use.";}
 }
 void Install(const json& updated){ValidateBundle(updated);SafeStorage::Write(path,updated.dump());bundle=updated;message.clear();}
 json Public()const{return {{"bundle",bundle},{"refreshing",refreshing},{"message",message}};}
};
}
