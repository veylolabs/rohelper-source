#pragma once
#include "Clients.h"
#include "Macros.h"
namespace Automation {
struct Target{RosterClients::Client client;json options;std::string script,status="Waiting";std::unique_ptr<MacroVM> vm;std::set<WORD> held;std::set<std::string> mouseHeld;ULONGLONG due=0;bool pending=false,stopped=false;MacroAction action;};
inline std::map<DWORD,std::unique_ptr<Target>> targets;inline std::mt19937 rng(std::random_device{}());inline DWORD lastSynthetic=0;inline HWND previous=nullptr;inline DWORD owner=0;inline ULONGLONG settle=0;
inline bool Valid(const RosterClients::Client& c){RosterClients::Handle p(OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION|SYNCHRONIZE,FALSE,c.pid));DWORD pid=0;GetWindowThreadProcessId(c.window,&pid);return p.value&&pid==c.pid&&RosterClients::IsRoblox(p.value)&&RosterClients::Token(p.value)==c.token&&WaitForSingleObject(p.value,0)==WAIT_TIMEOUT;}
inline INPUT Key(WORD key,bool up){INPUT in{};in.type=INPUT_KEYBOARD;in.ki.wScan=(WORD)MapVirtualKeyW(key,MAPVK_VK_TO_VSC);in.ki.dwFlags=KEYEVENTF_SCANCODE|(up?KEYEVENTF_KEYUP:0);if(key==VK_LEFT||key==VK_RIGHT||key==VK_UP||key==VK_DOWN||key==VK_HOME||key==VK_END||key==VK_DELETE||key==VK_INSERT||key==VK_PRIOR||key==VK_NEXT)in.ki.dwFlags|=KEYEVENTF_EXTENDEDKEY;return in;}
inline void Mark(){LASTINPUTINFO info={sizeof(info)};if(GetLastInputInfo(&info))lastSynthetic=info.dwTime;}
inline bool Held(const Target& t){return !t.held.empty()||!t.mouseHeld.empty();}
inline void ReleaseMouse(Target& t){bool sent=false;for(const auto& button:t.mouseHeld){auto input=MouseMacro::Button(button,true);sent=(SendInput(1,&input,sizeof(input))==1)||sent;}t.mouseHeld.clear();if(sent)Mark();}
inline void Release(Target& t){ReleaseMouse(t);bool sent=false;for(auto key:t.held){auto in=Key(key,true);sent=(SendInput(1,&in,sizeof(in))==1)||sent;}t.held.clear();if(sent)Mark();}
inline void Unfocus(Target& t){if(owner==t.client.pid){if(GetForegroundWindow()==t.client.window&&previous&&IsWindow(previous))SetForegroundWindow(previous);owner=0;previous=nullptr;}}
inline bool Quiet(){LASTINPUTINFO info={sizeof(info)};return GetLastInputInfo(&info)&&(info.dwTime==lastSynthetic||DWORD(GetTickCount()-info.dwTime)>=3000);}
inline void Stop(DWORD pid,const std::string& token){auto it=targets.find(pid);if(it!=targets.end()&&it->second->client.token==token){Release(*it->second);Unfocus(*it->second);targets.erase(it);}}
inline void StopAll(){while(!targets.empty())Stop(targets.begin()->first,targets.begin()->second->client.token);}
inline void Start(const RosterClients::Client& client,const json& opts,const std::string& script){ValidateOptions(opts);if(!Valid(client))throw std::runtime_error("This client has closed.");if(opts["mode"]=="macro"){if(script.empty())throw std::runtime_error("Select a saved macro in this account’s settings.");MacroVM::Check(script);}Stop(client.pid,client.token);auto t=std::make_unique<Target>();t->client=client;t->options=opts;t->script=script;t->due=GetTickCount64();targets[client.pid]=std::move(t);}
inline void Tick(){auto now=GetTickCount64();for(auto it=targets.begin();it!=targets.end();){auto& t=*it->second;if(!Valid(t.client)){Release(t);Unfocus(t);it=targets.erase(it);continue;}++it;if(t.stopped)continue;
 try{
 if(t.options.value("pauseOnActivity",true)&&!Quiet()){Release(t);Unfocus(t);t.vm.reset();t.pending=false;t.due=now+1000;t.status="Paused while you use the PC";continue;}
 if(owner==t.client.pid&&GetForegroundWindow()!=t.client.window){Release(t);Unfocus(t);t.vm.reset();t.pending=false;t.due=now+1000;t.status="Paused after focus changed";continue;}
 if(now<t.due)continue;if(owner&&owner!=t.client.pid)continue;
 if(!t.pending){if(!t.vm){auto code=t.script;if(t.options["mode"]=="simple"){auto keys=t.options["keys"];code="press(\""+keys[std::uniform_int_distribution<size_t>(0,keys.size()-1)(rng)].get<std::string>()+"\",0.2)";}t.vm=std::make_unique<MacroVM>(code);}if(!t.vm->Advance()){Release(t);Unfocus(t);t.vm.reset();double delay=t.options["repeatSeconds"].get<double>();if(t.options["mode"]=="simple")delay=std::uniform_real_distribution<double>(t.options["minSeconds"].get<double>(),t.options["maxSeconds"].get<double>())(rng);t.due=now+(ULONGLONG)(1000*delay);t.status="Waiting for next cycle";continue;}t.action=t.vm->next;t.pending=true;}
 auto action=t.action;if(action.kind=="mouse_release"){ReleaseMouse(t);t.pending=false;t.status="Mouse released";if(!Held(t))Unfocus(t);continue;}if(action.kind=="wait"){t.due=now+(ULONGLONG)(action.seconds*1000);t.pending=false;t.status=Held(t)?"Holding input":"Waiting";if(!Held(t))Unfocus(t);continue;}
 if(owner!=t.client.pid){previous=GetForegroundWindow();if(IsIconic(t.client.window))ShowWindow(t.client.window,SW_RESTORE);SetForegroundWindow(t.client.window);if(GetForegroundWindow()!=t.client.window){previous=nullptr;t.status="Windows blocked focus; waiting";t.due=now+1000;continue;}owner=t.client.pid;settle=now+150;t.due=settle;continue;}if(now<settle)continue;
 if(action.kind=="mouse_move"||action.kind=="mouse_click"||action.kind=="mouse_double"||action.kind=="mouse_hold"){
 const auto point=MouseMacro::ScreenPosition(t.client.window,action.origin,action.x,action.y);auto hit=WindowFromPoint(point);
 if(hit!=t.client.window&&!IsChild(t.client.window,hit))throw std::runtime_error("Click location is covered by another window.");
 if(t.mouseHeld.count(action.button))throw std::runtime_error("Release the held mouse button before clicking it.");
 const RECT desktop{GetSystemMetrics(SM_XVIRTUALSCREEN),GetSystemMetrics(SM_YVIRTUALSCREEN),GetSystemMetrics(SM_XVIRTUALSCREEN)+GetSystemMetrics(SM_CXVIRTUALSCREEN),GetSystemMetrics(SM_YVIRTUALSCREEN)+GetSystemMetrics(SM_CYVIRTUALSCREEN)};
 if(action.kind=="mouse_move"){auto input=MouseMacro::Move(point,desktop);if(SendInput(1,&input,sizeof(input))!=1)throw std::runtime_error("Windows blocked mouse movement.");Mark();t.pending=false;t.status="Running · mouse move";if(!Held(t))Unfocus(t);continue;}
 auto input=MouseMacro::Inputs(point,desktop,action.button,action.kind=="mouse_hold");t.mouseHeld.insert(action.button);
 if(SendInput((UINT)input.size(),input.data(),sizeof(INPUT))!=input.size())throw std::runtime_error("Windows blocked mouse input.");
 if(action.kind!="mouse_hold")t.mouseHeld.erase(action.button);Mark();t.status=action.kind=="mouse_hold"?"Holding "+action.button+" mouse button":"Running · mouse click";
 if(action.kind=="mouse_double"){t.action.kind="mouse_click";t.due=now+std::max<DWORD>(20,std::min<DWORD>(80,GetDoubleClickTime()/4));continue;}
 t.pending=false;if(!Held(t))Unfocus(t);continue;
 }
 auto key=MacroVM::Key(action.key);auto in=Key(key,action.kind=="up");if(SendInput(1,&in,sizeof(in))!=1)throw std::runtime_error("Windows blocked keyboard input.");if(action.kind=="down")t.held.insert(key);else t.held.erase(key);Mark();t.pending=false;t.status="Running · "+action.key;if(!Held(t))Unfocus(t);
 }catch(const std::exception& e){Release(t);Unfocus(t);t.stopped=true;t.vm.reset();t.status=e.what();}}
}
inline json Status(){json result=json::array();for(auto& item:targets){auto& t=*item.second;result.push_back({{"pid",t.client.pid},{"token",t.client.token},{"running",!t.stopped},{"status",t.status},{"mode",t.options["mode"]}});}return result;}
}
