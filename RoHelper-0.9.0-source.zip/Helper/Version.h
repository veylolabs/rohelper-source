#pragma once
#define ROHELPER_VERSION "0.9.0"
