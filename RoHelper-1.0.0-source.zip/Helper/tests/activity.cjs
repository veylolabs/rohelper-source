const fs=require('node:fs'),path=require('node:path'),http=require('node:http'),assert=require('node:assert/strict');
const {chromium}=require('playwright');
const root=path.resolve(__dirname,'../web'),out=path.resolve(__dirname,'../../Output/RoHelper-tests');fs.mkdirSync(out,{recursive:true});
const H=3600000,D=24*H,now=Date.now(),today=Math.floor(now/D)*D;
const gameContent={bundle:JSON.parse(fs.readFileSync(path.join(root,'game-content.json'),'utf8')),message:'',refreshing:false};
const defaults={volume:75,muted:false,enabled:true,mode:'simple',keys:['SPACE'],minSeconds:300,maxSeconds:480,macroId:'',repeatSeconds:30,pauseOnActivity:true};
const accounts=Array.from({length:8},(_,i)=>({id:String(101+i),userId:101+i,username:['Main','Storage','Trading','Garden','Collector','Builder','Explorer','Workshop'][i],displayName:['Main','Storage','Trading','Garden','Collector','Builder','Explorer','Workshop'][i],nickname:'',avatar:'',color:'#818cf8',tags:[],notes:'',settings:{},hasSession:true}));
let workspace={schema:1,revision:0,accounts,servers:[],macros:[],tags:[],selectedServer:'',defaults,settings:{theme:'dark',accent:'#818cf8',minimizeToTray:true,compact:false,sidebarCollapsed:false,closedGroups:[],layout:{auto:false,mainUserId:0,mainDisplay:'',displays:[]}}};
const resources={cpuSum:3.7*H,cpuMs:H,cpuPeak:9.2,ramSum:640*1024*1024*H,ramMs:H,ramPeak:950*1024*1024,gpuSum:18*H,gpuMs:H,gpuPeak:43};
let activity={schema:1,startedAt:now-32*D,updatedAt:now,totals:{combinedMs:48*H,wallActiveMs:12*H,sessions:24,peakAccounts:8,longestSessionMs:7*H,activeDays:23,bestStreak:9,uniqueAccounts:8,antiAfkInputs:1840,macroCycles:82},accounts:{},active:{},history:[],historyCount:16,hours:{},days:{},unlocks:{},preferences:{dailyGoalMs:8*H,pinned:['runtime-1','parallel-8']},error:'',blocked:false};
for(let d=0;d<32;d++)activity.days[String(today-d*D)]={combinedMs:(d%5+1)*H,observedMs:4*H,activeMs:2*H,peakAccounts:d%8+1,...resources};
for(let h=0;h<7*24;h++)if(h%13!==4)activity.hours[String(Math.floor(now/H)*H-h*H)]={combinedMs:(h%8+1)*H,observedMs:H,activeMs:H,peakAccounts:h%8+1,...resources};
for(const [i,a] of accounts.entries()){
 const session={userId:String(a.userId),startedAt:now-(i+1)*H,lastSeenAt:now,elapsedMs:(i+1)*H,metrics:{...resources},counters:{antiAfkInputs:120+i*30,macroCycles:10,inputFailures:i?0:2,focusFailures:i?0:3,pausedMs:300000},baseline:{},lastAntiAfkAt:now-42000,health:'healthy',currentResources:{cpu:3.4,ram:640*1024*1024,gpu:i===1?null:14}};
 activity.active[String(i+1)+'|test']=session;activity.accounts[String(a.userId)]={combinedMs:(i+1)*2*H,sessions:3,longestSessionMs:(i+1)*H,metrics:{...resources}};
 for(let n=0;n<2;n++)activity.history.push({...session,elapsedMs:2*H,startedAt:now-(n+2)*D,endedAt:now-(n+2)*D+2*H,endReason:'Client no longer observed'});
}
for(const id of ['runtime-1','runtime-12','parallel-2','parallel-4','parallel-8','sessions-1','sessions-10'])activity.unlocks[id]={at:now-D,definition:gameContent.bundle.achievements.entries.find(a=>a.id===id)};
activity.milestoneMetrics={...activity.totals,savedMacros:2,trackedGames:4,catalogedItems:138};
let snapshot={clients:accounts.map((a,i)=>({pid:i+1,token:'test',accountId:a.id,userId:a.userId,username:a.username,audio:{available:true,volume:75,muted:false},effective:defaults,overrides:{},automation:{running:true,mode:'simple',status:'Waiting for next cycle'},session:activity.active[String(i+1)+'|test']})),monitors:[],multi:{running:true,error:''},activity:{totals:activity.totals,updatedAt:now,error:'',unlockCount:7}};
const server=http.createServer((req,res)=>{try{const name=decodeURIComponent(req.url.split('?')[0]),file=path.join(root,name==='/'?'index.html':name);res.setHeader('Content-Type',({'.html':'text/html','.css':'text/css','.js':'text/javascript','.svg':'image/svg+xml'})[path.extname(file)]||'application/json');res.end(fs.readFileSync(file));}catch{res.writeHead(404).end();}});
(async()=>{await new Promise(r=>server.listen(0,'127.0.0.1',r));const browser=await chromium.launch({channel:'msedge',headless:true});try{
 const p=await browser.newPage({viewport:{width:1500,height:1100}}),errors=[],calls=[];p.on('pageerror',e=>errors.push(e.message));p.setDefaultTimeout(10000);
 await p.exposeFunction('native',async m=>{calls.push(m);const r={ok:true,requestId:m.requestId};if(m.action==='load')Object.assign(r,{data:workspace,snapshot,gameContent,version:'1.0.0',dataPath:'Isolated synthetic data'});if(m.action==='activity_get')r.activity=activity;if(m.action==='activity_preferences'){activity.preferences=structuredClone(m.preferences);r.activity=activity;}if(m.action==='scan')r.snapshot=snapshot;if(m.action==='save'){workspace=m.data;workspace.revision++;r.data=workspace;}await p.evaluate(r=>window.receive(r),r);});
 await p.addInitScript(()=>{const listeners=[];window.chrome={webview:{addEventListener:(_,fn)=>listeners.push(fn),postMessage:m=>window.native(m)}};window.receive=r=>listeners.forEach(fn=>fn({data:r}));});
 await p.goto('http://127.0.0.1:'+server.address().port);await p.locator('.account-card').first().waitFor();
 const navigation=await p.locator('#navigation button').allTextContents();assert(navigation.findIndex(t=>t==='Activity')===navigation.findIndex(t=>t==='Events & timers')+1);
 await p.getByRole('button',{name:'Running clients',exact:true}).click();await p.locator('[data-session-timer]').first().waitFor();await p.waitForFunction(()=>document.querySelector('[data-session-timer]').textContent.includes('Session 01:'));
 assert.equal(await p.locator('.client-session-details').count(),0);assert.equal(await p.locator('.resource-row').count(),0);assert.match(await p.locator('[data-session-input]').first().innerText(),/Last anti-AFK [1-9][0-9]* sec ago/);
 await p.getByRole('button',{name:'Session details',exact:true}).first().click();assert.equal(await p.locator('.resource-row').count(),3);assert.match(await p.locator('.client-session-details').innerText(),/Focus retries/);
 await p.evaluate(s=>window.receive({type:'snapshot',snapshot:s}),snapshot);assert.equal(await p.locator('.client-session-details').count(),1);
 await p.screenshot({path:path.join(out,'activity-client-details-100.png'),fullPage:false});
 await p.getByRole('button',{name:'Activity',exact:true}).click();await p.locator('.activity-hero').waitFor();assert.match(await p.locator('.activity-multiplier').innerText(),/8×/);assert.equal(await p.locator('.heatmap-day').count(),91);assert.equal(await p.locator('.activity-account-row').count(),8);assert(await p.locator('.activity-chart svg rect').count()>20);
 await p.screenshot({path:path.join(out,'activity-overview-100.png'),fullPage:true});
 await p.getByRole('button',{name:'Set goal',exact:true}).click();await p.getByRole('spinbutton',{name:'Combined hours per day'}).fill('12');await p.getByRole('button',{name:'Save goal',exact:true}).click();assert.equal(activity.preferences.dailyGoalMs,12*H);
 await p.getByRole('button',{name:'Achievements',exact:true}).click();assert.equal(await p.locator('.achievement-card').count(),53);assert.equal(await p.locator('.achievement-card.unlocked').count(),7);
 await p.getByRole('textbox',{name:'Search achievements'}).fill('decade');assert.equal(await p.locator('.achievement-card').count(),1);assert.match(await p.locator('.achievement-card').innerText(),/10 years/);await p.getByRole('textbox',{name:'Search achievements'}).fill('');
 const crown=p.locator('.achievement-card').filter({has:p.getByRole('heading',{name:'A Decade in Parallel',exact:true})});await crown.getByRole('button',{name:'Pin',exact:true}).click();assert(activity.preferences.pinned.includes('runtime-87600'));
 await p.screenshot({path:path.join(out,'activity-achievements-100.png'),fullPage:false});
 await p.getByRole('button',{name:'Sessions',exact:true}).click();assert.equal(await p.locator('.activity-session').count(),24);await p.locator('.activity-session').first().getByRole('button',{name:'View summary'}).click();assert(await p.getByText('Observed duration',{exact:true}).isVisible());await p.getByRole('button',{name:'Done',exact:true}).click();
 // Native preferences survive a complete UI reload, with unlock state unchanged.
 await p.reload();await p.locator('.account-card').first().waitFor();await p.getByRole('button',{name:'Activity',exact:true}).click();await p.locator('.activity-hero').waitFor();assert.match(await p.locator('.trophy-shelf').innerText(),/A Decade in Parallel/);
 await p.setViewportSize({width:390,height:844});await p.waitForTimeout(300);assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));await p.screenshot({path:path.join(out,'activity-phone-100.png'),fullPage:true});
 await p.getByRole('button',{name:'Achievements',exact:true}).click();await p.waitForTimeout(100);assert(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1));
 // External text is rendered as text; unavailable resources are not zero.
 assert.deepEqual(errors,[]);assert(calls.every(c=>!['launch','client_close','override'].includes(c.action)));
 console.log('PASS Activity navigation, compact/expanded health, persisted goals and trophies, all 53 data-driven achievements, session summaries, charts, account statistics and phone layout. Synthetic data only.');
 }finally{await browser.close();server.close();}})().catch(e=>{console.error(e);process.exitCode=1;server.close();});
