"""Export only public game facts and declarative fields. Never read account storage."""
import hashlib,json,pathlib,re,os,base64
from release_privacy import strip_png_timestamps, clean_public_images
root=pathlib.Path(__file__).resolve().parents[1]
source=root.parent/'Roster'/'web'
target=root.parent/'GameCatalog'
target.mkdir(exist_ok=True)
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
assets=read(source/'asset-sources.json')
def public(value):
    if isinstance(value,dict):return {k:public(v) for k,v in value.items()}
    if isinstance(value,list):return [public(v) for v in value]
    if isinstance(value,str) and value.startswith('assets/'):
        url=assets.get(value,{}).get('url')
        if url:return url
        # Existing trait images have per-record imageSource attribution but no entry in
        # the brainrot-only artwork manifest. Embed their exact bytes in the public
        # pack so all 105 source icons remain available, including offline.
        if re.fullmatch(r'assets/traits/[a-z0-9_-]+\.(?:png|webp)',value):
            path=source/value
            if path.is_file():
                raw=strip_png_timestamps(path.read_bytes());assert len(raw)<250000
                mime='image/png' if raw.startswith(b'\x89PNG\r\n\x1a\n') else 'image/webp' if raw[:4]==b'RIFF' and raw[8:12]==b'WEBP' else None
                assert mime,'Unsupported source trait image'
                return 'data:'+mime+';base64,'+base64.b64encode(raw).decode('ascii')
        return None # unverified brainrot artwork stays unknown
    return value
catalogs={k:public(read(source/v)) for k,v in {
    'inventory':'inventory-catalog.json','index':'index-catalog.json','rebirths':'rebirths.json',
    'jumpForEggs':'ltm-catalog.json','hauntedFuse':'haunted-fuse-catalog.json','skullBlock':'skull-block-catalog.json'}.items()}
catalogs['gear']=read(root/'content'/'sab-gear.json')
catalogs['mutationEffects']=read(root/'content'/'sab-mutation-effects.json')
ordering=read(root/'content'/'sab-menu-order.json')
colors={'eclipse':'#ffff80','gold':'#fbbf24','diamond':'#67e8f9','bloodrot':'#f43f5e','candy':'#f9a8d4','lava':'#fb923c','galaxy':'#a78bfa','yinyang':'#e5e7eb','radioactive':'#a3e635','cursed':'#dc2626','divine':'#fef08a','rainbow':'#c084fc','cyber':'#22d3ee','phantom':'#94a3b8','crystal':'#e9d5ff'}
for m in catalogs['inventory']['mutations']:
 m['color']=colors.get(m['id'],'#b8c0d4');m['menuOrder']=ordering['mutationOrder'].get(m['id'],50);m['indexOrder']=['default','gold','diamond','rainbow'].index(m['id']) if m['id'] in ['default','gold','diamond','rainbow'] else 10+m['menuOrder'];m['rainbowText']=m['id']=='rainbow'
for t in catalogs['inventory']['traits']:t['menuOrder']=ordering['traitOrder'].get(t['id'],500)

games=[{
 'schema':1,'id':'sab','name':'Steal a Brainrot','aliases':['SAB','brainrot','brainrots'],
 'placeIds':['109983668079237'],'icon':'','fields':[
 {'id':'rebirth','name':'Rebirth','type':'number','default':0,'min':0,'max':len(catalogs['rebirths']['rebirths']),'step':1}],
 'catalogs':catalogs,'sources':catalogs['inventory']['sources'],
 'contentNote':'Imported public reference snapshot. Individual records retain their original checkedOn/updated dates; this export is not a fresh fact check.',
 'assetPackaging':'Trait icons retain exact bundled image bytes and individual imageSource attribution. Brainrot artwork uses approved source URLs.',
 'artworkPolicy':['SABRValues','SABExistCount','Steal a Brainrot Fandom (last resort)']},
 {'schema':1,'id':'adopt-me','name':'Adopt Me!','aliases':['Adopt Me','adoptme'],
 'placeIds':['920587237'],'icon':'','fields':[],
 'catalogs':{},'sources':['https://www.roblox.com/games/920587237/Adopt-Me'],
 'contentNote':'Notebook support. A verified pet/value catalog has not been added yet.'}]

# Navigation is public data too. Built-in view types are implemented by the app;
# names, order, groups, helper catalog keys and event schedules are maintained here.
def tab(id,name,icon,view,**extra):return dict(id=id,name=name,icon=icon,view=view,**extra)
sab,adopt=games
game_icons=read(root/'content'/'game-icons.json')
for game in map(clean_public_images, games):
    evidence=game_icons.get(game['id'])
    if evidence:
        assert evidence['placeId'] in game['placeIds'] and evidence['icon'].startswith('https://')
        game['icon']=evidence['icon']
        game['iconSource']={k:v for k,v in evidence.items() if k!='icon'}
sab['inventoryEngine']='sab'
sab['currencies']=[{'id':'cash','name':'Cash','default':0,'max':1e30}]
sab['navigation']=[tab('overview','Overview','game','sab-overview'),tab('servers','Servers','flag','servers'),tab('inventory','Inventory search','search','sab-inventory'),tab('catalog','Catalog','book','sab-catalog'),tab('gear','Gear inventory','box','sab-gear'),tab('compare','Comparison','trade','sab-compare'),tab('helpers','Event helpers','gift','event-helpers'),tab('events','Events & timers','calendar','events'),tab('checklist','Session checklist','check','sab-checklist')]
sab['accountTabs']=[tab('rebirth','Rebirth','crown','sab-rebirth'),tab('inventory','Inventory','box','sab-inventory'),tab('gear','Gear','box','sab-gear'),tab('index','Index','book','sab-index')]
sab['helpers']=[dict(id='skull-block',name='Skull Lucky Block',type='rewards',catalog='skullBlock'),dict(id='haunted-fuse',name='Haunted Fuse',type='fuse',catalog='hauntedFuse'),dict(id='jump-eggs',name='Jump for Eggs',type='islands',catalog='jumpForEggs')]
def schedule(id,title,**values):
    return dict(id=id,title=title,group='',icon='calendar',color='#818cf8',start=None,zone='UTC',duration=None,repeat='once',enabled=False,estimatedEnd=False,scheduleConfirmed=False,notes='',remindStart=False,remindEnd=False,reminderMinutes=10,skipped=[],**values)
# Avoid ambiguous kwargs on default fields by updating a common explicit record.
def event(id,title,**values):
    e=schedule(id,title);e.update(values);return e
sab['events']=[
 event('sab-saturday','SAB · Saturday Admin Abuse',group='Steal a Brainrot',icon='crown',color='#a78bfa',start='2026-10-17T15:00',zone='America/New_York',duration=45,repeat='weekly',estimatedEnd=True,enabled=True,scheduleConfirmed=True,notes='Community reference: Saturday 3 pm Eastern; reported duration 30–45 minutes. The displayed end uses the estimated outer window. Announcements may move or cancel it.',source='https://sabexistcount.com/wiki/admin-abuse',checkedOn='2026-10-17',sourceCheckedOn='2026-09-02',confidence='community'),
 event('sab-tuesday','SAB · Taco Tuesday',group='Steal a Brainrot',icon='taco',color='#fbbf24',start='2026-10-20T18:00',zone='America/New_York',duration=60,repeat='weekly',estimatedEnd=True,enabled=True,scheduleConfirmed=True,notes='Community reference: Tuesday 6 pm Eastern; reported duration 30–60 minutes. The displayed end is estimated. Check current announcements.',source='https://sabexistcount.com/wiki/admin-abuse',checkedOn='2026-10-17',sourceCheckedOn='2026-09-02',confidence='community')]
for helper in sab['helpers']:
    ref=catalogs[helper['catalog']]
    sab['events'].append(event(helper['id'],ref['name'],group='Steal a Brainrot',icon='gift',dateStart=ref.get('starts'),dateEnd=ref.get('ends'),helperId=helper['id'],notes='Reference start date only. Exact schedule and current end are unconfirmed. '+ref.get('notes',''),source=ref['source'],checkedOn=ref['checkedOn'],confidence='community'))
items=read(root/'content'/'adopt-me.json')
items['hatchPools']=read(root/'content'/'adopt-hatch-pools.json')
adopt['inventoryEngine']='adopt-me'
adopt['catalogs']={'items':items,'sourceEvidence':read(root/'content'/'adopt-me-sources.json')}
adopt['sources']=items['sources']
adopt['fields']=[]
adopt['contentNote']='Public item catalog and AMTV trading snapshots. Personal inventories, balances and pet progress stay local.'
adopt['currencies']=[{'id':'bucks','name':'Bucks','default':0},{'id':'candy-corn-2026','name':'Candy Corn · Halloween 2026','default':0},{'id':'releaser-tickets','name':'Releaser tickets','default':0}]
adopt['navigation']=[tab('overview','Overview & money','paw','adopt-overview'),tab('servers','Servers','flag','servers'),tab('catalog','Catalog','book','adopt-catalog'),{'id':'inventories','name':'Inventories','icon':'box','children':[tab('inventory-'+c['id'],c['name'],'paw' if c['id']=='pets' else 'box','adopt-inventory',category=c['id']) for c in items['categories']]},tab('helpers','Event helpers','gift','event-helpers'),tab('events','Events & timers','calendar','events')]
adopt['helpers']=[]
for helper in items['eventHelpers']:
    key='event-'+helper['id'];adopt['catalogs'][key]=helper
    adopt['helpers'].append(dict(id=helper['id'],name=helper['name'],type=helper['type'],catalog=key))
adopt['events']=[event('adopt-weather','Adopt Me · Weather change',group='Adopt Me!',icon='cloud',color='#38bdf8',repeat='weekly',weekday=3,notes='Official documentation says weather changes on Wednesdays. The exact hour and current weather interval are unconfirmed; set a personal timer from the in-game bell countdown.',source='https://www.playadopt.me/news/new-weather-needs',checkedOn='2026-10-17',confidence='official'),event('adopt-2d-tuesday','Adopt Me · 2D Tuesday',group='Adopt Me!',icon='paw',color='#34d399',repeat='weekly',weekday=2,notes='The official news lists 2D Tuesday. Exact current start and duration are unconfirmed; use the in-game countdown before enabling.',source='https://www.playadopt.me/news/new-weather-needs',checkedOn='2026-10-17',confidence='official')]
for helper in items['eventHelpers']:
    adopt['events'].append(event(helper['id'],helper['name'],group='Adopt Me!',icon='gift',dateStart=helper['starts'],dateEnd=helper['ends'],helperId=helper['id'],notes='Official event reference. Exact schedule, payouts and end date have not been confirmed.',source=helper['source'],checkedOn=helper['checkedOn'],confidence='official'))
games.extend(read(p) for p in sorted((root/'content/collections').glob('*.json')))
manifest={'schema':1,'engineVersion':1,'layoutVersion':5,'revision':'','games':[]}
bundle={'manifest':manifest,'packs':{}}
for game in map(clean_public_images, games):
    raw=(json.dumps(game,ensure_ascii=False,separators=(',',':'))+'\n').encode('utf-8')
    digest=hashlib.sha256(raw).hexdigest();name='game-'+game['id']+'-'+digest[:16]+'.json'
    (target/name).write_bytes(raw)
    manifest['games'].append({'id':game['id'],'file':name,'sha256':digest})
    bundle['packs'][game['id']]=game
previous=read(target/'manifest.json') if (target/'manifest.json').exists() else {}
manifest['revision']=previous.get('revision') if previous.get('games')==manifest['games'] else 'content-'+hashlib.sha256(json.dumps(manifest['games'],sort_keys=True).encode()).hexdigest()[:12]
(target/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
(root/'web'/'game-content.json').write_text(json.dumps(bundle,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')
# Public payload audit: reject device paths, credentials and old author identity.
for p in target.glob('*.json'):
    text=p.read_text(encoding='utf-8')
    assert not re.search(r'(?i)((?<![a-z])[a-z]:[\\/]|\\\\Users\\|\.ROBLOSECURITY|accounts\.json|sessions\.bin)',text),p.name
    for term in filter(None,os.environ.get('ROHELPER_PRIVATE_IDENTITY_TERMS','').split(',')):
        assert term.lower() not in text.lower(),p.name
print('Exported',len(games),'game packs;',len(catalogs['inventory']['brainrots']),'public SAB entries. No account files read.')

# Keep optional application catalogs when rebuilding game packs.
from export_achievements import export as export_achievements
export_achievements()
