"""Passive client-discovery regression tests; no game input or mutation."""
from pathlib import Path
import subprocess, sys
from toolchain import vcvars32
root=Path(__file__).resolve().parents[1]
out=root.parent/'Output/RoHelper-tests'
out.mkdir(exist_ok=True)
q=lambda p:'"'+str(p)+'"'
batch=out/'test-clients.cmd'
batch.write_text('@echo off\ncall '+q(vcvars32())+' >nul\ncl /nologo /EHsc /MD /utf-8 /std:c++17 /DUNICODE /D_UNICODE /I'+q(root/'vendor')+' /Fo'+q(out/'log-owners.obj')+' '+q(root/'tests/log-owners.cpp')+' /link user32.lib shell32.lib ole32.lib uuid.lib advapi32.lib crypt32.lib bcrypt.lib /OUT:'+q(out/'log-owners.exe')+'\nexit /b %errorlevel%\n')
subprocess.run(['cmd','/c',str(batch)],cwd=root,check=True)
subprocess.run([str(out/'log-owners.exe'),*sys.argv[1:]],check=True)
