#pragma once
#include <windows.h>
#include <map>
#include <set>
#include <string>
#include <sstream>
#include <cstdio>
#include <algorithm>
#include <cmath>

// Match public log records to live Windows threads. Creation timestamps reject
// recycled thread/process IDs; timestamps alone never identify an account.
namespace LogAssociation {
struct Thread { DWORD pid=0; unsigned long long processCreated=0,threadCreated=0; };
struct Record { DWORD thread=0; unsigned long long at=0; };
inline Record Parse(const std::string& line) {
    SYSTEMTIME time{}; unsigned y=0,mo=0,d=0,h=0,mi=0,s=0,ms=0,tid=0; double elapsed=0; char level=0;
    if(sscanf_s(line.c_str(),"%4u-%2u-%2uT%2u:%2u:%2u.%3uZ,%lf,%8x,%c",&y,&mo,&d,&h,&mi,&s,&ms,&elapsed,&tid,&level,1u)!=10 || level<'0'||level>'9'||!tid||!std::isfinite(elapsed)||elapsed<0)return {};
    time.wYear=WORD(y);time.wMonth=WORD(mo);time.wDay=WORD(d);time.wHour=WORD(h);time.wMinute=WORD(mi);time.wSecond=WORD(s);time.wMilliseconds=WORD(ms);
    FILETIME ft{};if(!SystemTimeToFileTime(&time,&ft))return {};
    return {tid,(static_cast<unsigned long long>(ft.dwHighDateTime)<<32)|ft.dwLowDateTime};
}
inline std::map<DWORD,unsigned long long> Records(const std::string& text) {
    std::map<DWORD,unsigned long long> result;std::istringstream lines(text);std::string line;
    while(std::getline(lines,line)){auto r=Parse(line);if(r.thread)result[r.thread]=std::max(result[r.thread],r.at);}
    return result;
}
inline DWORD Owner(const std::map<DWORD,unsigned long long>& records,const std::map<DWORD,Thread>& threads,unsigned long long now) {
    std::set<DWORD> owners;
    for(auto& [tid,at]:records){auto it=threads.find(tid);if(it==threads.end())continue;auto& t=it->second;
        // Roblox truncates its UTC log timestamp to milliseconds.
        if(t.pid&&at<=now&&at/10000>=t.processCreated/10000&&at/10000>=t.threadCreated/10000)owners.insert(t.pid);
    }
    return owners.size()==1?*owners.begin():0;
}
}
