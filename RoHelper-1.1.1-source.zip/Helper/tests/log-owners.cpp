#define NOMINMAX
#include <windows.h>
#include <cassert>
#include "../native/Store.h"
#include "../native/Clients.h"
#include <iostream>
int main(int argc,char** argv){
 if(argc>1&&std::string(argv[1])=="--live-read-only"){
  auto clients=RosterClients::Windows();RosterClients::Identify(clients);size_t identified=0;
  for(auto& c:clients)if(c.userId>0)++identified;
  std::cout<<"Passive discovery: "<<clients.size()<<" visible clients, "<<identified<<" exact identities. No account identifiers printed; no input or process changes.\n";return 0;
 }
 auto record=LogAssociation::Parse("2026-11-22T16:11:51.267Z,0.267332,63e8,6,Info [FLog::Test] Synthetic");assert(record.thread==0x63e8&&record.at);
 auto records=LogAssociation::Records("2026-11-22T16:11:51.267Z,0.267332,63e8,6,Info [FLog::Test] Synthetic\nnot a native log line\n");
 assert(records.size()==1);std::map<DWORD,LogAssociation::Thread> threads={{record.thread,{101,record.at-1000000,record.at-500000}}};
 assert(LogAssociation::Owner(records,threads,record.at+10000)==101);
 threads[record.thread].threadCreated=record.at+10000;assert(!LogAssociation::Owner(records,threads,record.at+100000));
 threads[record.thread]={101,record.at+10000,record.at-10000};assert(!LogAssociation::Owner(records,threads,record.at+100000));
 threads[record.thread]={101,record.at-10000,record.at-10000};assert(!LogAssociation::Owner(records,threads,record.at-10000));
 threads[123]={202,record.at-10000,record.at-10000};records[123]=record.at;assert(!LogAssociation::Owner(records,threads,record.at));
 for(auto& bad:{"hello", "2026-13-22T16:11:51.267Z,0.2,63e8,6", "2026-11-22T16:11:51.267Z,nan,63e8,6", "2026-11-22T16:11:51.267Z,0.2,0,6"})assert(!LogAssociation::Parse(bad).thread);
 assert(RosterClients::LogIdentity("[FLog::GameJoinLoadTime] userid: 1234")==1234);
 assert(RosterClients::LogIdentity("[FLog::GameJoinLoadTime] userid: 1234\n[FLog::GameJoinLoadTime] userid: 5678")==0);
 FILETIME c{},e{},k{},u{};assert(GetThreadTimes(GetCurrentThread(),&c,&e,&k,&u));
 std::vector<RosterClients::Client> local={{GetCurrentProcessId(),RosterClients::Token(GetCurrentProcess()),nullptr}};
 auto actual=RosterClients::LogThreads(local,{GetCurrentThreadId()});assert(actual.size()==1&&actual.begin()->second.pid==GetCurrentProcessId()&&actual.begin()->second.threadCreated==RosterClients::Stamp(c));
 local[0].userId=1234;assert(RosterClients::LogThreads(local,{GetCurrentThreadId()}).empty());
 std::cout<<"PASS passive log/thread matching, recycled IDs, ambiguous identity, malformed timestamps and known-launch scan exclusion.\n";
}
